#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use lib qw(/opt/taranis/pm );
use Taranis qw(:all);
no warnings;
use Getopt::Long;
use Taranis::Config;
use Taranis::Config::Stats;
use Taranis::Config::XMLGeneric;
use Taranis::Collector;
use Taranis::Sources;
use HTML::Entities;
use Digest::MD5 qw(md5 md5_hex md5_base64);
use DBI;
use strict;
use Shell qw(kill);
use Encode;
use Data::Dumper;
#use POSIX;
use URI::Escape;
use Time::localtime;

###### global variables ########
my ( $pidfile, $collector, $sources, $pid );

my ( $debugSource, $nomtbc, $nostats, $nobackend, $noclustering, $help ) = 0;
  
my $usage = <<"EOL";
Usage: 
$0 --debug <name> --nomtbc --nostats --nobackend

--debug <sourcename> (turn on extra debugging output)  
--nomtbc (do not check for MTBC, for testing purposes only!)
--nostats (do not run stats)
--nobackend (do not run backend)
--noclustering (do not start clustering script)
EOL

GetOptions(
	"debug=s" => \$debugSource,
	"nomtbc" => \$nomtbc,
	"nostats" => \$nostats,
	"nobackend" => \$nobackend,
	"noclustering" => \$noclustering,
	"help" => \$help
);
 
if ( $help ) {
  print  "$usage\n" ;
  exit;
}

print "Begin @ " . nowstring(7) . "\n";

$collector = Taranis::Collector->new( $debugSource );
$collector->{nomtbc} = $nomtbc;

my $cfg = new Taranis::Config();

### Check if a taranis collector process is already running and, if so, kill it!
### This prevents that a lot of processes have connections to the db
### after which the db will become unresponsive

$pidfile 	= $cfg->{pidfile};

if ( -e $pidfile ) {
	## PID-file exists!
	my $fh1;
	open( $fh1, "<", $pidfile );
	$pid = <$fh1>;
	kill(" -9 $pid");
	close( $fh1 );
}

### Create a PID file for this process
my $fh2;
open( $fh2, ">", $pidfile );
print $fh2 $$;
close( $fh2 );


### Don't run collector after and before configured hours
if ( 
	( localtime->hour() >= $cfg->{notafter} ) 
	|| ( localtime->hour() <= $cfg->{notbefore} ) 
) {
	print "Running outside configured time window, exit!\n";
	exit ; 
}

my $collectorRunId = $collector->setCollectorStarted();

######################################################################
### 1. COLLECTING NEWS ITEMS FROM IMAP, POP3, HTML AND XML SOURCES ###
######################################################################
say "### COLLECTING NEWS ITEMS FROM IMAP, POP3, HTML AND XML SOURCES ###";

### get all sources ###

my $sourceObject = Taranis::Sources->new();
$sources = $sourceObject->getSources();

### check sources and collect new items ###

SOURCE:
foreach my $source ( @$sources ) {
	
	my $sourceIsOk = 0;
	my $debug = ( $collector->{debugSource} ) ? 1 : 0;
   
	next SOURCE if ( !$source->{enabled} ); 

######## DEBUG OUTPUT ########
	if ( $collector->{debugSource} ) {
		next SOURCE if ( $source->{sourcename} ne $collector->{debugSource} ); 
		
		say "DEBUGGING: $source->{sourcename}\n" if ( $debug );
	}
	say "-------------------------------------------------------------------------" if ( $debug );
	say "processing " . $source->{sourcename} . ' ' . $source->{fullurl} if ( $debug );
	say Dumper $source if ( $debug );
############################## 
	
	$collector->{this_source} = $source;

	if ( !$collector->getSourceMtbc( $debug ) ) {
		say "It's not time to check " . $collector->{this_source}->{host} if ( $debug );
		next SOURCE;
	}

	print nowstring(1) . " processing source " . $source->{sourcename} . "... ";
	
	if ( $source->{protocol} =~ /^(imap|pop3)/i ) {

### IMAP & POP3 SOURCE ###
		my $protcolDependedSub = ( $source->{protocol} =~ /(pop3|pop3s)/i ) ? 'processPop3Mail' : 'processImapMail'; 

		say "Coll: process incoming mail source" if ( $debug );
		
		if ( $collector->$protcolDependedSub( $debug ) ) {
			say "Coll: done processing mail source" if ( $debug );
			$sourceIsOk = 1;
		} else {

			$collector->{err}->writeError(
				digest     => $source->{digest},
				sourceName => $source->{sourcename},
				error      => $collector->{errmsg},
				error_code => '010',
				content    => undef
			) if ( !$collector->{link_check_only} );
			
			say "Mail proces error: " . $collector->{errmsg} if ( $debug );
			$sourceIsOk = 0;
		}

		my $sourceStatus = ( $sourceIsOk ) ? "OK" : "ERROR";
		
		$collector->writeSourceCheck(
			source  => $source->{digest},
			comment => '(' . nowstring(2) . ') ' . $sourceStatus 
		);
	
	} elsif ( $source->{parser} =~ /^twitter$/i ) {
		if ( $collector->{twitter} ) {
			if ( $collector->processTweets( $debug ) ) {
				say "Coll: done processing tweets" if ( $debug );
				$sourceIsOk = 1;
			} else {
				$sourceIsOk = 0;
			}
			
			my $sourceStatus = ( $sourceIsOk ) ? "OK" : "ERROR";
			
			$collector->writeSourceCheck(
				source  => $source->{digest},
				comment => '(' . nowstring(2) . ') ' . $sourceStatus 
			);
		} else {
			say "Could not create an OAUTH connection for Twitter, please check configuration settings.";
		}		
	} else {

### XML & HTML SOURCE	###
		my $sourceData;
		
		if ( $sourceData = $collector->getSourceData() ) {

			$collector->writeSourceCheck( 
				source  => $source->{digest},
				comment => '(' . nowstring(2) . ') OK' 
			);	

			my $feed_links;
			
			if ( $source->{parser} =~ /^xml/ ) {
				$feed_links = $collector->processXmlFeed( $sourceData );
			} else {
				$feed_links = $collector->processHtmlFeed( $sourceData );
			}
		
			if ( ref( $feed_links ) ne 'ARRAY' ) {
				print " no items found, writing error 099\n";

				$collector->{err}->writeError(
					digest     => $source->{digest},
					sourceName => $source->{sourcename},
					error      => $collector->{errmsg},
					error_code => 204,
					content    => $sourceData
				) if ( !$collector->{link_check_only} );
				next SOURCE;
			} elsif ( scalar( @$feed_links ) == 0 || "@$feed_links" eq "0" ) {
				print "0 new links \n";
				next SOURCE;

			} else {
				print scalar( @$feed_links ) . " new links \n";

### CHECK XML AND HTML CONTENT FOR IDENTIFIERS (LIKE CVE) ###				
				foreach my $feed ( @$feed_links ) {
					say "Check CVE ID in feed_links: " . $source->{checkid} if ( $debug );
					
					# we need it to store the related items with the right digest
					# put the item.digest into the collector->object
					$collector->{item_digest} = $feed->{itemDigest};
	
					if ( $source->{checkid} ) {
						say "CheckId, getting SourceData " . $feed->{'link'} if ( $debug );
						say "unescaped feed link: " . uri_unescape( $feed->{'link'} )  if ( $debug );
						
						my $feedSourceData = $collector->getSourceData( uri_unescape( $feed->{'link'} ) );
						my @foundIdentifiers = $collector->parseIdentifierPatterns( $feedSourceData );
						
						if ( scalar @foundIdentifiers > 0 ) {
							
							foreach my $identifier ( @foundIdentifiers ) {
								if ( !$collector->writeCVE( identifier => $identifier->{identifier}, digest => $identifier->{digest} ) ) {
									$collector->{err}->writeError(
										digest => $source->{digest},
										error => 'Identifier Parse Error: ' .  $collector->{cve_error},
										error_code => '014',
										content => $feedSourceData,
										sourcename => $source->{sourcename}
									);
								}
							}
						}
					}

					undef $collector->{cve_error};
					undef $collector->{item_digest};
				}
			}
		} else {

			print  "Error: no data\n";

			$collector->writeSourceCheck( 
				source  => $source->{digest},
				comment => '(' . nowstring(2) . ') ERROR' 
			);	
			next SOURCE;
		}
	}
}
say "--------------------------------------------------------------------------";

#######################################################################
### 							2. CLUSTERING 						###
#######################################################################

#TODO: pas logging aan
#TODO: $clusterScript naar config oid
if ( !$noclustering ) {
	say "### RUNNING CLUSTERING SCRIPT ###";
	
	my $clusterScript = '/opt/taranis/collector/clustering.pl';
	
	if ( ! -e $clusterScript ) {
		print nowstring(1) . "WARNING: Can't find $clusterScript\n";	
	} else {
		if ( -x $clusterScript && -r $clusterScript ) {
			no warnings;
			my $result = eval { system("/usr/bin/perl $clusterScript") };
			if ( $result < 0 ) {
				print nowstring(1) . " WARNING: clustering failed: \n$@\n";
			} else {
				print nowstring(1) . " INFO: clustering OK\n";
			}
		} else {
			print nowstring(1) . " WARNING: unable to read or execute clustering script\n"; 
		}
	}
	say "--------------------------------------------------------------------------";
}
######################################################################
### 							3. BACKEND SCRIPTS				   ###
######################################################################
if ( !$nobackend ) {
	say "### RUNNING BACKEND SCRIPTS ###";
	
	my $tl = Taranis::Config::XMLGeneric->new( "toolsconfig", "toolname", "tools" );
	my $tools = $tl->loadCollection();
	my $backend_tools_location = $tl->{config}->{backend_tools};
	my $scripts_ok = 0;
	
	my @backend_scripts;
	foreach my $tool ( @$tools ) {
		push @backend_scripts, $backend_tools_location . $tool->{backend} if $tool->{backend};
	}
	
	BACKENDSCRIPT:
	foreach ( @backend_scripts ) {
		if ( ! -e $_ ) {
			print nowstring(1) . " WARNING: file $_ does not exists\n";
			next BACKENDSCRIPT;
		}
		
		print nowstring(1) . " processing $_\n";
		if ( -x $_ && -r $_ ) {
			no warnings;
			my $result = eval { system("$_") };
			if ( $result < 0 ) {
				print nowstring(1) . " WARNING: script failed;\n$@\n";
			} else {
				$scripts_ok++;
			}
		} else {
			print nowstring(1) . " WARNING: unable to read or execute $_\n"; 
		}
	}
	print nowstring(1) . " backend script run $scripts_ok scripts ok\n";
	say "--------------------------------------------------------------------------";
}

######################################################################
### 							4. GENERATE STATISTICS			   ###
######################################################################
if ( !$nostats ) {
	say "### GENERATING AND COLLECTING STATISTICS ###";
	$collector->getStats();
	
	my ( $self ) = @_;
	my ( $stmnt, $cntr, $sth, $record );
	my @bind;
	
	#################################
	### Graph #1: number of items ###
	#################################
	$stmnt = "
		SELECT   substring(date from 7 for 2) AS label, COUNT(*) AS cnt 
		FROM     item
		GROUP BY date
		ORDER BY date DESC
		LIMIT    30";

	$collector->creategraph( 
		query 		=> $stmnt, 
		graphType 	=> "bar", 
		graphTitle 	=> "Collected Items by Taranis",
		graphXLabel => "Day of month", 
		graphYLabel => "Number of collected items",
		filename 	=> "taranis1.gif", 
		'reverse' 	=> 1 
	);

	######################################
	### Graph #2: Imported items to WR ###
	######################################
	$stmnt = "
			( SELECT substring( date from 7 for 2 ) AS label, COUNT(*) AS cnt, date
				FROM 			item 
				WHERE 		status = 3 
				GROUP BY 	date 
				UNION
				SELECT distinct( substring( date from 7 for 2 ) ), 0, date
				FROM 	item 
				WHERE date NOT IN
					( SELECT date 
						FROM 			item 
						WHERE 		status = 3 
						GROUP BY 	date 
					) 
			)
			ORDER BY date DESC LIMIT 30; ";

	$collector->creategraph( 
		query 		=> $stmnt, 
		graphType 	=> "bar", 
		graphTitle 	=> "Number of items imported to waitingroom",
		graphXLabel => "Day of month", 
		graphYLabel => "Number of items imported to WR", 
		filename 	=> "taranis2.gif", 
		'reverse' 	=> 1
	);

	#############################
	### Graph #3: Top sources ###
	#############################
	$cntr  = 2;
	my @categories;
#  $stmnt = "SELECT DISTINCT(category) FROM sources";
	
	$stmnt = "SELECT * FROM category WHERE is_enabled = 't'";
	
	$collector->{dbh}->prepare( $stmnt );
	$collector->{dbh}->executeWithBinds();

	while ( $collector->nextObject() ) { 
		$record = $collector->getObject();
		push @categories, $record;
	}
	
	foreach my $category ( @categories ) {
		$cntr++;
		
		( $stmnt, @bind ) = $collector->{sql}->select( 'item', 'DISTINCT(source) AS label, COUNT(*) AS cnt', { category => $category->{id} } );
		$stmnt .= " GROUP BY source ORDER BY cnt DESC LIMIT 10";

		$collector->creategraph( 
			query 		=> $stmnt, 
			graphType 	=> "hbar", 
			graphTitle 	=> "Top 10 sources (category " . $category->{name} . ")",
			graphXLabel => "Source",
			graphYLabel => "Number of collected items",
			filename	=> "taranis" . $cntr . ".gif", 
			'reverse' 	=> 0,
			binds		=> \@bind 												
		);
	}

	################################
	### Graph #4: Bottom sources ###
	################################

	foreach my $category ( @categories ) {
		$cntr++;

		( $stmnt, @bind ) = $collector->{sql}->select( 'item', 'DISTINCT(source) AS label, COUNT(*) AS cnt', { category => $category->{id} } );
		$stmnt .= " GROUP BY source ORDER BY cnt ASC LIMIT 10";

	    !$collector->creategraph( 
			query 		=> $stmnt, 
			graphType 	=> "hbar", 
			graphTitle 	=> "Bottom 10 sources (category " . $category->{name} . ")",
			graphXLabel => "Source",
			graphYLabel => "Number of collected items",
			filename	=> "taranis" . $cntr . ".gif", 
			'reverse' 	=> 0,
			binds		=> \@bind															
		); 
	}
	say "--------------------------------------------------------------------------";	
}


######################################################################
### 							5. FINALIZE AND CLEAN UP		   ###
######################################################################
say "### FINALIZING AND CLEAN UP ###";
### remove the PID file ###
unlink( $pidfile );

$collector->setCollectorFinished( $collectorRunId );

say "--END-- @ " . nowstring(7) . "\n";;
