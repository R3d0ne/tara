#/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;
use lib qw(/opt/taranis/pm );
use Taranis::Config;
use Taranis::Database;
use Taranis::Cluster;
use Taranis::Clustering::DocumentSet;
use Taranis::Clustering::Document;
use Taranis::Clustering::ClusterSet;
use DateTime;
use DateTime::Duration;

use Data::Dumper;

my $doCleanup = 1;

my $cfg = new Taranis::Config();
my $dbh = Taranis::Database->new();
my $cl = Taranis::Cluster->new();

my ( @categories, %categoryClusterMap );

my @clustersConfig = $cl->getCluster( 
	'cl.is_enabled' => 1,
	threshold => \"IS NOT NULL",
	timeframe_hours => \"IS NOT NULL",
	'ca.is_enabled' => 1
);

if ( !$clustersConfig[0] ) {
	print "No clusters configured. Please add cluster(s) in web application.\n";
	exit;
}

foreach my $clusterConfig ( @clustersConfig ) {
	if ( exists $categoryClusterMap{ $clusterConfig->{category_id} } ) {
		push @{ $categoryClusterMap{ $clusterConfig->{category_id} } }, $clusterConfig; 
	} else {
		$categoryClusterMap{ $clusterConfig->{category_id} } = [ $clusterConfig ];
	}
}

my $documentSet = new Taranis::Clustering::DocumentSet();

foreach my $category ( keys %categoryClusterMap ) {
	
	my $longestTimeframe = 0;

	# Go through all clusterconfigs and one where the language has not been set, which will select sources that have not set a language
	foreach my $clusterConfig ( @{ $categoryClusterMap{ $category } }, { category_id => $category, language => undef, timeframe_hours => undef } ) {
		
		# get/set the longest timeframe (per category) for soures which have not set a language
		$longestTimeframe = $clusterConfig->{timeframe_hours} if ( $clusterConfig->{timeframe_hours} > $longestTimeframe );
		$clusterConfig->{timeframe_hours} = $longestTimeframe if ( !$clusterConfig->{timeframe_hours} ); 

		if ( $doCleanup ) {
			# cleanup old clustering info.
			my $cleanupStmnt = "UPDATE item AS i" 
							. " SET cluster_score = NULL, cluster_id = NULL"
							. " FROM sources AS s" 
							. " WHERE s.id = i.source_id"
							. " AND i.created BETWEEN NOW() - '1 week'::INTERVAL AND NOW() - ?::INTERVAL"
							. " AND i.category = ?"
							. " AND s.language = ?;";
	
			$dbh->prepare( $cleanupStmnt );
			my $cleanupResult = $dbh->executeWithBinds( "'$clusterConfig->{timeframe_hours} hour'", $clusterConfig->{category_id}, lc $clusterConfig->{language} );	
		}
		
		my $itemsSelectStmnt = "SELECT i.digest, i.category, i.source, i.title, i.description, i.link, i.created, i.status, i.cluster_id, i.cluster_score"
							. " FROM item AS i"
							. " JOIN sources AS src ON src.id = i.source_id"
							. " WHERE i.category = ?"
							. " AND i.created > NOW() - ?::INTERVAL"
							. " AND i.source_id IS NOT NULL"
							. " AND src.language = ?"
							. " AND src.clustering_enabled = TRUE;";

		$dbh->prepare( $itemsSelectStmnt );
		$dbh->executeWithBinds( $clusterConfig->{category_id}, "'$clusterConfig->{timeframe_hours} hour'", lc( $clusterConfig->{language} ) );

		while ( $dbh->nextRecord() ) {
			my $item = $dbh->getRecord();
			$item->{cluster_score} = 'SEED' if ( $item->{cluster_score} == 0 );
			
			my $doc = [
				$item->{digest}, 
				$item->{category}, 
				$item->{source}, 
				$item->{title}, 
				$item->{'link'}, 
				$item->{description}, 
				$item->{created},
				$item->{status}, 
				$item->{cluster_id}, 
				$item->{cluster_score} 
			];
		
		    if ( my $docObj = Taranis::Clustering::Document->new( $doc,'taranis', lc $clusterConfig->{language} ) ) {
		        $documentSet->add( $docObj );
		    }
		}
	}
}

my $dtNow = DateTime->now();

foreach my $clusterConfig ( @clustersConfig ) {
	my $clusterSet = Taranis::Clustering::ClusterSet->new( { language  => lc( $clusterConfig->{language} ), threshold => $clusterConfig->{threshold}, settingspath => $cfg->{clustering_settings_path} } );
	my $documentSubset = Taranis::Clustering::DocumentSet->new();

	my $subsetDocs = $documentSet->subset({ Lang => $clusterConfig->{language}, Category => $clusterConfig->{category_id} } );

	my $dtTimeframe = $dtNow->clone();
	$dtTimeframe->subtract_duration( DateTime::Duration->new( hours => $clusterConfig->{timeframe_hours} ) );

	# Do not cluster items which are older than the given timeframe.
	# This is needed, because there can be items included in de subset which were selected with the longest timeframe of a category.
	foreach my $doc ( @$subsetDocs ) {	
		if ( $doc->get('Epoch') > $dtTimeframe->epoch() ) {
			$documentSubset->add( $doc );
		} 
	}

	$documentSubset->sortBy('Epoch');

	my $docToClusterMap = $clusterSet->cluster( { docset => $documentSubset, recluster => $clusterConfig->{recluster} } );

	foreach my $cluster ( $clusterSet->getClusters() ) {
		my $clusterId = $cluster->getID();
		my $clusterStatus = $cluster->getStatus();
		
		foreach my $document ( $cluster->getDocuments() ) {
			my $documentScore = ( $document->get('Score') =~ /SEED/i ) ? 0 : $document->get('Score');  
			
			my %clusterUpdate = (
				cluster_id => $clusterId,
				cluster_score => $documentScore,
			);
			
			# only set status for 'unread' and 'important'
			$clusterUpdate{status} = $clusterStatus if ( $clusterStatus =~ /(1|2)/ );
			$clusterUpdate{status} = 1 if ( $documentScore != 0 && $clusterStatus == 3 && $document->get('Status') != 3); # && documentStatus != 3

			my ( $stmnt, @bind ) = $dbh->{sql}->update( 'item', \%clusterUpdate, { digest => $document->get('ID') } );
			
			$dbh->prepare( $stmnt );
			
			my $result = $dbh->executeWithBinds( @bind );
		
			if ( defined( $result ) && ( $result !~ m/(0E0)/i ) ) {
				if ( $result > 0 ) {
					# it' OK
				} elsif ( defined( $dbh->{db_error_msg} ) ) {
					print 'Clustering DB error (1): ' . $dbh->{db_error_msg};
				}
			} elsif ( $result =~ /^0E0$/ ) {
				print 'Clustering  DB notification: item has not been changed.';
			} else {
				print 'DB error (2): ' . $dbh->{db_error_msg};
			}
		}
	}
}
