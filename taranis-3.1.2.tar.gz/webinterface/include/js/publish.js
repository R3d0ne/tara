/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
$( function () {

	$('#content').on('click', '.img-publish-send', function () {
	
		var publicationType = $(this).attr('data-pubtype'),
			publicationId = $(this).attr('data-publicationid'),
			action = 'openDialogPublish' + publicationType.charAt(0).toUpperCase() + publicationType.slice(1);

		var dialog = $('<div>').newDialog();
		dialog.html('<fieldset>loading...</fieldset>');
		
		var queryString = 'id=' + publicationId;

		$.main.ajaxRequest({
			modName: 'publish',
			pageName: 'publish_' + publicationType,
			action: action,
			queryString: queryString,
			success: action + 'Callback'
		});		
		
		dialog.dialog('option', 'title', 'Publish publication');
		dialog.dialog('option', 'width', '850px');
		dialog.dialog({
			buttons: {
				'Close': function () {
					$(this).dialog( 'close' );
				}
			}
		});

		dialog.dialog('open');
	});
	
	// click on lock icon
	$('#content').on('click', '.img-publish-lock', function () {
		if ( $(this).hasClass('pointer') ) {
			if ( confirm('Are you sure you want to remove lock') ) {
				var publicationId = $(this).attr('data-publicationid'),
					publicationType = $(this).attr('data-publicationtype'),
					action = 'close' + publicationType.charAt(0).toUpperCase() + publicationType.slice(1) + 'Publication';
				
				$.main.ajaxRequest({
					modName: 'publish',
					pageName: 'publish_' + publicationType,
					action: action,
					queryString: 'id=' + publicationId + '&releaseLock=1',
					success: refreshPublicationList({pub_type: publicationType})
				});				
			}
		} else {
			alert('Publish lock is currently enabled.\nPlease contact your Taranis Administrator if you want this lock to be deleted.');			
		}
	});
	
});

function refreshPublicationList ( params ) {
	var queryString = '';

	if ( params != null && 'pub_type' in params ) {
		queryString = 'pub_type=' + params.pub_type;
	}
			
	$.main.ajaxRequest({
		modName: 'publish',
		pageName: 'publish',
		action: 'displayPublish',
		queryString: queryString,
		success: null
	});
}
