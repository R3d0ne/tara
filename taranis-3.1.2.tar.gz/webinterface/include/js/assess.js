/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
$( function() {
	
	// Add to Publication action
	$('#content').on('click', '.addToPublicationOption', function () { 
		var itemClicked = $(this);
		
		var queryString = 'publicationTypeId=' + itemClicked.attr('data-publicationId') 
			+ '&digest=' + itemClicked.attr('data-digest') 
			+ '&publicationSpecifics=' + itemClicked.attr('data-specifics');
		
		$.main.ajaxRequest({
			modName: 'assess',
			pageName: 'assess',
			action: 'addToPublication',
			queryString: queryString,
			success: addToPublicationCallback
		}, true);	
	});
	
	// email icon; opens dialog for sending mail.
	$('#content').on('click', '.img-assess-item-mail', function () {
		
		var itemDigest = $(this).attr('data-digest');
		
		var dialog = $('<div>').newDialog();
		dialog.html('<fieldset>loading...</fieldset>');

		$.main.ajaxRequest({
			modName: 'assess',
			pageName: 'mail',
			action: 'displayMailAction',
			queryString: 'digest=' + itemDigest,
			success: mailItemOpenDialogCallback
		});			
		
		dialog.dialog('option', 'title', 'Email item');
		dialog.dialog('option', 'width', '730px');
		dialog.dialog({
			buttons: {
				'Send mail': function () {

					if ( $('#mailto:selected') == 0 ) {
						alert('Please select one or more email addresses.');
					} else if ( $('#subject').val() == '' ) {
						alert('Please fill out a subject.');
					} else if ( $('#description').val() == '' ) {
						alert('Please fill out a text to send.');					
					} else {
						$.main.ajaxRequest({
							modName: 'assess',
							pageName: 'mail',
							action: 'sendMail',
							queryString: $('#form-assess-mail-item').serializeWithSpaces(),
							success: mailItemCallback
						});							
					}
				},
				'Cancel': function () {
					$(this).dialog( 'close' );
				}
			}
		});

		dialog.dialog('open');
		
		$('.item-arrow:visible').hide();
		$('#' + itemDigest.replace(/%/g, '\\%') + ' .item-arrow').show();
		
		// Continue with mailItemOpenDialogCallback() after AJAX request is done.
	});
	
	// show / hide clustered items
	$('#content').on( 'click', '.item-clustering-toggle-items', function () {

		var clusterId = $(this).attr('data-clusterid');
		if ( $('.item-cluster-row[data-clusterid="' + clusterId + '"]:visible').length > 0 ) {
			$('.item-cluster-row[data-clusterid="' + clusterId + '"]').hide();
		} else {
			$('.item-cluster-row[data-clusterid="' + clusterId + '"]').show();
		}
	});
	
	// unlink assess item from cluster (by setting the cluster_enabled to false)
	$('#content').on( 'click', '.btn-unlink-from-cluster', function () {
		if ( confirm('Are you sure you want unlink item from cluster?') ) {
			
			$.main.ajaxRequest({
				modName: 'assess',
				pageName: 'assess',
				action: 'disableClustering',
				queryString: 'id=' + $(this).attr('data-digest') + '&clusterId=' + $(this).attr('data-clusterid') + '&seedDigest=' + $(this).attr('data-seeddigest'),
				success: disableClusteringCallback
			});
		}
	});
	
	$('#content').on( 'click', '#btn-show-more-items', function () {
		stopAssessTimer();
		// when no enddate is set
		if ( $('#assess-end-date').val() == '' && $('#assess-start-date').val() != '' ) {
			$('#assess-end-date').val('01-01-2030');
	   	}		

		var lastInBatch = $('.assess-item:last').attr('id') ;
		
		var firstInBatch = $('.assess-item:first').attr('id');
		if ( $('div[id="' + firstInBatch + '"]').hasClass('item-top-cluster-row') == true ) {
			var clusterId = $('div[id="' + firstInBatch + '"]').attr('data-clusterid');
			firstInBatch = $('.item-cluster-row[data-clusterid="' + clusterId + '"]:first').attr('id');
		}
		
		$.main.ajaxRequest({
			modName: 'assess',
			pageName: 'assess',
			action: 'search',
			queryString: $('#form-assess-standard-search').serializeWithSpaces() + '&lastInBatch=' + lastInBatch + '&firstInBatch=' + firstInBatch,
			success: function (params) {
				$('.assess-item:last').after(params.newItemsHtml);
				if ( $('.assess-item').length == parseInt( $('#assess-result-count').text() ) ) {
					$('#btn-show-more-items').hide();
				}
				startAssessTimer();
			}
		});
	});
	
});

function mailItemOpenDialogCallback ( params ) {

	var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	$('#btn-assess-mail-add-address').click( function () {
		var emailAddress = $('#assess-mail-extra-address').val(); 
		if ( emailAddress != '' && re.test( emailAddress ) ) {
			$('<option>')
				.val( emailAddress )
				.text( emailAddress )
				.appendTo('#assess-mail-to')
				.prop('selected', true);
			$('#assess-mail-extra-address').val('')
		} else {
			alert ("Please enter a valid e-mail address!");	
		}
	});
}

function mailItemCallback ( params ) {

	// replace all buttons with a Close button 
	$.main.activeDialog.dialog('option', 'buttons', [
		{
			text: 'Close',
			click: function () { $(this).dialog('close') }
		}
	]);
	$('#content').spin(false);
}


function addToPublicationCallback ( params ) {

	if ( params.isAddedToPublication == 1 ) {
		var itemClicked = $('li[data-digest="' + params.itemDigest + '"][data-publicationId="' + params.publicationTypeId + '"][data-specifics="' + params.publicationSpecifics + '"]');
		if ( params.action == 'addToPublication' ) {
			itemClicked.addClass('isAddedToPublication');
		} else {
			itemClicked.removeClass('isAddedToPublication');
		}
	} else {
		alert( params.message );
	}
}

function refreshAssessPageCallback ( params ) {
	
	if ( params.newItemsCount > 0 ) {
		if ( $('#assess-new-items-message').size() > 0 ) {
			$('#assess-new-items-message-number').text( params.newItemsCount );
		} else {
			$('<div>')
				.attr('id', 'assess-new-items-message')
				.addClass('center pointer')
				.html('<span id="assess-new-items-message-text"><span class="bold" id="assess-new-items-message-number">' + params.newItemsCount + '</span><span> new items collected</span></span><span id="assess-new-items-message-refresh">Reload</span>')
				.mouseover( function () {
					$('#assess-new-items-message-text').hide();
					$('#assess-new-items-message-refresh').show();
				})
				.mouseout( function () {
					$('#assess-new-items-message-text').show();
					$('#assess-new-items-message-refresh').hide();
				})
				.click( function () {
					if ( $('#btn-assess-search').is(':visible') ) {
						$('#btn-assess-search').trigger('click', 'autoRefresh');
					} else {
						$('#btn-custom-search').trigger('click', 'autoRefresh');
					}
				})
				.prependTo('.assess-items');
		}
	}
	
	if ( params.id ) {
		$('#' + params.id.replace(/%/g, '\\%') + ' .item-arrow').show();
		var currentItemPosition = $('#' + params.id.replace(/%/g, '\\%') ).position();

		if ( $('.ui-dialog:visible').size() == 0 && currentItemPosition ) {
			$(document).scrollTop( currentItemPosition.top );
		}
	}
}

function disableClusteringCallback ( params ) {

	if ( params.message ) {
		alert( params.message );
	} else {
		$('div[id="' + params.itemDigest + '"]').remove()

		var numberOfClusterItemsElement = $('.item-clustering-toggle-items[data-clusterid="' + params.clusterId + '"] span');
		var numberOfClusterItems = parseInt( numberOfClusterItemsElement.text() );
		if ( numberOfClusterItems > 2 ) {
			numberOfClusterItemsElement.text( numberOfClusterItems - 1 );
		} else {
			$.main.ajaxRequest({
				modName: 'assess',
				pageName: 'assess',
				action: 'getAssessItemHtml',
				queryString: 'insertNew=0&id=' + params.seedDigest,
				success: getAssessItemHtmlCallback
			});
		}

		$.main.ajaxRequest({
			modName: 'assess',
			pageName: 'assess',
			action: 'getAssessItemHtml',
			queryString: 'insertNew=1&id=' + params.itemDigest,
			success: getAssessItemHtmlCallback
		});
	}
}

function getAssessItemHtmlCallback( params ) {
	if ( params.insertNew == 1 ) {
		$('.assess-items').prepend( params.itemHtml );
	} else {
		$('div[id="' + params.itemDigest + '"]').html( params.itemHtml );
		
		$('.item-arrow:visible').hide();
		$('#' + params.itemDigest.replace(/%/g, '\\%') + ' .item-arrow').show();						
	}	
}
