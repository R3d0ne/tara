/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
$( function () {
	$(document).on('mouseenter', '#advisory-platforms-left-column option, #advisory-products-left-column option, #advisory-platforms-right-column option, #advisory-products-right-column option', function () {
		var tab = $(this).parent().attr('data-tab');
		
		var tabContext = $('#advisory-details-tabs-' + tab); 
		$('.publications-software-hardware-fulltext', tabContext).html( $(this).html() );
	});
	
	$(document).on('mouseleave', '#advisory-platforms-left-column option, #advisory-products-left-column option, #advisory-platforms-right-column option, #advisory-products-right-column option', function () {
		var tab = $(this).parent().attr('data-tab');
		
		var tabContext = $('#advisory-details-tabs-' + tab); 
		$('.publications-software-hardware-fulltext', tabContext).html( '' );
	});
	
});

function searchSoftwareHardwareWrite (context, searchType, publicationId, publicationType) {
	if ( $('#' + publicationType + '-' + searchType + '-search').val().length > 1 ) {
		var search = encodeURIComponent( $('#' + publicationType + '-' + searchType + '-search').val() );

		$.main.ajaxRequest({
			modName: 'write',
			pageName: 'common_actions',
			action: 'searchSoftwareHardwareWrite',
			queryString: 'search=' + search + '&publicationtype=' + publicationType + '&searchtype=' + searchType + '&publicationid=' + publicationId,
			success: searchSoftwareHardwareWriteCallback
		});
		
	} else {
		alert('Can only search with at least two characters.')
	}
}

function searchSoftwareHardwareWriteCallback ( params ) {
	var context = $('.publication-details-form[data-publicationid="' + params.publicationId + '"]');
	var rightColumn = $('#' + params.pubType + '-' + params.searchType + '-right-column', context ); 
	var leftColumn = $('#' + params.pubType + '-' + params.searchType + '-left-column', context );
	
	// clear former searchresults
	rightColumn.children('option').each( function (i) {
		$(this).remove();
	});

	if ( params.data.length > 0 ) {
		$.each( params.data, function (i, sh) {
			
			//create option element and add to rightcolumn
			var searchResult = $('<option>')
									.html( sh.producer.substr(0,1).toUpperCase() + sh.producer.substr(1) + ' ' + sh.name + ' ' + sh.version + ' (' + sh.description + ')' )
									.val( sh.id )
									.attr({
										'data-producer': sh.producer,
										'data-name': sh.name,
										'data-version': sh.version
									})
									.appendTo( rightColumn );
			
			// mark all the options which are in use by constituents
			if ( sh.in_use > 0 ) {
				searchResult.addClass('option-sh-in-use');
			}
		});
		
	} else {
		// give the search inputfield a red border when no results are found
		rightColumn
			.siblings('input[type="search"]')
			.css('border', '1px solid red')
			.keyup( function () {
				$(this).css('border', '1px solid #bbb');
			});
	}

	checkRightColumnOptions(leftColumn, rightColumn);
}


function getPublicationTemplateCallback ( params ) {
	if ( params.templateOk == 1 ) {
		var context = $('.publication-details-form[data-publicationid="' + params.publicationId + '"]');
		$('.publication-template-result[id="' + params.publicationType + '-' + params.tab + '-template"]', context).html(params.template);
	} else {
		alert( params.message );
	}
}

function getTemplateTextCallback ( params ) {
	if ( params.templateOk == 1 ) {
		var context = $('.publication-details-form[data-publicationid="' + params.publicationId + '"]');
		$('.publications-details-' + params.tab + '-text', context).html( params.templateText );
		$('.publications-details-' + params.tab + '-text', context).val( $('.publications-details-' + params.tab + '-text', context).text() );
	} else {
		alert( params.message );
	}
}

function getPulicationPreviewCallback ( params ) {

	if ( params.previewOk == 1 ) {
		var context = $('.publication-details-form[data-publicationid="' + params.publicationId + '"]');
		$('.publications-details-preview', context).html(params.previewText);
	} else {
		alert( params.message );
	}
}

function setPublicationCallback ( params ) {
	if ( params.saveOk == 1 ) {

		$.main.activeDialog.dialog('close');
		$('#content').spin(false);
		
	} else {
		alert( params.message );
	}	
}
