/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
$( function () {

	// open publications details dialog
	$('#content').on('click', '.img-publications-edit, .img-publications-view', function () {
		var pubType = $(this).attr('data-pubtype'),
			publicationId = ( $(this).attr('data-publicationid') ) ? $(this).attr('data-publicationid') : $(this).attr('data-id'),
			action = 'openDialog' + pubType.charAt(0).toUpperCase() + pubType.slice(1) + 'Details';
		
		var dialog = $('<div>').newDialog();
		dialog.html('<fieldset>loading...</fieldset>');
	
		$.main.ajaxRequest({
			modName: 'write',
			pageName: pubType,
			action: action,
			queryString: 'id=' + publicationId,
			success: action + 'Callback'
		});		
		
		dialog.dialog('option', 'title', 'Publication details');
		dialog.dialog('option', 'width', '850px');
		dialog.dialog({
			buttons: {
				'Close': function () {
					$(this).dialog( 'close' );
				}
			}
		});

		dialog.dialog('open');
	});
	
	// unlock publication (user needs to be admin)
	$('#content').on('click', '.img-publications-lock', function () {
		if ( confirm('Are you sure you want to remove lock') ) {
			var publicationId = $(this).attr('data-publicationid');
			// closePublication
			$.main.ajaxRequest({
				modName: 'write',
				pageName: 'publications',
				action: 'closePublication',
				queryString: 'id=' + publicationId + '&closeByAdmin=1',
				success: null
			}, true);
			
			// reload item
			$.main.ajaxRequest({
				modName: 'write',
				pageName: 'publications',
				action: 'getPublicationItemHtml',
				queryString: 'insertNew=0&id=' + publicationId + '&pubType=' + $(this).attr('data-pubtype'),
				success: getPublicationItemHtmlCallback
			}, true);			
		}
	});

    // delete publication
    $('#content').on('click', '.img-publications-delete', function () {
    	var publicationId = $(this).attr('data-publicationid');
    	
    	if ( confirm('Are you sure you want to delete "' + $.trim( $('.publications-item-title', $('#' + publicationId) ).text() ) + '"' ) ) {
    		
			$.main.ajaxRequest({
				modName: 'write',
				pageName: 'publications',
				action: 'deletePublication',
				queryString: 'del=' + $(this).attr('data-detailsid') + '&publicationId=' + publicationId + '&pubType=' + $(this).attr('data-pubtype'),
				success: deletePublicationCallback
			}, true);
    	}
    });
    
    // open update publication dialog
    $('#content').on('click', '.img-publications-update',function () {
		var pubType = $(this).attr('data-pubtype'),
			publicationId = $(this).attr('data-publicationid');
		
		var action = 'openDialogUpdate' + pubType.charAt(0).toUpperCase() + pubType.slice(1);
		
		var dialog = $('<div>').newDialog();
		dialog.html('<fieldset>loading...</fieldset>');

		$.main.ajaxRequest({
			modName: 'write',
			pageName: pubType,
			action: action,
			queryString: 'id=' + publicationId + '&pubType=' + pubType,
			success: action + 'Callback'
		});		
		
		dialog.dialog('option', 'title', 'Publication update');
		dialog.dialog('option', 'width', '850px');
		dialog.dialog({
			buttons: {
				'Close': function () {
					$(this).dialog( 'close' );
				}
			}
		});

		dialog.dialog('open');
    });

    // open preview publication dialog
    $('#content').on('click', '.img-publications-preview, .publications-preview-link', function () {
		var pubType = $(this).attr('data-pubtype'),
			publicationId = ( $(this).attr('data-publicationid') ) ? $(this).attr('data-publicationid') : $(this).attr('data-id'),
			action = 'openDialogPreview' + pubType.charAt(0).toUpperCase() + pubType.slice(1);
		
		var dialog = $('<div>').newDialog();
		dialog.html('<fieldset>loading...</fieldset>');

		$.main.ajaxRequest({
			modName: 'write',
			pageName: pubType,
			action: action,
			queryString: 'id=' + publicationId + '&pubType=' + pubType,
			success: action + 'Callback'
		});		
		
		dialog.dialog('option', 'title', 'Publication preview');
		dialog.dialog('option', 'width', '850px');
		dialog.dialog({
			buttons: {
				'Close': function () {
					$(this).dialog( 'close' );
				}
			}
		});

		dialog.dialog('open');
    });

});

function getPublicationItemHtmlCallback ( params ) {
	if ( params.insertNew == 1 ) {
		$('#empty-row').remove();
		$('#publications-content-heading').after( params.itemHtml );
	} else {
		$('#' + params.publicationId)
			.html( params.itemHtml )
			.removeClass( 'publications-pending publications-ready4review publications-approved publications-published' )
			.addClass( 'publications-' + params.publicationStatus );
	}
}

function deletePublicationCallback ( params ) {
	if ( params.deleteOk == 1 ) {
		if ( params.multiplePublicationsUpdated == 1) {
			$('#btn-publications-search').trigger('click');
		} else {
			$('#' + params.publicationid ).remove();
	
			if (params.previousVersion != '' ) {
				$.main.ajaxRequest({
					modName: 'write',
					pageName: 'publications',
					action: 'getPublicationItemHtml',
					queryString: 'insertNew=0&id=' + params.previousVersion + '&pubType=' + $('#' + params.previousVersion).attr('data-pubtype'),
					success: getPublicationItemHtmlCallback
				}, true);	
			}
		}		
	} else {
		alert( params.message );
	}
}
