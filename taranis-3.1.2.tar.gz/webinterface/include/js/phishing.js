/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
$( function () {
	
	// add url
	$('#filters').on('click', '#btn-phishing-add', function () {
		if ( $('#phishing-add-url').val() != '' && $('#phishing-add-url').val() != 'http://' ) {
			
			$.main.ajaxRequest({
				modName: 'tools',
				pageName: 'phishing_overview',
				action: 'addPhishingItem',
				queryString: 'tool=phishing_checker&url=' + encodeURIComponent( $('#phishing-add-url').val() ),
				success: addPhishingItemCallback
			});
		}
	});
	
	// delete url
	$('#content').on('click', '#btn-delete-phishing-item', function () {
		if ( confirm('Are you sure you want to delete the phishing check?') ) {
			
			$.main.ajaxRequest({
				modName: 'tools',
				pageName: 'phishing_overview',
				action: 'deletePhishingItem',
				queryString: 'tool=phishing_checker&url=' + $(this).attr('data-phishingurl') + '&urlhash=' + $(this).attr('data-urlhash'),
				success: deletePhishingItemCallback
			});
		}
	});
	
	// perform a whois on url
	$('#content').on('click', '#btn-whois-phishing-item', function () {
		
		$.main.ajaxRequest({
			modName: 'tools',
			pageName: 'whois',
			action: 'getWhoisHost',
			queryString: 'tool=whois&whois=' + $(this).attr('data-phishingurl'),
			success: null
		});	
	});
	
	// add url with enter
	$('#filters').on( 'keypress', '#phishing-add-url', function (event) {
		if ( !checkEnter(event) ) {
			event.preventDefault();
			$('#btn-phishing-add').trigger('click');
		}
	});

	$('#phishing-add-url').focus();
});


function addPhishingItemCallback ( params ) {
	if ( params.addOk == 1 ) {
		$('#phishing-content-heading').after( params.itemHtml );
		$('.no-items').remove();
	} else {
		alert(params.message);
	}
}

function deletePhishingItemCallback ( params ) {
	if ( params.deleteOk == 1 ) {
		$('#' + params.urlHash).remove();
	} else {
		alert(params.message);
	}
}
