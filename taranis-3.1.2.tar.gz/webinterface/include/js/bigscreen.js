/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/

$.bigScreen = {};
$(function () {

	$.bigScreen.webroot = $('#big-screen-webroot').val();
	$.bigScreen.scriptroot = $('#big-screen-scriptroot').val();
		
	$.bigScreen.ajaxRequest = function ( request ) {
	    
		var params = new Object();
		if ( request.queryString !== undefined ) {
			// if query starts with '&', remove it.
			if ( request.queryString.indexOf('&') == 0 ) {
				request.queryString = request.queryString.substr(1);
			}

			// create key/value datastructure of input parameters
			$.each( request.queryString.split('&'), function (i, kvPair) {
				var k = kvPair.substr(0, kvPair.indexOf('='));
				var v = kvPair.substr(kvPair.indexOf('=') +1);
				if ( k in params ) {
					if ( typeof params[k] === 'object' ) {
						params[k].push(v);
					} else {
						params[k] = [v, params[k]];	
					}
				} else {
					params[k] = v;
				}
			});
		}
		
		$.post(
				$.bigScreen.scriptroot + '/load/',
				{ 
					'modName': request.modName,
					'pageName': request.pageName,
					'action': request.action,
					'params': JSON.stringify(params)
				},
				function (result) {
					if ( result.session_ok ) {
						if ( result.is_success ) {
							
							// load page content html
							if ( result.page.bigScreenContent ) {
//								$('#content').html( result.page.bigScreenContent );
							}

							// run callback function if present
							if ( typeof request.success === 'function' ) {
								var resultParams = ( result.page.params ) ? result.page.params : [];
								request.success(resultParams);
							} 
							
						} else {
							// handle error
							$('#content').html('<span>' + result.message + ' (0)</span>');
						}
					} else {
						// handle no session
						window.location = 'login/?ent=' + result.message;
					}
				}, 'json'
		);
	}	

	$.bigScreen.ajaxRequest({
		modName: 'tools',
		pageName: 'get_screen',
		action: 'getBigScreenSettings',
		queryString: 'tool=big_screen',
		success: bigScreenInit
	});	
	
});

function resetContentSpace () {
	var offset = $('#bg_content_div').offset();
	var w = $('#bg_content_div').width() * 0.955;
	
	var wrapperDivheight = window.innerHeight * 0.75;

	$('#bg_content_div').css({
		'height': wrapperDivheight
	});
	
	$('#wrapper_div').css( {
		'position' : 'absolute',
		'left' : offset.left,
		'top' : offset.top,
		'height' : wrapperDivheight,
		'width' : w
	});		
}

function bigScreenInit ( params ) {
	
	$.bigScreen.timer = params.timer;
	$.bigScreen.numberOfScreens = params.numberOfScreens;
	
	if ( params.autoDetectResolution == 1 ) {
		$('body').css( 'background-image', "url('" + $.bigScreen.webroot + "/images/bigscreen_"  + screen.width + "x" + screen.height + ".jpg')");
	} else {
		var screenWidth = params.resolution.replace( /^(\d+)x.*$/, '$1'),
			screenHeight = params.resolution.val().replace( /^.*?x(\d+)$/, '$1');
		
		$('body').css( 'background-image', "url('" + $.bigScreen.webroot + "/images/bigscreen_"  + screenWidth + "x" + screenHeight + ".jpg')");
	}

	resetContentSpace();
	
	// when window resizes, also resize the available space for content 
	$(window).resize( function () {
		resetContentSpace();
	});

	// when F11 is pressed show screen 1
	$(document).keypress( function(e) {
		if ( e.keyCode == 122 ) {
			$.bigScreen.ajaxRequest({
				modName: 'tools',
				pageName: 'get_screen',
				action: 'getScreen',
				queryString: 'tool=big_screen&screen=1',
				success: getScreenCallback
			});
		}
	});
	
	// start by showing screen 1
	$.bigScreen.ajaxRequest({
		modName: 'tools',
		pageName: 'get_screen',
		action: 'getScreen',
		queryString: 'tool=big_screen&screen=1',
		success: getScreenCallback
	});
	
	var screenNumber = 1;
	
	// change screen every x seconds
	$(document).everyTime( $.bigScreen.timer, function() {
		screenNumber++;

		if ( screenNumber > $.bigScreen.numberOfScreens ) {
			screenNumber = 1;
		}
		
		$('#content')
			.animate({'opacity' : '0'}, 1500, function () {
				
				$.bigScreen.ajaxRequest({
					modName: 'tools',
					pageName: 'get_screen',
					action: 'getScreen',
					queryString: 'tool=big_screen&screen=' + screenNumber,
					success: getScreenCallback
				});
			
			$(this).css('text-align', 'left');
		});
		
	}, 0);
}

function getScreenCallback ( params ) {

	resetContentSpace();
	
	switch ( params.screenData.func ) {
		case 'welcomeScreen':
			welcomeScreen( params.screenData );
			break;
		case 'securityNews':
			securityNews( params.screenData );
			break;
		case 'securityVulnerability':
			securityVulnerability( params.screenData );
			break;							
		case 'symposiumNews':
			symposiumNews( params.screenData );
			break;
		case 'announcements':
			announcements( params.screenData );
			break;
		case 'buienRadar':
			buienRadar( params.screenData );
			break;
		case 'nsAnnouncements':
			nsAnnouncements( params.screenData );
			break;
		case 'news':
			news( params.screenData );
			break;
		case 'taranisDemo':
			taranisDemo( params.screenData );
			break;
		case 'twitter':
			twitter( params.screenData );
			break;
		case 'cloudSecurity':
			cloudSecurity( params.screenData );
			break;
		case 'cloudNews':
			cloudNews( params.screenData );
			break;
		case 'cloudICT':
			cloudICT( params.screenData );
			break;
		default:
			alert( 'error screen: ' + params.screenData.func );
	};
}



function welcomeScreen ( data ) {
	$('#header').html(data.screenTitle);
	$('#content').html('');
	$('#content').animate({'opacity' : '1'}, 1500);

	$('#content').css('text-align', data.welcomeTextAlign);

	$('<span />')
		.css({ 'font-size' : data.welcomeTextSize + 'px', 'text-align': 'center'})
		.attr( 'id', 'welcomeText')
		.text( data.welcomeText )
		.appendTo('#content')
		.hide();

	$('#welcomeText').fadeIn('normal');
	
}

function securityNews ( data ) {
	showAssessItems( data, 'Security News' );
}

function securityVulnerability ( data ) {
	showAssessItems( data, 'Security Vulnerability News');
}

function news ( data ) {
	showAssessItems( data, 'News' );
}

function symposiumNews ( data ) {
	$('#header').html('Symposium News<hr class="headerHR" />');

	$('#content').html('');
	$('#content').animate({'opacity' : '1'}, 1500);

	$('#content').css( 'opacity', '1');

	$('<table />')
		.attr('id', 'resultTable')
		.attr('width', '100%')
		.attr('cellpadding', '5')
		.attr('cellspacing', '0')
		.appendTo('#content');

	$.each( data.symposiumNews, function( i, news ) {

		$('<tr />')
			.attr('id', 'row' + i)
			.css('margin-top', '2%')
			.appendTo( $('#resultTable') )
			.hide();
		
		$('<td />')
			.attr({ 'id': 'cell' + i })
			.html( '<span class="title">' + news.title + '</span><br />' )
			.appendTo('#row' + i);

		$('<span>')
			.attr({ 'id': 'span' + i })
			.appendTo( '#cell' + i );
			
		$( '#span' + i ).html( news.description );
		$( '#span' + i ).html( $( '#span' + i ).text() );
	
		if ( $('#resultTable').height() < $('#content').height() ) {
			$('#row' + i ).fadeIn( 1000 );
		}
		
	});
}

function announcements ( data ) {
	$('#header').html('Announcements<hr class="headerHR" />');
	$('#content').html('');

	$('#content').animate({'opacity' : '1'}, 1500);

	$('#content').css( 'opacity', '1');

	
	$('<table />')
		.attr('id', 'resultTable')
		.attr('width', '100%')
		.attr('cellpadding', '5')
		.attr('cellspacing', '0')
		.appendTo('#content');

	$.each( data.announcements, function( i, announcement ) {

		$('<tr />')
			.attr('id', 'row' + i)
			.css('margin-top', '2%')
			.appendTo( $('#resultTable') )
			.hide();

		$('<td />')
			.html('<span class="title">' + announcement.title + '</span><br /><span class="description"><pre>' + announcement.description + '</pre></span>' )
			.css('font-size', data.announcementTextSize + 'px')
			.appendTo('#row' + i);

		if ( $('#resultTable').height() < $('#content').height() ) {
			$('#row' + i ).fadeIn( 1000 );
		}
		
	});
}

function buienRadar (data) {
	$('#header').html('Weather info from BuienRadar.nl<hr class="headerHR" />');
	$('#content').html('');
	$('#content').animate({'opacity' : '1'}, 1500);
	
	var buienRadarImgHeight =  $('#content').height();
	var buienRadarImgWidth = buienRadarImgHeight * 0.915;

	$('<table />')
		.attr( {'id': 'foreCast', 
						'width': '100%',
						'cellpadding': '5',
						'cellspacing': '5',
						'border': '0'
		})
		.css({'text-align': 'center'})
		.appendTo( $('#content') );

	
	// row0: buienRadar img
	$('<tr />')
		.attr({'id': 'row0'})
		.appendTo( $('#foreCast') )
		.hide();	
	
	$('<td />')
		.attr({'id': 'celBuienRadar', 'rowspan': '5'})
		.appendTo('#row0');	

	$('#foreCast > *').css('vertical-align', 'top');
	
	$('<iframe />')
		.attr({ 
						'src' : 'http://www2.buienradar.nl/display.php?width=' + buienRadarImgWidth + '&height=' + buienRadarImgHeight + '&country=nl&maptype=2&opacity=75', 
						'frameborder' : '0',
						'id' : 'buienRadarFrame',
						'hspace' : '0',
						'vspace' : '0',
						'marginheight' : '0',
						'marginwidth' : '0',
						'scrolling' : 'no'
					})
		.css({ 'width' : buienRadarImgWidth  , 'height' : buienRadarImgHeight })
		.hide()
		.appendTo( $('#celBuienRadar') );
		
	// row1: meetstation / verwachting NL
	$('<tr />')
		.attr({'id': 'row1'})
		.appendTo( $('#foreCast') )
		.hide();

	$('<td />')
		.html('<span>' + data.current.stationnaam.regio + '</span>')
		.attr('id', 'celRegio')
		.appendTo('#row1');
	
	$('<td />')
		.html('<span>Weersverwachting Nederland</span>')
		.attr({'colspan': '5', 'id': 'celVerwachtingNederland'})
		.appendTo('#row1');

	// row2: day
	$('<tr />')
		.attr({'id': 'row2'})
		.appendTo( $('#foreCast') )
		.css({'font-size': '12px'})
		.hide();	
	
	$('<td />')
		.html('<span class="title">' + data.current.datum + '</span>')
		.appendTo('#row2');		

	// row3: temperature
	$('<tr />')
		.attr({'id': 'row3'})
		.css({'font-size': '12px'})
		.appendTo( $('#foreCast') )
		.hide();		
	
	$('<td />')
		.html('<img src="' +  $.bigScreen.webroot  + '/images/buienRadar_' + data.current.icoonactueel.ID + '.png" /><br /><span class="title">' + data.current.temperatuurGC + '</span>')
		.appendTo('#row3');	

	// row4: wind
	$('<tr />')
		.attr({'id': 'row4'})
		.appendTo( $('#foreCast') )
		.hide();		

	$('<td />')
		.html('<span class="title">' + data.current.windsnelheidBF + ' bf</span>')
		.css({'font-size': '12px'})
		.attr('id', 'compass_today')	
		.appendTo('#row4');	

	$('<div />')
		.html('<img src="' +  $.bigScreen.webroot  + '/images/compass_arrow_' + data.current.windrichting.toLowerCase() + '.png" />')
		.css({
					'background-image': 'url("' +  $.bigScreen.webroot  + '/images/compass_w_150.png")', 
					'background-repeat' :'no-repeat', 
					'width': '150px', 
					'height': '152px',
					'margin-left': 'auto', 
					'margin-right': 'auto'						
		})
		.show()
		.appendTo('#compass_today');	
	
	$.each( data.foreCast, function( i, day ) {
		
		$('<td />')
			.html('<span class="title">' + day.datum + '</span>')
			.addClass( day.dayId )
			.appendTo('#row2');				
		
		$('<td />')
			.html('<img src="' +  $.bigScreen.webroot  + '/images/buienRadar_' + day.icoon.ID + '.png" /><br />max: <span class="title">' + day.maxtemp + '	&deg;</span> min: <span class="title">' + day.mintemp + '	&deg;</span>')
			.addClass( day.dayId )
			.appendTo('#row3');
		
		$('<td />')
			.html('<span class="title">' + day.windkracht + ' bf</span>')
			.attr({'id': 'compass_' + day.dayId})
			.css({'font-size': '12px'})			
			.addClass( day.dayId )
			.appendTo('#row4');	
		
		$('<div />')
			.html('<img src="' +  $.bigScreen.webroot  + '/images/compass_arrow_' + day.windrichting.toLowerCase() + '.png" />')
			.css({
						'background-image': 'url("' +  $.bigScreen.webroot  + '/images/compass_w_150.png")', 
						'background-repeat' :'no-repeat', 
						'width': '150px', 
						'height': '152px',
						'margin-left': 'auto', 
						'margin-right': 'auto'						
			})
			.show()
			.appendTo('#compass_' + day.dayId);
		
		var tableWidth = buienRadarImgWidth + $('#row4').width();
		
		if ( tableWidth > $('#content').width() ) {
			$('.' + day.dayId ).hide();
			return false;
		}
		
	});
	
	$.each( $('#foreCast tr'), function ( i )  {
		$('#buienRadarFrame').show();
		$('#row' + i).fadeIn( 1000 );
	});
	
}

function nsAnnouncements ( data ) {
	$('#header').html('Train Information<hr class="headerHR" />');
	$('#content').html('');
	
	$('#content').css('opacity', '1');
	
	$('<div />')
		.attr('id', 'announcementsWrapper')
		.css('border', '1px solid transparent' )
		.appendTo('#content');

	$.each( data.items, function(i, item) {
		
		$('<div />')
			.attr({'id': 'divAnnouncement' + i})
			.css({
						'-moz-border-radius': '10px',
						'border-radius' : '10px',
						'border': '2px solid FFCC33', 
						'padding-bottom' : '10px',
						'padding-right' : '8px',
						'padding-left' : '10px',
						'background-color': '#FFCC33',
						'margin-top': '10px',
						'visibility': 'hidden'
			})
			.appendTo('#announcementsWrapper');
		
		$('<table />')
			.attr('id', 'resultTable' + i + 'NS')
			.attr('cellpadding', '5')
			.attr('cellspacing', '0')
			.css({'color': '#000066'})
			.appendTo('#divAnnouncement' + i);
		
		$('<tr />')
			.attr({'id': 'logo' + i + 'NS', 'align': 'left'})
			.css({
						'margin-top': '2%',
						'background-color': '#FFCC33',
			})
			.appendTo('#resultTable' + i + 'NS');
				
		$('<td />')
			.attr({ 'id': 'logo', 'rowspan': '3' })
			.html('<img src="' +  $.bigScreen.webroot  + '/images/ns_logo_transparant.png" />')
			.css({'width': '100px', 'text-align': 'center'})
			.appendTo('#logo' + i + 'NS');
		
		$('<tr />')
			.attr({'id': 'routeRow' + i + 'NS', 'align': 'left'})
			.css({
						'margin-top': '2%',
						'background-color': '#FFCC33',
						'color': '#000066'	
			})
			.appendTo('#resultTable' + i + 'NS')
			
		$('<td />')
			.attr( 'id', '')
			.html('<span class="titleNS">' + item.title + '</span><span class="dateNS">' + item.date + '</span>')
			.appendTo('#routeRow' + i + 'NS');

		$('<tr />')
			.attr({'id': 'descriptionRow' + i + 'NS', 'align': 'left'})
			.appendTo('#resultTable' + i + 'NS')
		
		$('<td />')
			.attr( 'id', '')
			.html('<span class="descriptionNS">' + item.description + '</span>' )
			.css({
					'background-color': 'white', 
					'width': '100%', 						
					'-moz-border-radius': '5px',
					'border-radius' : '5px'
			})
			.appendTo('#descriptionRow' + i + 'NS');

		if ( $('#announcementsWrapper').height() < $('#content_wrapper').height() ) {
			$('#divAnnouncement' + i).hide();
			$('#divAnnouncement' + i).css('visibility', 'visible');
			$('#divAnnouncement' + i).fadeIn(1000);
		} 
		
	});	
	
}

function cloudSecurity ( data ) {
	$('#header').html('Tag Cloud // Security<hr class="headerHR" />');
	$('#content').html('');
	$('#content').animate({'opacity' : '1'}, 1500);

	var cloudHeight = $('#content').height() * 1.2;
	cloudWidth = $('#content').width();

	$('<iframe />') 
		.attr({ 
						'src' : 'https://liquorix.lab.govcert.nl/stats/tagcloud_security.html', 
						'frameborder' : '0',
						'id' : 'cloudSecurity',
						'hspace' : '0',
						'vspace' : '0',
						'marginheight' : '0',
						'marginwidth' : '0',
						'scrolling' : 'no'
					})
		.css({ 'width' : cloudWidth  , 'height' : cloudHeight, 'opacity' : 0.8 })
		.fadeIn ( 1000 )
		.appendTo ( $('#content') );
}

function cloudNews ( data ) {
	$('#header').html('Tag Cloud // News<hr class="headerHR" />');
	$('#content').html('');
	$('#content').animate({'opacity' : '1'}, 1500);

	var cloudHeight = $('#content').height() * 1.2;
	cloudWidth = $('#content').width();

	$('<iframe />') 
		.attr({ 
						'src' : 'https://liquorix.lab.govcert.nl/stats/tagcloud_news.html', 
						'frameborder' : '0',
						'id' : 'cloudNews',
						'hspace' : '0',
						'vspace' : '0',
						'marginheight' : '0',
						'marginwidth' : '0',
						'scrolling' : 'no'
					})
		.css({ 'width' : cloudWidth  , 'height' : cloudHeight, 'opacity' : 0.8 })
		.fadeIn ( 1000 )
		.appendTo ( $('#content') );
}

function cloudICT ( data ) {
	$('#header').html('Tag Cloud // ICT<hr class="headerHR" />');
	$('#content').html('');
	$('#content').animate({'opacity' : '1'}, 1500);

	var cloudHeight = $('#content').height() * 1.2;
	cloudWidth = $('#content').width();

	$('<iframe />') 
		.attr({ 
						'src' : 'https://liquorix.lab.govcert.nl/stats/tagcloud_ictnews.html', 
						'frameborder' : '0',
						'id' : 'cloudICT',
						'hspace' : '0',
						'vspace' : '0',
						'marginheight' : '0',
						'marginwidth' : '0',
						'scrolling' : 'no'
					})
		.css({ 'width' : cloudWidth  , 'height' : cloudHeight, 'opacity' : 0.8 })
		.fadeIn ( 1000 )
		.appendTo ( $('#content') );
}

function taranisDemo ( data ) {
	$('#header').html('Taranis<hr class="headerHR" />');
	$('#content').html('');
	$('#content').animate({'opacity' : '1'}, 1500);

	$('#content').css('text-align', 'center');
	
	$('<table />')
		.attr('id', 'resultTable')
		.attr('width', '100%')
		.attr('cellpadding', '15')
		.attr('cellspacing', '0')
		.appendTo('#content')
		.hide();
	
	$('<tr>')
		.attr({ 'id': 'resultTableTR'})
		.appendTo('#resultTable');
	
	$('<td>')
		.attr({ 'id': 'demoImgTD'})
		.appendTo('#resultTableTR');

	$('<img>')
		.attr({ 
			'id' : 'taranisDemo',
			'src': $.bigScreen.webroot + '/images/demo.png',
			'alt': 'Taranis'
		})
		.appendTo('#demoImgTD');

	$('<td>')
		.attr({ 'id': 'demoTextTD'})
		.css({'font-size': '16pt'})
		.html('<span><b>Taranis</b> is the tool used by GOVCERT.NL for monitoring hundreds of web-based and e-mail based security resources.<br /><br />Interested in a <b>demo</b>&#63;<br />Ask for Sebastiaan or Edwin.<br /><br />More information is also available via <b>www.govcert.nl/taranis</b></span>')
		.appendTo('#resultTableTR');	
	
	$('#resultTable').fadeIn('normal');	
}

function twitter ( data ) {
	showAssessItems( data, 'Tweets and news about GOVCERT.NL on the net' );
}

function showAssessItems ( data, headerTitle ) {
	$('#header').html( headerTitle + '<hr class="headerHR" />' );
	$('#content').html('');
	
	$('#content').css( 'opacity', '1');

	$('<table />')
		.attr('id', 'resultTable')
		.attr('width', '100%')
		.attr('cellpadding', '15')
		.attr('cellspacing', '0')
		.appendTo('#content');

	$.each( data.items, function(i, item) {

		$('<tr />')
			.attr({'id': 'row' + i, 'align': 'left'})
			.css('margin-top', '2%')
			.appendTo( $('#resultTable') )
			.hide();
			
		$('<td />')
			.html('<img src="' + $.bigScreen.webroot + '/images/icons/' + item.source + '.gif" />' )
			.attr('valign', 'top')
			.css('width', '80px')
			.appendTo('#row' + i);

		$('<td />')
			.html('<span class="title">' + item.title + '</span>' )
			.css('font-size', data.textSize + 'px')
			.appendTo('#row' + i);

		if ( $('#resultTable').height() < $('#content').height() ) {
			$('#row' + i ).fadeIn( 1000 );
		}
		
	});
}
