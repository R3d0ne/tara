/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/

/***************************** functions for printing the preview  *****************************************/
function printInput( inputElement ){
	var ifr = window.frames['printFrame'];
	if (ifr){ //print the content of the invisible iframe
	 
		if ( $('#content', ifr.document ).length == 0 ) {
			$( '#body_preview', ifr.document ).empty();
			$( '#body_preview', ifr.document ).append( '<pre id="content"></pre>');
		}
	
		$('#content', ifr.document ).text( inputElement.val() );
		$('title', ifr.document).text( 'TARANIS' );

		ifr.focus();
		ifr.print();
	} else { //print by opening a new window and then closing it
		var textElement = $('<textarea>').val( inputElement.val() );
		textElement.text( textElement.val() );
		
		var html='<html><head><style type="text/css">pre{font:normal 11px Courier;}</style></head><body onload="window.print();window.close()"><pre>' + textElement.html() + '</pre></body></html>';
 
		var win = window.open('','_blank','menubar,scrollbars,resizable');
		win.document.open();
		win.document.write(html);
		win.document.close();
	}
}

function printHtmlInput( html ){
	
	var ifr = window.frames['printFrame'];
	if (ifr){ //print the content of the invisible iframe
		$('title', ifr.document).text( 'TARANIS' );
		$('#body_preview', ifr.document).html( html );
		$('#body_preview', ifr.document).html( $('#body_preview', ifr.document).text() );

		ifr.focus();
		ifr.print();
	} else { //print by opening a new window and then closing it
		var html='<html><head><style type="text/css">pre{font:normal 11px Courier;}</style></head><body onload="window.print();window.close()">' + html + '</body></html>'
		var win = window.open('','_blank','menubar,scrollbars,resizable');
		win.document.open();
		win.document.write(html);
		win.document.close();
	}
}

function writeContent(objIframe){
	var html='<html><head><title></title><style type="text/css" media="print">div{font:normal 12px Courier; white-space: pre-wrap}</style></head><body id="body_preview"><div id="content"></div></body></html>';
	objIframe.document.write(html);
	objIframe.document.close();
}
