/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
function openDialogNewEosCallback ( params ) {
	var context =  $('#eos-details-form[data-publicationid="NEW"]');
	
	// setup dialog buttons
	$.main.activeDialog.dialog('option', 'buttons', [
		{
			text: 'Save',
			click: function () {
					
				$.main.ajaxRequest({
					modName: 'write',
					pageName: 'eos',
					action: 'saveNewEos',
					queryString: $(context).find('.include-in-form').serializeWithSpaces(),
					success: saveNewEosCallback
				});
			}
		},
		{
			text: 'Cancel',
			click: function () { $(this).dialog('close') }
		}
	]);
	$('#eos-details-tabs', context).newTabs({selected: 0});
	
	setEosUIBehavior( context );
}

function openDialogEosDetailsCallback ( params ) {
	var context =  $('#eos-details-form[data-publicationid="' + params.publicationid + '"]');
	
	if ( params.isLocked == 1 ) {
		// setup dialog buttons
		$.main.activeDialog.dialog('option', 'buttons', [
			{
				text: 'Print preview',
				click: function () { 
					printInput( $('#eos-details-preview-text', context) );				
				}
			},
			{
				text: 'Close',
				click: function () { $(this).dialog('close') }
			}
		]);
		
		// disable all fields
		$('input, select, textarea', context).each( function (index) {
			$(this).prop('disabled', true);
		});
		
		$('#eos-details-preview-text', context).prop('disabled', false);
		
	} else {	
	
		// setup dialog buttons
		$.main.activeDialog.dialog('option', 'buttons', [
			{
				text: 'Print preview',
				click: function () {
					printInput( $('#eos-details-preview-text', context) );
				}
			},
			{
				text: 'Ready for review',
				click: function () {
						
					$.main.ajaxRequest({
						modName: 'write',
						pageName: 'eos',
						action: 'saveEosDetails',
						queryString: $(context).find('.include-in-form').serializeWithSpaces(),
						success: null
					});

					$.main.ajaxRequest({
						modName: 'write',
						pageName: 'eos',
						action: 'setEosStatus',
						queryString: 'publicationId=' + params.publicationid + '&status=1',
						success: setPublicationCallback
					});
				}
			},
			{
				text: 'Save',
				click: function () {
						
					$.main.ajaxRequest({
						modName: 'write',
						pageName: 'eos',
						action: 'saveEosDetails',
						queryString: $(context).find('.include-in-form').serializeWithSpaces(),
						success: setPublicationCallback
					});
				}
			},
			{
				text: 'Cancel',
				click: function () { $(this).dialog('close') }
			}
		]);
	}
	
	$('#eos-details-tabs', context).newTabs({selected: 0});

	// show/hide 'Print preview' button depending on which tab is active
	// and update the preview text
	$('a[href^="#eos-details-tabs-"]', context).click( function () {
		if ( $(this).attr('href') == '#eos-details-tabs-preview' ) {
			$(":button:contains('Print preview')").show();

			var obj_eos = new Object();


			var obj_eos = new Object();
			
			obj_eos.handler = $('#eos-details-handler', context).val();
			obj_eos.first_co_handler = $('#eos-details-first-co-handler', context).val();
			obj_eos.second_co_handler = $('#eos-details-second-co-handler', context).val();
			obj_eos.general_info = $('#eos-details-general-info-text', context).val();
			obj_eos.vulnerabilities_threats = $('#eos-details-vulnerabilities-and-threats-text', context).val();
			obj_eos.incident_info = $('#eos-details-incident-info-text', context).val();
			obj_eos.community_news = $('#eos-details-community-news-text').val();
			obj_eos.media_exposure = $('#eos-details-media-exposure-text').val();
			obj_eos.tlp_amber = $('#eos-details-tlp-amber-text').val();

			var timeframe_begin_date = $('#eos-details-timeframe-start-date', context).val().replace(/^(\d+)-(\d+)-(\d\d\d\d)$/ , "$2-$1-$3");
			obj_eos.timeframe_begin = timeframe_begin_date + ' ' + $('#eos-details-timeframe-begin-time', context).val();

			var timeframe_end_date = $('#eos-details-timeframe-end-date', context).val().replace(/^(\d+)-(\d+)-(\d\d\d\d)$/ , "$2-$1-$3");
	        obj_eos.timeframe_end = timeframe_end_date + ' ' + $('#eos-details-timeframe-end-time', context).val();
			

			var queryString = 'publicationJson=' + encodeURIComponent(JSON.stringify(obj_eos)) 
				+ '&publication=eos'
				+ '&publicationid=' + params.publicationid
				+ '&publication_type=email'
				+ '&line_width=0';
			
			$.main.ajaxRequest({
				modName: 'write',
				pageName: 'common_actions',
				action: 'getPulicationPreview',
				queryString: queryString,
				success: getPulicationPreviewCallback
			});
			
		} else {
			$(":button:contains('Print preview')").hide();
		}
	});

	// change close event for this dialog, so it will include clearing the opened_by of the end-of-shift
	$.main.activeDialog.bind( "dialogclose", function(event, ui) { 

		if ( 
			$.main.lastRequest.action != 'getPublicationItemHtml' 
			|| ( $.main.lastRequest.action == 'getPublicationItemHtml' && $.main.lastRequest.queryString.indexOf( 'id=' + params.publicationid ) == -1 ) 
		) {
			$.main.ajaxRequest({
				modName: 'write',
				pageName: 'publications',
				action: 'closePublication',
				queryString: 'id=' + params.publicationid,
				success: reloadEosHtml
			});			
		}
		
		if ( $('.dialogs:visible').size() == 0 ) {
			$('#screen-overlay').hide();
		}
	});

	// trigger click on first tab to display the correct buttons 
	$('a[href="#eos-details-tabs-general"]', context).trigger('click');
	
	setEosUIBehavior( context );
}

function openDialogPreviewEosCallback ( params ) {
	var context = $('#form-eos-preview[data-publicationid="' + params.publicationid + '"]');

	var buttonsArray = new Array(),
		buttonSettingsArray = new Array(),
		status = 0;
	
	if ( params.isLocked == 0 ) {
		// available button settings:
		// [ { text: "Set to Pending", status: 0 }, { text: "Ready for review", status: 1 } , { text: "Approve", status: 2 } ]
		switch (params.currentStatus) {
			case 0:
				buttonSettingsArray.push( { text: "Ready for review", status: 1 } );
				break;
			case 1:
				buttonSettingsArray.push( { text: "Set to Pending", status: 0 } );
				if ( params.executeRight == 1 ) {
					buttonSettingsArray.push( { text: "Approve", status: 2 }  );
				}
				break;
		};

		$.each( buttonSettingsArray, function (i, buttonSettings) {

			var button = {
				text: buttonSettings.text,
				click: function () { 
					$.main.ajaxRequest({
						modName: 'write',
						pageName: 'eos',
						action: 'setEosStatus',
						queryString: 'publicationId=' + params.publicationid + '&status=' + buttonSettings.status,
						success: setPublicationCallback
					});				
				}
			}
			buttonsArray.push( button );
		});
	}
		
	buttonsArray.push(
		{
			text: 'Print preview',
			click: function () { 
				printInput( $('#eos-preview-text', context) );				
			}
		}
	);

	buttonsArray.push(
			{
			text: 'Close',
			click: function () { $.main.activeDialog.dialog('close') }
		}
	);
	
	// add buttons to dialog
	$.main.activeDialog.dialog('option', 'buttons', buttonsArray);
	$(":button:contains('Print preview')").css('margin-left', '20px');

	// initialize tagging
	$('#eos-preview-tags', context).newAutocomplete();
	$('#btn-eos-preview-save-tags', context).click( function () {
		saveTags( $('#eos-preview-eos-id', context), 'publication_endofshift', $('#eos-preview-tags', context) );	
	});

	// change close event for this dialog, so it will include clearing the opened_by of the advisory
	$.main.activeDialog.bind( "dialogclose", function(event, ui) { 

		if ( 
			$.main.lastRequest.action != 'getPublicationItemHtml' 
			|| ( $.main.lastRequest.action == 'getPublicationItemHtml' && $.main.lastRequest.queryString.indexOf( 'id=' + params.publicationid ) == -1 ) 
		) {
			$.main.ajaxRequest({
				modName: 'write',
				pageName: 'publications',
				action: 'closePublication',
				queryString: 'id=' + params.publicationid,
				success: reloadEosHtml
			});			
		}
		
		if ( $('.dialogs:visible').size() == 0 ) {
			$('#screen-overlay').hide();
		}
	});
}


//TODO: maak 1 saveNewCallback in common_actions
function saveNewEosCallback ( params ) {
	if ( params.saveOk == 1 ) {

		$.main.activeDialog.dialog('close');
		
		$.main.ajaxRequest({
			modName: 'write',
			pageName: 'publications',
			action: 'getPublicationItemHtml',
			queryString: 'insertNew=1&id=' + params.publicationId + '&pubType=eos',
			success: getPublicationItemHtmlCallback
		});
		
		$('#content').spin(false);
		
	} else {
		alert( params.message );
	}
}

function getPublicationsAndVTNewsCallback ( params ) {
	if ( params.message == null ) {
		
		if ( params.sentPublications == '' ) {
			alert('No publications or news found for selected timeframe.')
		} else {
			var context = $('#eos-details-form[data-publicationid="' + params.publicationId + '"]');
			$('#eos-details-vulnerabilities-and-threats-text', context).html( params.sentPublications );
			$('#eos-details-vulnerabilities-and-threats-text', context).val( $('#eos-details-vulnerabilities-and-threats-text', context).text() );
		}
	} else {
		alert(params.message);
	}
}

function getMediaExposureItemsCallback ( params ) {
	if ( params.message == null ) {
		
		if ( params.mediaExposureItems == '' ) {
			alert('No publications or news found for selected timeframe.')
		} else {
			var context = $('#eos-details-form[data-publicationid="' + params.publicationId + '"]');
			$('#eos-details-media-exposure-text', context).html( params.mediaExposureItems );
			$('#eos-details-media-exposure-text', context).val( $('#eos-details-media-exposure-text', context).text() );
		}
	} else {
		alert(params.message);
	}
}

function setEosUIBehavior (context ) {

    // add timepicker to time input elements
    $('.time', context).each( function() {
    	$(this).timepicker({ 'scrollDefaultNow': true, 'timeFormat': 'H:i' });
    });
    
    // change value of begin-time input elements when begin of timeframe changes
    $('#eos-details-timeframe-begin-time', context).change( function () {
    	$('input[id$="-begin-time"]', context).each( function() {
    		if ( $(this).attr('id') != 'eos-details-timeframe-begin-time' ) {
    			$(this).val( $('#eos-details-timeframe-begin-time', context).val() );
    		}
    	});
    });    

    // change value of end-time input elements when end of timeframe changes
    $('#eos-details-timeframe-end-time', context).change( function () {
    	$('input[id$="-end-time"]', context).each( function() {
    		if ( $(this).attr('id') != 'eos-details-timeframe-end-time' ) {
    			$(this).val( $('#eos-details-timeframe-end-time', context).val() );
    		}
    	});
    });    
    
    // change value of start-date input elements when start-date of timeframe changes
    $('#eos-details-timeframe-start-date', context).change( function () {
    	$('input[id$="-start-date"]', context).each( function() {
    		if ( $(this).attr('id') != 'eos-details-timeframe-start-date' ) {
    			$(this).val( $('#eos-details-timeframe-start-date', context).val() );
    		}
    	});
    });    

    // change value of end-date input elements when end-date of timeframe changes
    $('#eos-details-timeframe-end-date', context).change( function () {
    	$('input[id$="-end-date"]', context).each( function() {
    		if ( $(this).attr('id') != 'eos-details-timeframe-end-date' ) {
    			$(this).val( $('#eos-details-timeframe-end-date', context).val() );
    		}
    	});
    });       
    
    // set all date and time field to initial value
    $('#eos-details-timeframe-start-date', context).trigger('change');
    $('#eos-details-timeframe-end-date', context).trigger('change');
    $('#eos-details-timeframe-begin-time', context).trigger('change');
    $('#eos-details-timeframe-end-time', context).trigger('change');

    // tab Vulnerabilities and threats, button 'Apply Selection'
    // this will add publications and
    // news items (added for this publication on Assess page) 
    $('#btn-eos-details-apply-vulnerabilities-and-threats', context).click( function () {
    	if ( 
    			$('#eos-details-vulnerabilities-and-threats-start-date', context).val() == '' 
    			|| $('#eos-details-vulnerabilities-and-threats-end-date', context).val() == '' 
    			|| $('#eos-details-vulnerabilities-and-threats-begin-time', context).val() == ''
    			|| $('#eos-details-vulnerabilities-and-threats-end-time', context).val() == ''
    			) {
    		alert('Please select a time frame');		
    	} else {
    	
	    	if ( validateForm(['eos-details-vulnerabilities-and-threats-start-date', 'eos-details-vulnerabilities-and-threats-end-date']) ) {
	
	    		var queryString = 'publicationTypeId=' + $('#eos-details-publication-type-id', context).val()
	    			+ '&publicationid=' + $(context).attr('data-publicationid')
	    			+ '&begin_date=' + $('#eos-details-vulnerabilities-and-threats-start-date', context).val()
	    			+ '&end_date=' + $('#eos-details-vulnerabilities-and-threats-end-date', context).val()
	    			+ '&begin_time=' + $('#eos-details-vulnerabilities-and-threats-begin-time', context).val()
	    			+ '&end_time=' + $('#eos-details-vulnerabilities-and-threats-end-time', context).val();

				$.main.ajaxRequest({
					modName: 'write',
					pageName: 'eos',
					action: 'getPublicationsAndVTNews',
					queryString: queryString,
					success: getPublicationsAndVTNewsCallback
				});
	    	}
	    }
    });

    // tab media exposure, button 'Apply Selection'
    // this will media exposure items (added for this publication on Assess page) 
    $('#btn-eos-details-apply-media-exposure', context).click( function () {
    	if ( 
    			$('#eos-details-media-exposure-start-date', context).val() == '' 
    			|| $('#eos-details-media-exposure-end-date', context).val() == '' 
    			|| $('#eos-details-media-exposure-begin-time', context).val() == ''
    			|| $('#eos-details-media-exposure-end-time', context).val() == ''
    			) {
    		alert('Please select a time frame');		
    	} else {
    	
	    	if ( validateForm(['eos-details-media-exposure-start-date', 'eos-details-media-exposure-end-date']) ) {
	    		
	    		var queryString = 'publicationTypeId=' + $('#eos-details-publication-type-id', context).val()
	    			+ '&publicationid=' + $(context).attr('data-publicationid')
	    			+ '&begin_date=' + $('#eos-details-media-exposure-start-date', context).val()
	    			+ '&end_date=' + $('#eos-details-media-exposure-end-date', context).val()
	    			+ '&begin_time=' + $('#eos-details-media-exposure-begin-time', context).val()
	    			+ '&end_time=' + $('#eos-details-media-exposure-end-time', context).val();

				$.main.ajaxRequest({
					modName: 'write',
					pageName: 'eos',
					action: 'getMediaExposureItems',
					queryString: queryString,
					success: getMediaExposureItemsCallback
				});	    		
	    	}
	    }    	
    });    
}

function reloadEosHtml ( params ) {
	$.main.ajaxRequest({
		modName: 'write',
		pageName: 'publications',
		action: 'getPublicationItemHtml',
		queryString: 'insertNew=0&id=' + params.id + '&pubType=eos',
		success: getPublicationItemHtmlCallback
	});
}
