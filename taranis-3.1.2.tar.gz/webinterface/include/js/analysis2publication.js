/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
function openDialogAnalysisToPublicationCallback ( params ) {
	var context = 'fieldset[data-analysisid="' + params.id + '"]';
	
	$.main.activeDialog.dialog('option', 'buttons', [
		{
			text: 'Create',
			click: function () {
				var analysisToPublicationAction = null,
					analysisToPublicationCallback = null,
					analysisToPublicationPage = null,
					queryString = 'analysisId=' + params.id;
				
				switch ( $("#analysis-to-publication-type option:selected", context).val() ) {
					case 'advisory':
						analysisToPublicationAction = 'openDialogNewAdvisory';
						analysisToPublicationCallback = 'openDialogNewAdvisoryCallback';
						analysisToPublicationPage = 'advisory';
						break;
					case 'advisory_update':
						analysisToPublicationAction = 'openDialogAnalysisToPublicationUpdate';
						analysisToPublicationCallback = 'openDialogAnalysisToPublicationUpdateCallback';
						analysisToPublicationPage = 'analysis2publication';
						queryString += '&pubclicationType=advisory';
						break;
					case 'advisory_import':
						analysisToPublicationAction = 'openDialogImportAdvisory';
						analysisToPublicationCallback = 'openDialogImportAdvisoryCallback';
						analysisToPublicationPage = 'advisory';
						queryString += '&emailItemId=' + $('#analysis-to-publication-import-source', context).val();
						break;
					default:
						alert('No can do');
				}
				
				$.main.ajaxRequest({
					modName: 'write',
					pageName: analysisToPublicationPage,
					action: analysisToPublicationAction,
					queryString: queryString,
					success: analysisToPublicationCallback
				});
				
				$.main.activeDialog.html('<fieldset>loading...</fieldset>');
			}
		},
		{
			text: 'Cancel',
			click: function () { $(this).dialog('close') }
		}
	]);

	// show/hide the source selection for advisory import
	if ( $('#analysis-to-publication-import-source', context).length > 0 ) {
		$('#analysis-to-publication-type', context).change( function () {
			if ( $(this).val() == 'advisory_import' ) {
				$('#analysis-to-publication-import-settings', context).show();
			} else {
				$('#analysis-to-publication-import-settings', context).hide();
			}
		});
	}
	
}

function openDialogAnalysisToPublicationUpdateCallback ( params ) {
	var tabsContext = 'div[id="analysis-to-publication-tabs"][data-analysisid="' + params.id + '"]';
	
	// init tabs
 	$(tabsContext).tabs({
 		select: function (event,ui) {
 			if ( $(ui.tab).attr('href') == '#analysis-to-publication-tabs-2' ) {
 				$('#analysis-to-publication-search-results').triggerHandler('change');
 			} else {
 				$('#analysis-to-publication-publication-id-match').triggerHandler('change');
 			}
 		}
 	});
	
	// change existing dialog width
	$.main.activeDialog.dialog('option', 'width', '700px');
	
	// add dialog buttons
	$.main.activeDialog.dialog('option', 'buttons', [
		{
			text: 'Create',
			click: function () {
				var analysisToPublicationAction = null,
					analysisToPublicationCallback = null,
					analysisToPublicationPage = null,
					queryString = 'analysisId=' + params.id;
				
				switch ( $(tabsContext).attr('data-publicationtype') ) {
					case 'advisory':
						analysisToPublicationAction = 'openDialogUpdateAdvisory';
						analysisToPublicationCallback = 'openDialogUpdateAdvisoryCallback';
						analysisToPublicationPage = 'advisory';
						break;
					default:
						alert('No can do');
				}
				
				$.main.ajaxRequest({
					modName: 'write',
					pageName: analysisToPublicationPage,
					action: analysisToPublicationAction,
					queryString: 'id=' + $.main.activeDialog.find('.analysis-to-publication-select:visible').val() + '&analysisId=' + params.id,
					success: analysisToPublicationCallback
				});
				
				$.main.activeDialog.html('<fieldset>loading...</fieldset>');
			}
		},
		{
			text: 'Preview publication',
			click: function () {
				
				var pubType = $(tabsContext).attr('data-publicationtype');

				var action = 'openDialogPreview' + pubType.charAt(0).toUpperCase() + pubType.slice(1);
				
				var dialog = $('<div>').newDialog();
				dialog.html('<fieldset>loading...</fieldset>');

				$.main.ajaxRequest({
					modName: 'write',
					pageName: pubType,
					action: action,
					queryString: 'id=' + $.main.activeDialog.find('.analysis-to-publication-select:visible').val() + '&pubType=' + pubType,
					success: action + 'Callback'
				});		
				
				dialog.dialog('option', 'title', 'Publication preview');
				dialog.dialog('option', 'width', '850px');
				dialog.dialog({
					buttons: {
						'Close': function () {
							$(this).dialog( 'close' );
						}
					}
				});

				dialog.dialog('open');				
			}
		},	
		{
			text: 'Cancel',
			click: function () { $(this).dialog('close') }
		}
	]); 	
 	
	// search publications
	$('#btn-analysis-to-publication-search', tabsContext).click( function () {

		var search = encodeURIComponent( $('#analysis-to-publication-search', tabsContext).val() );

		$.main.ajaxRequest({
			modName: 'write',
			pageName: 'analysis2publication',
			action: 'searchPublicationsAnalysisToPublication',
			queryString: 'search=' + search + '&publicationtype=' + $(tabsContext).attr('data-publicationtype') + '&id=' + params.id,
			success: searchPublicationsAnalysisToPublicationCallback
		});
	});

	// search publications when pressing enter
	$('#analysis-to-publication-search', tabsContext).keyup( function(e) {
		if ( e.keyCode == 13 ) {
			$('#btn-analysis-to-publication-search', tabsContext).trigger('click');
		}
		e.preventDefault();
		return false;
	});

	// enable/disable buttons 'Create' and 'Preview publication' depending on wether a publication is selected
	$('#analysis-to-publication-publication-id-match, #analysis-to-publication-search-results', tabsContext).change( function () {
		if ( $(this).val() == null ) {
			$(":button:contains('Create')")
				.prop('disabled', 'disabled')
				.addClass('ui-state-disabled');

			$(":button:contains('Preview publication')")
				.prop('disabled', 'disabled')
				.addClass('ui-state-disabled');
		} else {
			$(":button:contains('Create')")
				.prop('disabled', null)
				.removeClass('ui-state-disabled');
				
			$(":button:contains('Preview publication')")
				.prop('disabled', null)
				.removeClass('ui-state-disabled');
		}
	});
 
 	$('#analysis-to-publication-publication-id-match', tabsContext).triggerHandler('change');	
}

function searchPublicationsAnalysisToPublicationCallback ( params ) {

	if ( params.message ) {
		alert( params.message );
	} else {
		var context = 'div[id="analysis-to-publication-tabs"][data-analysisid="' + params.id + '"]';
		
		// remove old results
		$('#analysis-to-publication-search-results option', context).each( function () {
			$(this).remove();
		});
		
		// add new results
		$.each( params.publications, function () {
			$('<option />')
				.val( this.publication_id )
				.text( this.named_id + " [v" + this.version + "] " + this.publication_title )
				.appendTo('#analysis-to-publication-search-results');
		});
		
		$('#analysis-to-publication-search-results').triggerHandler('change');
	}
}
