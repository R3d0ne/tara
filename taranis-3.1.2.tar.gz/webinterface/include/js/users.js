/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
$( function () {
	
	// edit/view user details
	$('#content').on( 'click', '.btn-edit-user, .btn-view-user', function () {
		var dialog = $('<div>').newDialog();
		dialog.html('<fieldset>loading...</fieldset>');
		
		$.main.ajaxRequest({
			modName: 'configuration',
			pageName: 'users',
			action: 'openDialogUserDetails',
			queryString: 'id=' + $(this).attr('data-id'),				
			success: openDialogUserDetailsCallback
		});
		
		dialog.dialog('option', 'title', 'User details');
		dialog.dialog('option', 'width', '850px');
		dialog.dialog({
			buttons: {
				'Close': function () {
					$(this).dialog( 'close' );
				}
			}
		});

		dialog.dialog('open');
	});
	
	// delete a user
	$('#content').on( 'click', '.btn-delete-user', function () {
		if ( confirm('Are you sure you want to delete the user?') ) { 
			$.main.ajaxRequest({
				modName: 'configuration',
				pageName: 'users',
				action: 'deleteUser',
				queryString: 'id=' + $(this).attr('data-id'),				
				success: deleteConfigurationItemCallback
			});		
		}		
	});
	
	// add a new user
	$('#filters').on( 'click', '#btn-add-user', function () {

		var dialog = $('<div>').newDialog();
		dialog.html('<fieldset>loading...</fieldset>');
	
		$.main.ajaxRequest({
			modName: 'configuration',
			pageName: 'users',
			action: 'openDialogNewUser',
			success: openDialogNewUserCallback
		});		
		
		dialog.dialog('option', 'title', 'Add new user');
		dialog.dialog('option', 'width', '850px');
		dialog.dialog({
			buttons: {
				'Close': function () {
					$(this).dialog( 'close' );
				}
			}
		});
		
		dialog.dialog('open');
	});

	// search user
	$('#filters').on('click', '#btn-users-search', function () {
		$.main.ajaxRequest({
			modName: 'configuration',
			pageName: 'users',
			action: 'searchUsers',
			queryString: $('#form-users-search').serializeWithSpaces(),
			success: null
		});
	});
	
	// do constituent individual search on ENTER
	$('#filters').on('keypress', '#users-filters-search', function (event) {
		if ( !checkEnter(event) ) {
			event.preventDefault();
			$('#btn-users-search').trigger('click');
		}
	});
	
});

function openDialogNewUserCallback ( params ) {
	if ( params.writeRight == 1 ) { 
		var context = $('#users-details-form[data-id="NEW"]');

		$.main.activeDialog.dialog('option', 'buttons', [
			{
				text: 'Save',
				click: function () {

					if ( $("users-details-username").val() == "") {
						alert("Please specify a username.");	
					} else if ( $("uses-details-fullname").val() == "") {
						alert("Please specify a Full Name.");
					} else if ( $("users-details-mail-from-email").val() == "") {
						alert("Please specify an Email address.");
					} else if ( $("users-details-mail-from-sender").val() == "") {
						alert("Please specify an Email Name.");
					}  else {
					
						$('#users-details-membership-roles option', context).each( function (i){
							$(this).prop('selected', true);
						});
						
						$.main.ajaxRequest({
							modName: 'configuration',
							pageName: 'users',
							action: 'saveNewUser',
							queryString: $(context).serializeWithSpaces(),
							success: saveUserCallback
						});					
					}
				}
		    },			                                                 
			{
				text: 'Cancel',
				click: function () { $(this).dialog('close') }
			}
		]);

		$('input[type="text"]', context).keypress( function (event) {
			return checkEnter(event);
		});
		
		$('#users-details-tabs', context).newTabs();
		
	}
}

function openDialogUserDetailsCallback ( params ) {
	var context = $('#users-details-form[data-id="' + params.id + '"]');
	$('#users-details-tabs', context).newTabs();
	
	if ( params.writeRight == 1 ) { 

		$.main.activeDialog.dialog('option', 'buttons', [
			{
				text: 'Save',
				click: function () {

					if ( $("uses-details-fullname").val() == "") {
						alert("Please specify a Full Name.");
					} else if ( $("users-details-mail-from-email").val() == "") {
						alert("Please specify an Email address.");
					} else if ( $("users-details-mail-from-sender").val() == "") {
						alert("Please specify an Email Name.");
					} else {
					
						$('#users-details-membership-roles option', context).each( function (i){
							$(this).prop('selected', true);
						});
						
						$.main.ajaxRequest({
							modName: 'configuration',
							pageName: 'users',
							action: 'saveUserDetails',
							queryString: $(context).serializeWithSpaces() + '&id=' + params.id,
							success: saveUserCallback
						});					
					}
				}
		    },			                                                 
			{
				text: 'Cancel',
				click: function () { $(this).dialog('close') }
			},
			{
				text: 'Close',
				click: function () { $(this).dialog('close') }
			}			
		]);
		
		$('input[type="text"]', context).keypress( function (event) {
			return checkEnter(event);
		});

		$('#btn-user-details-change-password', context).click( function () {
			if ( $.trim( $('#users-details-change-password', context).val() ) != '' ) {
				$.main.ajaxRequest({
					modName: 'configuration',
					pageName: 'users',
					action: 'changeUserPassword',
					queryString: 'id=' + params.id + '&new_password=' + $('#users-details-change-password', context).val(),
					success: changeUserPasswordCallback
				});
			}
		})
		
		// show/hide 'validate template' button
		$('a[href^="#users-details-tabs-"]', context).click( function () {
			if ( $(this).attr('href') == '#users-details-tabs-change-password' ) {
				$(":button:contains('Close')").show();
				$(":button:contains('Cancel')").hide();
				$(":button:contains('Save')").hide();
			} else {
				$(":button:contains('Close')").hide();
				$(":button:contains('Cancel')").show();
				$(":button:contains('Save')").show();
			}
		});
		
	} else {
		$('input, select, textarea', context).each( function (index) {
			$(this).prop('disabled', true);
		});
	}
}

function saveUserCallback ( params ) {
	
	if ( params.saveOk ) {

		var queryString = 'id=' + params.id;
		
		if ( params.insertNew == 1 ) {
			queryString += '&insertNew=1';
		}
		
		$.main.ajaxRequest({
			modName: 'configuration',
			pageName: 'users',
			action: 'getUserItemHtml',
			queryString: queryString,
			success: getConfigurationItemHtmlCallback
		});
		
		$.main.activeDialog.dialog('close');
		$('#content').spin(false);
		
	} else {
		alert(params.message)
	}
}

function changeUserPasswordCallback ( params ) {
	if ( params.changeOk == 1 ) {
		alert( 'Password successfully changed!' );
	} else {
		alert( params.message );
	}
}
