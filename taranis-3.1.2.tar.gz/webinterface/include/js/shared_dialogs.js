/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
$( function () {

	// open the 'create analysis from assess item' dialog (assess2analyze)
	$(document).on('click', '.img-assess-item-analyze, #assess-details-digest, .btn-link-to-other-analysis', function () {
		
		var itemDigest = $(this).attr('data-digest');
		
		var hasClusteredItems = ( $('div[id="' + itemDigest +'"]').hasClass('item-top-cluster-row') ) ? 1 : 0;
		
		if ( itemDigest == undefined ) {
			itemDigest = $(this).val();
		}
		
		var dialog = $('<div>').newDialog();
		dialog.html('<fieldset>loading...</fieldset>');
		
		var queryString = 'digest=' + itemDigest + '&hasClusteredItems=' + hasClusteredItems; 
		if ( $(this).hasClass('btn-link-to-other-analysis') ) {
			queryString += '&ul=' + $(this).attr('data-analysisid');
		}

		$.main.ajaxRequest({
			modName: 'analyze',
			pageName: 'assess2analyze',
			action: 'displayAssessAnalysis',
			queryString: queryString,
			success: displayAssessAnalysisCallback
		});		
		
		// do not show dialog with content if user has no analysis_rights.read_right (assess2analyze) 
		dialog.dialog('option', 'title', 'Analyze item');
		dialog.dialog('option', 'width', '780px');
		dialog.dialog({
			buttons: {
				'Cancel': function () {
					$(this).dialog( 'close' );
				}
			}
		});

		dialog.dialog('open');
		
		if ( $(this).hasClass('img-assess-item-analyze') ) {
			$('.item-arrow:visible').hide();
			$('#' + itemDigest.replace(/%/g, '\\%') + ' .item-arrow').show();
		}
		// Continue with displayAssessAnalysisCallback in assess2anayze.js after AJAX request is done.
	});
	
	// open assess details dialog
	$(document).on('click', '.img-assess-item-details, .btn-analyze-assess-details, .assess-details-link', function () {
		
		var itemDigest = ( $(this).attr('data-digest') ) ? $(this).attr('data-digest') : $(this).attr('data-id'),
			queryString = 'digest=' + itemDigest; 
			
		if ( $(this).attr('data-isArchived') ) {
			queryString += '&is_archived=' + $(this).attr('data-isArchived');
		}
		
		var dialog = $('<div>').newDialog();
		dialog.html('<fieldset>loading...</fieldset>');

		$.main.ajaxRequest({
			modName: 'assess',
			pageName: 'assess_details',
			action: 'openDialogAssessDetails',
			queryString: queryString,
			success: openDialogAssessDetailsCallback
		});				
		
		dialog.dialog('option', 'title', 'Assessment details');
		dialog.dialog('option', 'width', '890px');
		dialog.dialog({
			buttons: [
			    {
					text: 'Close',
					click: function () {
						$(this).dialog( 'close' );
					}
			    }
			]
		});

		dialog.dialog('open');

		if ( $(this).hasClass('img-assess-item-details') ) {
			$('.item-arrow:visible').hide();
			$('#' + itemDigest.replace(/%/g, '\\%') + ' .item-arrow').show();
		}
		
	});

	// clicking on email items will open a dialog window showing the email.
	$(document).on('click', '.assess-item-title .span-link, .assess-email-item-link', function () {

		// the following replace is needed because of legacy 
		var queryString = $(this).attr('data-link').replace( /.*?(id=\d+)/, '$1');
		
		var dialog = $('<div>').newDialog();
		dialog.html('<fieldset>loading...</fieldset>');

		$.main.ajaxRequest({
			modName: 'assess',
			pageName: 'show_mail',
			action: 'displayMail',
			queryString: queryString,
			success: showmailCallback
		});		
		
		dialog.dialog('option', 'title', 'Email item details');
		dialog.dialog('option', 'width', '850px');
		dialog.dialog({
			buttons: {
				'Close': function () {
					$(this).dialog( 'close' );
				}
			}
		});

		dialog.dialog('open');

		var itemDigest = $(this).attr('data-id');
		if ( itemDigest ) {
			$('.item-arrow:visible').hide();
			$('#' + itemDigest.replace(/%/g, '\\%') + ' .item-arrow').show();
		}		
		// Continue with showmailCallback() after AJAX request is done.
	});
	
});

function showmailCallback ( params ) {
//TODO: add context to selectors
	$('#assess-show-mail-tabs').newTabs({selected: 0});

	$('.assess-show-mail-attachment').click( function () {
		var downloadParams = new Object();
		downloadParams.id = $('#mailItemId').val();
		downloadParams.attachmentName = $(this).text();
		
		$('#downloadFrame').attr( 'src', 'loadfile/?modName=assess&pageName=download_attachment&action=downloadAttachment&params=' + JSON.stringify(downloadParams) );
	});
	
}
