/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
$( function () {

	// show/edit bigscreen settings
	$('#filters').on('click', '#btn-bigscreen-settings', function () {
		var dialog = $('<div>').newDialog();
		dialog.html('<fieldset>loading...</fieldset>');

		$.main.ajaxRequest({
			modName: 'tools',
			pageName: 'screen_settings',
			action: 'openDialogScreenSettings',
			queryString: 'tool=big_screen',
			success: openDialogScreenSettingsCallback
		});			
		
		dialog.dialog('option', 'title', 'Big Screen settings');
		dialog.dialog('option', 'width', '700px');
		dialog.dialog({
			buttons: {
				'Close': function () {
					$(this).dialog( 'close' );
				}
			}
		});

		dialog.dialog('open');
	});

	// show bigscreen 
	$('#filters').on('click', '#btn-view-big-screen', function () {
		childWindow = open( $.main.scriptroot + '/loadbigscreen/' , 'TheBigScreen', 'resizable=no,width=' + screen.width +',height=' + screen.height + ',screenX=0,screenY=0,scrollbars=no');
		childWindow.focus();
	});

});

function openDialogScreenSettingsCallback ( params ) {

	var context =  $('#form-screen-settings');

	if ( params.writeRight == 1 ) {
		
		// set buttons
		$.main.activeDialog.dialog('option', 'buttons', [
			{
				text: 'Save',
				click: function () {
					
					$('#screen-settings-resolution').prop('disabled', false);

					$.each( $('#screen-settings-selected-security-news-sources, #screen-settings-selected-security-vulnerability-sources, #screen-settings-selected-news-sources').children(), function ( i, source ) {
						$(this).prop('selected', true);
					});
					
					var screenOrder =  $('#screen-settings-sortable').sortable('toArray');

					$.main.ajaxRequest({
						modName: 'tools',
						pageName: 'screen_settings',
						action: 'saveScreenSettings',
						queryString: $(context).serializeWithSpaces() + '&tool=big_screen&screenOrder=' + encodeURIComponent( JSON.stringify( screenOrder ) ),
						success: saveScreenSettingsCallback
					});
				}
			},
			{
				text: 'Cancel',
				click: function () { $(this).dialog('close') }
			}
		]);
		
		
	} else {
		$.main.activeDialog.dialog('option', 'buttons', [
			{
				text: 'Close',
				click: function () { $(this).dialog('close') }
			}
		]);
	}
	
	// init tabs
	$('#screen-settings-tabs').newTabs();

	$("#screen-settings-sortable").sortable( { placeholder: 'ui-state-highlight'} );
	$("#screen-settings-sortable").css('cursor' , 'move');
	$("#screen-settings-sortable").disableSelection();

	// disable the resolution selection when auto detec resolution is enabled
	$('#screen-settings-auto-detect-resolution').click( function () {
		if ( $(this).is(':checked') ) {
			$('#screen-settings-resolution').prop('disabled', true);
		} else {
			$('#screen-settings-resolution').prop('disabled', false);
		}
	});		

	$('#screen-settings-auto-detect-resolution').triggerHandler('click');
	
	//add item to Screen Order
	$('#btn-add-screen').click( function () {
		var itemSelected = $('#screen-settings-add-screen option:selected').text();

		$('#btn-delete-screen')
			.attr({ 'src': $.main.webroot + '/images/icon_delete.png', 'title': 'remove screen'})
			.css('cursor', 'pointer');
		
		var newItem = $('<li />')
			.attr( 'id', itemSelected )
			.text( ' ' + itemSelected )
			.addClass('ui-state-default')
			.appendTo( $('#screen-settings-sortable') );

		$('<img />')
			.attr({ 'src': $.main.webroot + '/images/icon_delete.png',
				'alt': 'delete screen',
				'id': 'btn-delete-screen',
				'title' : 'remove screen'
			})
			.addClass('pointer')
			.prependTo( newItem );
	});
	
	//remove item from Screen Order
	$(document).on( 'click', '#btn-delete-screen', function () {
		if ( $('#screen-settings-sortable').children().length > 1 ) {

			$(this).parent().remove();

			if ( $('#screen-settings-sortable').children().length == 1 ) {
				$('#btn-delete-screen')
					.attr({ 'src': $.main.webroot + '/images/icon_delete_disabled.png', 'title': ''})
					.css('cursor', 'move')
					.unbind( 'click' );
			}
		} 
	});	

	if ( $('#screen-settings-sortable').children().length == 1 ) {
		$('#btn-delete-screen')
			.attr({ 'src': $.main.webroot + '/images/icon_delete_disabled.png', 'title': ''})
			.css('cursor', 'move')
			.unbind( 'click' );
	}
	
	//announcements and assess screens: slider for selecting the font-size 
	$("#screen-settings-announcement-slider").slider({ 
		min: 20, 
		max: 80,
		value: params.announcementTextSize,
		slide: function(event, i) {
			$('#screen-settings-announcement-text-size').css('font-size', i.value + 'px');
			$('#screen-settings-announcement-text-size-value').val(i.value);
		} 
	});	

	$('#screen-settings-announcement-text-size').css('font-size', params.announcementTextSize + 'px' );
	
	//welcomeScreen: slider for selecting the font-size 
	$("#screen-settings-welcome-screen-text-size-slider").slider({ 
		min: 20, 
		max: 80,
		value: params.welcomeTextSize,
		slide: function(event, i) {
			$('#screen-settings-welcome-screen-text-size').css('font-size', i.value + 'px');
			$('#screen-settings-welcome-screen-text-size-value').val( i.value );
		} 
	});
	
	$('#screen-settings-welcome-screen-text-size').css('font-size', params.welcomeTextSize + 'px' );
	
	// securityNews settings: remove available items that are in selected list
	checkRightColumnOptions( $('#screen-settings-selected-security-news-sources'), $('#screen-settings-available-security-news-sources'));

	// securityVulnerability settings: remove available items that are in selected list
	checkRightColumnOptions( $('#screen-settings-selected-security-vulnerability-sources'), $('#screen-settings-available-security-vulnerability-sources'));

	// news settings: remove available items that are in selected list
	checkRightColumnOptions( $('#screen-settings-selected-news-sources'), $('#screen-settings-available-news-sources'));
	
	$('#content').spin(false);
}

function saveScreenSettingsCallback ( params ) {
	if ( params.saveOk == 1 ) {
		$.main.activeDialog.dialog('close');		
		$('#content').spin(false);
	} else {
		alert(params.message);
		$('#content').spin(false);
	}
}
