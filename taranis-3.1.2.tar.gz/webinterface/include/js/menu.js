/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
$( function () {
	
	// hover on main-menu item
	$('.menu-item').hover( 
		function () {
			// hover in
			var hoverOn = $(this).attr('id').replace( /(.*?)\-.*/, '$1');
			$('.selected-submenu').hide();
			$('#' + hoverOn + '-submenu').show();
			$(this).addClass('hover-menu');
			
			if ( $(this).attr('id') != $('.selected-menu').attr('id') ) {
				$('.selected-menu').addClass('hover-submenu');
			}
		},
		function () {
			// hover out
			var hoverOut = $(this).attr('id').replace( /(.*?)\-.*/, '$1');
			$('#' + hoverOut + '-submenu').hide();
			$('.selected-submenu').show();
			$(this).removeClass('hover-menu');
			$('.selected-menu').removeClass('hover-submenu');
		}
	);

	// move mouse over the submenu
	$('.submenu').mouseover( function () {
		var hoverOn = $(this).attr('id').replace( /(.*?)\-.*/, '$1');
		if ( $('#' + hoverOn + '-menu').hasClass('top-menu-item') == false ) {
			$('#' + hoverOn + '-menu').addClass('hover-menu');
	
			if ( $('#' + hoverOn + '-menu').attr('id') != $('.selected-menu').attr('id') ) {
				$('.selected-menu').addClass('hover-submenu');
			}
		}
		$('.selected-submenu').hide();
		$(this).show();
	});

	// move mouse out of the area of the submenu
	$('.submenu').mouseout( function () {
		var hoverOn = $(this).attr('id').replace( /(.*?)\-.*/, '$1');
		$('#' + hoverOn + '-menu').removeClass('hover-menu');
		$('.selected-menu').removeClass('hover-submenu');
		$(this).hide();
		$('.selected-submenu').show();
	});	
	
	// click on a main-menu item or sub-menu item
	$('.menu-item, .submenu-item').click( function () {
		$('.selected-menu').removeClass('hover-submenu');
		$('.selected-menu').removeClass('selected-menu');
		$('.selected-submenu').removeClass('selected-submenu');
		
		var clickedOnId = ( $(this).hasClass('submenu-item') ) ? $(this).parent().attr('id'): $(this).attr('id') ;
		var clickedOn = clickedOnId.replace( /(.*?)\-.*/, '$1');

		$('#' + clickedOn + '-menu').addClass('selected-menu');
		$('#' + clickedOn + '-submenu').addClass('selected-submenu');
		
		if ( $(this).hasClass('submenu-item') ) {
			if ( clickedOn == 'assess' ) {
				stopAssessTimer()
				$('#super-secret-link').attr('data-callback', 'startAssessTimer');
			}
			$('#super-secret-link')
				.attr('href', $(this).attr('data-url'))
				.trigger('click');
		}
	});
	
	// click on Assess main menu item will show all items of today for all allowed categories.
	$('#assess-menu').click( function () {
		stopAssessTimer()
		$('#super-secret-link').attr('data-callback', 'startAssessTimer');
		$('#super-secret-link').attr('href', 'assess/assess/displayAssess/');
		$('#super-secret-link').trigger('click');
	});
	
	// click on Analyze main menu item will show all analysis
	$('#analyze-menu').click( function () {
		$('#super-secret-link').attr('href', 'analyze/analyze/displayAnalyze/');
		$('#super-secret-link').trigger('click');
	});	
	
	// click on Write main menu item will show the publication options
	$('#write-menu').click( function () {
		$('#super-secret-link').attr('href', 'write/publications/displayPublicationOptions/');
		$('#super-secret-link').trigger('click');
	});		

	// click on Publish main menu item will show the publication options
	$('#publish-menu').click( function () {
		$('#super-secret-link').attr('href', 'publish/publish/displayPublishOptions/');
		$('#super-secret-link').trigger('click');
	});		

	// click on Tools main menu item will show the publication options
	$('#tools-menu').click( function () {
		$('#super-secret-link').attr('href', 'tools/toolspage/displayToolOptions/');
		$('#super-secret-link').trigger('click');
	});		
	
	// click configuration menu item
	$('#configuration-menu').click( function () {
		$('.selected-menu').removeClass('hover-submenu');
		$('.selected-menu').removeClass('selected-menu');
		$('.selected-submenu')
			.hide()
			.removeClass('selected-submenu');
		
		$('#configuration-submenu')
			.addClass('selected-submenu')
			.trigger('mouseover');
		$('#configuration-submenu').trigger('mouseout')
	});
});
