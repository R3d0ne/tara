/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
function validateTemplate() {
	try {
		// code for IE
		if (window.ActiveXObject) {
			var xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
			xmlDoc.async = "false";
			xmlDoc.loadXML(document.all("template").value);
	
			if (xmlDoc.parseError.errorCode != 0) {
				var txt = "Error Code: " + xmlDoc.parseError.errorCode + "\n";
				txt = txt + "Error Reason: " + xmlDoc.parseError.reason;
				txt = txt + "Error Line: " + xmlDoc.parseError.line;
				throw txt;
				//alert(txt);
			} else {
				throw "No errors found";
				//				alert("No errors found");
			}
		}
		// code for Mozilla, Firefox, Opera, etc.
		else if (document.implementation && document.implementation.createDocument) {
			var parser = new DOMParser();
			var text = document.getElementById("publication-template-details-template").value;
			var xmlDoc = parser.parseFromString(text, "text/xml");
			text = text.replace(/\n/gi, "");
			var manditory_fields_pattern = new RegExp("^<publication>.*<template>.*<fields>");
			if (xmlDoc.documentElement.nodeName == "parsererror") {
				throw xmlDoc.documentElement.childNodes[0].nodeValue;
				//alert(xmlDoc.documentElement.childNodes[0].nodeValue);
			} else if ( !manditory_fields_pattern.test(text) ) {
				throw "Fields are not properly defined. \nThe following are manditory: \n\n - <publication> \n - <template> \n - <fields>  ";
				//alert("Fields are not properly defined. \nThe following are manditory: \n\n - <publication> \n - <template> \n - <fields>  ");
			} else {
				throw "No errors found.";
				//alert("No errors found");
			}
		} else {
			throw "Your browser cannot handle this script.";
			//alert('Your browser cannot handle this script');
		}
	}
	catch ( err ) {
		alert( err );
		return true;
	}
}
