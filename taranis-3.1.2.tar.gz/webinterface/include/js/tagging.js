/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
// jQuery UI autocomplete wrapper for tagging
$.fn.newAutocomplete = function (idElement, type, inputElement) {
		
	function split( val ) {
		return val.split( /,\s*/ );
	}
	function extractLast( term ) {
		return split( term ).pop();
	}

	$(this)
		// don't navigate away from the field on TAB-key when selecting an item
		.bind( "keydown", function( event ) {
			if ( event.keyCode === $.ui.keyCode.TAB ) {
				event.preventDefault();
			}
		})
		.autocomplete({
			source: function( request, response ) {
				$.getJSON( 'loadfile/?modName=tagging&pageName=tag&action=getList', {
					term: extractLast( request.term )
				}, response );
			},
			search: function() {
				// custom minLength
				var term = $.trim( extractLast( this.value ) );
				if ( term.length < 1 ) {
					return false;
				}
			},
			focus: function() {
				// prevent value inserted on focus
				return false;
			},
			select: function( event, ui ) {
				var terms = split( this.value );
				// remove the current input
				terms.pop();
				// add the selected item
				terms.push( ui.item.value );
				// add placeholder to get the comma-and-space at the end
				terms.push( "" );
				this.value = terms.join( ", " );
				return false;
			}
		});		
	return $(this);
}

function saveTags ( idElement, type, inputElement ) {
	var tags = encodeURIComponent( $(inputElement).val() );
	var itemId = $(idElement).val();
	var tagType = encodeURIComponent( type );

	$.main.ajaxRequest({
		modName: 'tagging',
		pageName: 'tag',
		action: 'setTags',
		queryString: 'tags=' + tags + '&item_id=' + itemId + '&t_name=' + tagType,
		success: setTagsCallback
	});	
}

function setTagsCallback ( params ) {

	if ( $('.tags-button[data-tagsid="' + params.tagsid + '"]').siblings('.tags-result').length > 0 ) {
		// set tags result
		$('.tags-button[data-tagsid="' + params.tagsid + '"]').siblings('.tags-result').text(params.message);
	} else {
		// set tags result
		$('.tags-button[data-tagsid="' + params.tagsid + '"]').after('<span class="tags-result">' + params.message + '</span>');

		// remove tags result message when typing in tags input field.
		$('.tags-button[data-tagsid="' + params.tagsid + '"]').siblings('.tags-input').keyup( function () {
			$('.tags-button[data-tagsid="' + params.tagsid + '"]').siblings('.tags-result').text('');
		});
	}
}
