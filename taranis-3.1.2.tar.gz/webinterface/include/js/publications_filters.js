/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
$( function () {
	
	// search publications
	$('#filters').on('click', '#btn-publications-search', function (event, origin) {
		if ( origin != 'pagination' && $('#hidden-page-number').length > 0) {
			$('#hidden-page-number').val('1');
		}
		
		var datesAreValid = true; // initially dates are empty, which is valid
		if ( $("input:checkbox:checked[name='status']").length > 0 ) {
			
			if ( $('#publications-start-date').val() != '' && $('#publications-end-date').val() != '' ) {
				datesAreValid = validateForm(['publications-start-date', 'publications-end-date']);
			} else if ( $('#publications-start-date').val() != '' || $('#publications-end-date').val() != '' ) {
				datesAreValid = false;
				alert('Please set both From and To date leave both empty.');
			}

			if ( datesAreValid ) {
				
				$.main.ajaxRequest({
					modName: 'write',
					pageName: 'publications',
					action: 'searchPublications',
					queryString: $('#form-publications-search').serializeWithSpaces(),
					success: null
				});
			}
		} else {
			alert("At least one of the status options must be checked to perform search.");    		  
		}
	});
	
	// pressing enter in searchfield of filters section will trigger clicking the search button
	$('#filters').on( 'keypress', '#publications-search', function (event) {
		if ( !checkEnter(event) ) {
			$('#btn-publications-search').trigger('click', 'searchOnEnter');
		}
	});
	
	// open dialog to create a new publication
	$('#filters').on('click', '.btn-publications-new', function () {
		var pubType = $(this).attr('data-pubtype');
		var action = 'openDialogNew' + pubType.charAt(0).toUpperCase() + pubType.slice(1);
		
		var dialog = $('<div>').newDialog();
		dialog.html('<fieldset>loading...</fieldset>');
	
		$.main.ajaxRequest({
			modName: 'write',
			pageName: pubType,
			action: action,
			success: action + 'Callback'
		});		
		
		dialog.dialog('option', 'title', 'Create new publication');
		dialog.dialog('option', 'width', '840px');
		dialog.dialog({
			buttons: {
				'Close': function () {
					$(this).dialog( 'close' );
				}
			}
		});

		dialog.dialog('open');
	});
	
});
