/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
$( function () {
	
	$('#filters').on('click', '#btn-import-export-sources', function () {
		var dialog = $('<div>').newDialog();
		dialog.html('<fieldset>loading...</fieldset>');
	
		$.main.ajaxRequest({
			modName: 'configuration',
			pageName: 'sources_import_export',
			action: 'openDialogImportExportSources',
			success: openDialogImportExportSourcesCallback
		});		
		
		dialog.dialog('option', 'title', 'Import/Export Sources');
		dialog.dialog('option', 'width', '850px');
		dialog.dialog({
			buttons: {
				'Close': function () {
					$(this).dialog( 'close' );
				}
			}
		});
		
		dialog.dialog('open');		
	});	
	
});

function openDialogImportExportSourcesCallback ( params ) {

	$('#sources-import-export-tabs').newTabs();
	
	$.main.activeDialog.dialog('option', 'buttons', [
		{
			text: 'Import',
			click: function () {
				$('#sources-import-export-tabs').tabs('disable', 1);

				$(":button:contains('Import'), :button:contains('Export')")
					.prop('disabled', 'disabled')
					.addClass('ui-state-disabled');
				
				var importData = new FormData( document.getElementById('sources-import-export-form-import') );
				
				importData.append('modName', 'configuration');
				importData.append('pageName', 'sources_import_export');
				importData.append('action', 'importSources');
				
				$('#sources-import-export-form-import').hide();
				$('#sources-import-export-processing-import').removeClass('hidden');

				$.ajax({
					url: $.main.scriptroot + '/load/',
					data: importData,
					processData: false,
					type: 'POST',
					contentType: false,
					dataType: 'JSON',
					success: function ( result ) {
								if ( result.session_ok ) {
									if ( result.is_success ) {
										$.main.activeDialog.html( result.page.dialog );
										
										$.main.activeDialog.dialog('option', 'buttons', [
											{
												text: 'Close',
												click: function () { $(this).dialog('close') }
											}
										]);
										
										$('#sources-import-tabs').newTabs();
									} else {
										$('#sources-import-export-tabs').tabs('enable', 1);
										$(":button:contains('Import'), :button:contains('Export')")
											.prop('disabled', null)
											.removeClass('ui-state-disabled');
										
									}
								}
							}
				});
				
			}
		},
		{
			text: 'Export',
			click: function () {
				var exportParams = new Object();
				
				exportParams.protocols = new Array();
				exportParams.categories= new Array();
				exportParams.parsers = new Array();
				exportParams.languages = new Array();
				
				$('#sources-export-selected-protocols option').each( function (i) {
					exportParams.protocols.push( $(this).val() );	
				});

				$('#sources-export-selected-categories option').each( function (i) {
					exportParams.categories.push( $(this).val() );	
				});
				
				$('#sources-export-selected-languages option').each( function (i) {
					exportParams.languages.push( $(this).val() );	
				});

				$('#sources-export-selected-parsers option').each( function (i) {
					exportParams.parsers.push( $(this).val() );	
				});
				
				$('#downloadFrame').attr( 'src', 'loadfile/?modName=configuration&pageName=sources_import_export&action=exportSources&params=' + JSON.stringify( exportParams ) );
			}
		}
	]);
	
	// show/hide Import/Export buttons
	$('a[href^="#sources-import-export-tabs-"]').click( function () {
		if ( $(this).attr('href') == '#sources-import-export-tabs-import' ) {
			$(":button:contains('Import')").show();
			$(":button:contains('Export')").hide();
		} else {
			$(":button:contains('Import')").hide();
			$(":button:contains('Export')").show();
		}
	});
	
	$('a[href="#sources-import-export-tabs-import"]').triggerHandler('click');
	
}
