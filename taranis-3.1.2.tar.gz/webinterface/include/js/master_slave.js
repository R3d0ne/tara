/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
$(function () {
	
	$('#content').on('click', '.pointer#master, .pointer#slave', function() {

		$.main.ajaxRequest({
			modName: 'tools',
			pageName: 'master_slave',
			action: 'setMasterSlave',
			queryString: 'tool=master_slave&set=' + $(this).attr('id'),
			success: setMasterSlaveCallback
		});		
    });
});

function setMasterSlaveCallback ( params ) {
	
	if ( params.changeOk == 1 ) {
		if ( params.newSetting == 'master' ) {
			$('#master')
				.removeClass('strikethrough pointer')
				.addClass('bold');
			$('#slave')
				.removeClass('bold')
				.addClass('strikethrough pointer');
		} else {
			$('#slave')
				.removeClass('strikethrough pointer')
				.addClass('bold');
			$('#master')
				.removeClass('bold')
				.addClass('strikethrough pointer');
		}
	} else {
		alert(params.message);
	}
}
