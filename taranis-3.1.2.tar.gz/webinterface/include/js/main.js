/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
$.main = {};
function initMain ( webroot, scriptroot, userid, shortcut ) {
	$.main.webroot = webroot;
	$.main.scriptroot = scriptroot;
	$.main.userid = userid;
	$.main.shortcut = shortcut;
	$.main.loadedScripts = new Array();
	$.main.activeDialog = null;
	$.main.lastRequest = null;
	$.main.assessTimer = null;
	$.main.analyzeTimer = null;
	$.main.dashboardTimer = null;
}
$( function () {
	
	// catch F5 key (page refresh) and trigger
	$(document).keydown( function (e) {
		
		var refreshPageLookup = { 
				'assess-menu': '#btn-assess-search',
				'analyze-menu': '#btn-analyze-search',
				'write-menu': '#btn-publications-search'
			};
		var characterCode 
		try {
			if (e && e.which) { 
				e = e
				characterCode = e.which
			} else {
				e = event
				characterCode = e.keyCode 
			}
			if(characterCode == 116){
				var selectedMainMenu = $('.selected-menu').attr('id');
				if ( selectedMainMenu in refreshPageLookup ) {
					e.preventDefault();
					$( refreshPageLookup[selectedMainMenu] ).trigger('click');
					return false
				}
			}
			return true;
		}
		catch (err) {
			return true;
		}		
	});
	
	// timer for refreshing Assess page items
	$.main.assessTimer = $.timer( function () {
		if ( $('.selected-submenu').attr('id') == 'assess-submenu' ) {

			var queryString = ( $('#btn-assess-search').is(':visible') )
				? $('#form-assess-standard-search').serializeWithSpaces()
				: $('#form-assess-custom-search').serializeWithSpaces() + '&isCustomSearch=1';
			
			queryString += '&resultCount=' + $('#assess-result-count').text(); 
			if ( $('.item-arrow:visible').parent().attr('id') ) {
				queryString += '&currentItemID=' + $('.item-arrow:visible').parent().attr('id');
			}
			
			$.main.ajaxRequest({
				modName: 'assess',
				pageName: 'assess',
				action: 'refreshAssessPage',
				queryString: queryString,
				success: 'refreshAssessPageCallback'
			}, true);
			
		} else {
			stopAssessTimer();
		}
	}, 300000 ); // 300000 ms = 5 minutes

//	// timer for refreshing Analyze page items
//	$.main.analyzeTimer = $.timer( function () {
//		if ( $('.selected-submenu').attr('id') == 'analyze-submenu' ) {
//
//			var queryString = ( $('#btn-analyze-search').is(':visible') )
//				? $('#form-assess-standard-search').serializeWithSpaces()
//				: $('#form-assess-custom-search').serializeWithSpaces() + '&isCustomSearch=1';
//			
//			queryString += '&resultCount=' + $('#assess-result-count').text(); 
//			if ( $('.item-arrow:visible').parent().attr('id') ) {
//				queryString += '&currentItemID=' + $('.item-arrow:visible').parent().attr('id');
//			}
//			
//			$.main.ajaxRequest({
//				modName: 'analyze',
//				pageName: 'analyze',
//				action: 'refreshAnalyzePage',
//				queryString: queryString,
//				success: 'refreshAnalyzePageCallback'
//			}, true);
//			
//		} else {
//			stopAnalyzeTimer();
//		}
//	}, 300000 ); // 300000 ms = 5 minutes	
	
	// timer for refreshing dashboard data
	$.main.dashboardTimer = $.timer( function () {
		$.main.ajaxRequest({
				modName: 'dashboard',
				pageName: 'dashboard',
				action: 'getMinifiedDashboardData',
				success: null
		}, true);
		
		if ( $('.dashboard-block:visible').size() > 0 ) {
			$.main.ajaxRequest({
				modName: 'dashboard',
				pageName: 'dashboard',
				action: 'getDashboardData',
				success: 'getDashboardDataCallback'
			}, true);
		}			
	}, 60000 ); // 60000 ms = 1 minute
	
	// init the spinner
	$.fn.spin = function(opts) {
		this.each(function() {
			var $this = $(this),
				data = $this.data();

			if (data.spinner) {
				data.spinner.stop();
				delete data.spinner;
			}
			if (opts !== false) {
				data.spinner = new Spinner( $.extend({color: $this.css('color'), top: 0, left: 0}, opts) ).spin(this);
			}
		});
		return this;
	};	

	// Clicking on a pagination button will relocate the hidden input field 'hidden-page-number'
	// after the specified data-filterbutton, which should be in the same form as the filter input fields.
	$.fn.pagebar = function () {
		var pagebarButtons = $(this);
		
		$.each( pagebarButtons, function(i, pagebarButton) {
			$(pagebarButton).click( function () {

				var filterButton = $(this).parent('#pagination').attr('data-filterbutton');
				if ( $('#' + filterButton).siblings('#hidden-page-number').length > 0 ) {
					$('#hidden-page-number').val( $(this).attr('data-pagenumber') );
				} else {
					$('<input type="hidden" id="hidden-page-number" name="hidden-page-number">')
						.val( $(this).attr('data-pagenumber') )
						.insertAfter('#' + filterButton);
				}
				// The extra pagination parameter is used to tell what origin the click (search) event is.
				// The bound click event for the filterbutton should set the value of the hidden-page-number
				// to 1 if the origin is not 'pagination'.
				$('#' + filterButton).trigger('click', 'pagination');
			});
		});
	}	

	// create new dialogs with jQuery UI dialog wrapper
	$.fn.newDialog = function () {
		var dialog = $(this)
						.html('<fieldset>loading...</fieldset>')
						.addClass('dialogs')
						.dialog({
							autoOpen: false,
							title: 'Loading...',
							modal: false,
							position: 'top',
							resizable: false,
							open: function (event, ui) {
								if ( $('#screen-overlay').is(':visible') == false ) {

									var screenHeight = $(document).height();
									$('#screen-overlay')
										.css({ 'height': screenHeight + 'px' })
										.show();
								}
							},
							close: function (event,ui) {

								if ( $('.ui-dialog:visible').size() == 0 ) {
									$('#screen-overlay').hide();
								} else {
									// set focus to the last opened dialog
									$( $('.ui-dialog:visible')[ $('.ui-dialog:visible').size() -1]).children('.ui-dialog-content').trigger('dialogfocus');
								}
								
								// completely remove created dialog. 
								$(this).remove();
							}
						})
						.on( 'dialogfocus', function( event, ui ) {
							// 'move' other dialog to background
							if ( $.main.activeDialog ) {
								$.main.activeDialog.parent().css('opacity', '0.7');
							}
							
							$.main.activeDialog = $(this);
							// 'move' focussed dialog to foreground
							$.main.activeDialog.parent().css('opacity', '1');
								
							var screenHeight = $(document).height();
	
							$('#screen-overlay')
								.css({ 'height': screenHeight + 'px' })
								.show();							
						})
						.appendTo('#diaglog');

		return $(this);
	}
	
	$.fn.newTabs = function () {
		var tabs = $(this).tabs({
			activate: function (event, ui) {
				$.main.activeDialog.trigger('dialogfocus');
			}
		});
		return $(this);
	}
	
	// serialize forms with jQuery serialize, but keep the spaces.
	$.fn.serializeWithSpaces = function () {
		var serialized = $(this).serialize();
		return serialized.replace(/\+/g, ' ');
	}
	
	// clicking on a link (or triggering a click on the 'super-secret-link) will do a AJAX request to index.pl
	$(document).on('click', 'a', function(event) {
		
		if ( $(this).attr('href') == undefined || $(this).attr('href').charAt(0) == '#' ) {
			event.preventDefault();
			return false;
		} else if ( $(this).attr('href').indexOf('http') == 0 ) {
			return true;
		} else {
			event.preventDefault();

			// strip off last slash if present
			var url = $(this).attr('href').replace( /(.*?)\/?$/, "$1" );
			
			var url_arr = url.split('/');
	
			var modName = url_arr[0];
			var pageName = url_arr[1];
			var action = url_arr[2];
			var queryString = url_arr[3]
			
			var linkCallback = null;
			if ( $(this).attr('data-callback') ) {
				linkCallback = $(this).attr('data-callback');
				$(this).removeAttr('data-callback');
			} 

			if ( pageName == 'logout' ) {
				$('#main-wrapper').toggle('drop');
				$('#dashboard-minified').hide();
			}
			
			$.main.ajaxRequest({
				modName: modName,
				pageName: pageName,
				action: action,
				queryString: queryString,
				success: linkCallback
			});			
		}
	});

	// hover block show
	$('#content').on('mouseenter', '.hover-block', function () { 
		$('.hover-block-content', this).show();
	});

	// hover block hide
	$('#content').on('mouseleave', '.hover-block', function () { 
		$('.hover-block-content', this).hide();
	});
	
	// first page load of main, show the assess page 
	if ( $('#content').html() == '' ) {
		
		if ( $.main.shortcut ) {
			
			var shortcut = JSON.parse( $.main.shortcut )
			
			if ( shortcut.menuitem ) {
				$('.selected-menu').removeClass('hover-submenu');
				$('.selected-menu').removeClass('selected-menu');
				$('.selected-submenu').removeClass('selected-submenu');
				
				$('#' + shortcut.menuitem + '-menu').addClass('selected-menu');
				$('#' + shortcut.menuitem + '-submenu').addClass('selected-submenu');
			}
			
			$.main.ajaxRequest({
				modName: shortcut.modname,
				pageName: shortcut.scriptname,
				action: shortcut.action,
				queryString: shortcut.parameters,
				success: shortcut.action + 'Callback'
			}, false);
	
		} else {
			$.main.ajaxRequest({
				modName: 'dashboard',
				pageName: 'dashboard',
				action: 'getDashboardData',
				success: 'getDashboardDataCallback'
			}, true);
		}
		
		$.main.ajaxRequest({
			modName: 'dashboard',
			pageName: 'dashboard',
			action: 'getMinifiedDashboardData',
			success: null
		}, true);

	}
	
	$.main.dashboardTimer.play(true);
});

/*
 * @param {Object} request - consists of the following properties:
 * - modName
 * - pageName
 * - action
 * - queryString
 * - success
 * 
 * @param {Boolean} noSpinner - prevents the spinner and overlay from showing, default is false  
 */
$.main.ajaxRequest = function ( request, noSpinner ) {
	$('#error').html('');

	noSpinner = ( typeof noSpinner !== 'undefined' ) ? noSpinner : false;
	
    var filtersWrapperPosition = $("#filters-wrapper").offset();
    var overLayHeight = $('#filters-wrapper').height() + $('#content').height();
    
    if ( $('#screen-overlay').is(':visible') == false && noSpinner == false ) {
		$('#box-overlay')
	    	.css({
	    		left: filtersWrapperPosition.left, 
	    		top: filtersWrapperPosition.top, 
	    		width: $("#content-wrapper").width() + "px",
	    		height: overLayHeight + "px"
	    	})
			.show();

		$('#box-overlay-spinner')
			.spin( {
			  lines: 11, // The number of lines to draw
			  length: 12, // The length of each line
			  width: 20, // The line thickness
			  radius: 40, // The radius of the inner circle
			  color: '#000', // #rbg or #rrggbb
			  corners: 0.5, // Corner roundness (0..1)
			  speed: 1.2, // Rounds per second
			  trail: 60, // Afterglow percentage
			  shadow: true, // Whether to render a shadow
			  top: 50,
			  left: 'auto'
			});
    }
    
//    if ( $('.selected-submenu').attr('id') != 'assess-submenu' ) {
//    	stopAssessTimer();
//    }
    
	var params = new Object();
	if ( request.queryString !== undefined ) {
		// if query starts with '&', remove it.
		if ( request.queryString.indexOf('&') == 0 ) {
			request.queryString = request.queryString.substr(1);
		}

		// create key/value datastructure of input parameters
		$.each( request.queryString.split('&'), function (i, kvPair) {
			var k = kvPair.substr(0, kvPair.indexOf('='));
			var v = kvPair.substr(kvPair.indexOf('=') +1);
			if ( k in params ) {
				if ( typeof params[k] === 'object' ) {
					params[k].push(v);
				} else {
					params[k] = [v, params[k]];	
				}
			} else {
				params[k] = v;
			}
		});
	}
	
	$.ajaxSetup({ cache: false });
	
	$.post(
			$.main.scriptroot + '/load/',
			{ 
				'modName': request.modName,
				'pageName': request.pageName,
				'action': request.action,
				'params': JSON.stringify(params)
			},
			function (result) {
				if ( result.session_ok ) {
					if ( result.is_success ) {

						// load page filters html
						if ( result.page.filters ) {
							$('#filters').html( result.page.filters );
							// rebind the datepicker to .date-picker elements
							$('.date-picker').datepicker({dateFormat: "dd-mm-yy"});

							$('.btn-option-to-left').on('click', moveOptionToLeft);
							$('.btn-option-to-right').on('click', moveOptionToRight);
						}
						
						// load page content html
						if ( result.page.content ) {
							$('#content').html( result.page.content );
							$('.btn-pagebar').pagebar();
						}

						// load dashboard html
						if ( result.page.dashboard ) {
							$('#dashboard-minified-content').html( result.page.dashboard.html );
						}
						
						// load dialog html
						if ( result.page.dialog ) {
							
							$.main.activeDialog.html( result.page.dialog );
							
							// rebind the datepicker to .date-picker elements
							$('.date-picker').datepicker({dateFormat: "dd-mm-yy"});

							$('.btn-option-to-left').on('click', moveOptionToLeft);
							$('.btn-option-to-right').on('click', moveOptionToRight);
						}
						
						// load js scripts (once)
						if ( result.page.js ) {
							$.each( result.page.js, function( index, jsScript ) {
								if ( $.inArray( jsScript, $.main.loadedScripts ) == -1 ) {
									$.getScript( $.main.webroot + '/include/' + jsScript );
									$.main.loadedScripts.push( jsScript );
								} 
							});
						}
						
						// run callback function if present
						if ( typeof request.success === 'function' ) {
							var resultParams = ( result.page.params ) ? result.page.params : [];
							request.success(resultParams);
						} else if ( typeof request.success === 'string' && typeof window[request.success] === 'function' ) {
							var resultParams = ( result.page.params ) ? result.page.params : [];
							window[request.success](resultParams);
						} else { 
//							console.log('no callback? ' + request.success);
						}
						
						if ( noSpinner == false ) {
							// remove the spinner
							$('#box-overlay-spinner').spin( false );
							$('#box-overlay').hide();
						}
						
					} else {
						// handle error
						$('#content').html('<span>' + result.message + ' (0)</span>');

						// remove the spinner
						$('#box-overlay-spinner').spin( false );
						$('#box-overlay').hide();						
					}
				} else {
					// handle no session
					window.location = 'login/?ent=' + result.message;
				}
			}, 'json'
	);
	
	$.main.lastRequest = request;
}

function startAssessTimer ( params ) {
	$.main.assessTimer.play(true);

	// update assess items with linked (CVE) id's info
	var relatedIdsQueryString = ''
	$('.relatedID[data-checked="no"]').each( function (i) {
		relatedIdsQueryString += '&ids=' + $(this).attr('data-digest');
		$(this).attr('data-checked', 'yes');
	});

	$.main.ajaxRequest({
		modName: 'assess',
		pageName: 'assess',
		action: 'getRelatedIds',
		queryString: relatedIdsQueryString,
		success: function ( callbackParams ) {
			$.each( callbackParams.identifiers, function (itemDigest, identifiers) {
				$('.relatedID[data-digest="' + encodeURIComponent(itemDigest) + '"]')
					.attr('title', 'This item has ' + identifiers.length + ' related IDs')
					.removeClass('hidden');
			});
		}
	});

	// update assess items with added-to-publication-settings
	var addedToPublicationQueryString = ''
	$('.addToPublicationOptionHeader[data-checked="no"]').each( function (i) {
		addedToPublicationQueryString += '&ids=' + $(this).attr('data-digest');
		$(this).attr('data-checked', 'yes');
	});
	
	$.main.ajaxRequest({
		modName: 'assess',
		pageName: 'assess',
		action: 'getAddedToPublication',
		queryString: addedToPublicationQueryString,
		success: function ( callbackParams ) {
			$.each( callbackParams.publications, function (itemDigest, addedToPublicationSettingsArray) {
				$.each( addedToPublicationSettingsArray, function (i,addedToPublicationSetting) {
					$('.addToPublicationOption[data-digest="' + encodeURIComponent(itemDigest) + '"][data-publicationId="' + addedToPublicationSetting.publication_type + '"][data-specifics="' + addedToPublicationSetting.publication_specifics + '"]')
						.addClass('isAddedToPublication')
				})
			});
		}
	});
	
}

function stopAssessTimer () {
	$.main.assessTimer.stop();
}
