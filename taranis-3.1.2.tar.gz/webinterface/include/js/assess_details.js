/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
function openDialogAssessDetailsCallback ( params ) {
	
	var assessDetailsTabs = 'div[id="assess-details-tabs"][data-digest="' + params.digest + '"]';
	
	$(assessDetailsTabs).newTabs();
	
	$('#content').spin(false);

	$('#assess-details-tags', assessDetailsTabs).newAutocomplete();
	$('#btn-assess-details-save-tags', assessDetailsTabs).click( function () {
		saveTags( $('#assess-details-digest', assessDetailsTabs), 'item', $('#assess-details-tags', assessDetailsTabs) );	
	}); 
	
	if ( $('#assess-details-analyze-right', assessDetailsTabs).val() == 1 ) {
		
		$.main.activeDialog.dialog('option', 'buttons', [
			{
				text: 'Analyze',
				click: function () {
					if ( $('img.img-assess-item-analyze[data-digest="' + params.digest + '"]').length > 0 ) {
						$('img.img-assess-item-analyze[data-digest="' + params.digest + '"]').trigger('click');
					} else {
						$('#assess-details-digest', assessDetailsTabs).trigger('click')
					}
				}
		    },			                                                 
			{
				text: 'Close',
				click: function () { $(this).dialog('close') }
			}
		]);
	}

	var hoverConfig = {
			sensitivity: 4, // number = sensitivity threshold (must be 1 or higher)    
			interval: 400, // number = milliseconds for onMouseOver polling interval
			timeout: 300, // number = milliseconds delay before onMouseOut
			over: function () { // function = onMouseOver callback (REQUIRED)
				
				var cveID = $(this).text();
				
				$.main.ajaxRequest({
					modName: 'assess',
					pageName: 'assess_details',
					action: 'getRelatedId',
					queryString: 'id=' + cveID,
					success: getRelatedIdCallback
				});					
			},
			out: function () { // function = onMouseOut callback (REQUIRED)
				//Remove the appended tooltip template
				$(this).children('#tooltip').fadeOut("slow");
				// remove should to the trick, to really remove them
				$(this).children('#tooltip').remove();			
			}     
		};
	
	$('.id_string').hoverIntent(hoverConfig);	
}

//TODO: in jQuery UI 1.9 zit een tooltip widget. ontwikkeling van 1.9 is bijna klaar. 
function getRelatedIdCallback ( params ) {

	if ( params.identifier != '' ) {
		
		var idElement = $('#' + params.identifier); 
	
		//Remove the title attribute's to avoid the native tooltip from the browser
		idElement
			.attr('title','')
			.append('<div id="tooltip">');
							
			var offSet = idElement.offset(); 
			var offSetLeft = offSet.left;

		$("#tooltip")
			.append('<div class="tipHeader">')
			.append('<div class="tipBody">');
                
		$(".tipBody").html(params.description);           

		
		$(".tipHeader").append('<span class="cve_ID">');                 

		$('<img>')
			.attr({'id': 'close-tooltip', 'src':  $.main.webroot + '/images/cross_48.png'})
			.click( function () {
				$("#tooltip").remove();
			})
			.appendTo('.tipHeader');
                
		// Only show footer if we received an identifier 
		if( typeof( params.type ) != "UNKNOWN" ) {
			$(".cve_ID").html('<a href="http://cve.mitre.org/cgi-bin/cvename.cgi?name=' + params.identifier + '" target="_blank" >' + params.identifier + '</a>');
			$(".hideLinkAttr").css({'color': 'red', 'text-decoration' : 'underline'});
			$(".tipBody").append('<div id="mitre">');
			
			$("#mitre")
				.append('<div id="mitre_phase">')
				.append('<div id="mitre_status">');
                 
        	//$("#tooltip").append('<div class="tipFooter">'); 
            	 
			$("#mitre_phase")
				.html('Phase: ')
				.append('<span class="Blue" id="mPhase">');

			$("#mitre_status")
				.html('Status: ')
				.append('<span class="Blue"  id="mStatus">');
                
			$("#mPhase").html(params.phase  + '&nbsp;' +  params.phase_date);
			$("#mStatus").html(params.status);
                
			// put the mitre header <div> in front of the tipBody 
			$("#mitre").prependTo(".tipBody");
                    
			// Check if there are GOVERT-ID's and put them below the MITRE stuff 
			if ( params.ids.length > 0 ) {
				$("#tooltip").append('<div id="tipFooter" class="tipFooter">'); 
				$.each( params.ids, function (i, val) {
					$("#tipFooter").append('<div class="publicationAdvisory" id="' + params.ids[i].id+'">' + params.ids[i].govcertid);                    		
				});
//TODO: link naar advisory popup
//					$(".publicationAdvisory").each( function() { 
//						var openLink = 'openChild(\'/taranis/mod_write/advisory_preview.pl?id='+$(this).attr('id')+'\', \"win2\", 800, 720);';
//						$(this).attr('onclick', openLink);
//					});                    	
			}
		} else {
			$(".cve_ID").html(params.identifier);
		}

		var toolTipOffset = $("#tooltip").height() + 20;
			
		$("#tooltip").css({ 'top': '-' + toolTipOffset + 'px' , 'left': '0'});

		//Show the tooltip with fadeIn effect
		$('#tooltip').fadeIn('1000');
		$('#tooltip').fadeTo('10',0.9);
			
		$("#tooltip").draggable({ 'handle' : '.tipHeader' , 'containment' : 'window'});
	}
}
