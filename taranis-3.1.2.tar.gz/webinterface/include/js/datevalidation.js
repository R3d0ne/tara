/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
// Declaring valid date character, minimum year and maximum year
var dtCh= "-";
var minYear=1900;
var maxYear=2100;
var return_message = "Date entry error: ";

function isInteger(s){
	var i;
    for (i = 0; i < s.length; i++){   
        // Check that current character is number.
        var c = s.charAt(i);
        if (((c < "0") || (c > "9"))) return false;
    }
    // All characters are numbers.
    return true;
}

function stripCharsInBag(s, bag){
	var i;
    var returnString = "";
    // Search through string's characters one by one.
    // If character is not in bag, append to returnString.
    for (i = 0; i < s.length; i++){   
        var c = s.charAt(i);
        if (bag.indexOf(c) == -1) returnString += c;
    }
    return returnString;
}

function daysInFebruary (year){
	// February has 29 days in any year evenly divisible by four,
    // EXCEPT for centurial years which are not also divisible by 400.
    return (((year % 4 == 0) && ( (!(year % 100 == 0)) || (year % 400 == 0))) ? 29 : 28 );
}
function DaysArray(n) {
	for (var i = 1; i <= n; i++) {
		this[i] = 31
		if (i==4 || i==6 || i==9 || i==11) {this[i] = 30}
		if (i==2) {this[i] = 29}
   } 
   return this
}

function isDate(dtStr, id_input_field){
	var daysInMonth = DaysArray(12)
	var pos1=dtStr.indexOf(dtCh)
	var pos2=dtStr.indexOf(dtCh,pos1+1)
	var strDay=dtStr.substring(0,pos1)
	var strMonth=dtStr.substring(pos1+1,pos2)
	var strYear=dtStr.substring(pos2+1)
	strYr=strYear
	if (strDay.charAt(0)=="0" && strDay.length>1) strDay=strDay.substring(1)
	if (strMonth.charAt(0)=="0" && strMonth.length>1) strMonth=strMonth.substring(1)
	for (var i = 1; i <= 3; i++) {
		if (strYr.charAt(0)=="0" && strYr.length>1) strYr=strYr.substring(1)
	}
	month=parseInt(strMonth)
	day=parseInt(strDay)
	year=parseInt(strYr)
	if (pos1==-1 || pos2==-1){
//		alert("The date format should be : dd-mm-yyyy")
		return_message += "\nThe date format should be : dd-mm-yyyy (" +id_input_field+ ")"
		return false
	}
	if (strMonth.length<1 || month<1 || month>12){
//		alert("Please enter a valid month")
		return_message += "\nPlease enter a valid month (" +id_input_field+ ")"
		return false
	}
	if (strDay.length<1 || day<1 || day>31 || (month==2 && day>daysInFebruary(year)) || day > daysInMonth[month]){
//		alert("Please enter a valid day")
		return_message += "\nPlease enter a valid day (" +id_input_field+ ")"
		return false
	}
	if (strYear.length != 4 || year==0 || year<minYear || year>maxYear){
//		alert("Please enter a valid 4 digit year between "+minYear+" and "+maxYear)
		return_message += "\nPlease enter a valid 4 digit year between "+minYear+" and "+maxYear+ " (" +id_input_field+ ")"
		return false
	}
	if (dtStr.indexOf(dtCh,pos2+1)!=-1 || isInteger(stripCharsInBag(dtStr, dtCh))==false){
//		alert("Please enter a valid date")
		return_message += "\nPlease enter a valid date (" +id_input_field+ ")"
		return false
	}
return true
}

function checkLeadingZero( field_ids ) {
	for ( var i = 0; i < field_ids.length; i++ ) {
		var dtStr = document.getElementById( field_ids[i] ).value;

		var pos1=dtStr.indexOf( dtCh );
		var pos2=dtStr.indexOf( dtCh,pos1+1 );
		var strDay=dtStr.substring( 0,pos1 );
		var strMonth=dtStr.substring( pos1+1,pos2 );		
		var strYear=dtStr.substring(pos2+1)
		
		if ( strDay.charAt(0) != "0" && strDay.length == 1) {
			strDay = "0" + strDay;
		}
		
		if ( strMonth.charAt(0) != "0" && strMonth.length == 1) {
			strMonth = "0" + strMonth
		}
		
		document.getElementById( field_ids[i] ).value = strDay + dtCh + strMonth + dtCh + strYear;
	}
}

function validateForm(field_ids){
	var result = true
	var use_no_date = false
	
	for ( var i = 0; i < field_ids.length; i++ ) {
		var dt = document.getElementById(field_ids[i])
		
		if ( dt.value == "" ) {
			use_no_date = true
			break;
		}
		
		if ( isDate(dt.value, field_ids[i]) == false ){
			dt.focus()
			result = false
		}
	}
	
	if ( use_no_date ) {
		result = true
	} else if ( !result ) {
		alert( return_message )
		return_message = "Date entry error: "
	}
	
	if ( result && !use_no_date ) {
		checkLeadingZero(field_ids);
	}
	
	return result
}
