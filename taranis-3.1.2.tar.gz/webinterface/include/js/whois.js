/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
$( function () {

	$('#filters').on('click', '#btn-whois-search', function () {
		
		if ( $('#whois-host-search').val().match( /^([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])\.([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])\.([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])\.([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])$/ ) ) {

			$.main.ajaxRequest({
				modName: 'tools',
				pageName: 'whois',
				action: 'doWhoisLookup',
				queryString: 'tool=whois&whois=' + $('#whois-host-search').val(),
				success: null
			});

		} else {
			$.main.ajaxRequest({
				modName: 'tools',
				pageName: 'whois',
				action: 'getWhoisHost',
				queryString: 'tool=whois&whois=' + $('#whois-host-search').val(),
				success: null
			});
		}
	});

	$('#filters').on( 'keypress', '#whois-host-search', function (event) {
		if ( !checkEnter(event) ) {
			event.preventDefault();
			$('#btn-whois-search').trigger( 'click' );
		}
	});	
	
});
