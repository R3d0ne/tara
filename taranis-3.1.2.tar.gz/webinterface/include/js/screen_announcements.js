/*
 * Copyright 2013 NCSC-NL
 * 
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * 
 * http://ec.europa.eu/idabc/eupl
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and limitations under the Licence.
*/
$( function () {
	// add announcement or news
	$('#filters').on('click', '#btn-add-announcement-news', function () {
		var dialog = $('<div>').newDialog();
		dialog.html('<fieldset>loading...</fieldset>');

		$.main.ajaxRequest({
			modName: 'tools',
			pageName: 'screen_announcements',
			action: 'openDialogNewAnnouncement',
			queryString: 'tool=big_screen',
			success: openDialogNewAnnouncementCallback
		});			
		
		dialog.dialog('option', 'title', 'New Big Screen announcement');
		dialog.dialog('option', 'width', '500px');
		dialog.dialog({
			buttons: {
				'Close': function () {
					$(this).dialog( 'close' );
				}
			}
		});

		dialog.dialog('open');
	});
	
	// edit announcement / news
	$('#content').on('click', '.btn-bigscreen-item-edit, .btn-bigscreen-item-view', function () {
		var dialog = $('<div>').newDialog();
		dialog.html('<fieldset>loading...</fieldset>');

		$.main.ajaxRequest({
			modName: 'tools',
			pageName: 'screen_announcements',
			action: 'openDialogAnnouncementDetails',
			queryString: 'tool=big_screen&id=' + $(this).attr('data-itemid'),
			success: openDialogAnnouncementCallback
		});			
		
		dialog.dialog('option', 'title', 'Big Screen announcement');
		dialog.dialog('option', 'width', '500px');
		dialog.dialog({
			buttons: {
				'Close': function () {
					$(this).dialog( 'close' );
				}
			}
		});

		dialog.dialog('open');
	});

	// delete announcement / news
	$('#content').on('click', '.btn-bigscreen-item-delete', function () {
		
		if ( confirm('Are you sure you want to delete the announcement?') ) {
			$.main.ajaxRequest({
				modName: 'tools',
				pageName: 'screen_announcements',
				action: 'deleteAnnouncement',
				queryString: 'tool=big_screen&id=' + $(this).attr('data-itemid'),
				success: deleteAnnouncementCallback
			});					
		}		
	});
	
});

function openDialogNewAnnouncementCallback ( params ) {
	
	var context =  $('#form-screen-announcement[data-announcementid="NEW"]');

	if ( params.writeRight == 1 ) {
	
		$.main.activeDialog.dialog('option', 'buttons', [
			{
				text: 'Save',
				click: function () {
					$.main.ajaxRequest({
						modName: 'tools',
						pageName: 'screen_announcements',
						action: 'saveNewAnnouncement',
						queryString: $(context).serializeWithSpaces() + '&tool=big_screen&',
						success: updateAnnouncementList
					});
				}
			},
			{
				text: 'Cancel',
				click: function () { $(this).dialog('close') }
			}
		]);
	} else {
		$.main.activeDialog.dialog('option', 'buttons', [
			{
				text: 'Close',
				click: function () { $(this).dialog('close') }
			}
		]);
	}
	$('#content').spin(false);	
}

function openDialogAnnouncementCallback ( params ) {

	var context =  $('#form-screen-announcement[data-announcementid="' + params.id + '"]');

	if ( params.writeRight == 1 ) {
	
		$.main.activeDialog.dialog('option', 'buttons', [
			{
				text: 'Save',
				click: function () {
					$.main.ajaxRequest({
						modName: 'tools',
						pageName: 'screen_announcements',
						action: 'saveAnnouncementDetails',
						queryString: $(context).serializeWithSpaces() + '&tool=big_screen&id=' + params.id,
						success: updateAnnouncementList
					});
				}
			},
			{
				text: 'Cancel',
				click: function () { $(this).dialog('close') }
			}
		]);
	} else {
		$.main.activeDialog.dialog('option', 'buttons', [
			{
				text: 'Close',
				click: function () { $(this).dialog('close') }
			}
		]);
	}
	$('#content').spin(false);
}

function updateAnnouncementList ( params ) {
	
	if ( params.saveOk == 1 ) {
		if ( params.insertNew == 1 ) {
			$('#biscreen-content-heading').after( params.itemHtml );			
		} else {
			$('#' + params.id).html( params.itemHtml )
		}
		$.main.activeDialog.dialog('close');		
		$('#content').spin(false);
		
	} else {
		alert( params.message );
		$('#content').spin(false);
	}
}

function deleteAnnouncementCallback ( params ) {
	if ( params.deleteOk == 1 ) {
		$('#' + params.id).remove();
	} else {
		alert( params.message );
	}
}
