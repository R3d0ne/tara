#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use lib qw(/opt/taranis/pm );
use Taranis::Config;
use Taranis::Dashboard;
use Taranis::Template;
use Taranis qw(:all);
use JSON;
use File::Basename;
use Tie::IxHash;
use strict;

use Data::Dumper;

my $debug = 1;

print "\nDEBUG MODE\n" if ( $debug );

my $currentFilePath = dirname(__FILE__);
my $screenConfigFile = $currentFilePath . "/../conf/taranis.conf.dashboard.xml";
my $cfg = Taranis::Config->new( $screenConfigFile );
my $tt = Taranis::Template->new();
my $dab = Taranis::Dashboard->new();

my ( %loadedModules );
tie my %dashboardData, "Tie::IxHash";

my $dashboardHtml = '<div class="dashboard-content">';
my $minifiedDashboardHtml = '';
my @jsonData;

DASHBOARDITEM:
foreach my $dashboardItem ( @{ $cfg->{item} } ) {
	next DASHBOARDITEM if ( !$dashboardItem->{module} || !$dashboardItem->{dataProcessor} );

	# load dashboard module if it isn' t loaded yet
	if ( !exists( $loadedModules{ $dashboardItem->{module} } ) ) {
		eval {
			require $currentFilePath . "/../pm/Taranis/Dashboard/" . $dashboardItem->{module} . ".pm";
			my $module = 'Taranis::Dashboard::' . $dashboardItem->{module};
			$loadedModules{ $dashboardItem->{module} } = $module->new();
		} or do {
			next DASHBOARDITEM;
		};
	}

	my $dashboardModule = $loadedModules{ $dashboardItem->{module} };
	my $dataProcessor = $dashboardItem->{dataProcessor};
	
	# run method to generate statistics
	# generator methods should always return TRUE or FALSE
	if ( $dashboardItem->{dataGenerator} && $dashboardModule->can( $dashboardItem->{dataGenerator} ) ) {
		my $dataGenerator = $dashboardItem->{dataGenerator};
		if ( !$dashboardModule->$dataGenerator() ) {
			logErrorToSyslog( 'DASHBOARD ERROR: ' . $dashboardModule->{errmsg} );
		}
	}

	# run method to create JSON data and prepare data structur for template rendering
	if ( $dashboardModule->can( $dataProcessor ) ) {
		
		my $data = $dashboardModule->$dataProcessor();
		if ( ref( $data ) =~ /^HASH$/ ) {
			push @jsonData, $data;
		}
		
		if ( exists( $dashboardData{ $dashboardItem->{module} } ) ) {
			$dashboardData{ $dashboardItem->{module} }->{ $dashboardItem->{dataProcessor} } = 
				{ data => $data, showMinified => $dashboardItem->{showMinified} };
		} else {
			$dashboardData{ $dashboardItem->{module} } = {
				$dashboardItem->{dataProcessor} => {
					data => $data,
					showMinified => $dashboardItem->{showMinified}
				},
				'tpl' => $dashboardModule->{tpl},
				'tplMinified' => $dashboardModule->{tpl_minified}
			};
		}
	}
}

my %dashboardGroupsCollumns = ( left => [], right => [] );
my $dashboardGroupsCount = 0;

# run method to create HTML for dashboard
foreach my $dashboardGroupName ( keys %dashboardData ) {
	my $tpl = delete $dashboardData{ $dashboardGroupName }->{tpl};
	my $tplMinified = delete $dashboardData{ $dashboardGroupName }->{tplMinified};

	my $dashboardItemHtml = $tt->processTemplateNoHeader( $tpl , $dashboardData{ $dashboardGroupName }, 1 );
	my $minifiedDashboardItemHtml = $tt->processTemplateNoHeader( $tplMinified , $dashboardData{ $dashboardGroupName }, 1 );

	if ( $dashboardItemHtml ) {
		$dashboardGroupsCount++;

		if ( $dashboardGroupsCount % 2 ) {
			push @{ $dashboardGroupsCollumns{left} }, $dashboardItemHtml; 
		} else {
			push @{ $dashboardGroupsCollumns{right} }, $dashboardItemHtml;
		}
	}

	$minifiedDashboardHtml .= $minifiedDashboardItemHtml if ( $minifiedDashboardItemHtml );
}

foreach my $column ( 'left', 'right' ) {
	$dashboardHtml .= '<div class="block dashboard-column">';
	foreach my $groupHtml ( @{ $dashboardGroupsCollumns{$column} } ) {
		$dashboardHtml .= $groupHtml;
	}
	$dashboardHtml .= '</div>';
} 

$dashboardHtml .= '</div>';

# store dashboard
if ( !$dab->setDashboardItems( type => $dab->{maximized}, html => $dashboardHtml, json => to_json( \@jsonData ) ) ) {
	print "saving dashboard maximized failed: $dab->{errmsg}\n" if ( $debug );
	logErrorToSyslog( "saving dashboard maximized failed: $dab->{errmsg}\n" );
} else {
	print "Maximized OK\n" if ( $debug );
}

# store minified dashboard
if ( !$dab->setDashboardItems( type => $dab->{minified}, html => $minifiedDashboardHtml, json => '' ) ) {
	print "saving dashboard minified failed: $dab->{errmsg}\n" if ( $debug );
	logErrorToSyslog( "saving dashboard minified failed: $dab->{errmsg}\n" );
} else {
	print "Minified OK\n" if ( $debug );
}
