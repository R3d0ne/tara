--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: -
--

CREATE PROCEDURAL LANGUAGE plpgsql;


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: advisory_damage; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE advisory_damage (
    advisory_id integer NOT NULL,
    damage_id integer NOT NULL
);


--
-- Name: analysis; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE analysis (
    id character varying(8) NOT NULL,
    orgdate character varying(8),
    orgtime character varying(8),
    last_status_date character varying(8),
    last_status_time character varying(8),
    status character varying(15),
    title character varying(250),
    comments text,
    idstring text,
    rating integer,
    orgdatetime timestamp without time zone DEFAULT now(),
    last_status_change timestamp without time zone DEFAULT now(),
    joined_into_analysis character varying(8),
    opened_by character varying(50),
    owned_by character varying(50)
);


--
-- Name: analysis_publication; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE analysis_publication (
    analysis_id character varying(8) NOT NULL,
    publication_id integer NOT NULL
);


--
-- Name: calling_list_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE calling_list_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: calling_list; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE calling_list (
    id integer DEFAULT nextval('calling_list_id_seq'::regclass) NOT NULL,
    publication_id integer NOT NULL,
    group_id integer NOT NULL,
    is_called boolean DEFAULT false,
    locked_by character varying(50),
    comments character varying(250)
);


--
-- Name: category_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: category; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE category (
    id integer DEFAULT nextval('category_id_seq'::regclass) NOT NULL,
    name character varying(30) NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL
);


--
-- Name: checkstatus; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE checkstatus (
    source character varying(50) NOT NULL,
    "timestamp" character varying(10),
    comments character varying(50)
);


--
-- Name: cluster; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE cluster (
    id integer NOT NULL,
    language character varying(2) NOT NULL,
    threshold numeric NOT NULL,
    timeframe_hours integer NOT NULL,
    is_enabled boolean DEFAULT true,
    category_id integer NOT NULL,
    recluster boolean DEFAULT true NOT NULL
);


--
-- Name: cluster_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE cluster_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: cluster_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE cluster_id_seq OWNED BY cluster.id;    
    
    
--
-- Name: constituent_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE constituent_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: constituent_group; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE constituent_group (
    id integer DEFAULT nextval('constituent_group_id_seq'::regclass) NOT NULL,
    name character varying(150) NOT NULL,
    use_sh boolean NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    constituent_type integer NOT NULL,
    notes text,
    call_hh boolean DEFAULT false
);


--
-- Name: constituent_individual_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE constituent_individual_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: constituent_individual; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE constituent_individual (
    id integer DEFAULT nextval('constituent_individual_id_seq'::regclass) NOT NULL,
    call247 boolean NOT NULL,
    emailaddress character varying(100),
    firstname character varying(50) NOT NULL,
    lastname character varying(50) NOT NULL,
    role integer NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    tel_mobile character varying(12),
    tel_regular character varying(12),
    call_hh boolean DEFAULT false
);


--
-- Name: constituent_publication_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE constituent_publication_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: constituent_publication; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE constituent_publication (
    id integer DEFAULT nextval('constituent_publication_id_seq'::regclass) NOT NULL,
    type_id integer NOT NULL,
    constituent_id integer NOT NULL
);


--
-- Name: constituent_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE constituent_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: constituent_role; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE constituent_role (
    id integer DEFAULT nextval('constituent_role_id_seq'::regclass) NOT NULL,
    role_name character varying(50)
);


--
-- Name: constituent_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE constituent_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: constituent_type; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE constituent_type (
    id integer DEFAULT nextval('constituent_type_id_seq'::regclass) NOT NULL,
    type_description character varying(50) NOT NULL
);


--
-- Name: cpe_cve; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE cpe_cve (
    cve_id character varying(13) NOT NULL,
    cpe_id character varying(150) NOT NULL
);


--
-- Name: cpe_files; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE cpe_files (
    filename character varying(100) NOT NULL,
    last_change character varying(100) NOT NULL
);


--
-- Name: damage_description_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE damage_description_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: damage_description; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE damage_description (
    deleted boolean DEFAULT false NOT NULL,
    description character varying(255),
    id integer DEFAULT nextval('damage_description_id_seq'::regclass) NOT NULL
);


--
-- Name: dashboard; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dashboard (
    html text,
    json text,
    type integer NOT NULL
);


--
-- Name: download_files; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE download_files (
    file_url character varying(450) NOT NULL,
    last_change character varying(30),
    save_to character varying(250),
    name character varying(30) NOT NULL,
    filename character varying(100)
);


--
-- Name: email_item_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE email_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: email_item; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE email_item (
    id integer DEFAULT nextval('email_item_id_seq'::regclass) NOT NULL,
    digest character varying(50) NOT NULL,
    body text
);


--
-- Name: email_item_archive; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE email_item_archive (
    id character varying(16) NOT NULL,
    digest character varying(50) NOT NULL,
    body text
);


--
-- Name: entitlement_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE entitlement_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: entitlement; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE entitlement (
    id integer DEFAULT nextval('entitlement_id_seq'::regclass) NOT NULL,
    name character varying(50),
    description character varying(255),
    particularization boolean DEFAULT false
);


--
-- Name: COLUMN entitlement.particularization; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN entitlement.particularization IS 'This field indicates a particularization for role_right. if true the role_right (web)form should display a text field.';


--
-- Name: errors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE errors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: errors; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE errors (
    error text,
    error_code character varying(4),
    time_of_error timestamp with time zone DEFAULT now(),
    digest character varying(50),
    id integer DEFAULT nextval('errors_id_seq'::regclass) NOT NULL,
    logfile character varying(1000),
    reference_id integer    
);


--
-- Name: identifier; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE identifier (
    identifier character varying(50) NOT NULL,
    digest character varying(50) NOT NULL
);


--
-- Name: identifier_archive; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE identifier_archive (
    identifier character varying(50),
    digest character varying(50)
);


--
-- Name: identifier_description; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE identifier_description (
    identifier character varying(50) NOT NULL,
    description text,
    type character varying(3),
    phase character varying(15),
    status character varying(15),
    phase_date date
);


--
-- Name: import_issue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE import_issue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: import_issue; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE import_issue (
    id integer DEFAULT nextval('import_issue_id_seq'::regclass) NOT NULL,
    created_on timestamp with time zone DEFAULT now(),
    status integer NOT NULL,
    description character varying(250),
    comments text,
    type integer,
    soft_hard_id integer,
    resolved_by character varying(50),
    resolved_on timestamp with time zone,
    create_new_issue boolean,
    followup_on_issue_nr integer
);


--
-- Name: photo_import_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE photo_import_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: import_photo; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE import_photo (
    id integer DEFAULT nextval('photo_import_id_seq'::regclass) NOT NULL,
    group_id integer NOT NULL,
    created_on timestamp with time zone DEFAULT now(),
    imported_on timestamp with time zone,
    imported_by character varying(50)
);


--
-- Name: import_photo_software_hardware; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE import_photo_software_hardware (
    photo_id integer NOT NULL,
    import_sh integer NOT NULL,
    ok_to_import boolean
);


--
-- Name: import_software_hardware_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE import_software_hardware_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: import_software_hardware; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE import_software_hardware (
    id integer DEFAULT nextval('import_software_hardware_id_seq'::regclass) NOT NULL,
    cpe_id character varying(200),
    producer character varying(50),
    name character varying(100),
    type character varying(50),
    issue_nr integer
);


--
-- Name: item; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE item (
    digest character varying(50) NOT NULL,
    id character varying(16),
    date character varying(8),
    "time" character varying(8),
    source character varying(50),
    title character varying(250),
    link character varying(250),
    description character varying(500),
    status integer DEFAULT 0,
    created timestamp with time zone DEFAULT now() NOT NULL,
    is_mail boolean DEFAULT false,
    is_mailed boolean DEFAULT false NOT NULL,
    category integer,
    cluster_id character varying(22),
    cluster_score numeric,
    cluster_enabled boolean DEFAULT true,
    source_id integer    
);


--
-- Name: item_analysis; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE item_analysis (
    item_id character varying(50) NOT NULL,
    analysis_id character varying(8) NOT NULL
);


--
-- Name: item_archive; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE item_archive (
    digest character varying(50) NOT NULL,
    id character varying(16),
    date character varying(8),
    "time" character varying(8),
    source character varying(50),
    title character varying(250),
    link character varying(250),
    description character varying(500),
    status integer,
    created timestamp without time zone,
    is_mail boolean,
    is_mailed boolean DEFAULT false NOT NULL,
    category integer,
    cluster_id character varying(22),
    cluster_score numeric,
    cluster_enabled boolean DEFAULT true,
    source_id integer    
);


--
-- Name: item_publication_type; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE item_publication_type (
    item_digest character varying(50) NOT NULL,
    publication_type integer NOT NULL,
    publication_specifics text NOT NULL
);


--
-- Name: membership_membership_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE membership_membership_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: membership; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE membership (
    constituent_id integer NOT NULL,
    group_id integer NOT NULL,
    id integer DEFAULT nextval('membership_membership_id_seq'::regclass) NOT NULL
);


--
-- Name: parsers; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE parsers (
    parsername character varying(50) NOT NULL,
    link_prefix character varying(250),
    link_start character varying(250),
    link_stop character varying(250),
    desc_start character varying(250),
    desc_stop character varying(250),
    title_start character varying(250),
    title_stop character varying(250),
    strip0_start character varying(250),
    strip0_stop character varying(250),
    strip1_start character varying(250),
    strip1_stop character varying(250),
    strip2_start character varying(250),
    strip2_stop character varying(250),
    item_start character varying(250),
    item_stop character varying(250)
);


--
-- Name: phish; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE phish (
    url character varying(250) NOT NULL,
    datetime_added character varying(14),
    datetime_down character varying(14),
    datetime_hash_change character varying(14),
    counter_down integer,
    counter_hash_change integer,
    hash character varying(50)
);


--
-- Name: platform_in_publication; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE platform_in_publication (
    publication_id integer NOT NULL,
    softhard_id integer NOT NULL
);


--
-- Name: product_in_publication; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE product_in_publication (
    publication_id integer NOT NULL,
    softhard_id integer NOT NULL
);


--
-- Name: publication_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE publication_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: publication; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE publication (
    id integer DEFAULT nextval('publication_id_seq'::regclass) NOT NULL,
    contents text,
    approved_on timestamp with time zone,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    published_on timestamp with time zone,
    replacedby_id integer,
    status integer,
    title character varying(255),
    type integer,
    created_by character varying(50) NOT NULL,
    approved_by character varying(50),
    published_by character varying(50),
    xml_contents text,
    opened_by character varying(50)
);


--
-- Name: publication2constituent_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE publication2constituent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: publication2constituent; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE publication2constituent (
    channel integer,
    id integer DEFAULT nextval('publication2constituent_id_seq'::regclass) NOT NULL,
    constituent_id integer NOT NULL,
    publication_id integer,
    result character varying(50),
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: publication_advisory_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE publication_advisory_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: publication_advisory; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE publication_advisory (
    consequences text,
    damage smallint,
    deleted boolean DEFAULT false,
    endofweek_id integer,
    govcertid character varying(100),
    hyperlinks text,
    id integer DEFAULT nextval('publication_advisory_seq'::regclass) NOT NULL,
    ids character varying(2000),
    probability smallint,
    publication_id integer,
    ques_dmg_infoleak smallint,
    sms_id integer,
    solution text,
    summary text,
    title character varying(255),
    update text,
    version character varying(5),
    description text,
    ques_dmg_privesc smallint,
    ques_dmg_remrights smallint,
    ques_dmg_codeexec smallint,
    ques_dmg_dos smallint,
    ques_pro_solution smallint,
    ques_pro_expect smallint,
    ques_pro_exploited smallint,
    ques_pro_userint smallint,
    ques_pro_complexity smallint,
    ques_pro_credent smallint,
    ques_pro_access smallint,
    ques_pro_details smallint,
    ques_pro_exploit smallint,
    ques_pro_standard smallint,
    ques_leg_known smallint,
    ques_leg_exploited smallint,
    ques_leg_simplicity smallint,
    ques_leg_default smallint,
    ques_leg_physic smallint,
    ques_leg_user smallint,
    ques_leg_data smallint,
    ques_leg_dos smallint,
    ques_leg_rights smallint,
    ques_pro_deviation text,
    ques_dmg_deviation text,
    platforms_text text,
    products_text text,
    versions_text text,
    notes character varying(250),
    tlpamber text,
    based_on character varying(106)    
);


--
-- Name: publication_endofshift; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE publication_endofshift (
    id integer NOT NULL,
    publication_id integer,
    handler character varying(50),
    first_co_handler character varying(50),
    second_co_handler character varying(50),
    timeframe_begin timestamp with time zone,
    timeframe_end timestamp with time zone,
    general_info text,
    vulnerabilities_threats text,
    incident_info text,
    community_news text,
    media_exposure text,
    tlp_amber text
);


--
-- Name: publication_endofshift_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE publication_endofshift_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: publication_endofshift_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE publication_endofshift_id_seq OWNED BY publication_endofshift.id;


--
-- Name: publication_endofweek_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE publication_endofweek_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: publication_endofweek; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE publication_endofweek (
    closing text,
    id integer DEFAULT nextval('publication_endofweek_id_seq'::regclass) NOT NULL,
    introduction text,
    newondatabank text,
    publication_id integer,
    sent_advisories text,
    newsitem text
);


--
-- Name: publication_template_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE publication_template_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: publication_template; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE publication_template (
    description character varying(100),
    template text NOT NULL,
    title character varying(50) NOT NULL,
    type integer NOT NULL,
    id integer DEFAULT nextval('publication_template_id_seq'::regclass) NOT NULL
);


--
-- Name: publication_template_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE publication_template_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: publication_type_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE publication_type_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: publication_type; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE publication_type (
    description character varying(100),
    id integer DEFAULT nextval('publication_type_seq'::regclass) NOT NULL,
    title character varying(50)
);


--
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: role; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE role (
    id integer DEFAULT nextval('role_id_seq'::regclass) NOT NULL,
    name character varying(50),
    description character varying(255)
);


--
-- Name: role_right_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE role_right_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: role_right; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE role_right (
    entitlement_id integer,
    execute_right boolean,
    id integer DEFAULT nextval('role_right_id_seq'::regclass) NOT NULL,
    particularization character varying(250),
    read_right boolean,
    role_id integer,
    write_right boolean
);


--
-- Name: search_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE search_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: search; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE search (
    id integer DEFAULT nextval('search_id_seq'::regclass) NOT NULL,
    description character varying(100) NOT NULL,
    sortby character varying(15),
    keywords character varying(50),
    startdate timestamp with time zone NOT NULL,
    enddate timestamp with time zone NOT NULL,
    hitsperpage integer NOT NULL,
    uriw character varying(4),
    is_public boolean DEFAULT false NOT NULL,
    created_by character varying(50) NOT NULL
);


--
-- Name: search_category; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE search_category (
    search_id integer NOT NULL,
    category_id integer NOT NULL
);


--
-- Name: search_source; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE search_source (
    search_id integer NOT NULL,
    sourcename character varying(50) NOT NULL
);


--
-- Name: soft_hard_type; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE soft_hard_type (
    description text,
    base character varying(2) NOT NULL,
    sub_type character varying(2)
);


--
-- Name: soft_hard_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE soft_hard_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: soft_hard_usage_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE soft_hard_usage_usage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: soft_hard_usage; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE soft_hard_usage (
    group_id integer NOT NULL,
    soft_hard_id integer,
    usage_id integer DEFAULT nextval('soft_hard_usage_usage_id_seq'::regclass) NOT NULL
);


--
-- Name: soft_hard_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE soft_hard_usage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: software_hardware_id_seq1; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE software_hardware_id_seq1
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: software_hardware; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE software_hardware (
    deleted boolean,
    monitored boolean,
    name character varying(100),
    producer character varying(50),
    version character varying(50),
    id integer DEFAULT nextval('software_hardware_id_seq1'::regclass) NOT NULL,
    type character varying(2),
    cpe_id character varying(200)
);


--
-- Name: software_hardware_cpe_import; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE software_hardware_cpe_import (
    name character varying(100),
    producer character varying(50),
    version character varying(50),
    id integer NOT NULL,
    type character varying(2),
    cpe_id character varying(200),
    ok_to_import boolean DEFAULT true
);


--
-- Name: software_hardware_cpe_import_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE software_hardware_cpe_import_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: software_hardware_cpe_import_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE software_hardware_cpe_import_id_seq OWNED BY software_hardware_cpe_import.id;


--
-- Name: software_hardware_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE software_hardware_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: sources_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE sources_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: sources; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE sources (
    id integer DEFAULT nextval('sources_id_seq'::regclass) NOT NULL,
    digest character varying(25),
    fullurl character varying(610),
    host character varying(100),
    mailbox character varying(50),
    mtbc integer,
    parser character varying(50),
    username character varying(40),
    password character varying(50),
    protocol character varying(10),
    port integer,
    sourcename character varying(50),
    status character varying(20),
    url character varying(500),
    checkid boolean,
    enabled boolean DEFAULT true,
    archive_mailbox character varying(50),
    delete_mail boolean DEFAULT false,
    category integer,
    language character varying(2),
    clustering_enabled boolean DEFAULT false NOT NULL,
    contains_advisory boolean DEFAULT false,
    advisory_handler character varying(50),
    create_advisory boolean,
    deleted boolean DEFAULT false
);


--
-- Name: statistics_analyze; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE statistics_analyze (
    id integer NOT NULL,
    pending_count integer,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: statistics_analyze_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE statistics_analyze_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: statistics_analyze_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE statistics_analyze_id_seq OWNED BY statistics_analyze.id;


--
-- Name: statistics_assess; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE statistics_assess (
    id integer NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now(),
    tag_cloud text
);


--
-- Name: statistics_assess_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE statistics_assess_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: statistics_assess_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE statistics_assess_id_seq OWNED BY statistics_assess.id;


--
-- Name: statistics_collector; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE statistics_collector (
    started timestamp with time zone DEFAULT now() NOT NULL,
    finished timestamp with time zone,
    id integer NOT NULL
);


--
-- Name: statistics_collector_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE statistics_collector_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: statistics_collector_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE statistics_collector_id_seq OWNED BY statistics_collector.id;


--
-- Name: statistics_database; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE statistics_database (
    id integer NOT NULL,
    items_count integer,
    "timestamp" timestamp with time zone DEFAULT now()
);


--
-- Name: statistics_database_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE statistics_database_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: statistics_database_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE statistics_database_id_seq OWNED BY statistics_database.id;


--
-- Name: stats; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE stats (
    numrecords bigint,
    numrecords_archive bigint
);


--
-- Name: statsimages; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE statsimages (
    digest character varying(50),
    description character varying(100),
    link character varying(100),
    target character varying(100),
    source character varying(50),
    category character varying(50)
);


--
-- Name: tag_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: tag; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE tag (
    id integer DEFAULT nextval('tag_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL
);


--
-- Name: tag_item; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE tag_item (
    tag_id integer NOT NULL,
    item_id character varying(50) NOT NULL,
    item_table_name character varying(50) NOT NULL
);


--
-- Name: type_publication_constituent; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE type_publication_constituent (
    constituent_type_id integer NOT NULL,
    publication_type_id integer NOT NULL
);


--
-- Name: user_action_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_action_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: user_action; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_action (
    id integer DEFAULT nextval('user_action_id_seq'::regclass) NOT NULL,
    date timestamp without time zone,
    username character varying(50),
    entitlement character varying(50),
    action character varying DEFAULT 255,
    comment text
);


--
-- Name: user_action_id_seq1; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_action_id_seq1
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: user_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- Name: user_role; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_role (
    id integer DEFAULT nextval('user_role_id_seq'::regclass) NOT NULL,
    role_id integer,
    username character varying(50)
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE users (
    username character varying(50) NOT NULL,
    password character varying(50),
    uriw character varying(4),
    search character varying(250),
    anasearch character varying(250),
    anastatus character varying(25),
    mailfrom_sender character varying(50),
    mailfrom_email character varying(50),
    lmh character varying(4),
    statstype character varying(50),
    hitsperpage integer,
    fullname character varying(50),
    disabled boolean DEFAULT false,
    datestart date DEFAULT now(),
    datestop date DEFAULT now(),
    assess_orderby character varying(20),
    category integer,
    source character varying(50),
    assess_autorefresh boolean DEFAULT true NOT NULL
);


--
-- Name: versions; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW versions AS
    SELECT ov.id, ov.replacedby_id, ov.approved_on, ov.created_on FROM publication uo, publication ov WHERE (uo.id = ov.replacedby_id);

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY cluster ALTER COLUMN id SET DEFAULT nextval('cluster_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY publication_endofshift ALTER COLUMN id SET DEFAULT nextval('publication_endofshift_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY software_hardware_cpe_import ALTER COLUMN id SET DEFAULT nextval('software_hardware_cpe_import_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY statistics_analyze ALTER COLUMN id SET DEFAULT nextval('statistics_analyze_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY statistics_assess ALTER COLUMN id SET DEFAULT nextval('statistics_assess_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY statistics_collector ALTER COLUMN id SET DEFAULT nextval('statistics_collector_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY statistics_database ALTER COLUMN id SET DEFAULT nextval('statistics_database_id_seq'::regclass);


--
-- Name: Role_id_Entitlement_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY role_right
    ADD CONSTRAINT "Role_id_Entitlement_id" UNIQUE (entitlement_id, role_id);


--
-- Name: advisory_damage_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY advisory_damage
    ADD CONSTRAINT advisory_damage_pkey PRIMARY KEY (advisory_id, damage_id);


--
-- Name: analysis_publication_pk; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY analysis_publication
    ADD CONSTRAINT analysis_publication_pk PRIMARY KEY (analysis_id, publication_id);


--
-- Name: constituent_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY constituent_group
    ADD CONSTRAINT constituent_group_pkey PRIMARY KEY (id);


--
-- Name: constituent_individual_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY constituent_individual
    ADD CONSTRAINT constituent_individual_pkey PRIMARY KEY (id);


--
-- Name: constituent_publication_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY constituent_publication
    ADD CONSTRAINT constituent_publication_pkey PRIMARY KEY (id);


--
-- Name: constituent_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY constituent_role
    ADD CONSTRAINT constituent_role_pkey PRIMARY KEY (id);


--
-- Name: constituent_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY constituent_type
    ADD CONSTRAINT constituent_type_pkey PRIMARY KEY (id);


--
-- Name: cpe_unique; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY software_hardware
    ADD CONSTRAINT cpe_unique UNIQUE (cpe_id);


--
-- Name: damage_description_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY damage_description
    ADD CONSTRAINT damage_description_pkey PRIMARY KEY (id);


--
-- Name: download_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY download_files
    ADD CONSTRAINT download_files_pkey PRIMARY KEY (file_url);


--
-- Name: email_item_archive_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY email_item_archive
    ADD CONSTRAINT email_item_archive_pkey PRIMARY KEY (id);


--
-- Name: email_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY email_item
    ADD CONSTRAINT email_item_pkey PRIMARY KEY (id);


--
-- Name: entitlement_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY entitlement
    ADD CONSTRAINT entitlement_pkey PRIMARY KEY (id);


--
-- Name: id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY analysis
    ADD CONSTRAINT id PRIMARY KEY (id);


--
-- Name: identifier_description_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY identifier_description
    ADD CONSTRAINT identifier_description_pkey PRIMARY KEY (identifier);


--
-- Name: item_analysis_pk; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY item_analysis
    ADD CONSTRAINT item_analysis_pk PRIMARY KEY (item_id, analysis_id);


--
-- Name: membership_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY membership
    ADD CONSTRAINT membership_pkey PRIMARY KEY (id);


--
-- Name: parsers_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY parsers
    ADD CONSTRAINT parsers_pkey PRIMARY KEY (parsername);


--
-- Name: ph_import_photo; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY import_photo
    ADD CONSTRAINT ph_import_photo PRIMARY KEY (id);


--
-- Name: ph_import_photo_sh; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY import_photo_software_hardware
    ADD CONSTRAINT ph_import_photo_sh PRIMARY KEY (photo_id, import_sh);


--
-- Name: phish_pk; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY phish
    ADD CONSTRAINT phish_pk PRIMARY KEY (url);

--
-- Name: pk_calling_list; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY calling_list
    ADD CONSTRAINT pk_calling_list PRIMARY KEY (id);


--
-- Name: pk_category; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY category
    ADD CONSTRAINT pk_category PRIMARY KEY (id);


--
-- Name: pk_checkstatus; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY checkstatus
    ADD CONSTRAINT pk_checkstatus PRIMARY KEY (source);


--
-- Name: pk_cluster; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY cluster
    ADD CONSTRAINT pk_cluster PRIMARY KEY (id);
    
    
--
-- Name: pk_cpe_cve; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY cpe_cve
    ADD CONSTRAINT pk_cpe_cve PRIMARY KEY (cve_id, cpe_id);


--
-- Name: pk_cpe_files; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY cpe_files
    ADD CONSTRAINT pk_cpe_files PRIMARY KEY (filename);


--
-- Name: pk_endofweek; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY publication_endofweek
    ADD CONSTRAINT pk_endofweek PRIMARY KEY (id);


--
-- Name: pk_errors_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY errors
    ADD CONSTRAINT pk_errors_id PRIMARY KEY (id);


--
-- Name: pk_identifier_digest; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY identifier
    ADD CONSTRAINT pk_identifier_digest PRIMARY KEY (identifier, digest);


--
-- Name: pk_import_issue; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY import_issue
    ADD CONSTRAINT pk_import_issue PRIMARY KEY (id);

    
--
-- Name: pk_import_software_hardware; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY import_software_hardware
    ADD CONSTRAINT pk_import_software_hardware PRIMARY KEY (id);


--
-- Name: pk_item_publication_type; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY item_publication_type
    ADD CONSTRAINT pk_item_publication_type PRIMARY KEY (item_digest, publication_type, publication_specifics);


--
-- Name: pk_platform_in_publication; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY platform_in_publication
    ADD CONSTRAINT pk_platform_in_publication PRIMARY KEY (publication_id, softhard_id);


--
-- Name: pk_product_in_publication; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY product_in_publication
    ADD CONSTRAINT pk_product_in_publication PRIMARY KEY (publication_id, softhard_id);


--
-- Name: pk_publication_endofshift; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY publication_endofshift
    ADD CONSTRAINT pk_publication_endofshift PRIMARY KEY (id);


--
-- Name: pk_search; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY search
    ADD CONSTRAINT pk_search PRIMARY KEY (id);


--
-- Name: pk_search_category; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY search_category
    ADD CONSTRAINT pk_search_category PRIMARY KEY (search_id, category_id);


--
-- Name: pk_search_source; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY search_source
    ADD CONSTRAINT pk_search_source PRIMARY KEY (search_id, sourcename);


--
-- Name: pk_tag_item; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tag_item
    ADD CONSTRAINT pk_tag_item PRIMARY KEY (tag_id, item_id, item_table_name);

--
-- Name: publication2constituent_pk; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY publication2constituent
    ADD CONSTRAINT publication2constituent_pk PRIMARY KEY (id);


--
-- Name: publication_advisory_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY publication_advisory
    ADD CONSTRAINT publication_advisory_pkey PRIMARY KEY (id);


--
-- Name: publication_pk; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY publication
    ADD CONSTRAINT publication_pk PRIMARY KEY (id);


--
-- Name: publication_template_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY publication_template
    ADD CONSTRAINT publication_template_pkey PRIMARY KEY (id);


--
-- Name: publication_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY publication_type
    ADD CONSTRAINT publication_type_pkey PRIMARY KEY (id);


--
-- Name: role_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id);


--
-- Name: role_right_ID; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY role_right
    ADD CONSTRAINT "role_right_ID" PRIMARY KEY (id);


--
-- Name: rss_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY item
    ADD CONSTRAINT rss_pkey PRIMARY KEY (digest);


--
-- Name: soft_hard_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY soft_hard_type
    ADD CONSTRAINT soft_hard_type_pkey PRIMARY KEY (base);


--
-- Name: soft_hard_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY soft_hard_usage
    ADD CONSTRAINT soft_hard_usage_pkey PRIMARY KEY (usage_id);


--
-- Name: software_hardware_cpe_import_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY software_hardware_cpe_import
    ADD CONSTRAINT software_hardware_cpe_import_pkey PRIMARY KEY (id);


--
-- Name: software_hardware_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY software_hardware
    ADD CONSTRAINT software_hardware_pkey PRIMARY KEY (id);


--
-- Name: sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY sources
    ADD CONSTRAINT sources_pkey PRIMARY KEY (id);


--
-- Name: statistics_analyze_pk; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY statistics_analyze
    ADD CONSTRAINT statistics_analyze_pk PRIMARY KEY (id);


--
-- Name: statistics_assess_pk; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY statistics_assess
    ADD CONSTRAINT statistics_assess_pk PRIMARY KEY (id);


--
-- Name: statistics_collector_pk; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY statistics_collector
    ADD CONSTRAINT statistics_collector_pk PRIMARY KEY (id);


--
-- Name: statistics_database_pk; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY statistics_database
    ADD CONSTRAINT statistics_database_pk PRIMARY KEY (id);


--
-- Name: tag_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tag
    ADD CONSTRAINT tag_id PRIMARY KEY (id);


--
-- Name: type_publication_constituent_pk; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY type_publication_constituent
    ADD CONSTRAINT type_publication_constituent_pk PRIMARY KEY (constituent_type_id, publication_type_id);


--
-- Name: un_publicationid_groupid; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY calling_list
    ADD CONSTRAINT un_publicationid_groupid UNIQUE (publication_id, group_id);

--
-- Name: unique_cluster; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY cluster
    ADD CONSTRAINT unique_cluster UNIQUE (language, category_id);


--
-- Name: user_action_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_action
    ADD CONSTRAINT user_action_pkey PRIMARY KEY (id);


--
-- Name: user_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_role
    ADD CONSTRAINT user_role_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (username);


--
-- Name: base_subtype; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX base_subtype ON soft_hard_type USING btree (sub_type, base);


--
-- Name: cpeId; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX "cpeId" ON software_hardware USING btree (cpe_id);


--
-- Name: ent; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX ent ON user_action USING btree (entitlement);


--
-- Name: entitlement_role_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX entitlement_role_id ON role_right USING btree (entitlement_id, role_id);


--
-- Name: fki_; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_ ON sources USING btree (parser);

--
-- Name: fki_advisory_handler; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_advisory_handler ON sources USING btree (advisory_handler);


--
-- Name: fki_analysis_id_fk; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_analysis_id_fk ON item_analysis USING btree (analysis_id);


--
-- Name: fki_category_item; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_category_item ON item USING btree (category);


--
-- Name: fki_category_item_archive; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_category_item_archive ON item_archive USING btree (category);


--
-- Name: fki_category_sources; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_category_sources ON sources USING btree (category);


--
-- Name: fki_category_users; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_category_users ON users USING btree (category);


--
-- Name: fki_constituent_type; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_constituent_type ON constituent_group USING btree (constituent_type);


--
-- Name: fki_followup_issue_nr; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_followup_issue_nr ON import_issue USING btree (followup_on_issue_nr);


--
-- Name: fki_imported_by; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_imported_by ON import_photo USING btree (imported_by);


--
-- Name: fki_issue_nr; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_issue_nr ON import_software_hardware USING btree (issue_nr);


--
-- Name: fki_joined_into_analysis; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_joined_into_analysis ON analysis USING btree (joined_into_analysis);


--
-- Name: fki_opened_by; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_opened_by ON analysis USING btree (opened_by);


--
-- Name: fki_opened_by_users; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_opened_by_users ON publication USING btree (opened_by);


--
-- Name: fki_owned_by; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_owned_by ON analysis USING btree (owned_by);


--
-- Name: fki_publication_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_publication_id ON publication USING btree (replacedby_id);


--
-- Name: fki_publication_id_advisory; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_publication_id_advisory ON publication_advisory USING btree (publication_id);


--
-- Name: fki_resolved_by; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_resolved_by ON import_issue USING btree (resolved_by);


--
-- Name: fki_role_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_role_id ON user_role USING btree (role_id);


--
-- Name: fki_search_user; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_search_user ON search USING btree (created_by);


--
-- Name: fki_software_hardware_id_issue; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_software_hardware_id_issue ON import_issue USING btree (soft_hard_id);

--
-- Name: fki_source_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_source_id ON item USING btree (source_id);


--
-- Name: fki_username; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_username ON user_role USING btree (username);


--
-- Name: fki_users_publishedby; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_users_publishedby ON publication USING btree (published_by);


--
-- Name: fki_users_username; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX fki_users_username ON publication USING btree (approved_by);


--
-- Name: identifier_index; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX identifier_index ON identifier_description USING btree (identifier);


--
-- Name: idx_category; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_category ON item USING btree (category);


--
-- Name: idx_created; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_created ON item_archive USING btree (created);


--
-- Name: idx_cveid; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_cveid ON identifier USING btree (identifier);


--
-- Name: idx_cveid2; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_cveid2 ON identifier_archive USING btree (identifier);


--
-- Name: idx_digest; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_digest ON item USING btree (digest);


--
-- Name: idx_digest2; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_digest2 ON identifier USING btree (digest);


--
-- Name: idx_digest3; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_digest3 ON item_archive USING btree (digest);


--
-- Name: idx_digest4; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_digest4 ON identifier_archive USING btree (digest);


--
-- Name: item_digest_index; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX item_digest_index ON item_publication_type USING btree (item_digest);


--
-- Name: name_producer_type; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX name_producer_type ON software_hardware USING btree (producer, name, type);

--
-- Name: fk_source_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY item
    ADD CONSTRAINT fk_source_id FOREIGN KEY (source_id) REFERENCES sources(id);
    

--
-- Name: analysis_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY analysis_publication
    ADD CONSTRAINT analysis_id FOREIGN KEY (analysis_id) REFERENCES analysis(id);


--
-- Name: analysis_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY item_analysis
    ADD CONSTRAINT analysis_id_fk FOREIGN KEY (analysis_id) REFERENCES analysis(id);


--
-- Name: base; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY soft_hard_type
    ADD CONSTRAINT base FOREIGN KEY (sub_type) REFERENCES soft_hard_type(base);


--
-- Name: constituent_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY publication2constituent
    ADD CONSTRAINT constituent_fk FOREIGN KEY (constituent_id) REFERENCES constituent_individual(id);


--
-- Name: constituent_group_constituent_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY constituent_group
    ADD CONSTRAINT constituent_group_constituent_type_fkey FOREIGN KEY (constituent_type) REFERENCES constituent_type(id);


--
-- Name: constituent_individual_role_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY constituent_individual
    ADD CONSTRAINT constituent_individual_role_fkey FOREIGN KEY (role) REFERENCES constituent_role(id);


--
-- Name: constituent_publication_constituent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY constituent_publication
    ADD CONSTRAINT constituent_publication_constituent_id_fkey FOREIGN KEY (constituent_id) REFERENCES constituent_individual(id);


--
-- Name: constituent_publication_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY constituent_publication
    ADD CONSTRAINT constituent_publication_type_id_fkey FOREIGN KEY (type_id) REFERENCES publication_type(id);


--
-- Name: damage_description_damage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY advisory_damage
    ADD CONSTRAINT damage_description_damage_id_fkey FOREIGN KEY (damage_id) REFERENCES damage_description(id);


--
-- Name: entitlement; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY role_right
    ADD CONSTRAINT entitlement FOREIGN KEY (entitlement_id) REFERENCES entitlement(id);


--
-- Name: fk_advisory_handler; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY sources
    ADD CONSTRAINT fk_advisory_handler FOREIGN KEY (advisory_handler) REFERENCES users(username);


--
-- Name: fk_category; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY item
    ADD CONSTRAINT fk_category FOREIGN KEY (category) REFERENCES category(id);


--
-- Name: fk_category; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY item_archive
    ADD CONSTRAINT fk_category FOREIGN KEY (category) REFERENCES category(id);


--
-- Name: fk_category; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY sources
    ADD CONSTRAINT fk_category FOREIGN KEY (category) REFERENCES category(id);


--
-- Name: fk_category; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users
    ADD CONSTRAINT fk_category FOREIGN KEY (category) REFERENCES category(id);


--
-- Name: fk_category; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY search_category
    ADD CONSTRAINT fk_category FOREIGN KEY (category_id) REFERENCES category(id);


--
-- Name: fk_category; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cluster
    ADD CONSTRAINT fk_category FOREIGN KEY (category_id) REFERENCES category(id);


--
-- Name: fk_constituen_group; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY calling_list
    ADD CONSTRAINT fk_constituen_group FOREIGN KEY (group_id) REFERENCES constituent_group(id);



--
-- Name: fk_first_co_handler; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY publication_endofshift
    ADD CONSTRAINT fk_first_co_handler FOREIGN KEY (first_co_handler) REFERENCES users(username);


--
-- Name: fk_followup_issue_nr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY import_issue
    ADD CONSTRAINT fk_followup_issue_nr FOREIGN KEY (followup_on_issue_nr) REFERENCES import_issue(id);


--
-- Name: fk_handler; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY publication_endofshift
    ADD CONSTRAINT fk_handler FOREIGN KEY (handler) REFERENCES users(username);


--
-- Name: fk_import_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY import_photo
    ADD CONSTRAINT fk_import_group_id FOREIGN KEY (group_id) REFERENCES constituent_group(id);


--
-- Name: fk_import_photo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY import_photo_software_hardware
    ADD CONSTRAINT fk_import_photo FOREIGN KEY (photo_id) REFERENCES import_photo(id);


--
-- Name: fk_import_sh2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY import_photo_software_hardware
    ADD CONSTRAINT fk_import_sh2 FOREIGN KEY (import_sh) REFERENCES import_software_hardware(id);


--
-- Name: fk_imported_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY import_photo
    ADD CONSTRAINT fk_imported_by FOREIGN KEY (imported_by) REFERENCES users(username);


--
-- Name: fk_issue_nr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY import_software_hardware
    ADD CONSTRAINT fk_issue_nr FOREIGN KEY (issue_nr) REFERENCES import_issue(id);


--
-- Name: fk_item_digest; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY item_publication_type
    ADD CONSTRAINT fk_item_digest FOREIGN KEY (item_digest) REFERENCES item(digest);


--
-- Name: fk_joined_into_analysis; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY analysis
    ADD CONSTRAINT fk_joined_into_analysis FOREIGN KEY (joined_into_analysis) REFERENCES analysis(id);


--
-- Name: fk_opened_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY analysis
    ADD CONSTRAINT fk_opened_by FOREIGN KEY (opened_by) REFERENCES users(username);


--
-- Name: fk_opened_by_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY publication
    ADD CONSTRAINT fk_opened_by_users FOREIGN KEY (opened_by) REFERENCES users(username);


--
-- Name: fk_owned_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY analysis
    ADD CONSTRAINT fk_owned_by FOREIGN KEY (owned_by) REFERENCES users(username);


--
-- Name: fk_platform_in_publication; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY platform_in_publication
    ADD CONSTRAINT fk_platform_in_publication FOREIGN KEY (publication_id) REFERENCES publication(id);


--
-- Name: fk_platform_in_publication_2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY platform_in_publication
    ADD CONSTRAINT fk_platform_in_publication_2 FOREIGN KEY (softhard_id) REFERENCES software_hardware(id);


--
-- Name: fk_publication; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY calling_list
    ADD CONSTRAINT fk_publication FOREIGN KEY (publication_id) REFERENCES publication(id);


--
-- Name: fk_publication_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY product_in_publication
    ADD CONSTRAINT fk_publication_id FOREIGN KEY (publication_id) REFERENCES publication(id);


--
-- Name: fk_publication_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY publication_advisory
    ADD CONSTRAINT fk_publication_id FOREIGN KEY (publication_id) REFERENCES publication(id);


--
-- Name: fk_publication_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY publication_endofweek
    ADD CONSTRAINT fk_publication_id FOREIGN KEY (publication_id) REFERENCES publication(id);



--
-- Name: fk_publication_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY publication_endofshift
    ADD CONSTRAINT fk_publication_id FOREIGN KEY (publication_id) REFERENCES publication(id);



--
-- Name: fk_publication_type; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY item_publication_type
    ADD CONSTRAINT fk_publication_type FOREIGN KEY (publication_type) REFERENCES publication_type(id);


--
-- Name: fk_resolved_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY import_issue
    ADD CONSTRAINT fk_resolved_by FOREIGN KEY (resolved_by) REFERENCES users(username);


--
-- Name: fk_search; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY search_source
    ADD CONSTRAINT fk_search FOREIGN KEY (search_id) REFERENCES search(id);


--
-- Name: fk_search; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY search_category
    ADD CONSTRAINT fk_search FOREIGN KEY (search_id) REFERENCES search(id);


--
-- Name: fk_search_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY search
    ADD CONSTRAINT fk_search_user FOREIGN KEY (created_by) REFERENCES users(username);


--
-- Name: fk_second_co_handler; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY publication_endofshift
    ADD CONSTRAINT fk_second_co_handler FOREIGN KEY (second_co_handler) REFERENCES users(username);


--
-- Name: fk_software_hardware_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY product_in_publication
    ADD CONSTRAINT fk_software_hardware_id FOREIGN KEY (softhard_id) REFERENCES software_hardware(id);


--
-- Name: fk_software_hardware_id_issue; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY import_issue
    ADD CONSTRAINT fk_software_hardware_id_issue FOREIGN KEY (soft_hard_id) REFERENCES software_hardware(id);


--
-- Name: fk_tag_item; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tag_item
    ADD CONSTRAINT fk_tag_item FOREIGN KEY (tag_id) REFERENCES tag(id);


--
-- Name: fk_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY calling_list
    ADD CONSTRAINT fk_users FOREIGN KEY (locked_by) REFERENCES users(username);


--
-- Name: fk_users_approvedby; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY publication
    ADD CONSTRAINT fk_users_approvedby FOREIGN KEY (approved_by) REFERENCES users(username);


--
-- Name: fk_users_publishedby; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY publication
    ADD CONSTRAINT fk_users_publishedby FOREIGN KEY (published_by) REFERENCES users(username);


--
-- Name: item_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY item_analysis
    ADD CONSTRAINT item_id_fk FOREIGN KEY (item_id) REFERENCES item(digest);


--
-- Name: membership_constituent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY membership
    ADD CONSTRAINT membership_constituent_id_fkey FOREIGN KEY (constituent_id) REFERENCES constituent_individual(id);


--
-- Name: membership_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY membership
    ADD CONSTRAINT membership_group_id_fkey FOREIGN KEY (group_id) REFERENCES constituent_group(id);


--
-- Name: publication_advisory_advisory_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY advisory_damage
    ADD CONSTRAINT publication_advisory_advisory_id_fkey FOREIGN KEY (advisory_id) REFERENCES publication_advisory(id);


--
-- Name: publication_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY publication2constituent
    ADD CONSTRAINT publication_fk FOREIGN KEY (publication_id) REFERENCES publication(id);


--
-- Name: publication_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY publication
    ADD CONSTRAINT publication_id FOREIGN KEY (replacedby_id) REFERENCES publication(id);


--
-- Name: publication_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY analysis_publication
    ADD CONSTRAINT publication_id FOREIGN KEY (publication_id) REFERENCES publication(id);


--
-- Name: publication_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY publication
    ADD CONSTRAINT publication_type_id FOREIGN KEY (type) REFERENCES publication_type(id);


--
-- Name: role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_role
    ADD CONSTRAINT role_id FOREIGN KEY (role_id) REFERENCES role(id);


--
-- Name: role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY role_right
    ADD CONSTRAINT role_id FOREIGN KEY (role_id) REFERENCES role(id);


--
-- Name: soft_hard_usage_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY soft_hard_usage
    ADD CONSTRAINT soft_hard_usage_group_id_fkey FOREIGN KEY (group_id) REFERENCES constituent_group(id);


--
-- Name: soft_hard_usage_soft_hard_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY soft_hard_usage
    ADD CONSTRAINT soft_hard_usage_soft_hard_id_fkey FOREIGN KEY (soft_hard_id) REFERENCES software_hardware(id);


--
-- Name: sources_parser_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY sources
    ADD CONSTRAINT sources_parser_fkey FOREIGN KEY (parser) REFERENCES parsers(parsername);


--
-- Name: type; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY publication_template
    ADD CONSTRAINT type FOREIGN KEY (type) REFERENCES publication_type(id);


--
-- Name: type; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY software_hardware
    ADD CONSTRAINT type FOREIGN KEY (type) REFERENCES soft_hard_type(base);


--
-- Name: username; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_role
    ADD CONSTRAINT username FOREIGN KEY (username) REFERENCES users(username);


--
-- Name: users_username; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY publication
    ADD CONSTRAINT users_username FOREIGN KEY (created_by) REFERENCES users(username);


--
-- Name: public; Type: ACL; Schema: -; Owner: -
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

