ALTER TABLE sources ADD COLUMN deleted boolean DEFAULT FALSE;
