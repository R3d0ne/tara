ALTER TABLE sources ADD COLUMN contains_advisory boolean DEFAULT FALSE;
ALTER TABLE sources ADD COLUMN advisory_handler character varying(50);
ALTER TABLE sources ADD CONSTRAINT fk_advisory_handler FOREIGN KEY (advisory_handler) REFERENCES users (username)
   ON UPDATE NO ACTION ON DELETE NO ACTION;
CREATE INDEX fki_advisory_handler ON sources(advisory_handler);
ALTER TABLE sources ADD COLUMN create_advisory boolean;

ALTER TABLE publication_advisory ADD COLUMN based_on character varying(106);

ALTER TABLE errors ADD COLUMN reference_id integer;
