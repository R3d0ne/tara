CREATE TABLE dashboard
(
   html text, 
   json text, 
   "type" integer NOT NULL
);

INSERT INTO dashboard(
            html, json, "type")
    VALUES ('', '', 1);

INSERT INTO dashboard(
            html, json, "type")
    VALUES ('', '', 2);
    
CREATE TABLE statistics_collector
(
   started timestamp with time zone NOT NULL DEFAULT now(), 
   finished timestamp with time zone, 
   id serial, 
   CONSTRAINT statistics_collector_pk PRIMARY KEY (id)
);

CREATE TABLE statistics_analyze
(
   id serial, 
   pending_count integer, 
   "timestamp" timestamp with time zone NOT NULL DEFAULT now(), 
   CONSTRAINT statistics_analyze_pk PRIMARY KEY (id)
);

CREATE TABLE statistics_database
(
   id serial, 
   items_count integer, 
   "timestamp" timestamp with time zone DEFAULT NOW(), 
   CONSTRAINT statistics_database_pk PRIMARY KEY (id)
);

CREATE TABLE statistics_assess
(
   id serial, 
   "timestamp" timestamp with time zone DEFAULT now(), 
   tag_cloud text, 
   CONSTRAINT statistics_assess_pk PRIMARY KEY (id)
);