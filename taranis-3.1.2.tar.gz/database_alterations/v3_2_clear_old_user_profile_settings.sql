update users set 
	uriw = NULL, 
	"search" = NULL, 
	anasearch = NULL, 
	anastatus = NULL, 
	lmh = NULL, 
	statstype = NULL, 
	hitsperpage = NULL, 
	datestart= NULL, 
	datestop = NULL, 
	assess_orderby = NULL, 
	category = NULL, 
	source = NULL;