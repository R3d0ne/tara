INSERT INTO users (username, password, uriw, search, category, anasearch, anastatus, mailfrom_sender, mailfrom_email, lmh, statstype, hitsperpage, fullname, disabled, datestart, datestop) VALUES ('admin', 'ISMvKXpXpadDiUoOSoAfww', '1111', NULL, NULL, NULL, NULL, 'Taranis Admin', 'admin@localhost', '111', NULL, NULL, 'Taranis Admin', false, NULL, NULL);

INSERT INTO entitlement (id, name, description, particularization) VALUES (1, 'analysis', 'Rechten op een analyse. Via een particularization kunnen rechten op analyses met een bepaalde status worden gespecificeerd.', true);
INSERT INTO entitlement (id, name, description, particularization) VALUES (2, 'configuration_generic', 'Rechten op de generieke Taranis configuratie', false);
INSERT INTO entitlement (id, name, description, particularization) VALUES (3, 'configuration_parser', 'Rechten op Parser configuraties ', false);
INSERT INTO entitlement (id, name, description, particularization) VALUES (4, 'configuration_strips', 'Rechten op Strips configuraties', false);
INSERT INTO entitlement (id, name, description, particularization) VALUES (5, 'constituent_groups', 'Rechten op Constituent Groups', false);
INSERT INTO entitlement (id, name, description, particularization) VALUES (6, 'constituent_individuals', 'Rechten op Constituent Individuals. Via een particularization kunnen rechten op constituents van een bepaalde groep worden gespecificeerd.', true);
INSERT INTO entitlement (id, name, description, particularization) VALUES (7, 'damage_description', 'Rechten op de lijst van schadeomschrijvingen', false);
INSERT INTO entitlement (id, name, description, particularization) VALUES (8, 'entitlements', 'Rechten op Entitlement definities', false);
INSERT INTO entitlement (id, name, description, particularization) VALUES (9, 'item_analysis', 'Rechten op de koppeling tussen een item en een analyse. Via een particularization kunnen rechten op het koppelen van items van een bepaalde categorie worden gespecificeerd.', true);
INSERT INTO entitlement (id, name, description, particularization) VALUES (10, 'items', 'Rechten op verzamelde items. Via een particularization kunnen rechten op items van een bepaalde categorie worden gespecificeerd.', true);
INSERT INTO entitlement (id, name, description, particularization) VALUES (11, 'membership', 'Rechten op de groepslidmaatschappen van Constituent Individuals. Via een particularization kunnen rechten op lidmaatschappen voor een bepaalde Constituent Group worden gespecificeerd.', true);
INSERT INTO entitlement (id, name, description, particularization) VALUES (12, 'publication', 'Rechten op een publicatie. Via een particularization kunnen rechten op publicaties van een bepaald type worden gespecificeerd. De rechten op een publicatie bepalen ook de rechten op het koppelen van kwetsbare platformen, etc.', true);
INSERT INTO entitlement (id, name, description, particularization) VALUES (13, 'publication_template', 'Rechten op publicatie templates. Via een particularization kunnen rechten op templates van een bepaald type worden gespecificeerd.', true);
INSERT INTO entitlement (id, name, description, particularization) VALUES (14, 'publication_type', 'Rechten op publicatie typen', true);
INSERT INTO entitlement (id, name, description, particularization) VALUES (15, 'software_hardware', 'Rechten op de lijst van hard- en software', false);
INSERT INTO entitlement (id, name, description, particularization) VALUES (16, 'soft_hard_usage', 'Rechten op het koppelen van hard- en software aan Constituent Groups (''onderhouden foto''). Via een  particularization kunnen rechten op het koppelen van een hard- en software aan een specifieke Constituent  Group worden gespecificeerd.', false);
INSERT INTO entitlement (id, name, description, particularization) VALUES (17, 'sources_errors', 'Rechten op foutmeldingen rondom bronnen.', true);
INSERT INTO entitlement (id, name, description, particularization) VALUES (18, 'sources_items', 'Rechten op de bronnenlijst (items bronnen). Via een particularization kunnen rechten op bronnen van een bepaalde categorie worden gespecificeerd.', true);
INSERT INTO entitlement (id, name, description, particularization) VALUES (19, 'sources_stats', 'Rechten op de bronnenlijst (statistiek bronnen). Via een particularization kunnen rechten op bronnen van  een bepaalde categorie worden gespecificeerd.', true);
INSERT INTO entitlement (id, name, description, particularization) VALUES (20, 'role_right', 'Rechten op rechtentoekenningen aan rol', false);
INSERT INTO entitlement (id, name, description, particularization) VALUES (21, 'roles', 'Rechten op Role definities', false);
INSERT INTO entitlement (id, name, description, particularization) VALUES (22, 'user_role', 'Rechten op toegekende rollen aan een gebruiker', false);
INSERT INTO entitlement (id, name, description, particularization) VALUES (23, 'user_action', 'Rechten op uitgevoerde acties van gebruikers (kan alleen ''read'' rechten zijn, ''write'' rechten zijn voorbehouden aan Taranis zelf)', false);
INSERT INTO entitlement (id, name, description, particularization) VALUES (24, 'users', 'Rechten op gebruikersgegevens', false);
INSERT INTO entitlement (id, name, description, particularization) VALUES (25, 'generic', 'Generieke rechten (login/logout)', false);
INSERT INTO entitlement (id, name, description, particularization) VALUES (26, 'tools', 'Rechten op tools', false);
INSERT INTO entitlement (id, name, description, particularization) VALUES (27, 'admin_generic', 'Taranis Administrator Rechten', false);
INSERT INTO entitlement (id, name, description, particularization) VALUES (28, 'photo_import', 'Rechten op importeren van foto', false);

INSERT INTO role (name, description) VALUES ('Taranis Administrator', 'Admin');

INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (1, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (2, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (3, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (4, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (5, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (6, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (7, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (8, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (9, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (10, true, 'security-news,ict-news,security-vuln,KC,news,', true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (11, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (12, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (13, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (14, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (15, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (16, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (17, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (18, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (19, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (20, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (21, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (22, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (23, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (24, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (25, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (26, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (27, true,  NULL, true, 1, true);
INSERT INTO role_right (entitlement_id, execute_right, particularization, read_right, role_id, write_right) VALUES (28, true,  NULL, true, 1, true);

INSERT INTO user_role (role_id, username) VALUES (1, 'admin');

INSERT INTO publication_type( title) VALUES ( 'Advisory (email)' );
INSERT INTO publication_type( title) VALUES ( 'Advisory (XML)' );
INSERT INTO publication_type( title) VALUES ( 'End-of-Week (email)' );
INSERT INTO publication_type (title) VALUES ( 'End-of-Shift (email)' );
INSERT INTO publication_type (title) VALUES ( 'End-of-Shift (email public)' );

INSERT INTO cpe_files( filename, last_change ) VALUES ( 'nvdcve-2.0-modified.xml', 'firsttime' );
INSERT INTO cpe_files( filename, last_change ) VALUES ( 'nvdcve-2.0-recent.xml' , 'firsttime' );

INSERT INTO soft_hard_type (description, base, sub_type) VALUES ('Application', 'a', NULL);
INSERT INTO soft_hard_type (description, base, sub_type) VALUES ('Operating System', 'o', NULL);
INSERT INTO soft_hard_type (description, base, sub_type) VALUES ('Hardware', 'h', NULL);

INSERT INTO publication_template(description, "template", title, "type") 
	VALUES ('Complete advisory email template', 
'&lt;publication&gt;
&lt;template&gt;
   #########################################
  ##  S E C U R I T Y   A D V I S O R Y  ##
 #########################################

Title            : _fld_title_
Advisory ID      : _fld_govcert_id_
Version          : _fld_version_
Probability      : _fld_probability_
CVE ID           : _fld_cve_ids_
                   (http://cve.mitre.org/cve/)
Damage           : _fld_damage_
                   _fld_damage_descriptions_
Publication date : _fld_publication_date_
Product(s)       : _fld_affected_products_
Version(s)       : _fld_product_versions_
Platform(s)      : _fld_platforms_

   _fld_update_

   _fld_summary_

   _fld_consequences_

   _fld_description_

   _fld_solution_

   _fld_links_


&lt;/template&gt;

&lt;fields&gt;
  &lt;fld_update type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;update&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_update&gt;
  &lt;fld_update type=&quot;settings&quot;&gt;
    &lt;setting type=&quot;heading&quot;&gt;Update&lt;/setting&gt;
  &lt;/fld_update&gt;
  &lt;fld_summary type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;summary&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_summary&gt;
  &lt;fld_summary type=&quot;settings&quot;&gt;
    &lt;setting type=&quot;heading&quot;&gt;Summary&lt;/setting&gt;
  &lt;/fld_summary&gt;
  &lt;fld_description type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;description&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_description&gt;
  &lt;fld_description type=&quot;settings&quot;&gt;
    &lt;setting type=&quot;heading&quot;&gt;Description&lt;/setting&gt;
  &lt;/fld_description&gt;
  &lt;fld_solution type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;solution&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_solution&gt;
  &lt;fld_solution type=&quot;settings&quot;&gt;
    &lt;setting type=&quot;heading&quot;&gt;Solution&lt;/setting&gt;
  &lt;/fld_solution&gt;
  &lt;fld_consequences type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;consequences&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_consequences&gt;
  &lt;fld_consequences type=&quot;settings&quot;&gt;
    &lt;setting type=&quot;heading&quot;&gt;Consequences&lt;/setting&gt;
  &lt;/fld_consequences&gt;
  &lt;fld_links type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;hyperlinks&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_links&gt;
  &lt;fld_links type=&quot;settings&quot;&gt;
    &lt;setting type=&quot;heading&quot;&gt;Hyperlinks&lt;/setting&gt;
  &lt;/fld_links&gt;
  &lt;fld_publication_date type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication&lt;/tbl&gt;
    &lt;tbl type=&quot;select_date&quot; column=&quot;published_on&quot;&gt;publication&lt;/tbl&gt;
  &lt;/fld_publication_date&gt;
  &lt;fld_cve_ids type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;ids&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_cve_ids&gt;
  &lt;fld_damage type=&quot;replace&quot;&gt;
    &lt;rp original_value=&quot;1&quot;&gt;high&lt;/rp&gt;
    &lt;rp original_value=&quot;2&quot;&gt;medium&lt;/rp&gt;
    &lt;rp original_value=&quot;3&quot;&gt;low&lt;/rp&gt;
  &lt;/fld_damage&gt;
  &lt;fld_damage type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;damage&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_damage&gt;
  &lt;fld_probability type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;probability&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_probability&gt;
  &lt;fld_probability type=&quot;replace&quot;&gt;
    &lt;rp original_value=&quot;1&quot;&gt;high&lt;/rp&gt;
    &lt;rp original_value=&quot;2&quot;&gt;medium&lt;/rp&gt;
    &lt;rp original_value=&quot;3&quot;&gt;low&lt;/rp&gt;
  &lt;/fld_probability&gt;
  &lt;fld_title type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;title&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_title&gt;
  &lt;fld_govcert_id type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;govcertid&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_govcert_id&gt;
  &lt;fld_version type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;version&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_version&gt;
  &lt;fld_damage_descriptions type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;advisory_id&quot;&gt;advisory_damage&lt;/tbl&gt;
    &lt;tbl type=&quot;join1&quot; column=&quot;damage_id&quot;&gt;advisory_damage&lt;/tbl&gt;
    &lt;tbl type=&quot;join2&quot; column=&quot;id&quot;&gt;damage_description&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;description&quot;&gt;damage_description&lt;/tbl&gt;
  &lt;/fld_damage_descriptions&gt;
  &lt;fld_platforms type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;platforms_text&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_platforms&gt;
  &lt;fld_affected_products type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;products_text&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_affected_products&gt;
  &lt;fld_product_versions type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;versions_text&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_product_versions&gt;
&lt;/fields&gt;
&lt;/publication&gt;', 
'Advisory (email)', 
(SELECT id FROM publication_type WHERE title = 'Advisory (email)') );
INSERT INTO publication_template(description, "template", title, "type") 
	VALUES ('Complete advisory update template', 
'&lt;publication&gt;
&lt;template&gt;
   #########################################
  ##  S E C U R I T Y   A D V I S O R Y  ##
 #########################################

######################## UPDATE _fld_version2_ #############################

Title            : _fld_title_
Advisory ID      : _fld_govcert_id_
Version          : _fld_version_
Probability      : _fld_probability_
CVE ID           : _fld_cve_ids_
                   (http://cve.mitre.org/cve/)
Damage           : _fld_damage_
                   _fld_damage_descriptions_
Publication date : _fld_publication_date_
Product(s)       : _fld_affected_products_
Version(s)       : _fld_product_versions_
Platform(s)      : _fld_platforms_

   _fld_update_

   _fld_summary_

   _fld_consequences_

   _fld_description_

   _fld_solution_

   _fld_links_


&lt;/template&gt;

&lt;fields&gt;
  &lt;fld_update type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;update&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_update&gt;
  &lt;fld_update type=&quot;settings&quot;&gt;
    &lt;setting type=&quot;heading&quot;&gt;Update&lt;/setting&gt;
  &lt;/fld_update&gt;
  &lt;fld_summary type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;summary&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_summary&gt;
  &lt;fld_summary type=&quot;settings&quot;&gt;
    &lt;setting type=&quot;heading&quot;&gt;Summary&lt;/setting&gt;
  &lt;/fld_summary&gt;
  &lt;fld_description type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;description&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_description&gt;
  &lt;fld_description type=&quot;settings&quot;&gt;
    &lt;setting type=&quot;heading&quot;&gt;Description&lt;/setting&gt;
  &lt;/fld_description&gt;
  &lt;fld_solution type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;solution&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_solution&gt;
  &lt;fld_solution type=&quot;settings&quot;&gt;
    &lt;setting type=&quot;heading&quot;&gt;Solution&lt;/setting&gt;
  &lt;/fld_solution&gt;
  &lt;fld_consequences type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;consequences&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_consequences&gt;
  &lt;fld_consequences type=&quot;settings&quot;&gt;
    &lt;setting type=&quot;heading&quot;&gt;Consequences&lt;/setting&gt;
  &lt;/fld_consequences&gt;
  &lt;fld_links type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;hyperlinks&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_links&gt;
  &lt;fld_links type=&quot;settings&quot;&gt;
    &lt;setting type=&quot;heading&quot;&gt;Hyperlinks&lt;/setting&gt;
  &lt;/fld_links&gt;
  &lt;fld_publication_date type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication&lt;/tbl&gt;
    &lt;tbl type=&quot;select_date&quot; column=&quot;published_on&quot;&gt;publication&lt;/tbl&gt;
  &lt;/fld_publication_date&gt;
  &lt;fld_cve_ids type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;ids&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_cve_ids&gt;
  &lt;fld_damage type=&quot;replace&quot;&gt;
    &lt;rp original_value=&quot;1&quot;&gt;high&lt;/rp&gt;
    &lt;rp original_value=&quot;2&quot;&gt;medium&lt;/rp&gt;
    &lt;rp original_value=&quot;3&quot;&gt;low&lt;/rp&gt;
  &lt;/fld_damage&gt;
  &lt;fld_damage type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;damage&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_damage&gt;
  &lt;fld_probability type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;probability&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_probability&gt;
  &lt;fld_probability type=&quot;replace&quot;&gt;
    &lt;rp original_value=&quot;1&quot;&gt;high&lt;/rp&gt;
    &lt;rp original_value=&quot;2&quot;&gt;medium&lt;/rp&gt;
    &lt;rp original_value=&quot;3&quot;&gt;low&lt;/rp&gt;
  &lt;/fld_probability&gt;
  &lt;fld_title type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;title&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_title&gt;
  &lt;fld_govcert_id type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;govcertid&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_govcert_id&gt;
  &lt;fld_version type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;version&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_version&gt;
  &lt;fld_version2 type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;version&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_version2&gt;
  &lt;fld_damage_descriptions type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;advisory_id&quot;&gt;advisory_damage&lt;/tbl&gt;
    &lt;tbl type=&quot;join1&quot; column=&quot;damage_id&quot;&gt;advisory_damage&lt;/tbl&gt;
    &lt;tbl type=&quot;join2&quot; column=&quot;id&quot;&gt;damage_description&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;description&quot;&gt;damage_description&lt;/tbl&gt;
  &lt;/fld_damage_descriptions&gt;
  &lt;fld_platforms type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;platforms_text&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_platforms&gt;
  &lt;fld_affected_products type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;products_text&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_affected_products&gt;
  &lt;fld_product_versions type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_advisory&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;versions_text&quot;&gt;publication_advisory&lt;/tbl&gt;
  &lt;/fld_product_versions&gt;
&lt;/fields&gt;
&lt;/publication&gt;', 
'Advisory (update)', 
(SELECT id FROM publication_type WHERE title = 'Advisory (email)') );
INSERT INTO publication_template(description, "template", title, "type") 
	VALUES ('Complete End-of-Week email template', 
'&lt;publication&gt;
&lt;template&gt;
_fld_introduction_

Verstuurde beveiligingsadviezen
===============================
_fld_sent_advisories_

Nieuw op de kennisbank (https://kennisbank.ncsc.nl)
===================================================
_fld_newondatabank_

Wat was er nog meer in het nieuws
=================================
_fld_newsitem_

_fld_closing_


&lt;/template&gt;

&lt;fields&gt;
  &lt;fld_introduction type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofweek&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;introduction&quot;&gt;publication_endofweek&lt;/tbl&gt;
  &lt;/fld_introduction&gt;
  &lt;fld_sent_advisories type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofweek&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;sent_advisories&quot;&gt;publication_endofweek&lt;/tbl&gt;
  &lt;/fld_sent_advisories&gt;
  &lt;fld_newondatabank type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofweek&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;newondatabank&quot;&gt;publication_endofweek&lt;/tbl&gt;
  &lt;/fld_newondatabank&gt;
  &lt;fld_newsitem type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofweek&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;newsitem&quot;&gt;publication_endofweek&lt;/tbl&gt;
  &lt;/fld_newsitem&gt;
  &lt;fld_closing type=&quot;database&quot;&gt;
    &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofweek&lt;/tbl&gt;
    &lt;tbl type=&quot;select&quot; column=&quot;closing&quot;&gt;publication_endofweek&lt;/tbl&gt;
  &lt;/fld_closing&gt;
&lt;/fields&gt;
&lt;/publication&gt;', 
'End-of-Week (email)', 
(SELECT id FROM publication_type WHERE title = 'End-of-Week (email)') );

INSERT INTO publication_template (description, "template", title, "type") VALUES ('', '&lt;publication&gt;
&lt;template&gt;&lt;![CDATA[
==============
= Dagrapport =
==============
Periode:     _fld_timeframe_begin_ &amp;minus; _fld_timeframe_end_
Handler:     _fld_handler_
Tweede man:  _fld_first_co_handler_
Canis:       _fld_second_co_handler_

_fld_general_info_

===========================
= Kwetsbaarheden/Dreiging =
===========================
_fld_vulnerabilities_threats_

=================
= Incident-info =
=================
_fld_incident_info_

_fld_tlp_amber_

====================
= Community nieuws =
====================
_fld_community_news_

==================
= Media Exposure =
==================
_fld_media_exposure_

]]&gt;&lt;/template&gt;

&lt;fields&gt;
    &lt;fld_timeframe_begin type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;select_date_Dutch&quot; column=&quot;timeframe_begin&quot;&gt;publication_endofshift&lt;/tbl&gt;
    &lt;/fld_timeframe_begin&gt;
    &lt;fld_timeframe_end type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;select_date_Dutch&quot; column=&quot;timeframe_end&quot;&gt;publication_endofshift&lt;/tbl&gt;
    &lt;/fld_timeframe_end&gt;
    &lt;fld_handler type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;select&quot; column=&quot;fullname&quot; alias=&quot;handler&quot;&gt;users&lt;/tbl&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;join1&quot; column=&quot;handler&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;join2&quot; column=&quot;username&quot;&gt;users&lt;/tbl&gt;
    &lt;/fld_handler&gt;
    &lt;fld_first_co_handler type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;select&quot; column=&quot;fullname&quot; alias=&quot;first_co_handler&quot;&gt;users&lt;/tbl&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;join1&quot; column=&quot;first_co_handler&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;join2&quot; column=&quot;username&quot;&gt;users&lt;/tbl&gt;
    &lt;/fld_first_co_handler&gt;
    &lt;fld_second_co_handler type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;select&quot; column=&quot;fullname&quot; alias=&quot;second_co_handler&quot;&gt;users&lt;/tbl&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;join1&quot; column=&quot;second_co_handler&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;join2&quot; column=&quot;username&quot;&gt;users&lt;/tbl&gt;
    &lt;/fld_second_co_handler&gt;
    &lt;fld_general_info type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;select&quot; column=&quot;general_info&quot;&gt;publication_endofshift&lt;/tbl&gt;
    &lt;/fld_general_info&gt;
    &lt;fld_vulnerabilities_threats type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;select&quot; column=&quot;vulnerabilities_threats&quot;&gt;publication_endofshift&lt;/tbl&gt;
    &lt;/fld_vulnerabilities_threats&gt;
    &lt;fld_incident_info type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;select&quot; column=&quot;incident_info&quot;&gt;publication_endofshift&lt;/tbl&gt;
    &lt;/fld_incident_info&gt;
    &lt;fld_tlp_amber type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;select&quot; column=&quot;tlp_amber&quot;&gt;publication_endofshift&lt;/tbl&gt;
    &lt;/fld_tlp_amber&gt;
    &lt;fld_tlp_amber type=&quot;settings&quot;&gt;
        &lt;setting type=&quot;heading&quot;&gt;=============
= TLP-Amber =
=============&lt;/setting&gt;
    &lt;/fld_tlp_amber&gt;
    &lt;fld_community_news type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;select&quot; column=&quot;community_news&quot;&gt;publication_endofshift&lt;/tbl&gt;
    &lt;/fld_community_news&gt;
    &lt;fld_media_exposure type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;select&quot; column=&quot;media_exposure&quot;&gt;publication_endofshift&lt;/tbl&gt;
    &lt;/fld_media_exposure&gt;
&lt;/fields&gt;
&lt;/publication&gt;', 'End-of-Shift (email)', ( SELECT publication_type.id FROM publication_type WHERE title = 'End-of-Shift (email)') );

INSERT INTO publication_template (description, "template", title, "type") VALUES ('', '&lt;publication&gt;
&lt;template&gt;&lt;![CDATA[
==============
= Dagrapport =
==============
Periode:     _fld_timeframe_begin_ &amp;minus; _fld_timeframe_end_
Handler:     _fld_handler_
Tweede man:  _fld_first_co_handler_
Canis:       _fld_second_co_handler_

_fld_general_info_

===========================
= Kwetsbaarheden/Dreiging =
===========================
_fld_vulnerabilities_threats_

=================
= Incident-info =
=================
_fld_incident_info_

====================
= Community nieuws =
====================
_fld_community_news_

==================
= Media Exposure =
==================
_fld_media_exposure_

]]&gt;&lt;/template&gt;

&lt;fields&gt;
    &lt;fld_timeframe_begin type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;select_date_Dutch&quot; column=&quot;timeframe_begin&quot;&gt;publication_endofshift&lt;/tbl&gt;
    &lt;/fld_timeframe_begin&gt;
    &lt;fld_timeframe_end type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;select_date_Dutch&quot; column=&quot;timeframe_end&quot;&gt;publication_endofshift&lt;/tbl&gt;
    &lt;/fld_timeframe_end&gt;
    &lt;fld_handler type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;select&quot; column=&quot;fullname&quot; alias=&quot;handler&quot;&gt;users&lt;/tbl&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;join1&quot; column=&quot;handler&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;join2&quot; column=&quot;username&quot;&gt;users&lt;/tbl&gt;
    &lt;/fld_handler&gt;
    &lt;fld_first_co_handler type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;select&quot; column=&quot;fullname&quot; alias=&quot;first_co_handler&quot;&gt;users&lt;/tbl&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;join1&quot; column=&quot;first_co_handler&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;join2&quot; column=&quot;username&quot;&gt;users&lt;/tbl&gt;
    &lt;/fld_first_co_handler&gt;
    &lt;fld_second_co_handler type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;select&quot; column=&quot;fullname&quot; alias=&quot;second_co_handler&quot;&gt;users&lt;/tbl&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;join1&quot; column=&quot;second_co_handler&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;join2&quot; column=&quot;username&quot;&gt;users&lt;/tbl&gt;
    &lt;/fld_second_co_handler&gt;
    &lt;fld_general_info type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;select&quot; column=&quot;general_info&quot;&gt;publication_endofshift&lt;/tbl&gt;
    &lt;/fld_general_info&gt;
    &lt;fld_vulnerabilities_threats type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;select&quot; column=&quot;vulnerabilities_threats&quot;&gt;publication_endofshift&lt;/tbl&gt;
    &lt;/fld_vulnerabilities_threats&gt;
    &lt;fld_incident_info type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;select&quot; column=&quot;incident_info&quot;&gt;publication_endofshift&lt;/tbl&gt;
    &lt;/fld_incident_info&gt;
    &lt;fld_community_news type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;select&quot; column=&quot;community_news&quot;&gt;publication_endofshift&lt;/tbl&gt;
    &lt;/fld_community_news&gt;
    &lt;fld_media_exposure type=&quot;database&quot;&gt;
        &lt;tbl type=&quot;key&quot; column=&quot;id&quot;&gt;publication_endofshift&lt;/tbl&gt;
        &lt;tbl type=&quot;select&quot; column=&quot;media_exposure&quot;&gt;publication_endofshift&lt;/tbl&gt;
    &lt;/fld_media_exposure&gt;
&lt;/fields&gt;
&lt;/publication&gt;', 'End-of-Shift (email public)', ( SELECT publication_type.id FROM publication_type WHERE title = 'End-of-Shift (email public)') );

INSERT INTO parsers (parsername) VALUES ( 'xml' );
INSERT INTO parsers (parsername) VALUES ('twitter');
INSERT INTO category (name) VALUES ( 'security-news' );
INSERT INTO category (name) VALUES ( 'ict-news' );
INSERT INTO category (name) VALUES ( 'security-vuln' );
INSERT INTO category (name) VALUES ( 'news' );
INSERT INTO download_files (file_url, save_to, name, filename) VALUES ('http://static.nvd.nist.gov/feeds/xml/cve/nvdcve-2.0-recent.xml', '/opt/taranis/tmp/', 'cpe_download', 'nvdcve-2.0-recent.xml');
INSERT INTO download_files (file_url, save_to, name, filename) VALUES ('http://static.nvd.nist.gov/feeds/xml/cve/nvdcve-2.0-modified.xml', '/opt/taranis/tmp/', 'cpe_download', 'nvdcve-2.0-modified.xml');
INSERT INTO download_files (file_url, save_to, name, filename) VALUES ('http://cve.mitre.org/data/downloads/allitems.xml.gz', '/opt/taranis/tmp/', 'cve_description', 'allitems.xml.gz');

INSERT INTO dashboard(html, json, "type") VALUES ('', '', 1);
INSERT INTO dashboard(html, json, "type") VALUES ('', '', 2);
