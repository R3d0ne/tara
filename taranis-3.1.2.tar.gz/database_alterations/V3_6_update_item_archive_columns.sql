ALTER TABLE item_archive ADD COLUMN cluster_id character varying(22);
ALTER TABLE item_archive ADD COLUMN cluster_score numeric;
ALTER TABLE item_archive ADD COLUMN cluster_enabled boolean DEFAULT TRUE;
ALTER TABLE item_archive ADD COLUMN source_id integer;