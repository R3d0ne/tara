ALTER TABLE sources ADD COLUMN clustering_enabled boolean NOT NULL DEFAULT TRUE;

ALTER TABLE item ADD COLUMN cluster_id character varying(22);
ALTER TABLE item ADD COLUMN cluster_score numeric;
ALTER TABLE item ADD COLUMN cluster_enabled boolean DEFAULT TRUE;

-- add the item - source relation
ALTER TABLE item ADD COLUMN source_id integer;
ALTER TABLE item ADD CONSTRAINT fk_source_id FOREIGN KEY (source_id) REFERENCES sources (id) ON UPDATE NO ACTION ON DELETE NO ACTION;
CREATE INDEX fki_source_id ON item(source_id);

CREATE TABLE cluster
(
   id serial, 
   language character varying(2) NOT NULL, 
   threshold numeric NOT NULL, 
   timeframe_hours integer NOT NULL,
   recluster boolean NOT NULL DEFAULT TRUE,
   is_enabled boolean DEFAULT TRUE, 
   category_id integer NOT NULL, 
   CONSTRAINT pk_cluster PRIMARY KEY (id), 
   CONSTRAINT fk_category FOREIGN KEY (category_id) REFERENCES category (id) ON UPDATE NO ACTION ON DELETE NO ACTION, 
   CONSTRAINT unique_cluster UNIQUE (language, category_id)
);