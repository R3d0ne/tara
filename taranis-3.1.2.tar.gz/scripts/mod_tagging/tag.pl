#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Tagging;
use Taranis qw(:all);
use URI::Escape;
use JSON;
use strict;

my @EXPORT_OK = qw(getList setTags);

sub tag_export {
	return @EXPORT_OK; 
}

my $tag = Taranis::Tagging->new();

sub getList {
	my ( %kvArgs ) = @_;

	my $tags = $tag->getTags( $kvArgs{term} );

	print "Content-type: application/json \n\n";
	print to_json( $tags );

	return {};
}

sub setTags {
	my ( %kvArgs ) = @_;	
	
	my $tags_str = $kvArgs{tags};
	my $table = $kvArgs{t_name};
	my $item_id = $kvArgs{item_id};

	my $msg = "";
	
	$tags_str =~ s/,$//;
	
	my @tags = split( ',', $tags_str );
	
	$tag->{dbh}->startTransaction();
	TAG: foreach my $t ( @tags ) {
		$t = trim( $t );

		my $tag_id;
		if ( !$tag->{dbh}->checkIfExists( { name => $t }, "tag", "IGNORE_CASE" ) ) {
			$tag->addTag( $t );
			$tag_id = $tag->{dbh}->getLastInsertedId( "tag" );
		} else {
			$tag_id = $tag->getTagId( $t );
			
			if ( $tag->{dbh}->checkIfExists( 
				{ tag_id => $tag_id, item_table_name => $table, item_id => $item_id }, 
				"tag_item", 
				"IGNORE_CASE" 
			) ) {
				next TAG;
			}
		}
		
		if ( !$tag->setItemTag( $tag_id, $table, $item_id ) ) {
			$msg = $tag->{errmsg};
		}
	}

	if ( !$tag->removeItemTag( $item_id, $table, \@tags ) ) {
		$msg = $tag->{errmsg};
	}

	if ( !$msg ) {
		$msg = "Tag(s) have been saved.";
	}
	
	$tag->cleanUp();
	
	$tag->{dbh}->endTransaction();
	
	return { 
		params => { 
			message => $msg,
			tagsid => $table . '-' . uri_escape( $item_id )
		} 
	};
}
1;
