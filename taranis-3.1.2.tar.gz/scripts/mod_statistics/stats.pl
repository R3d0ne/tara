#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:util);
use Taranis::Template;
use Taranis::Statistics;
use Taranis::Users;
use Taranis::Config;
use strict;

my @EXPORT_OK = qw( displayStats searchStats );

sub stats_export {
	return @EXPORT_OK;
}

sub displayStats {
	my ( %kvArgs) = @_;
	my ( $vars );
	
	my $tt = Taranis::Template->new();
	my $st = Taranis::Statistics->new();
	my $statsType = ( exists( $kvArgs{statstype} ) && $kvArgs{statstype} ) ? $kvArgs{statstype} : undef;
	
	$vars->{stats_categories} = $st->getStatsCategories();
	$vars->{stats} = $st->loadCollection( category => $statsType );

	my $absroot = Taranis::Config->getSetting("absroot");
	
	foreach ( @{ $vars->{stats} } ) {
		$_->{target} =~ s/$absroot//gi;
	}
	
	my $pageTitle; 
	if ( $statsType ) {
		$pageTitle = ( $statsType =~ /statistics/i ) ? $statsType : $statsType .' Statistics';
	} else {
		$pageTitle = 'All Statistics';
	}
	
	$vars->{stats_selected} = $statsType;
	$vars->{page_title} = $pageTitle;
	
	my @js = ('js/stats.js');
	my $htmlContent = $tt->processTemplateNoHeader('stats.tt', $vars, 1);
	my $htmlFilters = $tt->processTemplateNoHeader('stats_filters.tt', $vars, 1);
	
	return { content => $htmlContent, filters => $htmlFilters, js => \@js };
}

sub searchStats {
	my ( %kvArgs) = @_;
	my ( $vars );

	my $tt = Taranis::Template->new();
	my $st = Taranis::Statistics->new();
	my $statsType = ( exists( $kvArgs{statstype} ) && $kvArgs{statstype} ) ? $kvArgs{statstype} : undef;
	
	$vars->{stats_categories} = $st->getStatsCategories();
	$vars->{stats} = $st->loadCollection( category => $statsType );

	my $absroot = Taranis::Config->getSetting("absroot");

	foreach ( @{ $vars->{stats} } ) {
		$_->{target} =~ s/$absroot//gi;
	}

	my $htmlContent = $tt->processTemplateNoHeader('stats.tt', $vars, 1);

	return { content => $htmlContent };	
}
1;
