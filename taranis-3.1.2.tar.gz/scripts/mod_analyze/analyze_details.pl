#!/usr/bin/perl	
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Analysis;
use Taranis::Assess;
use Taranis::Users;
use Taranis::Template;
use Taranis::Tagging;
use Taranis::MetaSearch;
use Taranis qw(:all);
use strict;

my @EXPORT_OK = qw(openDialogAnalyzeDetails saveAnalyzeDetails openDialogNewAnalysis saveNewAnalysis closeAnalysis analyzeDetailsMetaSearch);

sub analyze_details_export {
	return @EXPORT_OK; 
}

sub openDialogAnalyzeDetails {
	my ( %kvArgs ) = @_;
	my ( $vars, $tpl, $message, $locked, $openedByFullname, $isJoined );
	
	my $session = $kvArgs{session};
	my $an = Taranis::Analysis->new();
	my $as = Taranis::Assess->new();
	my $tt = Taranis::Template->new();
	my $tg = Taranis::Tagging->new();
	
	$vars->{pageSettings} = $session->getSessionUserSettings();
	my $id = ( exists( $kvArgs{id} ) && $kvArgs{id} =~ /^\d{8}$/ ) ? $kvArgs{id} : undef;
	
	if ( $id ) {
		my $analysis = $an->getRecordsById( table => "analysis", id => $id )->[0];
		
		$isJoined = ( $analysis->{status} =~ /^joined$/i ) ? 1 : 0;
		
		$analysis->{idstring} = trim( $analysis->{idstring} );      
		
	    $vars->{analysis} = $analysis;
		$vars->{items} = $an->getLinkedItems( $id );
		my $tags = $tg->getTagsByItem( $id, "analysis" );
		$vars->{tags} = "@$tags";
		
		my $userId = $session->{cgisession}->param("userid");
		
		if ( my $openedBy = $an->isOpenedBy( $id ) ) {
			$locked = ( $openedBy->{opened_by} =~ $userId ) ? 0 : 1;
			$vars->{openedByFullname} = $openedBy->{fullname};
		} elsif( $session->right("write") ) {
			if ( $an->openAnalysis( $userId, $id ) ) {
				$locked = 0;
			} else {
				$locked = 1;
			}
		} else {
			$vars->{locked} = 1;
		}
		$tpl = 'analyze_details.tt';
	} else {
		$tpl = 'dialog_no_right.tt';
		$message = 'Invalid id...';
	}
	
	$vars->{idLocked} = $locked;
	
	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );
	
	return { 
		dialog => $dialogContent, 
		params => {
			id => $id,
			isLocked => $locked,
			isJoined => $isJoined
		}
	};
}

sub openDialogNewAnalysis {
	my ( %kvArgs ) = @_;
	my ( $vars, $tpl );
	
	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	
	if ( $session->right("write") ) {
		$vars->{newAnalysis} = 1;
		$vars->{analysis}->{status} = 'pending';
		$vars->{pageSettings} = $session->getSessionUserSettings();
		$tpl = "analyze_details_tab1.tt";
	} else {
		$tpl = "dialog_no_right.tt";
		$vars->{message} = 'No rights...'; 	
	}	

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );		
	
	return { dialog => $dialogContent };
}

sub saveNewAnalysis {
	my ( %kvArgs ) = @_;
	my ( $message, $analysisId );
	
	my $session = $kvArgs{session};
	my $analysisIsAdded = 0;
	my $tagsAreSaved = 0;
	
	if ( $session->right("write") ) {
		
		my $an = Taranis::Analysis->new();
		
		if ( $analysisId = $an->addObject( 	
			table => "analysis",
			title => $kvArgs{title}, 
			comments => $kvArgs{comments}, 
			idstring => $kvArgs{idstring}, 
			rating => $kvArgs{rating},
			status => $kvArgs{status}
		)) {
			my $tags_str = $kvArgs{tags}; 
			$tags_str =~ s/,$//;
		
			my @tags = split( ',', $tags_str );

			$tagsAreSaved = 1 if ( !@tags );

			if ( $analysisId ) {

				my $tg = Taranis::Tagging->new();
				$tg->{dbh}->startTransaction();					
				
				foreach my $t ( @tags ) {
					$t = trim( $t );

					my $tag_id;
					if ( !$tg->{dbh}->checkIfExists( { name => $t }, "tag", "IGNORE_CASE" ) ) {
						$tg->addTag( $t );
						$tag_id = $tg->{dbh}->getLastInsertedId( "tag" );
					} else {
						$tag_id = $tg->getTagId( $t );
					}

					if ( !$tg->setItemTag( $tag_id, "analysis", $analysisId ) ) {
						$message = $tg->{errmsg};
					}
				} 
				$tg->{dbh}->endTransaction();
				
			} else {
				$message = "Cannot save tag(s), missing analysis id."
			}
			
			if ( $message ) {
				$message .= " The analysis has been saved.";
			} else {
				$tagsAreSaved = 1;
			}
			
			$analysisIsAdded = 1;
		} else {
			$message = $an->{errmsg};
		}	
	}

	return { 
		params => {
			analysisIsAdded => $analysisIsAdded,
			message => $message,
			tagsAreSaved => $tagsAreSaved,
			id => $analysisId
		} 
	};
}

sub saveAnalyzeDetails {
	my ( %kvArgs ) = @_;
	my ( $message );
	
	my $an = Taranis::Analysis->new();
	
	my $isSaved = 0;
	my $analysisId = ( exists($kvArgs{id}) && $kvArgs{id} =~ /^\d{8}$/ ) ? $kvArgs{id} : undef;	
	
	if ( $analysisId ) {
		if ( !$an->setAnalysis( 
			id => $analysisId,
			title => $kvArgs{title}, 
			comments => $kvArgs{comments}, 
			idstring => $kvArgs{idstring}, 
			rating => $kvArgs{rating},
			status => $kvArgs{status},
			original_status => $kvArgs{original_status} 
		)) {
			$message = $an->{errmsg};
		} else {
			$isSaved = 1;
		}
	} else {
		$message = 'Invalid id...';
	}

	return {
		params => {
			isSaved => $isSaved,
			message => $message,
			analysisId => $analysisId
		}
	};
}

sub closeAnalysis {
	my ( %kvArgs ) = @_;
	
	my $session = $kvArgs{session};
	my $an = Taranis::Analysis->new();

	my $id = $kvArgs{id};

	my $userid = $session->{cgisession}->param("userid");

	my $is_admin = $session->getUserRights( 
		entitlement => "admin_generic", 
		username => $userid 
	)->{admin_generic}->{write_right};

	my $openedBy = $an->isOpenedBy( $id );

	if ( ( exists( $openedBy->{opened_by} ) && $openedBy->{opened_by} eq $userid ) || $is_admin ) {
		$an->closeAnalysis( $id );
	}
	
	return {
		params => { 
			id => $id,
			removeItem => $kvArgs{removeItem}
		}
	};
}

sub analyzeDetailsMetaSearch {
	my ( %kvArgs ) = @_;
	my ( $vars );
	
	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();	
	my $ms = Taranis::MetaSearch->new();

	my $searchSettings = $ms->dissectSearchString( $kvArgs{ids} );
	my $searchArchive = $kvArgs{archive};
	my $analysisId = $kvArgs{id};
	
	my %searchDBSettings;
	$searchDBSettings{item}->{archive} = $searchArchive;
	$searchDBSettings{analyze}->{searchAnalyze} = 1;
	$searchDBSettings{publication}->{searchAllProducts} = 1;
	$searchDBSettings{publication_advisory}->{status} = 3;
	$searchDBSettings{publication_endofweek}->{status} = 3;

	$vars->{results} = $ms->search( $searchSettings, \%searchDBSettings ); 

	my $analyzeDetailsTab3Html = $tt->processTemplateNoHeader( 'analyze_details_tab3.tt', $vars, 1 );

	return {
		params => { 
			searchResultsHtml => $analyzeDetailsTab3Html,
			id => $analysisId 
		}
	};
}

1;
