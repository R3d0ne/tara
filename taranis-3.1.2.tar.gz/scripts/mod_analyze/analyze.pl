#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:all);
use Taranis::Users;
use Taranis::Template;
use Taranis::Analysis;
use Taranis::Publication;
use Taranis::Config;
use strict;

my @EXPORT_OK = qw(displayAnalyze searchAnalyze getAnalyzeItemHtml setOwnership checkOwnership);

my $an = Taranis::Analysis->new();
my $pu = Taranis::Publication->new();
my $settings;
my $advisoryPrefix = Taranis::Config->getSetting("advisory_prefix");
my $advisoryIdLength = Taranis::Config->getSetting("advisory_id_length");

sub analyze_export {
	return @EXPORT_OK;
}

sub displayAnalyze {
	my ( %kvArgs ) = @_;

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	
	my $vars = getAnalyzeSettings( session => $session );
	my $pageNumber = ( exists( $kvArgs{'hidden-page-number'} ) && $kvArgs{'hidden-page-number'} =~ /^\d+$/ )
		? $kvArgs{'hidden-page-number'}
		: 1;

	my $status = ( exists( $kvArgs{status} ) ) ? $kvArgs{status} : '';
	
	$vars->{status} = $status;
	
	$vars->{collection} = getAnalyzeResults(
		page => $pageNumber,
		status => $status,
		session => $session
	);
	
	$vars->{newItem} = 1;
	$vars->{filterButton} = 'btn-analyze-search';
	$vars->{page_bar} = $tt->createPageBar( $pageNumber, $an->{result_count}, $an->{limit} );
	
	my $htmlContent = $tt->processTemplateNoHeader('analyze.tt', $vars, 1);
	my $htmlFilters = $tt->processTemplateNoHeader('analyze_filters.tt', $vars, 1);
	
	my @js = (
		'js/tagging.js',
		'js/publications_common_actions.js',
		'js/publications.js',
		'js/publications_advisory.js',
		'js/analyze.js', 
		'js/analyze_filters.js',
		'js/analyze_details.js',
		'js/assess_details.js', 
		'js/assess2analyze.js',
		'js/analysis2publication.js',
		'js/jquery.hoverIntent.minified.js'
	);
	
	return { content => $htmlContent, filters => $htmlFilters, js => \@js };
}

sub searchAnalyze {
	my ( %kvArgs) = @_;

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();

	my $vars = getAnalyzeSettings( session => $session );

	my @rating = ();
	if ( exists( $kvArgs{rating} ) ) {
		if ( ref( $kvArgs{rating} ) =~ /^ARRAY$/ ) {
			@rating = @{ $kvArgs{rating} };
		} else {
			push @rating, $kvArgs{rating};
		}
	} 
	
	my $pageNumber = ( exists( $kvArgs{'hidden-page-number'} ) && $kvArgs{'hidden-page-number'} =~ /^\d+$/ )
		? $kvArgs{'hidden-page-number'}
		: 1;

	my $status = ( exists( $kvArgs{status} ) ) ? $kvArgs{status} : '';	
	my $search = ( exists( $kvArgs{searchkeywords} ) ) ? trim( $kvArgs{searchkeywords} ) : undef;
	
	$vars->{collection} = getAnalyzeResults(
		page => $pageNumber,
		status => $status,
		rating => \@rating,
		search => $search,
		session => $session
	);
	
	$vars->{newItem} = 1;
	$vars->{filterButton} = 'btn-analyze-search';	
	$vars->{page_bar} = $tt->createPageBar( $pageNumber, $an->{result_count}, $an->{limit} );
	
	my $htmlContent = $tt->processTemplateNoHeader('analyze.tt', $vars, 1);
	
	my @js = ('js/analyze.js');
	
	return { content => $htmlContent , js => \@js };
}

sub getAnalyzeItemHtml {
	my ( %kvArgs ) = @_;
	my ( $vars, $tpl, $status );
	
	my $session = $kvArgs{session};
	my $an = Taranis::Analysis->new();
	my $tt = Taranis::Template->new();
	
	my $analysisId = $kvArgs{id};
	my $insertNew = $kvArgs{insertNew};
 
	my $analysis = $an->getRecordsById( table => 'analysis', id => $analysisId );
	
	if ( $analysis ) {
		$vars = getAnalyzeSettings( session => $session );
		
		$vars->{newItem} = $insertNew;
		my $formattedAnalysis = formatAnalysisRecord( record => $analysis->[0] ); 
		$formattedAnalysis->{links} = $an->getLinkedItems( $analysisId );
		$status = $formattedAnalysis->{status};
		$vars->{analysis} = $formattedAnalysis;
		
		$tpl = 'analyze_item.tt';
	} else {
		$tpl = 'empty_row.tt';
		$vars->{message} = 'Could not find the item...';
	}

	my $analyzeItemHtml = $tt->processTemplateNoHeader($tpl, $vars, 1);

	return {
		params => { 
			itemHtml => $analyzeItemHtml,
			analysisId => $analysisId,
			insertNew => $insertNew,
			status => $status
		} 
	};
}

sub checkOwnership {
	my ( %kvArgs ) = @_;
	
	my $message;
		
	my $session = $kvArgs{session};
	my $an = Taranis::Analysis->new();
	
	my $analysisId = $kvArgs{id};
	
	my $owner = $an->getOwnerShip( $analysisId );
	my $userIsOwner = 0;

	if ( defined( $owner ) && $owner eq $session->{cgisession}->param("userid") ) {
		$userIsOwner = 1;
	} else {
		$message = $an->{errmsg};
	}

	return { 
		params => {
			owner => $owner,
			analysisId => $analysisId,
			message => $message,
			userIsOwner => $userIsOwner
		}
	};
}

sub setOwnership {
	my ( %kvArgs ) = @_;
	
	my $ownershipSet = 0;
	my $message;
		
	my $session = $kvArgs{session};
	my $an = Taranis::Analysis->new();
	
	my $analysisId = $kvArgs{id};
	my $username = ( exists( $kvArgs{userIsOwner} ) && $kvArgs{userIsOwner} =~ /^0$/ ) 
		? $session->{cgisession}->param("userid")
		: undef;
	
	if ( $an->setOwnerShip( $username, $analysisId ) ) {
		$ownershipSet = 1;
	}  else {
		$message = $an->{errmsg};
	}
	
	return { 
		params => {
			ownershipSet => $ownershipSet,
			analysisId => $analysisId,
			message => $message
		}
	};
}

## HELPERS ##

sub getAnalyzeResults {
	my ( %kvArgs ) = @_;
	
	my $session = $kvArgs{session};
	
	my $page = ( exists( $kvArgs{page} ) && $kvArgs{page} =~ /^\d+$/ ) ? $kvArgs{page} : 1;
	my $limit = $an->{limit};
	my $offset = ( $page - 1 ) * $limit;
	
	my %collectionSettings = ( offset => $offset );
	
	$collectionSettings{search} = $kvArgs{search} if ( exists( $kvArgs{search} ) && $kvArgs{search} );
	$collectionSettings{rating} = $kvArgs{rating} if ( exists( $kvArgs{rating} ) && $kvArgs{rating} );
	
	my $status = ( exists( $kvArgs{status} ) ) ? $kvArgs{status} : '';
	
	my @searchStatus = @{ $settings->{pageSettings}->{analysis_status_options} };
	if ( $status ne '' ) {
		my $isStatusAllowed = 0;
		
		foreach my $allowedStatus ( @searchStatus ) {
			$isStatusAllowed = 1 if ( lc( $allowedStatus ) eq lc( $status ) );
		}
		
		if ( $isStatusAllowed  ) {
			@searchStatus = $status;	
		}
	}

	$collectionSettings{status} = \@searchStatus if ( @searchStatus );
	$an->loadAnalysisCollection( %collectionSettings );

	my @collection;
	my @analysisIds;
	while ( $an->nextObject() ) {
		my $record = $an->getObject();
		push @analysisIds, $record->{id};
		push @collection, formatAnalysisRecord( record => $record );
	}

	my $linkedItemsBulk = $an->getLinkedItemsBulk( 'ia.analysis_id' => \@analysisIds );
	for ( my $i = 0; $i < @collection; $i++ ) {
		if ( exists( $linkedItemsBulk->{ $collection[$i]->{orgid} } ) ) {
			$collection[$i]->{links} = $linkedItemsBulk->{ $collection[$i]->{orgid} };
		}
	}
	
	return \@collection;
}

sub formatAnalysisRecord {
	my ( %kvArgs ) = @_;

	my $analysis = {};
	my $record = $kvArgs{record};

	for ( $record->{rating} ) {
		if (/1/) { $analysis->{rating} = "low"; }
		elsif (/2/) { $analysis->{rating} = "medium"; }
		elsif (/3/) { $analysis->{rating} = "high"; }
		elsif (/4/) { $analysis->{rating} = "undefined"; }
	}
	
	$analysis->{orgid} = $record->{id};
	$analysis->{id} = "AN-" . substr( $record->{id}, 0, 4 ) . "-" . substr( $record->{id}, 4, 4 );    
	$analysis->{status} = ucfirst( lc( $record->{status} ) );
	$analysis->{created} = $record->{created};
	$analysis->{title} = $record->{title};
	$analysis->{opened_by} = $record->{opened_by};
	$analysis->{owned_by} = $record->{owned_by};
	$analysis->{openedbyfullname} = $record->{openedbyfullname};
	$analysis->{ownedbyfullname} = $record->{ownedbyfullname};
	$analysis->{sentAdvisory} = 0;
	
	my $comments = sanitizeInput( "newline_to_br", $record->{comments});
	$comments =~ s/\[\=\=\ /\<div\ class\=\"comments\"\>/gi;
	$comments =~ s/\ \=\=\](.*?)\<br\/\>/<\/div\>/gi;
	$comments =~ s/\[\=\=\=\ /\<div\ class\=\"joinedAnalysis\"\>/gi;
	$comments =~ s/\ \=\=\=\](.*?)\<br\/\>/<\/div\>/gi;

	my %foundAdvisoryIds;
	$analysis->{publishedAdvisories} = [];
	
	ADVISORYID:
	foreach my $id ( $comments =~ /($advisoryPrefix-\d{$advisoryIdLength}-\d+)/gi ) {
		if ( exists( $foundAdvisoryIds{ $id } ) ) {
			next ADVISORYID;
		}
		$foundAdvisoryIds{ $id } = 1;
		my $advisory = $pu->getLatestAdvisoryVersion( govcertId => uc( $id ) );
		$comments =~ s/$id/$id\[$advisory->{publication_id}]/gi if ( $advisory );
		
		my $advisories = $pu->getPublishedPublicationsByAnalysisId( table => 'publication_advisory', govcertid => uc( $id ), analysis_id => $record->{id} );
		push @{ $analysis->{publishedAdvisories} }, @$advisories if ( $advisories );
	}


	$analysis->{comments} = $comments;

	return $analysis;
}

sub getAnalyzeSettings {
	my ( %kvArgs ) = @_;
	
	my $session = $kvArgs{session};
	my $userId = $session->{cgisession}->param("userid");
	
	$settings->{write_right} = $session->right("write");
	$settings->{pageSettings} = $session->getSessionUserSettings();
	$settings->{is_admin} = $session->getUserRights(
			entitlement => "admin_generic", 
			username => $userId
		)->{admin_generic}->{write_right};

	my $publication_rights = $session->getUserRights( entitlement => "publication", username => $userId )->{publication};
	
	$settings->{publication_right} = 0;
	
	if ( $publication_rights->{write_right} ) {
		if ( $publication_rights->{particularization} ) {
			foreach my $right ( @{ $publication_rights->{particularization} } ) {
				if ( lc ( $right ) eq "advisory (email)" ) {
					$settings->{publication_right} = 1;
				}
			} 
		} else {
			$settings->{publication_right} = 1;		
		}
	}
	
	return $settings;
}

1;
