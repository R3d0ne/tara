#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

#TODO: howto open links from outside Taranis (links from mailed items)
use strict;
use Taranis::Session;
use Taranis::Template;
use Taranis::Config;
use Taranis::Config::XMLGeneric;
use URI::Escape;
use JSON;
use CGI::Simple;

use Taranis qw(:all);
use Data::Dumper;

# set max 10MB posts, which is needed for sources import function
$CGI::Simple::POST_MAX= 1024 * 100 * 100 *10; 

my $isAjax = ( $ENV{REQUEST_URI} =~ /load\/$/ ) ? 1 : 0;
my $isDownload = ( $ENV{REQUEST_URI} =~ /loadfile\// ) ? 1 : 0;
my $isBigScreen = ( $ENV{REQUEST_URI} =~ /loadbigscreen\/$/ ) ? 1 : 0;
my $isShortCut = ( $ENV{REQUEST_URI} =~ /goto\/.*?$/ ) ? 1 : 0;
my $blingOn = ( $ENV{REQUEST_URI} =~ /blingbling\/$/ ) ? 1 : 0;
 
my ( $userid, $query, $session, $shortcutSettings );
my $response = { session_ok => 0, is_success => 0 };

if ( $session = Taranis::Session->loadSession( redirect => $ENV{REQUEST_URI}, ajax => $isAjax ) ) {
	$query = $session->{cgisession}->query;

	if ( !$session->{errmsg} ) {
	
		$response->{session_ok} = 1;
	
		my $scriptRootPath = Taranis::Config->getSetting('scriptpath'); 
		
		# add trailing slash if not present
		$scriptRootPath .= '/' if ( $scriptRootPath !~ /.*?\/$/ );

		if ( $isShortCut ) {
			my $shortcuts = Taranis::Config::XMLGeneric->new("shortcutsconfig", "shortcut", "shortcuts");
			
			my $uri = $ENV{REQUEST_URI};
			my ( $shortcut ) = $uri =~ /goto\/(.*?)\/?$/i;
			$shortcutSettings = $shortcuts->getElement( $shortcut );
		}	

		my $modName 	= $query->param('modName');
		my $scriptName 	= $query->param('pageName');
		my $subName 	= $query->param('action');
		my $params 		= ( $query->param('params') ) ? from_json( $query->param('params') ) : {};
		
		if ( $query->param('term') ) {
			$params = { 'term' => $query->param('term') };
		}

#		logdit 'mod: ' . $query->param('modName');
#		logdit 'page: ' . $query->param('pageName');
#		logdit 'action: ' . $query->param('action');
		# only key/value arguments are allowed
		my %kvArgs = ();
		if ( %$params ) {		
			foreach my $key ( keys( %$params ) ) {
				if ( ref( $params->{$key} ) =~ /^ARRAY$/ ) {
						$kvArgs{$key} = [];
						foreach ( @{ $params->{$key} } ) {
							my $val = uri_unescape( $_ );
							push @{ $kvArgs{$key} }, encodeInput( \$val );
						}
				} else {
					my $val = uri_unescape( $params->{$key} );
					$kvArgs{ $key } = encodeInput( \$val );
				}
			}
		}
		
		my $bling = ( $blingOn || ( $session->{cgisession}->param('bling') && $isAjax ) ) ? 1 : 0;
		$session->{cgisession}->param('bling', $bling);
		
		$kvArgs{session} = $session;

		# module name and script name may only consist of letters, numbers and _ (underscore)
		if ( 
			!$modName || !$scriptName || !$subName 
			|| $modName =~ /[^A-Za-z_\d]/ || $scriptName =~ /[^A-Za-z_\d]/
			|| ( $modName =~ /^tools$/ && $kvArgs{tool} =~ /[^A-Za-z_\d]/ )
		) {
			$response->{message} = 'Illegal action!! (0)';
		} else {
			my $scriptPath = $scriptName;
			if ( $modName =~ /tools/ ) {
				$scriptPath = $kvArgs{tool} . '/' . $scriptName;
			}
			
			my $scriptFilePath = $scriptRootPath . 'mod_' . $modName . '/' . $scriptPath . '.pl';

			my @exportList = undef;
			eval{
				require $scriptFilePath;
				### Get the list of subroutines which are available.
				# Every script should have a subroutine which returns @EXPORT_OK
				# The name of the subroutine begins with the name of the script and a suffix '_export' 
				# i.e. the export subroutine of assess.pl is assess_export
				my $exportSubName = $scriptName . '_export';
				my $exportSub = \&$exportSubName;
#				logdit $exportSubName;
				@exportList = $exportSub->();
#				logdit Dumper \@exportList;
			};

			if ( $@ ) {
				$response->{message} = 'Illegal action!! (1) ';# . $@;
			} else {
				
				# only allow execution of subroutines which are in the exportlist
				if ( grep $_ eq $subName, @exportList ) {
		
					my $subRef = \&$subName;
					eval {
						$response->{page} = &$subRef( %kvArgs );
					};
					
					if ( $@ ) {
						$response->{message} = 'Illegal action!! (2) ';# . $@;
					} else {
						$response->{is_success} = 1;
					}
				} else {
					$response->{message} = 'Illegal action!! (3) Missing sub in EXPORTLIST...';
				}
			}
			
			undef @exportList;
		}
	}
}

# scripts that serve file downloads, should also print the appropiate header

if ( $isAjax ) {
	# if it's an AJAX request print header and response in JSON
	
	if ( $session->{errmsg} ) {
		$response->{message} = $session->{errmsg};
		$response->{session_ok} = 0;
	}
	
	print $query->header();
	print to_json( $response );	
} elsif ( $isBigScreen ) {
	my $tt = Taranis::Template->new();
	my $vars = { user => $session->{cgisession}->param("userid") };
	
	$vars->{pageSettings} = $session->getSessionUserSettings();
	$tt->processTemplate( "bigscreen.tt", $vars );
} elsif ( !$isDownload ) {
	# if it's not an AJAX request and not a file download load the main page.
	my $tt = Taranis::Template->new();
	my $vars = { user => $session->{cgisession}->param("userid") };
	
	$vars->{pageSettings} = $session->getSessionUserSettings();
	$vars->{shortcutSettings} = ( $shortcutSettings ) ? to_json( $shortcutSettings ) : undef;
		
	$tt->processTemplate( "main.tt", $vars);
}
