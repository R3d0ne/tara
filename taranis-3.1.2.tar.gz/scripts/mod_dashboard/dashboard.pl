#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Dashboard;
use Taranis::Template;
use JSON;
use strict;

my @EXPORT_OK = qw( getDashboardData getMinifiedDashboardData );

sub dashboard_export {
	return @EXPORT_OK;
}

sub getMinifiedDashboardData {
	my ( %kvArgs ) = @_;
	my $dab = Taranis::Dashboard->new();

	my $dashboardHtml = $dab->getDashboard( $dab->{minified} );

	return {
		dashboard => $dashboardHtml
	}
}

sub getDashboardData {
	my ( %kvArgs ) = @_;
	my $dab = Taranis::Dashboard->new();
	my $tt = Taranis::Template->new();
	
	my $dashboardData = $dab->getDashboard( $dab->{maximized} );
	
	my $htmlFilters = $tt->processTemplateNoHeader('dashboard_filters.tt', undef, 1);

	return {
		content => $dashboardData->{html},
		filters => $htmlFilters,
		params => {
			dashboard => from_json( $dashboardData->{json} )
		}
	};
}

1;
