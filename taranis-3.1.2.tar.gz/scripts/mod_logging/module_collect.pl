#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Template;
use Taranis::Error;
use strict;
use Taranis qw(:util);

my @EXPORT_OK = qw( 
	displayCollectorLogging openDialogCollectorLoggingDetails
	deleteCollectorLogging searchCollectorLogging bulkDeleteCollectorLogging
);

sub module_collect_export {
	return @EXPORT_OK;
}

sub displayCollectorLogging {
	my ( %kvArgs) = @_;
	my ( $vars );
	
	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $er = Taranis::Error->new();

	my $pageNumber = ( exists( $kvArgs{'hidden-page-number'} ) && $kvArgs{'hidden-page-number'} =~ /^\d+$/ )
		? $kvArgs{'hidden-page-number'}
		: 1;

	$er->loadCollection( offset => ( $pageNumber - 1 ) * 100 );
#	tie my %loggingPerSource, "Tie::IxHash";
	my @loggingItems;
	my $loggingCount = 0;
	while ( $er->nextObject() ) {
		my $record = $er->getObject();
		$record->{sourceid} = "STATSIMG" if ( !$record->{sourceid} );
#		if ( exists( $loggingPerSource{ $record->{sourceid} } ) ) {
#			if ( exists( $loggingPerSource{ $record->{sourceid} }->{$record->{error_code} } ) ) {
#				push @{ $loggingPerSource{ $record->{sourceid} }->{$record->{error_code} } }, { error => $record->{error}, datetime => $record->{datetime} };
#			} else {
#				$loggingPerSource{ $record->{sourceid} }->{$record->{error_code} } = [ { error => $record->{error}, datetime => $record->{datetime} }  ];
#			}
#		} else {
#			$loggingPerSource{ $record->{sourceid} } = {  
#				fullurl => $record->{fullurl},
#				sourcename => $record->{sourcename},
#				sourceid => $record->{sourceid},
#				$record->{error_code} => [ { error => $record->{error}, datetime => $record->{datetime} } ]
#			}
#		}
#		$loggingCount++;
		push @loggingItems, $record;
	}

#	foreach my $logging ( keys %loggingPerSource ) {
#		push @loggingItems, $loggingPerSource{ $logging };
#	}

	$vars->{loggingItems} = \@loggingItems;
	$vars->{error_codes} = $er->getDistinctErrorCodes();
	
	$vars->{page_bar} = $tt->createPageBar( $pageNumber, $er->{result_count}, 100 );
	$vars->{filterButton} = 'btn-collector-logging-search';
	$vars->{write_right} = $session->right('write');
	$vars->{numberOfResults} = $loggingCount;
	$vars->{newItem} = 1;
	
	my $htmlContent = $tt->processTemplateNoHeader('logging_module_collect.tt', $vars, 1);
	my $htmlFilters = $tt->processTemplateNoHeader('logging_module_collect_filters.tt', $vars, 1);
	
	my @js = ('js/logging_module_collect.js');
	
	return { content => $htmlContent, filters => $htmlFilters, js => \@js };		
}
	
sub openDialogCollectorLoggingDetails {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $tt = Taranis::Template->new();
	my $er = Taranis::Error->new();
	
	if ( $kvArgs{id} =~ /^\d+$/ ) {
		my $error = $er->getError( $kvArgs{id} );
		$vars->{collectorLog} = $error;

		my $log = fileToString( $error->{logfile} );
		$vars->{"log"} = encodeInput( \$log ) || "No logfile available.";

		$tpl = 'logging_module_collect_details.tt';
	} else {
		$vars->{message} = 'Invalid input supplied';
		$tpl = 'dialog_no_right.tt';
	}

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );
	
	return { dialog => $dialogContent };	
}

sub deleteCollectorLogging {
	my ( %kvArgs) = @_;
	my $message;
	my $deleteOk = 0;
	
	my $session = $kvArgs{session};
	my $er = Taranis::Error->new();
	
	if ( $session->right("write") ) {
		
		if ( !$er->deleteLog( $kvArgs{id} ) ) {
			$message = $er->{errmsg};
		} else {
			$deleteOk = 1;
		}
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			deleteOk => $deleteOk,
			message => $message,
			id => $kvArgs{id}
		}
	};	
}

sub searchCollectorLogging {
	my ( %kvArgs) = @_;
	my ( $vars, %search );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $er = Taranis::Error->new();
	

	my $pageNumber = ( exists( $kvArgs{'hidden-page-number'} ) && $kvArgs{'hidden-page-number'} =~ /^\d+$/ )
		? $kvArgs{'hidden-page-number'}
		: 1;

	$er->loadCollection( 
		offset => ( $pageNumber - 1 ) * 100,
		error_code => $kvArgs{error_code}
	);
									 
	my @loggingItems;
	while ( $er->nextObject() ) {
		my $record = $er->getObject();
		$record->{sourcename} = "STATSIMG" if ( !$record->{sourcename} );
		push @loggingItems, $record;
	}

	$vars->{loggingItems} = \@loggingItems;
	
	$vars->{filterButton} = 'btn-collector-logging-search';
	$vars->{page_bar} = $tt->createPageBar( $pageNumber, $er->{result_count}, 100 );
	$vars->{write_right} = $session->right('write');
	$vars->{numberOfResults} = scalar @loggingItems;

	$vars->{write_right} = $session->right("write");
	$vars->{newItem} = 1;
	
	my $htmlContent = $tt->processTemplateNoHeader('logging_module_collect.tt', $vars, 1);
	
	return { content => $htmlContent };	
}

sub bulkDeleteCollectorLogging {
	my ( %kvArgs) = @_;
	my ( $message, $logs );
	
	my $deleteOk = 0;
	my $session = $kvArgs{session};
	my $er = Taranis::Error->new();
	
	my $errorCode = $kvArgs{errorCode};
	my $deleteSub = ( $errorCode ) ? 'deleteLogs' : 'deleteAllLogs';
	
	if ( $errorCode ) {
		
		$er->loadCollection( error_code => $errorCode );		
		
		while ( $er->nextObject() ) {
			my $record = $er->getObject();

			next if ( !$record->{logfile} );
			
			my $filename = $record->{logfile};
			$filename =~ s/.*\/(.*?)$/$1/i;
			
			$logs->{ $filename } = $record;
		}		
	}

	if ( $er->$deleteSub( $logs, $errorCode ) ) {
		$deleteOk = 1;
		$message = "Logs have been deleted.";
	} else {
		$message = $er->{errmsg};
	}

	return { 
		params => { 
			deleteOk => $deleteOk,
			message => $message
		} 
	};	
}

1;
