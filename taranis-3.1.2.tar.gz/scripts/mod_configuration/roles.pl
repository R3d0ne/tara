#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;
use Taranis qw(:all);
use Taranis::Category;
use Taranis::Config;
use Taranis::Entitlement;
use Taranis::Publication;
use Taranis::Role;
use Taranis::Template;
use POSIX;

my @EXPORT_OK = qw( 
	displayRoles openDialogNewRole openDialogRoleDetails
	saveNewRole saveRoleDetails deleteRole searchRoles 
	getRoleItemHtml 
);

sub roles_export {
	return @EXPORT_OK;
}

sub displayRoles {
	my ( %kvArgs) = @_;
	my ( $vars );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $ro = Taranis::Role->new();
	my $en = Taranis::Entitlement->new();
	
	my @entitlements;
	$en->getEntitlement();
	while ( $en->nextObject() ) {
	    push @entitlements, $en->getObject();
	}
	$vars->{entitlements} = \@entitlements;

    my @roles;
    $ro->getRole();
    while ( $ro->nextObject ) {
        push @roles, $ro->getObject();
    }

	$vars->{roles} = \@roles;
	
	$vars->{numberOfResults} = scalar @roles;
	$vars->{write_right} = $session->right("write");	
	$vars->{newItem} = 1;
	
	my $htmlContent = $tt->processTemplateNoHeader('roles.tt', $vars, 1);
	my $htmlFilters = $tt->processTemplateNoHeader('roles_filters.tt', $vars, 1);
	
	my @js = ('js/roles.js');
	
	return { content => $htmlContent, filters => $htmlFilters, js => \@js };		
}

sub openDialogNewRole {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $writeRight = $session->right("write"); 
	
	if ( $writeRight ) {
		$vars = getEntitlementSettings();
		$tpl = 'roles_details.tt';
		
	} else {
		$vars->{message} = 'No permission...';
		$tpl = 'dialog_no_right.tt';
	}

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );

	return { 
		dialog => $dialogContent,
		params => { writeRight => $writeRight }  
	};
}

sub openDialogRoleDetails {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl, $id );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $writeRight = $session->right("write"); 

	if ( $kvArgs{id} =~ /^\d+$/ ) {
		$id = $kvArgs{id};

		my $ro = Taranis::Role->new();
		my ( @roles, %roleRights, @roleRightsList );

		$ro->getRoleRightsFromRole( role_id => $id );
		while ( $ro->nextObject ) {
			my $roleRight = $ro->getObject();
			$roleRights{ $roleRight->{entitlement_id} } = $roleRight;
			push @roleRightsList, $roleRight;
		}

		$vars = getEntitlementSettings( @roleRightsList );		
		$vars->{role_rights} = \%roleRights;

		$vars->{write_right} = $writeRight;

		$ro->getRole( id => $id );
		while ( $ro->nextObject ) {
			$vars->{role} = $ro->getObject();
		}
		
		$tpl = 'roles_details.tt';
		
	} else {
		$vars->{message} = 'Invalid input supplied';
		$tpl = 'dialog_no_right.tt';
	}

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );
	
	return { 
		dialog => $dialogContent,
		params => { 
			writeRight => $writeRight,
			id => $id
		}  
	};	
}

sub saveNewRole {
	my ( %kvArgs) = @_;
	my ( $message, $id );
	my $saveOk = 0;
	
	my $session = $kvArgs{session};

	if ( $session->right("write") ) {
		my $ro = Taranis::Role->new();
		my $roleName = $kvArgs{name};
		my $roleDescription = $kvArgs{description};
		
		$ro->{dbh}->startTransaction();
 
		if ( $ro->addRole( name => $roleName, 'description' => $roleDescription ) ) {
#			$session->setUserAction(
#				username => $session->{cgisession}->param("userid"),
#				entitlement => 'role',
#				action => 'add role',
#				comment => 'added role with name ' . $roleName . ' and ID: ' .  $newRoleId
#			);

			$id = $ro->{dbh}->getLastInsertedId('role');
			
			my $particularizationsJson = $kvArgs{particularizations};
			$particularizationsJson =~ s/&quot;/"/g;
			my $particularizations = from_json( $particularizationsJson );

			my %roleRights;

			foreach my $entitlementId ( @{ $kvArgs{entitlementId} } ) {
				
				$ro->addRoleRight( entitlement_id => $entitlementId, role_id => $id );
				
				$roleRights{$entitlementId} = undef;
				
				if ( exists( $kvArgs{$entitlementId} ) ) {
					
					if ( ref( $kvArgs{$entitlementId} ) !~ /^ARRAY$/ ) {
						$kvArgs{$entitlementId} = [ $kvArgs{$entitlementId} ];
					}
					
					my %rights = map { $_ => 1 } @{ $kvArgs{ $entitlementId } };
					$roleRights{$entitlementId}->{read_right} = ( exists( $rights{R} ) ) ? 1 : 0;
					$roleRights{$entitlementId}->{write_right} = ( exists( $rights{W} ) ) ? 1 : 0;
					$roleRights{$entitlementId}->{execute_right} = ( exists( $rights{X} ) ) ? 1 : 0; 
				} else {
					$roleRights{$entitlementId}->{read_right} = 0;
					$roleRights{$entitlementId}->{write_right} = 0;
					$roleRights{$entitlementId}->{execute_right} = 0;
				}
			}

			foreach my $entitlementId ( keys %$particularizations ) {
				my $particularizationString = "";
				foreach my $particularization ( @{ $particularizations->{ $entitlementId } } ) {
					$particularizationString .= $particularization . ',';
				}
				$particularizationString =~ s/,$//;

				$roleRights{ $entitlementId }->{particularization} = $particularizationString;
			}

			for ( keys %roleRights ) {

				$roleRights{ $_ }->{role_id} = $id;
				my $particularization = $roleRights{ $_ }->{particularization};
				$particularization =~ s/,+$/,/g;

				my %update = (
					'entitlement_id'    => $_ ,
					'read_right'        => $roleRights{ $_ }->{read_right},
					'role_id'           => $roleRights{ $_ }->{role_id},
					'execute_right'     => $roleRights{ $_ }->{execute_right},
					'write_right'       => $roleRights{ $_ }->{write_right},
					'particularization' => $particularization
				);
        
				if ( !$ro->setRoleRight( %update ) ) {
					$message = 'user role DB error ' . $ro->{errmsg};
				}
			}
    		
#			$session->setUserAction(
#				username    => $session->{cgisession}->param("userid"),
#				entitlement => 'roles_details',
#				action      => 'role_right update',
#				comment     => 'role name ' . $roleName 
#			);

		} else {
			$message = $ro->{errmsg};
		}
		
		$ro->{dbh}->endTransaction();
	} else {
		$message = 'No permission';
	}
	
	$saveOk = 1 if ( !$message );
	
	return {
		params => {
			saveOk => $saveOk,
			message => $message,
			id => $id,
			insertNew => 1
		}
	};	
}

sub saveRoleDetails {
	my ( %kvArgs) = @_;
	my ( $message, $id );
	my $saveOk = 0;
	
	my $session = $kvArgs{session};
	my $cg = Taranis::Constituent_Group->new();

	if ( $session->right("write") && $kvArgs{id} =~ /^\d+$/ ) {
		$id = $kvArgs{id};

		my $ro = Taranis::Role->new();
		my $roleName = $kvArgs{name};
		my $roleDescription = $kvArgs{description};
		
		$ro->{dbh}->startTransaction();

		if ( $ro->setRole( id => $id, name => $roleName, 'description' => $roleDescription ) ) {
#			$session->setUserAction(
#				username => $session->{cgisession}->param("userid"),
#				entitlement => 'role',
#				action => 'add role',
#				comment => 'added role with name ' . $roleName . ' and ID: ' .  $newRoleId
#			);

			my $particularizationsJson = $kvArgs{particularizations};
			$particularizationsJson =~ s/&quot;/"/g;
			my $particularizations = from_json( $particularizationsJson );

			my %roleRights;

			foreach my $entitlementId ( @{ $kvArgs{entitlementId} } ) {
				
				$roleRights{$entitlementId} = undef;
				
				if ( exists( $kvArgs{$entitlementId} ) ) {
					
					if ( ref( $kvArgs{$entitlementId} ) !~ /^ARRAY$/ ) {
						$kvArgs{$entitlementId} = [ $kvArgs{$entitlementId} ];
					}
					
					my %rights = map { $_ => 1 } @{ $kvArgs{ $entitlementId } };
					$roleRights{$entitlementId}->{read_right} = ( exists( $rights{R} ) ) ? 1 : 0;
					$roleRights{$entitlementId}->{write_right} = ( exists( $rights{W} ) ) ? 1 : 0;
					$roleRights{$entitlementId}->{execute_right} = ( exists( $rights{X} ) ) ? 1 : 0; 
				} else {
					$roleRights{$entitlementId}->{read_right} = 0;
					$roleRights{$entitlementId}->{write_right} = 0;
					$roleRights{$entitlementId}->{execute_right} = 0;
				}
			}

			foreach my $entitlementId ( keys %$particularizations ) {
				my $particularizationString = "";
				foreach my $particularization ( @{ $particularizations->{ $entitlementId } } ) {
					$particularizationString .= $particularization . ',';
				}
				$particularizationString =~ s/,$//;
				
				$roleRights{ $entitlementId }->{particularization} = $particularizationString || undef;
			}

			for ( keys %roleRights ) {

				$roleRights{ $_ }->{role_id} = $id;
				my $particularization = $roleRights{ $_ }->{particularization};
				$particularization =~ s/,+$/,/g;

				my %update = (
					'entitlement_id'    => $_ ,
					'read_right'        => $roleRights{ $_ }->{read_right},
					'role_id'           => $roleRights{ $_ }->{role_id},
					'execute_right'     => $roleRights{ $_ }->{execute_right},
					'write_right'       => $roleRights{ $_ }->{write_right},
					'particularization' => $particularization
				);
        
				if ( !$ro->setRoleRight( %update ) ) {
					$message = 'user role DB error ' . $ro->{errmsg};
				}
			}
    		
#			$session->setUserAction(
#				username    => $session->{cgisession}->param("userid"),
#				entitlement => 'roles_details',
#				action      => 'role_right update',
#				comment     => 'role name ' . $roleName 
#			);

		} else {
			$message = $ro->{errmsg};
		}
		
		$ro->{dbh}->endTransaction();
		
		
	} else {
		$message = 'No permission';
	}

	$saveOk = 1 if ( !$message );
	
	return {
		params => {
			saveOk => $saveOk,
			message => $message,
			id => $id,
			insertNew => 0
		}
	};
}

sub deleteRole {
	my ( %kvArgs) = @_;
	my $message;
	my $deleteOk = 0;
	
	my $session = $kvArgs{session};
	my $ro = Taranis::Role->new();

	if ( $session->right("write") && $kvArgs{id} =~ /^\d+$/ ) {
		$ro->{dbh}->startTransaction();

		if ( !$ro->deleteRole( id => $kvArgs{id} ) ) {
			$message = $ro->{errmsg};
		} else {
			$deleteOk = 1;
		}
		$ro->{dbh}->endTransaction();
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			deleteOk => $deleteOk,
			message => $message,
			id => $kvArgs{id}
		}
	};	
}

sub searchRoles {
	my ( %kvArgs) = @_;
	my ( $vars, %search, @roles );

	my $session = $kvArgs{session};
	
	my $tt = Taranis::Template->new();
	my $ro = Taranis::Role->new();
	
	$search{name} = $kvArgs{search};
	$search{entitlement_id} = $kvArgs{entitlement};
	
	if ( $ro->getRolesWithEntitlement( %search ) ) {
		while ( $ro->nextObject ) {
			push @roles, $ro->getObject();
		}
	}
	
	$vars->{roles} = \@roles;
	$vars->{numberOfResults} = scalar @roles;
	$vars->{write_right} = $session->right("write");	
	$vars->{newItem} = 1;
	
	my $htmlContent = $tt->processTemplateNoHeader('roles.tt', $vars, 1);
	
	return { content => $htmlContent };	
}

sub getRoleItemHtml {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $ro = Taranis::Role->new();
	
	my $insertNew = $kvArgs{insertNew};
	
	my $id = $kvArgs{id};
	$ro->getRole( id => $id );
	my $role = $ro->{dbh}->fetchRow();
 
	if ( $role ) {
		$vars->{role} = $role;
		$vars->{write_right} = $session->right("write");
		$vars->{newItem} = $insertNew;
		
		$tpl = 'roles_item.tt';
	} else {
		$tpl = 'empty_row.tt';
		$vars->{message} = 'Error: Could not find the role...';
	}

	my $itemHtml = $tt->processTemplateNoHeader($tpl, $vars, 1);

	return {
		params => { 
			itemHtml => $itemHtml,
			insertNew => $insertNew,
			id => $id
		}
	};	
}

#TODO: translate to EN
#	analysis				: conf analyze_status_options
#	item_analysis			: not in use (set to disable)
#	items					: table category
#	membership				: NOT IN USE
#	publication				: publication.conf --> xxxxxx (email)
#	publication_template	: publication.conf all
#	soft_hard_usage			: NOT IN USE
#	sources_items			: table category
#	sources_stats			: table category

# NOTE:
#	membership	Rechten op de groepslidmaatschappen van
#				Constituent Individuals. Via een particularization
#				kunnen rechten op lidmaatschappen voor een
#				bepaalde Constituent Group worden gespecificeerd.

#	soft_hard_usage Rechten op het koppelen van hard- en software aan
#					Constituent Groups (‘onderhouden foto’). Via een
#					particularization kunnen rechten op het koppelen van
#					een hard- en software aan een specifieke Constituent
#					Group worden gespecificeerd.

#	item_analysis 	Rechten op de koppeling tussen een item en een
#					analyse. Via een particularization kunnen rechten op
#					het koppelen van items van een bepaalde categorie
#					worden gespecificeerd.
sub getEntitlementSettings {
	my @roleRights = @_;
	my ( @analysisStatusOptions, @publicationTypes, @assessCategoryNames, @entitlements );
	my $ro = Taranis::Role->new();
	my $en = Taranis::Entitlement->new();
	my $ca = Taranis::Category->new();
	my $pu = Taranis::Publication->new();
	
	my $vars;

	foreach my $status ( split( ",", Taranis::Config->getSetting("analyze_status_options") ) ) {
		push @analysisStatusOptions, trim( lc( $status ) );
	}

	foreach my $assessCategory ( $ca->getCategory( 'is_enabled' => 1 ) ) {
		push @assessCategoryNames, lc( $assessCategory->{name} );
	}

	foreach my $type ( $pu->getDistinctPublicationTypes() ) {
		push @publicationTypes, lc( $type );
	}
		
	$vars->{sourceCategories} = \@assessCategoryNames;
	$vars->{publicationTypes} = \@publicationTypes;
	$vars->{analysisStatusOptions} = \@analysisStatusOptions;
		
	my %particularizations = ( 
		analysisStatusOptions => \@analysisStatusOptions,
		sourceCategories => \@assessCategoryNames,
		publicationTypes => \@publicationTypes
	);

	my %particularizationEntitlementSettings = ( 
		analysis => 'analysisStatusOptions',
	#	item_analysis => '',
		items => 'sourceCategories',
	#	membership => '',
		publication => 'publicationTypes',
		publication_template => 'publicationTypes',
	#	soft_hard_usage => ''
		sources_items => 'sourceCategories',
		sources_stats => 'sourceCategories'
	);

	$en->getEntitlement();
	while ( $en->nextObject() ) {
		my $record = $en->getObject();
		my %entitlement;
		
		$entitlement{id} = $record->{id};
		$entitlement{name} = $record->{name} ;
		$entitlement{description} = $record->{description};
		$entitlement{particularization} = $record->{particularization};
		
		if ( $record->{particularization} && $particularizationEntitlementSettings{ $entitlement{name} } ) {
			$entitlement{all_particularizations} = $particularizations{ $particularizationEntitlementSettings{ $entitlement{name} } };
			foreach my $roleRight ( @roleRights ) {
				if ( $roleRight->{entitlement_id} == $record->{id} ) {
					foreach my $particularization ( split( ',', $roleRight->{particularization} ) ) {
						push @{ $entitlement{particularizations} }, trim( lc( $particularization ) );
					}
				}
			}
		}
		push @entitlements, \%entitlement;
	}

	$vars->{entitlements} = \@entitlements;
	
	return $vars;
	
} 
1;
