#!/usr/bin/perl 
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;
use Taranis qw(:all);
use Taranis::Template;
use Taranis::Parsers;
use Taranis::Sources;

my @EXPORT_OK = qw( 
	displayParsers openDialogNewParser openDialogParserDetails
	saveNewParser saveParserDetails deleteParser
	searchParsers getParserItemHtml 
);

sub parsers_export {
	return @EXPORT_OK;
}

sub displayParsers {
	my ( %kvArgs) = @_;
	my ( $vars );

	my $session = $kvArgs{session};
	my $ps = Taranis::Parsers->new();
	my $tt = Taranis::Template->new();
	
	my $parsers = $ps->getParsers();
	$vars->{parsers} = $parsers;
	$vars->{numberOfResults} = scalar @$parsers;
	$vars->{write_right} = $session->right("write");	
	$vars->{newItem} = 1;
	
	my $htmlContent = $tt->processTemplateNoHeader('parsers.tt', $vars, 1);
	my $htmlFilters = $tt->processTemplateNoHeader('parsers_filters.tt', $vars, 1);
	
	my @js = ('js/parsers.js');

	return { content => $htmlContent, filters => $htmlFilters, js => \@js };
}

sub openDialogNewParser {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $writeRight = $session->right("write"); 
	
	if ( $writeRight ) {

		$tpl = 'parsers_details.tt';
		
	} else {
		$vars->{message} = 'No permission...';
		$tpl = 'dialog_no_right.tt';
	}

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );

	return { 
		dialog => $dialogContent,
		params => { writeRight => $writeRight }  
	};	
}

sub openDialogParserDetails {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl, $id );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $writeRight = $session->right("write"); 

	if ( exists( $kvArgs{id} ) && $kvArgs{id} ) {
		$id = $kvArgs{id};

		my $ps = Taranis::Parsers->new();
		my $src	= Taranis::Sources->new();

		my $parser = $ps->getParserSimple( $id );
		
		$vars->{parser} = $parser;
		$vars->{sources} = $src->getSources( parser => $id );
		$vars->{write_right} = $writeRight;
        
		$tpl = 'parsers_details.tt';
		
	} else {
		$vars->{message} = 'Invalid input';
		$tpl = 'dialog_no_right.tt';
	}

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );
	
	return { 
		dialog => $dialogContent,
		params => { 
			writeRight => $writeRight,
			id => $id
		}  
	};	
}

sub saveNewParser {
	my ( %kvArgs) = @_;
	my ( $message, $id );
	my $saveOk = 0;
	
	my $session = $kvArgs{session};
	
	if ( $session->right("write") && exists( $kvArgs{parsername} ) && $kvArgs{parsername} ) {
		$id = $kvArgs{parsername};
		my $ps = Taranis::Parsers->new();
		
		if ( !$ps->{dbh}->checkIfExists( { parsername => $kvArgs{parsername} }, "parsers", "IGNORE_CASE" ) ) {
		
			if (
				!$ps->addParser(
					parsername => $kvArgs{parsername}, 
					item_start => $kvArgs{item_start},	
					item_stop => $kvArgs{item_stop}, 
					title_start => $kvArgs{title_start},
					title_stop => $kvArgs{title_stop},
					desc_start => $kvArgs{desc_start},
					desc_stop => $kvArgs{desc_stop},
					link_start => $kvArgs{link_start},
					link_stop => $kvArgs{link_stop},
					link_prefix => $kvArgs{link_prefix},
					strip0_start => $kvArgs{strip0_start},
					strip0_stop => $kvArgs{strip0_stop},													
					strip1_start => $kvArgs{strip1_start},
					strip1_stop => $kvArgs{strip1_stop},
					strip2_start => $kvArgs{strip2_start},
					strip2_stop => $kvArgs{strip2_stop},													
				) 
			) {
				$message = $ps->{errmsg};
			}
		} else {
			$message = "A parser with the same name already exists.";
		}
	} else {
		$message = 'No permission';
	}
	
	$saveOk = 1 if ( !$message );
	
	return {
		params => {
			saveOk => $saveOk,
			message => $message,
			id => $id,
			insertNew => 1
		}
	};
}

sub saveParserDetails {
	my ( %kvArgs) = @_;
	my ( $message, $id );
	my $saveOk = 0;
	
	my $session = $kvArgs{session};

	if ( $session->right("write") && $kvArgs{id} ) {
		$id = $kvArgs{id};
		my $ps = Taranis::Parsers->new();

		if ( 
			!$ps->setParser(
				parsername => $id,
				item_start => $kvArgs{item_start},	
				item_stop => $kvArgs{item_stop}, 
				title_start=> $kvArgs{title_start},
				title_stop => $kvArgs{title_stop},
				desc_start => $kvArgs{desc_start},
				desc_stop => $kvArgs{desc_stop},
				link_start => $kvArgs{link_start},
				link_stop => $kvArgs{link_stop},
				link_prefix => $kvArgs{link_prefix},
				strip0_start => $kvArgs{strip0_start},
				strip0_stop => $kvArgs{strip0_stop},													
				strip1_start => $kvArgs{strip1_start},
				strip1_stop => $kvArgs{strip1_stop},
				strip2_start => $kvArgs{strip2_start},
				strip2_stop => $kvArgs{strip2_stop}
			) 
		) {
			$message = $ps->{errmsg};
		}

		$saveOk = 1 if ( !$message );

	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			saveOk => $saveOk,
			message => $message,
			id => $id,
			insertNew => 0
		}
	};
}

sub deleteParser {
	my ( %kvArgs) = @_;
	my $message;
	my $deleteOk = 0;
	
	my $session = $kvArgs{session};

	my $ps = Taranis::Parsers->new();
	
	if ( $session->right("write") ) {

		if ( !$ps->deleteParser( parsername => $kvArgs{id} ) ) {
			$message = $ps->{errmsg};
		} else {
			$deleteOk = 1;
		}

	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			deleteOk => $deleteOk,
			message => $message,
			id => $kvArgs{id}
		}
	};	
}

sub searchParsers {
	my ( %kvArgs) = @_;
	my ( $vars, %search );

	my $session = $kvArgs{session};
	
	my $tt = Taranis::Template->new();
	my $ps = Taranis::Parsers->new();
	
	my $parsers = $ps->getParsers( $kvArgs{search_parsername} );
	
	$vars->{parsers} = $parsers;
	$vars->{numberOfResults} = scalar @$parsers;
	$vars->{write_right} = $session->right("write");	
	$vars->{newItem} = 1;
	
	my $htmlContent = $tt->processTemplateNoHeader('parsers.tt', $vars, 1);
	
	return { content => $htmlContent };	
}

sub getParserItemHtml {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $ps = Taranis::Parsers->new();
	
	my $id = $kvArgs{id};
	my $insertNew = $kvArgs{insertNew};

 	my $parser = $ps->getParserSimple( $id );
 	
	if ( $parser ) {
		$vars->{parser} = $parser;
		$vars->{write_right} = $session->right("write");
		$vars->{newItem} = $insertNew;
		
		$tpl = 'parsers_item.tt';
	} else {
		$tpl = 'empty_row.tt';
		$vars->{message} = 'Error: Could not find the parser...';
	}

	my $itemHtml = $tt->processTemplateNoHeader($tpl, $vars, 1);

	return {
		params => { 
			itemHtml => $itemHtml,
			insertNew => $insertNew,
			id => $id
		}
	};
}

1;
