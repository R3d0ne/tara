#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;

use Taranis qw(:all); 
use Taranis::Users;
use Taranis::Template;
use Taranis::Role;
use Digest::MD5 qw(md5 md5_hex md5_base64);
use POSIX;

my @EXPORT_OK = qw( 
	displayUsers openDialogNewUser openDialogUserDetails
	saveNewUser saveUserDetails deleteUser
	searchUsers getUserItemHtml changeUserPassword
);

sub users_export {
	return @EXPORT_OK;
}

sub displayUsers {
	my ( %kvArgs) = @_;
	my ( $vars, @users, @roles );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $usr = Taranis::Users->new();
	my $ro = Taranis::Role->new();
	
	my %usersHash;
	$ro->getUsersWithRole();
    while ( $ro->nextObject() ) {
    	my $user = $ro->getObject();
    	
    	if ( exists( $usersHash{ $user->{username} } ) ) {
    		$usersHash{ $user->{username} }->{role_name} .= ', ' . $user->{role_name} 
    	} else {
    		$usersHash{ $user->{username} } = $user;
    	}
    }

	foreach my $userId ( keys %usersHash ) {
		push @users, $usersHash{$userId};
	}
    
    $vars->{users} = \@users;

    $ro->getRole();
    while ( $ro->nextObject ) {
        push @roles, $ro->getObject();
    }

    $vars->{roles} = \@roles;
	$vars->{numberOfResults} = scalar @users;
	$vars->{write_right} = $session->right("write");	
	$vars->{newItem} = 1;
	
	my $htmlContent = $tt->processTemplateNoHeader('users.tt', $vars, 1);
	my $htmlFilters = $tt->processTemplateNoHeader('users_filters.tt', $vars, 1);
	
	my @js = ('js/users.js');
	
	return { content => $htmlContent, filters => $htmlFilters, js => \@js };	
}

sub openDialogNewUser {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $writeRight = $session->right("write"); 
	
	if ( $writeRight ) {
		my $ro = Taranis::Role->new();
	    my @roles;
	    $ro->getRole();
	    while ( $ro->nextObject ) {
	        push @roles, $ro->getObject();
	    }
		
		$vars->{roles} = \@roles;
		
		$tpl = 'user_details.tt';
		
	} else {
		$vars->{message} = 'No permission...';
		$tpl = 'dialog_no_right.tt';
	}

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );

	return { 
		dialog => $dialogContent,
		params => { writeRight => $writeRight }  
	};	
}

sub openDialogUserDetails {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl, $id );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $writeRight = $session->right("write"); 

	if ( exists( $kvArgs{id} ) && $kvArgs{id} ) {
		$id = $kvArgs{id};
		my $usr = Taranis::Users->new();
		my $ro = Taranis::Role->new();
		
		$vars->{user} = $usr->getUser( $id );

		my $userRoles = $ro->getRolesFromUser( username => $id );

		# get roles this user has.
		$vars->{membershipRoles} = $userRoles;

		# get all roles
		my $allRoles = $ro->getRoles();

		my @allRolesList;

		# match membership roles with allroles
		# if a role from allroles is not present in user_role
		# add it to available roles
		foreach my $id ( keys %$allRoles ) {
			if ( !defined( $userRoles->{$id} ) ) {
				push @allRolesList, {name => $allRoles->{$id}->{name}, id => $id}; 
			}
		}
		
		$vars->{roles} = \@allRolesList;
		$vars->{description} = $id;

		$usr->getUserAction(username => $id );
		
		my @userActions;
		while ($usr->nextObject) {
			push @userActions, $usr->getObject();
		}
		$vars->{userActions} = \@userActions;

		$vars->{write_right} = $writeRight;
        
		$tpl = 'user_details.tt';
		
	} else {
		$vars->{message} = 'Invalid input supplied';
		$tpl = 'dialog_no_right.tt';
	}

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );
	
	return { 
		dialog => $dialogContent,
		params => { 
			writeRight => $writeRight,
			id => $id
		}  
	};	
}

sub saveNewUser {
	my ( %kvArgs) = @_;
	my ( $message, $id );
	my $saveOk = 0;
	
	my $session = $kvArgs{session};

	if ( $session->right("write") ) {
		my $usr = Taranis::Users->new();
		$id = $kvArgs{username};
		my @membershipRoles;
		if ( $kvArgs{membership_roles} ) {
			@membershipRoles = ( ref( $kvArgs{membership_roles} ) =~ /^ARRAY$/ )
				? @{ $kvArgs{membership_roles} }
				: $kvArgs{membership_roles};		
		}
		        
        my $password = md5_base64( $kvArgs{password} );
        $usr->{dbh}->startTransaction();
        
        if ( 
        	$usr->addUser(
				username => $kvArgs{username},
				fullname => $kvArgs{fullname},
				mailfrom_sender => $kvArgs{mailfrom_sender},
				mailfrom_email => $kvArgs{mailfrom_email},
				password => $password
			) 
		) {
			if ( scalar( @membershipRoles > 0 ) ) {
				foreach my $role (@membershipRoles) {
					if ( !$usr->setRoleToUser( username => $kvArgs{username}, role_id => $role ) ) {
						$message = $usr->{errmsg};
					}
				}
			}
		} else {
			$message = $usr->{errmsg};
		}
        
		$usr->{dbh}->endTransaction();
	} else {
		$message = 'No permission';
	}
	
	$saveOk = 1 if ( !$message );
	
	return {
		params => {
			saveOk => $saveOk,
			message => $message,
			id => $id,
			insertNew => 1
		}
	};
}

sub saveUserDetails {
	my ( %kvArgs) = @_;
	my ( $message, $id );
	my $saveOk = 0;
	
	my $session = $kvArgs{session};

	if ( $session->right("write") && exists( $kvArgs{id} ) && $kvArgs{id} ) {
		my $usr = Taranis::Users->new();
		my $ro = Taranis::Role->new();
		$id = $kvArgs{id};
		
		my %userUpdate = (
			username => $kvArgs{id},
			fullname => $kvArgs{fullname},
			mailfrom_sender => $kvArgs{mailfrom_sender},
			mailfrom_email => $kvArgs{mailfrom_email},		
		);
		
		if ( exists( $kvArgs{password} ) && $kvArgs{password} ) {
			$userUpdate{password} = md5_base64( $kvArgs{password} );
		}

		my $currentRoles = $ro->getRolesFromUser( username => $kvArgs{id} );
		my @currentRolesList = keys %$currentRoles;
		my @membershipRoles;
		
		if ( $kvArgs{membership_roles} ) {
			@membershipRoles = ( ref( $kvArgs{membership_roles} ) =~ /^ARRAY$/ )
				? @{ $kvArgs{membership_roles} }
				: $kvArgs{membership_roles};		
		}
		
		my %currentRolesHash = map { $_ => 1 } @currentRolesList;
		my %newRoles = map { $_ => 1 } @membershipRoles;

		my @insertRoles = grep( !defined $currentRolesHash{$_}, @membershipRoles );
		my @deleteRoles = grep( !defined $newRoles{$_}, @currentRolesList );
        
		$usr->{dbh}->startTransaction();

        if ( $usr->setUser( %userUpdate ) ) {

			# do the stuf with adding/changing roles to user with startTransaction/endTransaction
			if ( scalar( @deleteRoles > 0 ) ) {
				foreach my $role ( @deleteRoles ) {
					if ( !$usr->delUserFromRole( username => $kvArgs{id}, role_id  => $role) ) {
						$message = $usr->{errmsg};
					}
				}
			}

			if ( scalar( @insertRoles > 0 ) ) {
				foreach my $role ( @insertRoles ) {
                    if ( !$usr->setRoleToUser( username => $kvArgs{id}, role_id  => $role ) ) {
						$message = $usr->{errmsg};
					}
				}
			}
		} else {
			$message = $usr->{errmsg};
		}

        $usr->{dbh}->endTransaction();
		
	} else {
		$message = 'No permission';
	}

	$saveOk = 1 if ( !$message );
	
	return {
		params => {
			saveOk => $saveOk,
			message => $message,
			id => $id,
			insertNew => 0
		}
	};
}

sub deleteUser {
	my ( %kvArgs) = @_;
	my $message;
	my $deleteOk = 0;
	
	my $session = $kvArgs{session};
	my $usr = Taranis::Users->new();

	if ( $session->right("write") && exists( $kvArgs{id} ) && $kvArgs{id} ) {
		$usr->{dbh}->startTransaction();
		if ( 
			$usr->setUser( disabled => 1, username => $kvArgs{id} )
			&& $usr->delUserFromRole( username => $kvArgs{id} )
		) {
			$deleteOk = 1;
		} else {
			$message = $usr->{errmsg};			
		}
		
		$usr->{dbh}->endTransaction();
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			deleteOk => $deleteOk,
			message => $message,
			id => $kvArgs{id}
		}
	};	
}

sub searchUsers {
	my ( %kvArgs) = @_;
	my ( $vars, @users, %search );

	my $session = $kvArgs{session};
	my $ro = Taranis::Role->new();
	my $tt = Taranis::Template->new();

	if ( exists( $kvArgs{name} ) && $kvArgs{name} ) {
		$search{'username'} = ( { -ilike => [ '%' .  $kvArgs{name} . '%' ] } );
		$search{'fullname'} = ( { -ilike => [ '%' .  $kvArgs{name} . '%' ] } );
    }

	if ( exists( $kvArgs{role_id} ) && $kvArgs{role_id} ) {
		$search{'role_id'} = $kvArgs{role_id};
	}

	my %usersHash;
	$ro->getUsersWithRole( %search );
	while ( $ro->nextObject() ) {
    	my $user = $ro->getObject();
    	
    	if ( exists( $usersHash{ $user->{username} } ) ) {
    		$usersHash{ $user->{username} }->{role_name} .= ', ' . $user->{role_name} 
    	} else {
    		$usersHash{ $user->{username} } = $user;
    	}
    }

	foreach my $userId ( keys %usersHash ) {
		push @users, $usersHash{$userId};
	}
	
	$vars->{users} = \@users;
	$vars->{numberOfResults} = scalar @users;
	$vars->{write_right} = $session->right("write");	
	$vars->{newItem} = 1;
	
	my $htmlContent = $tt->processTemplateNoHeader('users.tt', $vars, 1);
	
	return { content => $htmlContent };
}

sub getUserItemHtml {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $ro = Taranis::Role->new();
	my $usr = Taranis::Users->new();
	
	my $insertNew = $kvArgs{insertNew};
	my $id = $kvArgs{id};
	
	my $user = $usr->getUser( $id );

	if ( $user ) {
		my $roles = $ro->getRolesFromUser( username => $id );
		$user->{role_name} = '';
		foreach my $roleID ( keys %$roles ) {
			$user->{role_name} .= $roles->{$roleID}->{name} . ', ';
		}
		
		$user->{role_name} =~ s/(.*?), $/$1/;
		$vars->{user} = $user;
		$vars->{write_right} = $session->right("write");
		$vars->{newItem} = $insertNew;
		
		$tpl = 'users_item.tt';
	} else {
		$tpl = 'empty_row.tt';
		$vars->{message} = 'Error: Could not find the new constituent individual...';
	}

	my $itemHtml = $tt->processTemplateNoHeader($tpl, $vars, 1);

	return {
		params => { 
			itemHtml => $itemHtml,
			insertNew => $insertNew,
			id => $id
		}
	};
}

sub changeUserPassword {
	my ( %kvArgs) = @_;
	my ( $message );
	my $changeOk = 0;
	
	my $session = $kvArgs{session};
	my $usr = Taranis::Users->new();	

	if ( 
		$kvArgs{new_password} && $kvArgs{id} 
		&& $usr->setUser( username => $kvArgs{id}, password => md5_base64( $kvArgs{new_password} ) ) 
	) {
		$changeOk = 1;
	} else {
		$message = $usr->{errmsg};
	}

	return { 
		params => {
			changeOk => $changeOk,
			message => $message
		} 
	};	
}
1;
