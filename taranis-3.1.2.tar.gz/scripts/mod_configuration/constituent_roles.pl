#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Constituent_Individual;
use Taranis::Template;
use Taranis qw( :all);
use Tie::IxHash;
use strict;

my @EXPORT_OK = qw( 
	displayConstituentRoles openDialogNewConstituentRole openDialogConstituentRoleDetails 
	saveNewConstituentRole saveConstituentRoleDetails deleteConstituentRole getConstituentRoleItemHtml
);

sub constituent_roles_export {
	return @EXPORT_OK;
}

sub displayConstituentRoles {
	my ( %kvArgs) = @_;
	my ( $vars );

	my $session = $kvArgs{session};
	my $ci = Taranis::Constituent_Individual->new();
	my $tt = Taranis::Template->new();

	my @constituentRoles = $ci->getRoleByID();
	if ( $constituentRoles[0] ) {
		for (my $i = 0; $i < @constituentRoles; $i++ ) {
			if ( !$ci->{dbh}->checkIfExists( { role => $constituentRoles[$i]->{id}, status => { "!=" => 1 } }, "constituent_individual") ) {
				$constituentRoles[$i]->{status} = 1;
			} else {
				$constituentRoles[$i]->{status} = 0;
			}
		}
	} else {
		undef @constituentRoles;
	}
	
	$vars->{constituentRoles} = \@constituentRoles;
	$vars->{numberOfResults} = scalar @constituentRoles;
	$vars->{write_right} = $session->right("write");	
	$vars->{newItem} = 1;
	
	my $htmlContent = $tt->processTemplateNoHeader('constituent_roles.tt', $vars, 1);
	my $htmlFilters = $tt->processTemplateNoHeader('constituent_roles_filters.tt', $vars, 1);
	
	my @js = ('js/constituent_roles.js');
	
	return { content => $htmlContent, filters => $htmlFilters, js => \@js };
}


sub deleteConstituentRole {
	my ( %kvArgs) = @_;
	my ( $message, $roleId );
	my $deleteOk = 0;
	
	my $session = $kvArgs{session};
	my $ci = Taranis::Constituent_Individual->new();

	if ( $session->right("write") && $kvArgs{id} =~ /^\d+$/ ) {
		$roleId = $kvArgs{id};
		if ( !$ci->deleteRole( $kvArgs{id} ) ) {
			$message = $ci->{errmsg};
		} else {
			$deleteOk = 1;
		}
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			deleteOk => $deleteOk,
			message => $message,
			id => $roleId
		}
	};
}

sub openDialogNewConstituentRole {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $writeRight = $session->right("write");
	
	if ( $writeRight ) {
		$tpl = 'constituent_roles_details.tt';
	} else {
		$vars->{message} = 'No permission...';
		$tpl = 'dialog_no_right.tt';
	}
	
	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );

	return { 
		dialog => $dialogContent,
		params => { writeRight => $writeRight }  
	};
}

sub saveNewConstituentRole {
	my ( %kvArgs) = @_;
	my ( $message, $constituentRoleId );
	my $saveOk = 0;
	
	my $session = $kvArgs{session};
	my $ci = Taranis::Constituent_Individual->new();

	if ( $session->right("write") ) {
		
		if ( !$ci->{dbh}->checkIfExists( {role_name => $kvArgs{role_name} }, "constituent_role", "IGNORE_CASE" ) ) {
			if ( $ci->addObject( table => "constituent_role", role_name => $kvArgs{role_name} ) ) {
				$constituentRoleId = $ci->{dbh}->getLastInsertedId(	"constituent_role" );
			} else {
				$message = $ci->{errmsg};
			} 
		} else {
			$message .= "A role description with this description already exists.";
		}		
		$saveOk = 1 if ( !$message );
		
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			saveOk => $saveOk,
			message => $message,
			id => $constituentRoleId,
			insertNew => 1
		}
	};
}

sub openDialogConstituentRoleDetails {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl, $constituentRoleId );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $ci = Taranis::Constituent_Individual->new();
	
	my $writeRight = $session->right("write");	

	if ( $kvArgs{id} =~ /^\d+$/ ) {
		$constituentRoleId = $kvArgs{id};
		my $constituentRole = $ci->getRoleByID( $constituentRoleId );
		
		$vars->{role_name} = $constituentRole->{role_name};
		$vars->{id} = $constituentRoleId;

		$tpl = 'constituent_roles_details.tt';
		
	} else {
		$vars->{message} = 'Invalid input supplied';
		$tpl = 'dialog_no_right.tt';
	}

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );
	
	return { 
		dialog => $dialogContent,
		params => { 
			writeRight => $writeRight,
			id => $constituentRoleId
		}  
	};	
}

sub saveConstituentRoleDetails {
	my ( %kvArgs) = @_;
	my ( $message, $constituentRoleId );
	my $saveOk = 0;
	
	my $session = $kvArgs{session};

	if ( $session->right("write") && $kvArgs{id} =~ /^\d+$/ ) {
		$constituentRoleId = $kvArgs{id};
		my $ci = Taranis::Constituent_Individual->new();

		my %constituentRoleUpdate = ( table => "constituent_role", id => $constituentRoleId, role_name => $kvArgs{role_name} );

		my $originaleConstituentRole = $ci->getRoleByID( $constituentRoleId );

		if ( 
			!$ci->{dbh}->checkIfExists( { role_name => $kvArgs{role_name} } , "constituent_role", "IGNORE_CASE" ) 
			|| lc( $kvArgs{role_name} ) eq lc( $originaleConstituentRole->{role_name} ) 
		) {		
			
			$ci->setObject( %constituentRoleUpdate );
			$message = $ci->{errmsg};

		} else {
			$message = "A role description with the same description already exists.";
		}

		$saveOk = 1 if ( !$message );
		
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			saveOk => $saveOk,
			message => $message,
			id => $constituentRoleId,
			insertNew => 0
		}
	};	
}

sub getConstituentRoleItemHtml {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $ci = Taranis::Constituent_Individual->new();
	
	my $constituentRoleId = $kvArgs{id};
	my $insertNew = $kvArgs{insertNew};
 
 	my $constituentRole = $ci->getRoleByID( $constituentRoleId );
 
	if ( $constituentRole ) {

		if ( !$insertNew && $ci->{dbh}->checkIfExists( { role => $constituentRoleId, status => { "!=" => 1 } }, "constituent_individual") ) {
			$constituentRole->{status} = 0;
		} else {
			$constituentRole->{status} = 1;
		}

		$vars->{constituentRole} = $constituentRole;
		$vars->{write_right} =  $session->right("write");
		$vars->{newItem} = $insertNew;
		
		$tpl = 'constituent_roles_item.tt';
	} else {
		$tpl = 'empty_row.tt';
		$vars->{message} = 'Could not find the item...';
	}

	my $itemHtml = $tt->processTemplateNoHeader($tpl, $vars, 1);

	return {
		params => { 
			itemHtml => $itemHtml,
			insertNew => $insertNew,
			id => $constituentRoleId
		}
	};
}

1;
