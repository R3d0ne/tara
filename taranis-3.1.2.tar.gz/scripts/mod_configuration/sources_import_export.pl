#!/usr/bin/perl 
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;
use Taranis qw(:all);
use Taranis::Config;
use Taranis::Template;
use Taranis::Sources;
use Taranis::Category;
use Taranis::Parsers;
use XML::Simple;
use Archive::Tar;

$Archive::Tar::WARN = 0;

my @EXPORT_OK = qw( openDialogImportExportSources importSources exportSources );

sub sources_import_export_export {
	return @EXPORT_OK;
}

sub openDialogImportExportSources {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $writeRight = $session->right("write");

	if ( $writeRight ) {
		my $ca = Taranis::Category->new();
		my $pa = Taranis::Parsers->new();
		
		@{ $vars->{categories} } = $ca->getCategory("is_enabled" => 1);

		my $parsers = $pa->getParsers();
		my @parsers_unsorted;
		if ( $parsers ) {
			for (my $i = 0; $i < @$parsers; $i++ ) {
				push @parsers_unsorted, $parsers->[$i]->{parsername};
			}
		}

		my @sorted_parsers = sort {$a cmp $b} @parsers_unsorted;
		$vars->{parsers} = \@sorted_parsers;
		$tpl = "sources_import_export.tt";

	} else {
		$vars->{message} = 'No permission...';
		$tpl = 'dialog_no_right.tt';
	}
	
	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );

	return { 
		dialog => $dialogContent,
		params => { writeRight => $writeRight }  
	};	
}

sub importSources {
	my ( %kvArgs) = @_;
	my ( $tpl, $vars );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	
	if ( $session->right("write") ) {
		my ( $tar, $importSourcesXml, $importParsersXml );
		my $ca = Taranis::Category->new();
		my $pa = Taranis::Parsers->new();
		my $src = Taranis::Sources->new();
				
		my $query = $session->{cgisession}->query;

		my $filename = $query->param("import_file");
		my $fh = $query->upload($filename);

		eval{
			$tar = Archive::Tar->new( $fh );
		};
	
		if ( !$tar ) {
			$vars->{error} = "Error: cannot read import file.";
		} else {

			eval{
				$importSourcesXml = $tar->get_content( "taranis.sources.xml" );  
			};

			eval{
				$importParsersXml = $tar->get_content( "taranis.parsers.xml" );  
			};

			if ( !$importSourcesXml ) {
				$vars->{error} = $tar->error();
			} else {

				if ( !$importParsersXml ) {
					$vars->{error} = "Missing taranis.parsers.xml.";
				} else {
					my $importParsers;

					eval{
						$importParsers = XMLin( $importParsersXml, SuppressEmpty => undef );
					};

					if ( $@ || !exists( $importParsers->{parser} ) ) {
						$vars->{error} = $@ || "Missing parser element in XML.";
					} else {

						my ( @failedParserImports, @successfulParserImports );
						my @parsers = ( ref( $importParsers->{parser} ) =~ /^ARRAY$/ ) 
							? @{ $importParsers->{parser} }
							: ( $importParsers->{parser} );
							
						PARSER:
						foreach my $parser ( @parsers ) {
							if ( !exists( $parser->{parsername} ) ) {
								$parser->{failReason} = "Missing mandatory field 'parsername' for import.";
								push @failedParserImports, $parser; 
							} elsif ( $pa->{dbh}->checkIfExists( { parsername => $parser->{parsername} } , "parsers", "IGNORE_CASE" ) ) {
								$parser->{failReason} = "Parser already exists.";
								push @failedParserImports, $parser; 
							} else {
								if ( !$pa->addParser( %$parser ) ) {
									$parser->{failReason} = "Import failed: $pa->{errmsg}.";
									push @failedParserImports, $parser;     			
								} else {
									push @successfulParserImports, $parser;                
								}
							}
						}

						$vars->{successfulParserImports} = \@successfulParserImports;
						$vars->{failedParserImports} = \@failedParserImports;
					}
				}

				my $importSources;
				eval{
					$importSources = XMLin( $importSourcesXml, SuppressEmpty => undef );
				};

				if ( $@ || !exists( $importSources->{source} ) ) {
					$vars->{error} = $@ || "Missing source element in XML.";
				} else {

					my ( @failedSourceImports, @successfulSourceImports, @addedCategories );
					my $iconDir = Taranis::Config->getSetting('absroot') . "/images/icons/";

					my @sources = ( ref( $importSources->{source} ) =~ /^ARRAY$/ ) 
						? @{ $importSources->{source} }
						: ( $importSources->{source} );

					SOURCE:
					foreach my $source ( @sources ) {
						if (
							!exists($source->{protocol})   || !$source->{protocol} ||
							!exists($source->{mtbc})       || !$source->{mtbc} ||
							!exists($source->{parser})     || !$source->{parser} ||
							!exists($source->{category})   || !$source->{category} ||
							!exists($source->{sourcename}) || !$source->{sourcename} ||
							!exists($source->{fullurl})    || !$source->{fullurl} ||
							!exists($source->{port})       || !$source->{port} ||
							!exists($source->{host})       || !$source->{host} ||
							!exists($source->{digest})     || !$source->{digest}
						) {
							$source->{failReason} = "Missing one or more mandatory fields for import.";
							push @failedSourceImports, $source; 
						} elsif ( $src->{dbh}->checkIfExists( { digest => $source->{digest} } , "sources", "IGNORE_CASE" ) ) {
							$source->{failReason} = "Source already exists.";
							push @failedSourceImports, $source; 
						} elsif ( !$src->{dbh}->checkIfExists( { parsername => $source->{parser} } , "parsers", "IGNORE_CASE" ) ) {
							$source->{failReason} = "Missing parser for this source.";
							push @failedSourceImports, $source; 
						} else {

							my $category = $ca->getCategory( name => { -ilike => $source->{category} } );

							if ( !$category ) {
								if ( !$ca->addCategory( name => $source->{category} ) ) {
									$source->{failReason} = "Could not add category.";
									push @failedSourceImports, $source;
									next SOURCE;
								} else {
									push @addedCategories, $source->{category};
									$source->{category} = $ca->{dbh}->getLastInsertedId('category');
								}
							} else {
								$source->{category} = $category->{id};
							}

							foreach my $key ( keys %$source ) {
								if ( ref( $source->{$key} ) =~ /^HASH$/ ) {
									$source->{$key} = undef;
								}
							}

							# boolean conversions
							for ( 'checkid', 'delete_mail', 'enabled', 'clustering_enabled' ) {
								$source->{$_} = 1 if ( $source->{$_} =~ /^true$/ );
								$source->{$_} = 0 if ( $source->{$_} =~ /^false$/ );
							}

							if ( !$src->addSource( %$source ) ) {
								$source->{failReason} = "Import failed: $src->{errmsg}.";
								push @failedSourceImports, $source;     			
							} else {
								my $iconImage;
								my $sourceName = $source->{sourcename};

								eval{
									$iconImage = $tar->get_content( $sourceName . ".gif" );
								};

								if ( !$iconImage ) {
									$iconImage = $src->createSourceIcon( $sourceName );
								}
              
								eval{		    			
									my $fh;
									open $fh, ">", $iconDir . $source->{sourcename} . ".gif";
									print $fh $iconImage;
									close $fh;
								};

								if ( $@ ) {
									logErrorToSyslog( $@ );
								}

								push @successfulSourceImports, $source;
							}
						} 
					}
					$vars->{categories} = \@addedCategories;
					$vars->{successfulSourceImports} = \@successfulSourceImports;
					$vars->{failedSourceImports} = \@failedSourceImports;
				}
			}
		}
		
		$tpl = 'sources_import.tt';
	
	} else {
		$vars->{message} = 'No permission...';
		$tpl = 'dialog_no_right.tt';
	}
	
	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );

	return { dialog => $dialogContent };	
}

sub exportSources {
	my ( %kvArgs ) = @_;
	my $src = Taranis::Sources->new();
	my $pa = Taranis::Parsers->new();
	
	my ( %where, $returnToBrowser, %parsersList, @parsersExport );
	
	if ( @{ $kvArgs{protocols} } > 0 ) { 
		$where{protocol} = $kvArgs{protocols};
	}

	if ( @{ $kvArgs{categories} } > 0) { 
		$where{category} = $kvArgs{categories};
	} 

	if ( @{ $kvArgs{languages} } > 0 ) { 
		$where{language} = $kvArgs{languages};
	} 
	
	if ( @{ $kvArgs{parsers} } > 0) { 
		$where{parser} = $kvArgs{parsers};
	} 

	my $sources = $src->getSources( %where );
	my $tar = Archive::Tar->new;

	for ( my $i = 0; $i < @$sources; $i++ ) {

		# delete fields which can cause conflicts or are not in use
		for ( 'id', 'categoryid', 'status', 'advisory_handler', 'contains_advisory', 'create_advisory' ) {
			delete $sources->[$i]->{$_};
		}
    
		# boolean conversions
		for ( 'checkid', 'delete_mail', 'enabled', 'clustering_enabled' ) {
			$sources->[$i]->{$_} = "true" if ( $sources->[$i]->{$_} =~ /^1$/ );
			$sources->[$i]->{$_} = "false" if ( $sources->[$i]->{$_} =~ /^0$/ );
		}

		$parsersList{ $sources->[$i]->{parser} } = 1;
    
		# decode all source details
		foreach my $key ( keys %{ $sources->[$i] }) {
			$sources->[$i]->{$key} = decodeInput( \$sources->[$i]->{$key} );
		}
		my $sourceName = $sources->[$i]->{sourcename};

		# add icon to archive file
		$tar->add_data( $sourceName . ".gif", $src->createSourceIcon( $sourceName ) );
	}
  
	my $xmlSourcesOut = ""  ;
	eval{
		$xmlSourcesOut = XMLout( { 'source' => $sources }, NoAttr => 1, RootName => 'sources', XMLDecl => 1 );
	};

	# add XML file to archive file 
	$tar->add_data("taranis.sources.xml", $xmlSourcesOut );

	# collect parsers to export
	foreach my $parser ( keys %parsersList ) {
		my $parserDetails = $pa->getParser( $parser ); 
		push @parsersExport, $parserDetails if ( $parserDetails );
	}

	my $xmlParsersOut = ""  ;
	eval{
		$xmlParsersOut = XMLout( { 'parser' => \@parsersExport }, NoAttr => 1, RootName => 'parsers', XMLDecl => 1 );
	};

	# add XML file to archive file 
	$tar->add_data("taranis.parsers.xml", $xmlParsersOut );

	$returnToBrowser->{content} = $tar->write();

	if ( !$@ ) {
		$returnToBrowser->{header} = "Content-Type: application/x-tar \n" 
			. "Content-disposition: attachment; filename=taranis.sources.tar;\n\n";
		print $returnToBrowser->{header};
		print $returnToBrowser->{content};
	}
	
	return {};
}
1;
