#!/usr/bin/perl 
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Config::XMLGeneric;
use Taranis::Template;
use Taranis qw(:all);
use strict;

my @EXPORT_OK = qw( 
	displayIDPatterns openDialogNewIDPattern openDialogIDPatternDetails
	saveNewIDPattern saveIDPatternDetails deleteIDPattern
	searchIDPatterns getIDPatternItemHtml 
);

sub id_patterns_export {
	return @EXPORT_OK;
}

sub displayIDPatterns {
	my ( %kvArgs) = @_;
	my ( $vars );

	my $session = $kvArgs{session};
	my $ip = Taranis::Config::XMLGeneric->new("identifiersconfig", "idname", "ids");
	my $tt = Taranis::Template->new();
	
	my $unsortedPatterns = $ip->loadCollection();
	my @patterns = sort { $$a{'idname'} cmp $$b{'idname'} } @$unsortedPatterns;
	
	$vars->{patterns} = \@patterns;
	$vars->{numberOfResults} = scalar @patterns;
	$vars->{write_right} = $session->right("write");	
	$vars->{newItem} = 1;
	
	my $htmlContent = $tt->processTemplateNoHeader('id_patterns.tt', $vars, 1);
	my $htmlFilters = $tt->processTemplateNoHeader('id_patterns_filters.tt', $vars, 1);
	
	my @js = ('js/id_patterns.js');

	return { content => $htmlContent, filters => $htmlFilters, js => \@js };
}

sub openDialogNewIDPattern {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $writeRight = $session->right("write"); 
	
	if ( $writeRight ) {

		$tpl = 'id_patterns_details.tt';
		
	} else {
		$vars->{message} = 'No permission...';
		$tpl = 'dialog_no_right.tt';
	}

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );

	return { 
		dialog => $dialogContent,
		params => { writeRight => $writeRight }  
	};
}

sub openDialogIDPatternDetails {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl, $id );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $ip = Taranis::Config::XMLGeneric->new("identifiersconfig", "idname", "ids");
	my $writeRight = $session->right("write"); 

	if ( exists( $kvArgs{id} ) && $kvArgs{id} ) {
		$id = $kvArgs{id};
		
		my $patterns = $ip->getElement( $kvArgs{id} );
		$vars->{pattern} = $patterns;

		$vars->{write_right} = $writeRight;
        
		$tpl = 'id_patterns_details.tt';
		
	} else {
		$vars->{message} = 'Invalid input supplied';
		$tpl = 'dialog_no_right.tt';
	}

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );
	
	return { 
		dialog => $dialogContent,
		params => { 
			writeRight => $writeRight,
			id => $id
		}  
	};	
}

sub saveNewIDPattern {
	my ( %kvArgs) = @_;
	my ( $message, $id );
	my $saveOk = 0;
	
	my $session = $kvArgs{session};
	
	if ( $session->right("write") && exists( $kvArgs{idname} ) && $kvArgs{idname} ) {
		$id = sanitizeInput("xml_primary_key", $kvArgs{idname} );
		
		my $ip = Taranis::Config::XMLGeneric->new("identifiersconfig", "idname", "ids");
		
		if ( !$ip->checkIfExists( $id ) ) {
			if ( 
				!$ip->addElement( 
					idname => $id, 
					pattern => $kvArgs{pattern}, 
					substitute => $kvArgs{substitute} 
				) 
			) {
				$message = $ip->{errmsg};
			}
		} else {
			$message = "A pattern with the same name already exists.";			
		}

	} else {
		$message = 'No permission';
	}
	
	$saveOk = 1 if ( !$message );
	
	return {
		params => {
			saveOk => $saveOk,
			message => $message,
			id => $id
		}
	};
}

sub saveIDPatternDetails {
	my ( %kvArgs) = @_;
	my ( $message, $id, $originalId );
	my $saveOk = 0;
	
	my $session = $kvArgs{session};
	
	if ( $session->right("write") && $kvArgs{idname} && $kvArgs{originalId} ) {
		( $id, $originalId ) = sanitizeInput("xml_primary_key", $kvArgs{idname}, $kvArgs{originalId} );	
		
		my $ip = Taranis::Config::XMLGeneric->new("identifiersconfig", "idname", "ids");

		if ( lc( $id ) eq lc( $originalId ) || !$ip->checkIfExists( $id ) ) {
			if ( 
				!$ip->setElement(	
					idname => $id,  
					pattern => $kvArgs{pattern}, 
					substitute => $kvArgs{substitute}, 
					orig_idname=> $originalId, 
				) 
			) {
				$message = $ip->{errmsg};
			} 
		} else {
			$message = "A pattern with the same name already exists.";
		}
		
	} else {
		$message = 'No permission';
	}

	$saveOk = 1 if ( !$message );
	
	return {
		params => {
			saveOk => $saveOk,
			message => $message,
			id => $id,
			originalId => $originalId
		}
	};
}

sub deleteIDPattern {
	my ( %kvArgs) = @_;
	my ( $message, $id );
	my $deleteOk = 0;
	
	my $session = $kvArgs{session};
	my $ip = Taranis::Config::XMLGeneric->new("identifiersconfig", "idname", "ids");

	if ( $session->right("write") && $kvArgs{id} ) {
		$id = sanitizeInput("xml_primary_key", $kvArgs{id} );
			
		if ( !$ip->deleteElement( $id ) ) {
			$message = $ip->{errmsg};
		} else {
			$deleteOk = 1;
		}
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			deleteOk => $deleteOk,
			message => $message,
			id => $id
		}
	};
}

sub searchIDPatterns {
	my ( %kvArgs) = @_;
	my ( $vars, @patterns );

	my $session = $kvArgs{session};
	
	my $tt = Taranis::Template->new();
	my $ip = Taranis::Config::XMLGeneric->new("identifiersconfig", "idname", "ids");

	my $unsortedPatterns = $ip->loadCollection( $kvArgs{search_idname} );
	@patterns = sort { $$a{'idname'} cmp $$b{'idname'} } @$unsortedPatterns if ( $unsortedPatterns ); 
	
	$vars->{patterns} = \@patterns;
	$vars->{numberOfResults} = scalar @patterns;
	$vars->{write_right} = $session->right("write");	
	$vars->{newItem} = 1;
	
	my $htmlContent = $tt->processTemplateNoHeader('id_patterns.tt', $vars, 1);
	
	return { content => $htmlContent };
}

sub getIDPatternItemHtml {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl, $id, $originalId );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $ip = Taranis::Config::XMLGeneric->new("identifiersconfig", "idname", "ids");
	
	my $insertNew = $kvArgs{insertNew};
	
 	( $id, $originalId ) = sanitizeInput("xml_primary_key", $kvArgs{id}, $kvArgs{originalId} );

	my $pattern = $ip->getElement( $id );
	 
	if ( $pattern ) {
		$vars->{pattern} = $pattern;
		$vars->{write_right} =  $session->right("write");
		$vars->{newItem} = $insertNew;
		
		$tpl = 'id_patterns_item.tt';
	} else {
		$tpl = 'empty_row.tt';
		$vars->{message} = 'Could not find the item...';
	}

	my $itemHtml = $tt->processTemplateNoHeader($tpl, $vars, 1);

	return {
		params => { 
			itemHtml => $itemHtml,
			insertNew => $insertNew,
			id => $id,
			originalId=> $originalId
		}
	};	
}

1; 
