#!/usr/bin/perl 
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:all);
use Taranis::Template;
use Taranis::Config;
use Taranis::SoftwareHardware;
use Taranis::ImportCpe;
use strict;
use JSON;
use LWP::UserAgent;
use XML::XPath;
use filetest 'access';

my @EXPORT_OK = qw(
	openDialogImportCPE getCPEImportEntries loadCPEFile processXml
	addCPEImportItem updateCPEImportItem deleteCPEImportItem 
	bulkDiscardCPEImport bulkImportCPEImport clearImport importRest 
);

sub import_cpe_export {
	return @EXPORT_OK;
}

sub openDialogImportCPE {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl, $dialogContent, $fileImportDone );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $writeRight = $session->right("write");
	
	if ( $writeRight ) {
		
		$fileImportDone = ( $session->{dbh}->checkIfExists({ cpe_id => "cpe%" }, "software_hardware_cpe_import", "IGNORE_CASE"	) ) ? 1 : 0;
		
		$tpl = 'import_cpe.tt';
		
	} else {
		$vars->{message} = 'No permission...';
		$tpl = 'dialog_no_right.tt';
	}
	
	$dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );

	return { 
		dialog => $dialogContent,
		params => { 
			writeRight => $writeRight, 
			fileImportDone => $fileImportDone 
		}  
	};	
}

sub loadCPEFile {
	my ( %kvArgs) = @_;
	my ( $message, $location );

	my $session = $kvArgs{session};
	my $writeRight = $session->right("write");
	
	my $loadFileOk = 0;
	$location = $kvArgs{location};

	if ( $writeRight ) {
		if ( $location !~ /\.xml$/i ) {
			$message = "Only valid XML is allowed.";	
		} elsif ( $location =~ /^http:\/\//i ) {
	
			## concerns web location
	
			if ( $location !~ /^http:\/\/static\.nvd\.nist\.gov\// ) {
				$message = "Only a web location from nist.gov is allowed.";	
			} else {
	
				my $filename = $location;
				$filename =~ s/.*\/(.*?\.xml)$/$1/i;
				my $download_path = Taranis::Config->getSetting("downloadpath");
				my $proxy_host = Taranis::Config->getSetting("proxy_host");
							
				my $ua = LWP::UserAgent->new();
	            my $userAgentString = Taranis::Config->getSetting("useragent_string");
	
				$ua->proxy(['http', 'https'], $proxy_host);
				$ua->agent( $userAgentString );						
	
				my $request = HTTP::Request->new( GET => $location );
				my $result = $ua->request( $request, $download_path . $filename );
	
				if ( $result->is_success ) {
					my $fh;
					open ( $fh, "<", $download_path . $filename );
					my $firstLine = <$fh>;
					close ( $fh );
	
					if ( $firstLine =~ /<\?xml version='1\.0' encoding='UTF-8'\?>/ ) {
						$loadFileOk = 1;
						$location = $download_path . $filename;
					} else {
						$message = "The downloaded file does not seem te be a valid XML file.";
					}
				} else {
					$message = "Error GET request: " . $result->status_line;
				}
			}
		} else {
			
		## concerns server location
	
			if ( !-r $location ) {
				$message = "Cannot read file";						
			} else {
				my $fh;
				open ( $fh, "<", $location );
				my $firstLine = <$fh>;
				close ( $fh ); 
	
				if ( $firstLine =~ /<\?xml version='1\.0' encoding='UTF-8'\?>/ ) {
					$loadFileOk = 1;
					$location = $location;
				} else {
					$message = "The downloaded file does not seem te be a valid XML file.";
				}
			}
		}
	} else {
		$message = "No permission";
	}
	
	return {
		params => { 
			location => $location,
			message => $message,
			loadFileOk => $loadFileOk
		}
	};
}

sub processXml {
	my ( %kvArgs) = @_;
	my $message;

	my $session = $kvArgs{session};
	my $writeRight = $session->right("write");
	
	if ( $writeRight ) {

		my $xp = XML::XPath->new( filename => $kvArgs{file} );
		my $sh = Taranis::SoftwareHardware->new();
		my $ic = Taranis::ImportCpe->new();

		my $importOptionVersions = $kvArgs{importOptionVersions};
		my $nodeset = $xp->find( '//cpe-item' );

		CPE:
		foreach my $cpe ( $nodeset->get_nodelist ) {

			my $is_deprecated = 0;
			my $cpe_id = $cpe->find( '@name' )->string_value;
			my ( $prefix, $type, $producer, $product, $version, $update, $edition, $language ) = split( /:/, $cpe_id );
			    
			$version = trim( encodeInput( \$version ) ) if ( $version );
			$version = undef if ( !defined( $version ) );

			$producer = trim( encodeInput( \$producer ) );			    
			$producer =~ /^([0-9]*)([\s\-_]*)([a-z]*.*)$/i;
			$producer = $1 . $2 . ucfirst( $3 );

			$type =~ s/\///;
			    			    
			if ( $cpe->find( '@deprecated' )->string_value =~ /true/ ) {
				$is_deprecated = 1;
			}
			
			my $name = trim( $cpe->find( 'title[@xml:lang="en-US"]' )->string_value );

			$name = encodeInput( \$name );

			if ( $name =~ /^(\Q$producer\E)/i ) {
				$producer = $1;
			}
					
			$name =~ s/^(\Q$producer\E\s)+//i if ( $name !~ /^\Q$producer\E$/i );
			$name =~ s/\s\Q$version\E$//i;	
					
			$name = trim( $name );
			$name = "" if ( !$name );
			
			my $versionCheck = ( $version ) ? $version : [ undef, '' ];
					
			if ( !$sh->{dbh}->checkIfExists( { cpe_id => $cpe_id }, "software_hardware" ) ) {

				## in dictionary, but not in Taranis
				if ( $is_deprecated ) {
					## deprecated in dictionary, skip entry
					next CPE;
				} else {
					## add to Taranis
							
					my $okToImport = ( $importOptionVersions && $version ) ? 0 : 1;
							
					if ( !$ic->addCpeImportEntry( 
							name => $name,
							producer => $producer,
							version => $version,
							type => $type,
							cpe_id => $cpe_id,
							ok_to_import => $okToImport
						)
					) {
						$message .= "Unable to ADD '$producer $name";
						$message .= " $version" if ( $version );
						$message .= "' with CPE ID $cpe_id, because of error: $sh->{errmsg} <br />";
					}
				}						

			} elsif ( $is_deprecated ) {
						
				## dictionary entry is deprecated, so check is SH in Taranis is linked to anything, if not delete SH in Taranis

				if ( $ic->isLinked( $cpe_id ) ) {
					next CPE;
				} else {
							
					if ( !$sh->deleteObject( cpe_id => $cpe_id ) ) {
						$message .= "Unable to DELETE '$producer $name";
						$message .= " $version" if ( $version );
						$message .= "' with CPE ID $cpe_id, because of error: $sh->{errmsg} <br />";
					}
				}

			} elsif ( 
				!$sh->{dbh}->checkIfExists( 
					{ 
						name => $name,
						producer => $producer,
						version => $versionCheck,
						type => $type,
						cpe_id => $cpe_id,
					},
					"software_hardware"
				)
				&& !$sh->{dbh}->checkIfExists( { cpe_id => $cpe_id, deleted => 't' }, "software_hardware" )
			) {

				## dictionary entry is not the same as in Taranis or is set to deleted, so add entry

				my $okToImport = ( $importOptionVersions && $version ) ? 0 : 1;

				if ( !$ic->addCpeImportEntry( 
						name => $name,
						producer => $producer,
						version => $version,
						type => $type,
						cpe_id => $cpe_id,
						ok_to_import => $okToImport
					)
				) {
					$message = "'$producer $name";
					$message .= " $version" if ( $version );
					$message .= "' with CPE ID $cpe_id<br />";
				}
														
			} else {
	
				## dictionary entry is same as in Taranis
				next CPE;
			}
		}

	} else {
		$message = "No permission";
	}
	
	return {
		params => { 
			message => $message
		}
	};
}

sub getCPEImportEntries {
	my ( %kvArgs) = @_;
	my ( $message, $importList, $leftToImport) ;

	my $session = $kvArgs{session};
	my $writeRight = $session->right("write");
	my $getEntriesOk = 0;
	
	if ( $writeRight ) {
	
		my $sh = Taranis::SoftwareHardware->new();
		my $ic = Taranis::ImportCpe->new();
				
		$importList = $ic->loadCollection( limit => 200, ok_to_import => 1 );
				
		foreach ( @$importList ) {
			$_->{version} = '' if ( !$_->{version} );
			$_->{is_new} = 0;
			$_->{has_multiple} = 0;

			## if there is an exact match on CPE ID ##
			if ( $sh->{dbh}->checkIfExists( { cpe_id => $_->{cpe_id} }, "software_hardware" ) ) {
				$_->{taranisEntry} = $sh->loadCollection( cpe_id => $_->{cpe_id} )->[0];

				$_->{taranisEntry}->{version} = '' if ( !$_->{taranisEntry}->{version} );
						
			} else {

				## if there is 1 match without a CPE ID ## 
				my $versionForCounting = ( $_->{version} ) ? $_->{version} : [ '', undef ];
				my $entryNoCPECount = $ic->{dbh}->countRows( 
					{ 
						producer 	=> $_->{producer},
						name 			=> $_->{name},
						version 	=> $versionForCounting,
						type 			=> $_->{type},
						cpe_id 		=> undef,
						deleted		=> 0
					}, 
					'software_hardware',
					'IGNORE_CASE',
					1 
				 ); 

				if ( $entryNoCPECount == 1 ) {

					$_->{taranisEntry} = $sh->loadCollection(  
						producer 	=> { -ilike => $_->{producer} },
						name 			=> { -ilike => $_->{name} },
						version 	=> $versionForCounting ,
						type 			=> $_->{type},
						cpe_id 		=> undef 
					)->[0];

					$_->{taranisEntry}->{version} = '' if ( !$_->{taranisEntry}->{version} );
							
				} elsif ( $entryNoCPECount > 1 ) {
					## if there are multiple matches without a CPE ID ##
					$_->{is_new} = 1;
					$_->{has_multiple} = 1;
				} else {
					## if there are no matches at all ##
					$_->{is_new} = 1;
				}
			}
		}
				
		if ( scalar( @$importList ) == 0 ) {
			$leftToImport = $sh->{dbh}->countRows( {}, 'software_hardware_cpe_import' );
		}
				
		$getEntriesOk = 1;
	
	
	} else {
		$message = "No permission";
	}
	
	return {
		params => { 
			message => $message,
			importList => $importList,
			leftToImport => $leftToImport,
			getEntriesOk => $getEntriesOk
		}
	};	
}

sub addCPEImportItem {
	my ( %kvArgs) = @_;
	my ( $message, $softwareHardwareId) ;

	my $session = $kvArgs{session};
	my $writeRight = $session->right("write");
	my $addOk = 0;
	
	if ( $writeRight ) {

		my $jsonImport = $kvArgs{import};
		$jsonImport =~ s/&quot;/"/g;
	
		my $import = from_json( $jsonImport );
		
		my $setDeleteFlag = ( $import->{setDelete} ) ? 1 : 0;				

		$softwareHardwareId = $import->{import_id};
		my $ic = Taranis::ImportCpe->new();
				
		$ic->{dbh}->startTransaction();
				
		if ( 
			$ic->importCpeEntry(
				producer => $import->{producer},
				name => $import->{name},
				version => $import->{version},
				type => $import->{type},
				cpe_id => $import->{cpe_id},
				deleted => $setDeleteFlag
			) 
			&& $ic->deleteImportEntry( id => $softwareHardwareId )
		) {
			$addOk = 1;
		} else {
			$message = $ic->{errmsg};
		}
				
		$ic->{dbh}->endTransaction();

	} else {
		$message = "No permission";
	}
	
	return {
		params => { 
			message => $message,
			importAction => $addOk,
			id => $softwareHardwareId
		}
	};
}

sub updateCPEImportItem {
	my ( %kvArgs) = @_;
	my ( $message, $importList, $leftToImport, $softwareHardwareId) ;

	my $session = $kvArgs{session};
	my $writeRight = $session->right("write");
	my $updateOk = 0;
	
	if ( $writeRight ) {

		my $jsonImport = $kvArgs{import};
		$jsonImport =~ s/&quot;/"/g;
	
		my $import = from_json( $jsonImport );
		my $producer = $import->{producer};
		my $name = $import->{name};
		my $version = $import->{version};
		my $type = $import->{type};
		$softwareHardwareId = $import->{import_id};
		my $cpeID = $import->{cpe_id};
		
		my $setDeleteFlag = ( $import->{setDelete} ) ? 1 : 0;				
		
		my $versionForLoadCollection = ( $version ) ? { -ilike => $version } : [ undef, '' ];
		
		my $sh = Taranis::SoftwareHardware->new();
		
		if ( 
			$sh->{dbh}->countRows( { 
				producer => $producer,
				name => $name,
				version => $versionForLoadCollection,
				type => $type,
				cpe_id => undef
			}, 
			'software_hardware',
			'IGNORE_CASE',
			1 
			) == 1
		) {

			my $sh = Taranis::SoftwareHardware->new();
			
			my $softwareHardware = $sh->loadCollection( 
				producer => { -ilike => $producer },
				name => { -ilike => $name },
				type => $type,
				version => $versionForLoadCollection,
				cpe_id => undef
			);

			$sh->{dbh}->startTransaction();

			if ( 
				$sh->setObject(
					id => $softwareHardware->[0]->{id},
					producer => $producer,
					name => $name,
					version => $version,																
					cpe_id => $cpeID
				) 
				&& $sh->deleteObject( table => 'software_hardware_cpe_import', id => $softwareHardwareId )
			) {
				$updateOk = 1;
			} else {
				$message = $sh->{errmsg};
			}
			
			$sh->{dbh}->endTransaction();	
			
		} else {
		
			$sh->{dbh}->startTransaction();

			if ( 
				$sh->setObject(
					producer => $producer,
					name => $name,
					version  => $version,
					type => $type,
					cpe_id => $cpeID,
					deleted => $setDeleteFlag															
				) 
				&& $sh->deleteObject( table => 'software_hardware_cpe_import', id => $softwareHardwareId )
			) {
				$updateOk = 1;
			} else {
				$message = $sh->{errmsg};
			}
			
			$sh->{dbh}->endTransaction();				
		}				

	} else {
		$message = "No permission";
	}
	
	return {
		params => { 
			message => $message,
			importAction => $updateOk,
			id => $softwareHardwareId
		}
	};
}

sub deleteCPEImportItem {
	my ( %kvArgs) = @_;
	my ( $message, $softwareHardwareId) ;

	my $session = $kvArgs{session};
	my $writeRight = $session->right("write");
	my $deleteOk = 0;
	
	if ( $writeRight ) {

		$softwareHardwareId = $kvArgs{id};
		my $ic = Taranis::ImportCpe->new();
		
		if ( $ic->deleteImportEntry( id => $softwareHardwareId ) ) {
			$deleteOk = 1;
		} else {
			$message = $ic->{errmsg};
		}
	
	} else {
		$message = "No permission";
	}
	
	return {
		params => { 
			message => $message,
			importAction => $deleteOk,
			id => $softwareHardwareId
		}
	};	
}

sub bulkImportCPEImport {
	my ( %kvArgs) = @_;
	my ( $message, @importIDs ) ;

	my $session = $kvArgs{session};
	my $writeRight = $session->right("write");
	my $importOk = 0;
	
	if ( $writeRight ) {

		my $jsonSelection = $kvArgs{selection};
		$jsonSelection =~ s/&quot;/"/g;
				
		my $selection = from_json( $jsonSelection );
		my $ic = Taranis::ImportCpe->new();
		my $sh = Taranis::SoftwareHardware->new();
		
		my $setDeleteFlag = $kvArgs{setDelete};
		
		$ic->{dbh}->startTransaction();

		foreach my $item ( @$selection ) {
			
			my $setItemToDeleted = ( $setDeleteFlag && $item->{version} ) ? 1 : 0; 
			my $versionForLoadCollection = ( $item->{version} ) ? { -ilike => $item->{version} } : [ undef, '' ];
			
			if ( $ic->{dbh}->checkIfExists( { cpe_id => $item->{cpe_id} }, 'software_hardware' ) ) {
				if ( !$ic->{dbh}->setObject(
						'software_hardware',
						{ cpe_id => $item->{cpe_id} },																					
						{
							producer => $item->{producer},
							name => $item->{name},
							version => $item->{version},
							type => $item->{type},
							deleted => $setItemToDeleted
						}
					) 
					|| !$ic->deleteImportEntry( id => $item->{import_id} )
				) {
					$message = $ic->{dbh}->{db_error_msg};
				} else {
					push @importIDs, $item->{import_id};
				}
			} elsif ( $ic->{dbh}->countRows( 
				{ 
					producer 	=> $item->{producer},
					name 			=> $item->{name},
					version 	=> $versionForLoadCollection,
					type 			=> $item->{type},
					cpe_id 		=> undef
				}, 
				'software_hardware',
				'IGNORE_CASE', 
				1 
				) == 1
			) {						
				
				my $softwareHardware = $sh->loadCollection( 
					producer=> { -ilike => $item->{producer} },
					name => { -ilike => $item->{name} },
					type => $item->{type},
					version => $versionForLoadCollection,
					cpe_id => undef
				);
				
				if ( !$ic->{dbh}->setObject(
						'software_hardware',
						{ id => $softwareHardware->[0]->{id} },																					
						{
							producer => $item->{producer},
							name => $item->{name},
							version => $item->{version},
							type => $item->{type},
							cpe_id => $item->{cpe_id},																				
							deleted => $setItemToDeleted
						}
					) 
					|| !$ic->deleteImportEntry( id => $item->{import_id} )
				) {
					$message = $sh->{errmsg};
				} else {
					push @importIDs, $item->{import_id};
				}

			} else {

				if ( !$ic->importCpeEntry(
						producer => $item->{producer},
						name 		 => $item->{name},
						version  => $item->{version},
						type 		 => $item->{type},
						cpe_id 	 => $item->{cpe_id},
						deleted	 => $setItemToDeleted
					) 
					|| !$ic->deleteImportEntry( id => $item->{import_id} )
				) {
					$message = $ic->{errmsg};
				}else {
					push @importIDs, $item->{import_id};
				}
			}
		}
		
		$ic->{dbh}->endTransaction();		
		
	} else {
		$message = "No permission";
	}
	
	$importOk = 1 if ( !$message );
	
	return {
		params => { 
			message => $message,
			importOk => $importOk,
			importIDs => \@importIDs
		}
	};
}

sub bulkDiscardCPEImport {
	my ( %kvArgs) = @_;
	my ( $message, @importIDs );

	my $session = $kvArgs{session};
	my $writeRight = $session->right("write");
	my $importOk = 0;
	
	if ( $writeRight ) {

		my $jsonSelection = $kvArgs{selection};
		$jsonSelection =~ s/&quot;/"/g;
				
		my $selection = from_json( $jsonSelection );

		my $ic = Taranis::ImportCpe->new();
						
		my @importIds;
		$ic->{dbh}->startTransaction();

		foreach my $item ( @$selection ) {
		
			if ( !$ic->deleteImportEntry( id => $item->{import_id} ) ) {
				$message = $ic->{errmsg};
			} else {
				push @importIDs, $item->{import_id};
			}
		}
		
		$ic->{dbh}->endTransaction();
	} else {
		$message = "No permission";
	}
	
	$importOk = 1 if ( !$message );
	
	return {
		params => { 
			message => $message,
			importOk => $importOk,
			importIDs => \@importIDs
		}
	};	
}

sub importRest {
	my ( %kvArgs) = @_;
	my ( $message );

	my $session = $kvArgs{session};
	my $writeRight = $session->right("write");
	my $importOk = 1;
	my $importCount = 0;
	
	if ( $writeRight ) {
		my $ic = Taranis::ImportCpe->new();
		my $products = $ic->getUniqueProducts();
		
		$ic->{dbh}->startTransaction();

		foreach my $product ( @$products ) {
			
			if ( !$ic->{dbh}->checkIfExists( 
					{ 
						producer => $product->{producer}, 
						name => $product->{name},
						type => $product->{type} 
					}, 
					'software_hardware', 
					'IGNORE_CASE' 
				)
			) {
				if ( !$ic->importCpeEntry( 
						producer => $product->{producer}, 
						name => $product->{name}, 
						type => $product->{type},
						deleted => 0,
				  )
				) {
					$message = $ic->{errmsg};
					$importOk = 0;
				} else {
					$importCount++;
				}
			}		
		}
		
		if ( $importOk ) {
			if ( !$ic->deleteAllImportEntries() ) {
				$importOk = 0;
				$message = $ic->{errmsg};						
			}
		}
		
		$ic->{dbh}->endTransaction();

	} else {
		$message = "No permission";
	}
	
	$importOk = 1 if ( !$message );
	
	return {
		params => { 
			message => $message,
			importOk => $importOk,
			itemsImported => $importCount
		}
	};	
}

sub clearImport {
	my ( %kvArgs) = @_;
	my ( $message );

	my $session = $kvArgs{session};
	my $writeRight = $session->right("write");
	my $clearOk = 0;
	
	if ( $writeRight ) {
	
		my $ic = Taranis::ImportCpe->new();
				
		if ( !$ic->deleteAllImportEntries() ) {
			$message = $ic->{errmsg};						
		}		
	} else {
		$message = "No permission";
	}
	
	$clearOk = 1 if ( !$message );
	
	return {
		params => { 
			message => $message,
			clearOk => $clearOk
		}
	};	
}
1;
