#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Config::XMLGeneric;
use Taranis::Template;
use Taranis qw(:all);
use strict;

my @EXPORT_OK = qw( 
	displayTools openDialogNewTool openDialogToolDetails
	saveNewTool saveToolDetails deleteTool getToolItemHtml
);

sub tools_export {
	return @EXPORT_OK;
}

sub displayTools {
	my ( %kvArgs) = @_;
	my ( $vars );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $tl = Taranis::Config::XMLGeneric->new("toolsconfig", "toolname", "tools");

	my $unsortedTools = $tl->loadCollection(); 
	$vars->{write_right} = $session->right("write");
	
	if ( $unsortedTools ) {
		my @sortedTools = sort { $$a{'toolname'} cmp $$b{'toolname'} } @$unsortedTools;
		$vars->{tools} = \@sortedTools;
		$vars->{numberOfResults} = scalar @sortedTools;	
	} else {
		$vars->{numberOfResults} = "0";
	}
	
	$vars->{newItem} = 1;
	
	my $htmlContent = $tt->processTemplateNoHeader('tools.tt', $vars, 1);
	my $htmlFilters = $tt->processTemplateNoHeader('tools_filters.tt', $vars, 1);
	
	my @js = ('js/tools.js');
	
	return { content => $htmlContent, filters => $htmlFilters, js => \@js };	
}

sub openDialogNewTool {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $writeRight = $session->right("write"); 
	
	if ( $writeRight ) {
		$tpl = 'tools_details.tt';
	} else {
		$vars->{message} = 'No permission...';
		$tpl = 'dialog_no_right.tt';
	}

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );

	return { 
		dialog => $dialogContent,
		params => { writeRight => $writeRight }  
	};	
}

sub openDialogToolDetails {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl, $toolName );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $writeRight = $session->right("write"); 

	if ( $kvArgs{toolname} ) {
		my $tl = Taranis::Config::XMLGeneric->new("toolsconfig", "toolname", "tools");
		my $tool = $tl->getElement( $kvArgs{toolname} );

		$vars->{orig_toolname} = $tool->{toolname};
		$vars->{tool} = $tool;
		$vars->{write_right} = $writeRight;
        
		$tpl = 'tools_details.tt';
		
	} else {
		$vars->{message} = 'Invalid input supplied';
		$tpl = 'dialog_no_right.tt';
	}

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );
	
	return { 
		dialog => $dialogContent,
		params => { 
			writeRight => $writeRight,
			toolname => $kvArgs{toolname}
		}  
	};
}

sub saveNewTool {
	my ( %kvArgs) = @_;
	my ( $message, $toolName );
	my $saveOk = 0;
	
	my $session = $kvArgs{session};
	
	$kvArgs{toolname} =	sanitizeInput("xml_primary_key", $kvArgs{toolname} );
	
	if ( $session->right("write") && $kvArgs{toolname} ) {
		
		$toolName = $kvArgs{toolname};
		my $tl = Taranis::Config::XMLGeneric->new("toolsconfig", "toolname", "tools");
		
		my $backendToolsLocation = $tl->{config}->{backend_tools};
		
		if ( !$tl->checkIfExists( $kvArgs{toolname} ) ) {
			
	        $kvArgs{backend} =~ s/$backendToolsLocation//gi;
	        $kvArgs{backend} =~ s/^\/+//;
	        $kvArgs{backend} =~ s/\/+/\//;

			if ( !$tl->addElement( 
				toolname => $kvArgs{toolname}, 
				webscript => $kvArgs{webscript},
				backend => $kvArgs{backend}													
				) 
			) {
				$message= $tl->{errmsg};
			}
		} else {
			$message = "A tool with the same name already exists.";			
		}
	} else {
		$message = 'No permission';
	}
	
	$saveOk = 1 if ( !$message );
	
	return {
		params => {
			saveOk => $saveOk,
			message => $message,
			toolname => $toolName,
			insertNew => 1
		}
	};
}

sub saveToolDetails {
	my ( %kvArgs) = @_;
	my ( $message, $toolName, $originalToolName );
	my $saveOk = 0;
	
	my $session = $kvArgs{session};

	( $kvArgs{toolname}, $kvArgs{orig_toolname} ) = sanitizeInput("xml_primary_key", $kvArgs{toolname}, $kvArgs{orig_toolname} );
	
	if ( $session->right("write") && $kvArgs{toolname} && $kvArgs{orig_toolname} ) {
		
		$toolName = $kvArgs{toolname};
		$originalToolName = $kvArgs{orig_toolname};
		my $tl = Taranis::Config::XMLGeneric->new("toolsconfig", "toolname", "tools");
		my $backendToolsLocation = $tl->{config}->{backend_tools};
		
		if ( lc( $kvArgs{toolname} ) eq lc( $kvArgs{orig_toolname} ) || !$tl->checkIfExists( $kvArgs{toolname} ) ) {
			$kvArgs{backend} =~ s/$backendToolsLocation//gi;
			$kvArgs{backend} =~ s/^\/+//;
			$kvArgs{backend} =~ s/\/+/\//;
			if ( !$tl->setElement(	
				toolname => $kvArgs{toolname}, 
				webscript => $kvArgs{webscript},
				backend => $kvArgs{backend},												
				orig_toolname => $kvArgs{orig_toolname} 
				) 
			) {
				$message = $tl->{errmsg};
			}
		} else {
			$message = "A tool with the same name already exists.";
		}
	} else {
		$message = 'No permission';
	}

	$saveOk = 1 if ( !$message );
	
	return {
		params => {
			saveOk => $saveOk,
			message => $message,
			toolname => $toolName,
			originalToolname => $originalToolName,
			insertNew => 0
		}
	};
}

sub deleteTool {
	my ( %kvArgs) = @_;
	my $message;
	my $deleteOk = 0;
	
	my $session = $kvArgs{session};
	my $tl = Taranis::Config::XMLGeneric->new("toolsconfig", "toolname", "tools");

	$kvArgs{toolname} = sanitizeInput("xml_primary_key", $kvArgs{toolname} );

	if ( $session->right("write") && $kvArgs{toolname} ) {
		if (!$tl->deleteElement( $kvArgs{toolname} ) ) {
			$message = $tl->{errmsg};
		} else {
			$deleteOk = 1;
		}
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			deleteOk => $deleteOk,
			message => $message,
			toolname => $kvArgs{toolname}
		}
	};
}

sub getToolItemHtml {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $tl = Taranis::Config::XMLGeneric->new("toolsconfig", "toolname", "tools");
	
	my $insertNew = $kvArgs{insertNew};
	
 	( $kvArgs{toolname}, $kvArgs{orig_toolname} ) = sanitizeInput("xml_primary_key", $kvArgs{toolname}, $kvArgs{orig_toolname} );
 	my $originalToolName = $kvArgs{orig_toolname};
	my $toolName= $kvArgs{toolname};

	my $tool = $tl->getElement( $kvArgs{toolname} );
	 
	if ( $tool ) {
		$vars->{tool} = $tool;
		$vars->{write_right} =  $session->right("write");
		$vars->{newItem} = $insertNew;
		
		$tpl = 'tools_item.tt';
	} else {
		$tpl = 'empty_row.tt';
		$vars->{message} = 'Could not find the item...';
	}

	my $itemHtml = $tt->processTemplateNoHeader($tpl, $vars, 1);

	return {
		params => { 
			itemHtml => $itemHtml,
			insertNew => $insertNew,
			toolname => $toolName,
			originalToolname => $originalToolName
		}
	};	
}
1;
