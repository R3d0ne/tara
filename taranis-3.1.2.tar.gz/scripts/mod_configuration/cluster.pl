#/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Cluster;
use Taranis::Category;
use Taranis::Template;
use JSON;
use Taranis qw(:all);
use strict;

my @EXPORT_OK = qw( 
	displayClusters openDialogNewCluster openDialogClusterDetails 
	saveNewCluster saveClusterDetails deleteCluster getClusterItemHtml
);

sub cluster_export {
	return @EXPORT_OK;
}

sub displayClusters {
	my ( %kvArgs) = @_;
	my ( $vars );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $cl = Taranis::Cluster->new();
	
	my @clusters = $cl->getCluster();

	$vars->{clusters} = ( $clusters[0] ) ? \@clusters : [];
	$vars->{numberOfResults} = scalar @clusters;
	$vars->{write_right} = $session->right("write");	
	$vars->{newItem} = 1;
	
	my $htmlContent = $tt->processTemplateNoHeader('cluster.tt', $vars, 1);
	my $htmlFilters = $tt->processTemplateNoHeader('cluster_filters.tt', $vars, 1);
	
	my @js = ('js/cluster.js');
	
	return { content => $htmlContent, filters => $htmlFilters, js => \@js };	
}

sub openDialogNewCluster {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $writeRight = $session->right("write");
	
	if ( $writeRight ) {
		my $ca = Taranis::Category->new();
		@{ $vars->{categories} } = $ca->getCategory( is_enabled => 1 );
		$tpl = 'cluster_details.tt';
	} else {
		$vars->{message} = 'No permission...';
		$tpl = 'dialog_no_right.tt';
	}
	
	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );

	return { 
		dialog => $dialogContent,
		params => { writeRight => $writeRight }  
	};	
}

sub openDialogClusterDetails {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl, $id );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $cl = Taranis::Cluster->new();
	
	my $writeRight = $session->right("write");	

	if ( $kvArgs{id} =~ /^\d+$/ ) {
		
		$id = $kvArgs{id};
		my $cluster = $cl->getCluster( 'cl.id' => $id );

		if ( exists $cluster->{id} ) {
			$vars->{cluster} = $cluster;
		} else {
			$vars->{message} = $cl->{errmsg};
		}

		my $ca = Taranis::Category->new();
		@{ $vars->{categories} } = $ca->getCategory( is_enabled => 1 );

		$tpl = 'cluster_details.tt';
		
	} else {
		$vars->{message} = 'Invalid input supplied';
		$tpl = 'dialog_no_right.tt';
	}

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );
	
	return { 
		dialog => $dialogContent,
		params => { 
			writeRight => $writeRight,
			id => $id
		}  
	};
}

sub saveNewCluster {
	my ( %kvArgs) = @_;
	my ( $message, $id );
	my $saveOk = 0;
	
	my $session = $kvArgs{session};
	
	if ( $session->right("write") ) {

		my $cl = Taranis::Cluster->new();
		if ( !$cl->{dbh}->checkIfExists( { language => lc $kvArgs{language}, category_id => $kvArgs{category} }, "cluster", "IGNORE_CASE" ) ) {
			
			my $recluster = ( $kvArgs{recluster} ) ? 1 : 0;
			
			if ( $cl->addCluster( 
					language => $kvArgs{language},
					category_id => $kvArgs{category},
					threshold => $kvArgs{threshold},
					timeframe_hours => $kvArgs{timeframe_hours},
					recluster => $recluster
				) 
			) {
				$id = $cl->{dbh}->getLastInsertedId('cluster');
			} else {
				$message = $cl->{errmsg};
			} 
		} else {
			$message = "A cluster with the same combination of language and category already exists.";
		}

		$saveOk = 1 if ( !$message );
		
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			saveOk => $saveOk,
			message => $message,
			id => $id,
			insertNew => 1
		}
	};	
}

sub saveClusterDetails {
	my ( %kvArgs) = @_;
	my ( $message, $id );
	my $saveOk = 0;
	
	my $session = $kvArgs{session};
	
	if ( $session->right("write") && $kvArgs{id} =~ /^\d+$/ ) {
		$id = $kvArgs{id};
		my $cl = Taranis::Cluster->new();
		
		my $is_enabled = ( $kvArgs{disable_cluster} ) ? 0 : 1;
		my $recluster = ( $kvArgs{recluster} ) ? 1 : 0;
		
		my %cluster_update = ( 
			id => $kvArgs{id}, 
			category_id => $kvArgs{category},
			threshold => $kvArgs{threshold},
			timeframe_hours => $kvArgs{timeframe_hours},
			language => $kvArgs{language},
			recluster => $recluster,
			is_enabled => $is_enabled 
		);
		
		if ( !$cl->{dbh}->checkIfExists( { language => lc $kvArgs{language}, category_id => $kvArgs{category} } , "category", "IGNORE_CASE" )	) {
							
			if ( !$cl->setCluster( %cluster_update ) ) {
				$message = $cl->{errmsg};
			}
		} else {
			$message = "A cluster with the same combination of language and category already exists.";
		}

		$saveOk = 1 if ( !$message );
		
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			saveOk => $saveOk,
			message => $message,
			id => $id,
			insertNew => 0
		}
	};
}

sub deleteCluster {
	my ( %kvArgs) = @_;
	my ( $message, $id );
	my $deleteOk = 0;
	
	my $session = $kvArgs{session};
	my $cl = Taranis::Cluster->new();

	if ( $session->right("write") && $kvArgs{id} =~ /^\d+$/ ) {
		$id = $kvArgs{id};
		
		if ( !$cl->deleteCluster( $kvArgs{id} ) ) {
			$message = $cl->{errmsg};
		} else {
			$deleteOk = 1;
		}

	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			deleteOk => $deleteOk,
			message => $message,
			id => $id
		}
	};
}

sub getClusterItemHtml{
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $cl = Taranis::Cluster->new();
		
	my $id = $kvArgs{id};
	my $insertNew = $kvArgs{insertNew};
 
 	my $cluster = $cl->getCluster( 'cl.id' => $id );
 
	if ( $cluster ) {
		$vars->{cluster} = $cluster;

		$vars->{write_right} =  $session->right("write");
		$vars->{newItem} = $insertNew;
		
		$tpl = 'cluster_item.tt';
	} else {
		$tpl = 'empty_row.tt';
		$vars->{message} = 'Could not find the item...';
	}

	my $itemHtml = $tt->processTemplateNoHeader($tpl, $vars, 1);

	return {
		params => { 
			itemHtml => $itemHtml,
			insertNew => $insertNew,
			id => $id
		}
	};
}

1;
