#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Template;
use Taranis::Statistics;
use Taranis qw(:all);
use strict;

my @EXPORT_OK = qw(displayConfigurationOptions);

sub configuration_export {
	return @EXPORT_OK;
}

sub displayConfigurationOptions {
	my ( %kvArgs) = @_;
	my ( $vars );
	my $tt = Taranis::Template->new();

	my $st = Taranis::Statistics->new();
	$vars->{statsCategories} = $st->getStatsCategories();

	my $session = $kvArgs{session};

	my $loadChartDirector = 1;
	eval "use perlchartdir; 1" or $loadChartDirector = 0;
	$vars->{canCreateStatistics} = $loadChartDirector; 
	
	$vars->{pageSettings} = $session->getSessionUserSettings();
	
	my $htmlFilters = $tt->processTemplateNoHeader('configuration_filters.tt', $vars, 1); 
	my $htmlContent = $tt->processTemplateNoHeader('configuration.tt', $vars, 1);
	
	my @js = (
		'js/configuration.js'
	);
	
	return { content => $htmlContent,  filters => $htmlFilters, js => \@js };
}

1;
