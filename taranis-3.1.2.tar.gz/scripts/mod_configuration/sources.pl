#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;
use Taranis::Sources;
use Taranis::Parsers;
use Taranis::Template;
use Taranis qw(:all);
use Taranis::Category;
use Taranis::Config;
use Taranis::Error;
use Taranis::Collector;
use Taranis::Users;
use Image::Size;
use Unicode::IMAPUtf7;
use Mail::IMAPClient;
use Mail::POP3Client;
use Digest::MD5 qw(md5_base64);

my @EXPORT_OK = qw( 
	displaySources openDialogNewSource openDialogSourceDetails 
	saveNewSource saveSourceDetails deleteSource getSourceItemHtml
	openDialogImportExportSources testSourceConnection testMailServerConnection 
	enableDisableSource searchSources testTwitterConnection
);

sub sources_export {
	return @EXPORT_OK;
}

sub displaySources {
	my ( %kvArgs) = @_;
	my ( $vars );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $sr = Taranis::Sources->new();
	my $ca = Taranis::Category->new();

	my ( %uniqueCategory, @categoryIds, @categories );
	
	if ( $session->right( "particularization" ) ) {
		foreach my $category ( @{ $session->right("particularization") } ) {
	
			$category = lc( $category );
			
			if ( !exists( $uniqueCategory{ $category } ) ) {
				$uniqueCategory{ $category} = 1;
				
				my $categoryId = $ca->getCategoryId( $category );
				push @categories, { id => $categoryId, name => $category };
			}
		}
	} else {
		@categories = $ca->getCategory( is_enabled => 1 );
	}

	$vars->{categories} = \@categories;
	
	foreach my $category ( @categories ) {
		push @categoryIds, $category->{id};
	}

	my $resultCount = $sr->getSourcesCount( category => \@categoryIds );
	my $sources = $sr->getSources( category => \@categoryIds, limit => 100, offset => 0 ); 
	
	$vars->{sources} = $sources;
	$vars->{filterButton} = 'btn-sources-search';
	$vars->{page_bar} = $tt->createPageBar( 1, $resultCount, 100 );
	
	$vars->{write_right} = $session->right("write");
	$vars->{newItem} = 1;
	$vars->{icon_dir} = Taranis::Config->getSetting("icondirectory_relative");
	
	my $htmlContent = $tt->processTemplateNoHeader('sources.tt', $vars, 1);
	my $htmlFilters = $tt->processTemplateNoHeader('sources_filters.tt', $vars, 1);
	
	my @js = ('js/sources.js', 'js/sources_import_export.js');
	
	return { content => $htmlContent, filters => $htmlFilters, js => \@js };	
}

sub openDialogNewSource {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $writeRight = $session->right("write");
	
	if ( $writeRight ) {
		$vars = getSourcesSettings( session => $session );
		
		$tpl = 'sources_details.tt';
	} else {
		$vars->{message} = 'No permission...';
		$tpl = 'dialog_no_right.tt';
	}
	
	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );

	return { 
		dialog => $dialogContent,
		params => { writeRight => $writeRight }  
	};
}

sub openDialogSourceDetails {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl, $id );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	
	my $writeRight = $session->right("write");	

	if ( $kvArgs{id} =~ /^\d+$/ ) {
		$id = $kvArgs{id};
		
		my $err = Taranis::Error->new();
		my $sr = Taranis::Sources->new();

		$vars = getSourcesSettings( session => $session );

		my $source = $sr->getSource( $id );
		$vars->{source} = $source;
		$vars->{collector_errors} = $err->getErrorsById( $source->{digest} );
				
		$tpl = 'sources_details.tt';
		
	} else {
		$vars->{message} = 'Invalid input supplied';
		$tpl = 'dialog_no_right.tt';
	}

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );
	
	return { 
		dialog => $dialogContent,
		params => { 
			writeRight => $writeRight,
			id => $id
		}  
	};	
}

sub saveNewSource {
	my ( %kvArgs) = @_;
	my ( $message, $id );
	my $saveOk = 0;
	
	my $session = $kvArgs{session};

	if ( $session->right("write") ) {
		my $sr = Taranis::Sources->new();
		for ( $kvArgs{protocol} ) {
			if (/(http|https)/) {
				delete $kvArgs{mailbox};
				delete $kvArgs{archive_mailbox};
				delete $kvArgs{delete_mail};
				delete $kvArgs{username};
				delete $kvArgs{password};
			} elsif (/(imap|imaps)/) {
				$kvArgs{url} = '';
				$kvArgs{parser} = undef;
				delete $kvArgs{delete_mail};				
			} elsif (/(pop3|pop3s)/) {
				$kvArgs{url} = '';
				$kvArgs{parser} = undef;
				delete $kvArgs{mailbox};
				delete $kvArgs{archive_mailbox};				
			}
		}
		

		my $sourceName = ( $kvArgs{'source-icon'} =~ /^1$/ )
			? sanitizeInput( "filename", $kvArgs{new_sourcename} ) 
			: sanitizeInput( "filename", $kvArgs{sourcename} );

		# add a leading slash on url part if it's not there 
		if ( $kvArgs{url} !~ /^\// ) { 
			$kvArgs{url} = '/' . $kvArgs{url};  
		}

		# delete protocol,port nr, trailing slash and url from host/domain part
		# http://www.somewhere.com:8080/feed.xml becomes www.somewhere.com
		$kvArgs{host} =~ s/^[a-zA-Z]{3,6}:\/{1,3}//; # http:// etc...
		$kvArgs{host} =~ s/[:\d+]*\/.*$//;           # :80/blah.html 
		$kvArgs{host} =~ s/:\d+$//;                  # :80 
		$kvArgs{host} =~ s/\/.*$//;                  # / or /blah.xml 

		my $addSlashes = ( $kvArgs{protocol} =~ /^(imap|pop3)/i ) ? '://' : '';

		my $full_url = $kvArgs{protocol} . $addSlashes . $kvArgs{host};
		$full_url .= ':' . $kvArgs{port} if ( $kvArgs{parser} !~ /^twitter$/ );
		$full_url .= $kvArgs{url};

		my $useForDigest = "";
		for ( $kvArgs{protocol} ) {
			if ( /^imap/ ) {
				$useForDigest = $kvArgs{mailbox} . $kvArgs{username};
			} elsif ( /^pop3/ ) {
				$useForDigest = $kvArgs{username};
			} else {
				$useForDigest = $kvArgs{url};
			}
		}
		
		my $digest = md5_base64( $kvArgs{host}, $useForDigest );
		my $clusteringEnabled = ( $kvArgs{clustering_enabled} ) ? 1 : 0;
		my $containsAdvisory = ( $kvArgs{contains_advisory} ) ? 1 : 0;
		my $createAdvisory = ( $kvArgs{create_advisory} ) ? 1 : 0;

		my $proceed = 1;
		if ( $kvArgs{'source-icon'} =~ /^1$/ ) {
			my $query = $session->{cgisession}->query;
			my $filename = $query->param("new_icon");
			
			my $fh = $query->upload( $filename );
	    
			my $mime = $query->upload_info( $filename, 'mime' ); # MIME type of uploaded file
			my $size = $query->upload_info( $filename, 'size' ); # size of uploaded file
      
			if ( $mime =~ /image.gif/ && $size < 5120 ) {
				$proceed = &checkIconImage( $fh, $sourceName );
			}
		} else {
			$proceed = 1;
		}

		if ( $proceed ) {			
			my %where = ( digest => $digest );
			if ( !$sr->{dbh}->checkIfExists( \%where, 'sources' ) ) {
				if ( 
					$sr->addElement( 
						sourcename => $sourceName, 
						checkid => $kvArgs{checkid},	
						digest => $digest, 
						host => $kvArgs{host},
						mailbox => $kvArgs{mailbox},
						mtbc => $kvArgs{mtbc},
						parser => $kvArgs{parser},
						password => $kvArgs{password},
						port => $kvArgs{port},
						protocol => $kvArgs{protocol},
						status => $kvArgs{status},
						url => $kvArgs{url},
						fullurl => $full_url,
						username => $kvArgs{username},
						category => $kvArgs{category},
						enabled => 1,
						archive_mailbox => $kvArgs{archive_mailbox},
						delete_mail => $kvArgs{delete_mail},
						language => $kvArgs{language},
						clustering_enabled => $clusteringEnabled,
						contains_advisory => $containsAdvisory,
						create_advisory => $createAdvisory,
						advisory_handler => $kvArgs{advisory_handler} || undef
					) 
				) {
					$id = $sr->{dbh}->getLastInsertedId('sources');
				} else {
					$message = $sr->{errmsg};
				}
			} else {
				$message = "A source with the specified host and URL already exists.";				
			}
		} else {
			$message = "Incorrect image selected. The Image icon must be 72 x 30 pixels (wxh), of type 'gif' and cannot exceed 5 kb.";			
		}

		$saveOk = 1 if ( !$message );
		
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			saveOk => $saveOk,
			message => $message,
			id => $id,
			insertNew => 1
		}
	};
}

sub saveSourceDetails {
	my ( %kvArgs) = @_;
	my ( $message, $id );
	my $saveOk = 0;
	
	my $session = $kvArgs{session};

	if ( $session->right("write") && $kvArgs{id} =~ /^\d+$/ ) {
		$id = $kvArgs{id};
		my $sr = Taranis::Sources->new();
		
		my $sourceName = ( $kvArgs{'source-icon'} =~ /^1$/ ) 
			? sanitizeInput( "filename", $kvArgs{new_sourcename} ) 
			: sanitizeInput( "filename", $kvArgs{sourcename} );
		
		for ( $kvArgs{protocol} ) {
			if (/(http|https)/) {
				delete $kvArgs{mailbox};
				delete $kvArgs{archive_mailbox};
				delete $kvArgs{delete_mail};
				delete $kvArgs{username};
				delete $kvArgs{password};
			} elsif (/(imap|imaps)/) {
				$kvArgs{parser} = "xml";
				$kvArgs{url} = '';
				delete $kvArgs{delete_mail};				
			} elsif (/(pop3|pop3s)/) {
				$kvArgs{parser} = "xml";
				$kvArgs{url} = '';
				delete $kvArgs{mailbox};
				delete $kvArgs{archive_mailbox};				
			}
		}

		# add a leading slash on url part if it's not there 
		if ($kvArgs{url} !~ /^\// ) { 
		   $kvArgs{url} = '/' . $kvArgs{url};  
		}
		
		# delete protocol,port nr, trailing slash and url from host/domain part 
		# http://www.somewhere.com:8080/feed.xml becomes www.somewhere.com
		$kvArgs{host} =~ s/^[a-zA-Z]{3,6}:\/{1,3}//; # http:// etc...
		$kvArgs{host} =~ s/[:\d+]*\/.*$//;           # :80/blah.html
		$kvArgs{host} =~ s/:\d+$//;                  # :80
		$kvArgs{host} =~ s/\/.*$//;                  # / or /blah.xml
		
		my $orig_digest = $kvArgs{digest};
		
		my $useForDigest = "";
		for ( $kvArgs{protocol} ) {
			if ( /^imap/ ) {
				$useForDigest = $kvArgs{mailbox} . $kvArgs{username};
			} elsif ( /^pop3/ ) {
				$useForDigest = $kvArgs{username};
			} else {
				$useForDigest = $kvArgs{url};
			}
		}
		
		my $new_digest = md5_base64( $kvArgs{host}, $useForDigest );

		my $addSlashes = ( $kvArgs{protocol} =~ /^(imap|pop3)/i ) ? '://' : '';

		my $full_url = $kvArgs{protocol} . $addSlashes . $kvArgs{host};
		$full_url .= ':' . $kvArgs{port} if ( $kvArgs{parser} !~ /^twitter$/ );
		$full_url .= $kvArgs{url};
		
		my $clusteringEnabled = ( $kvArgs{clustering_enabled} ) ? 1 : 0;
		my $containsAdvisory = ( $kvArgs{contains_advisory} ) ? 1 : 0;
		my $createAdvisory = ( $kvArgs{create_advisory} ) ? 1 : 0;
		
		my $proceed = 0;
		if ( $kvArgs{'source-icon'} =~ /^1$/ ) {
			my $query = $session->{cgisession}->query;
			my $filename = $query->param("new_icon");
			my $fh = $query->upload( $filename );
			my $mime = $query->upload_info( $filename, 'mime' ); # MIME type of uploaded file
			my $size = $query->upload_info( $filename, 'size' ); # size of uploaded file
      
			if ( $mime =~ /image.gif/ && $size < 5120 ) {
				$proceed = &checkIconImage( $fh, $sourceName );
			}
		} else {
			$proceed = 1;
		} 

		if ( $proceed ) {
			my %where = ( digest => $new_digest );
			if ( $orig_digest eq $new_digest || !$sr->{dbh}->checkIfExists( \%where, 'sources' ) ) {
				if ( 
					!$sr->setSource(
						id => $id,
						sourcename => $sourceName, 
						checkid => $kvArgs{checkid},	
						host => $kvArgs{host},
						mailbox => $kvArgs{mailbox},
						mtbc => $kvArgs{mtbc},
						parser => $kvArgs{parser},
						password => $kvArgs{password},
						port => $kvArgs{port},
						protocol => $kvArgs{protocol},
						status => $kvArgs{status},
						url => $kvArgs{url},
						fullurl => $full_url,
						username => $kvArgs{username},
						category => $kvArgs{category},
						archive_mailbox => $kvArgs{archive_mailbox},
						delete_mail => $kvArgs{delete_mail},
						language => $kvArgs{language},
						clustering_enabled => $clusteringEnabled,
						contains_advisory => $containsAdvisory,
						create_advisory => $createAdvisory,
						advisory_handler => $kvArgs{advisory_handler} || undef
					) 
				) {
					$message = $sr->{errmsg};
				}
			} else {
				$message = "A source with the specified host and URL already exists.";
			}
		} else {
			$message = "Incorrect image selected. The Image icon must be 72 x 30 pixels (wxh), of type 'gif' and cannot exceed 5 kb.";			
		}

		$saveOk = 1 if ( !$message );
		
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			saveOk => $saveOk,
			message => $message,
			id => $id,
			insertNew => 0
		}
	};
}

sub deleteSource {
	my ( %kvArgs) = @_;
	my ( $message, $id );
	my $deleteOk = 0;
	
	my $session = $kvArgs{session};
	my $sr = Taranis::Sources->new();

	if ( $session->right("write") && $kvArgs{id} =~ /^\d+$/ ) {
		$id = $kvArgs{id};
		if ( !$sr->deleteSource( $id ) ) {
			$message = $sr->{errmsg};
		} else {
			$deleteOk = 1;
		}
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			deleteOk => $deleteOk,
			message => $message,
			id => $id
		}
	};	
}

sub getSourceItemHtml {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $sr = Taranis::Sources->new();
	
	my $id = $kvArgs{id};
	my $insertNew = $kvArgs{insertNew};
 
	my $source = $sr->getSource( $id );
 
	if ( $source) {
		$vars->{source} = $source;
		$vars->{icon_dir} = Taranis::Config->getSetting("icondirectory_relative");
		$vars->{write_right} =  $session->right("write");
		$vars->{newItem} = $insertNew;
		
		$tpl = 'sources_item.tt';
	} else {
		$tpl = 'empty_row.tt';
		$vars->{message} = 'Could not find the item...';
	}

	my $itemHtml = $tt->processTemplateNoHeader($tpl, $vars, 1);

	return {
		params => { 
			itemHtml => $itemHtml,
			insertNew => $insertNew,
			id => $id
		}
	};	
}

sub searchSources {
	my ( %kvArgs) = @_;
	my ( $vars, %search );

	my $session = $kvArgs{session};
	
	my $tt = Taranis::Template->new();
	my $sr = Taranis::Sources->new();
	if ( exists( $kvArgs{category} ) && $kvArgs{category} =~ /^\d+$/ ) {
		$search{category} = [ $kvArgs{category} ];
	}

	if ( exists( $kvArgs{search} ) && $kvArgs{search} ) {
		$search{-or} = {
			url => {'-ilike' => '%' . $kvArgs{search} . '%'},
			sourcename => {'-ilike' => '%' . $kvArgs{search} . '%'}
		}
	}
	
	my $resultCount = $sr->getSourcesCount(	%search );

	my $pageNumber = ( exists( $kvArgs{'hidden-page-number'} ) && $kvArgs{'hidden-page-number'} =~ /^\d+$/ )
		? $kvArgs{'hidden-page-number'}
		: 1;
	my $hitsperpage = ( exists( $kvArgs{hitsperpage} ) && $kvArgs{hitsperpage} =~ /^[1-9][0-9]{0,2}$/ ) 
		? $kvArgs{hitsperpage} 
		: 100;

	my $offset = ( $pageNumber - 1 ) * $hitsperpage;
	$search{limit} = $hitsperpage;
	$search{offset} = $offset;
	
	my $sources = $sr->getSources( %search );
		
	$vars->{sources} = \@$sources;
	$vars->{page_bar} = $tt->createPageBar( $pageNumber, $resultCount, $hitsperpage );
	$vars->{filterButton} = 'btn-sources-search';
	$vars->{write_right} = $session->right("write");	
	$vars->{newItem} = 1;
	$vars->{icon_dir} = Taranis::Config->getSetting("icondirectory_relative");
	
	my $htmlContent = $tt->processTemplateNoHeader('sources.tt', $vars, 1);
	
	return { content => $htmlContent };	
}

sub testSourceConnection {
	my ( %kvArgs) = @_;
	my ( $message );
	my $checkOk = 0;

	my $testOnly = $kvArgs{testOnly};
	
	my %source = (
		host => $kvArgs{host},
		url => $kvArgs{url},
		protocol => $kvArgs{protocol},
		port => $kvArgs{port},
		parser => $kvArgs{parser},
		sourcename => 'checkXmlHtmlSource'
	);
	
	my $col = Taranis::Collector->new();
	$col->{no_db} = 1;

	my $fullurl = $source{protocol} . $source{host};
	$fullurl .= ':' . $source{port} if ( $source{port} && $source{port} != 80 );
	$fullurl .= $source{url};
	
	$col->{this_source} = \%source;
	
	my $sourceData = $col->getSourceData( $fullurl );
		
	my $feed_links;
				
	if ( $source{parser} =~ /^xml/ ) {
		$feed_links = $col->processXmlFeed( $sourceData );
	} else {
		$feed_links = $col->processHtmlFeed( $sourceData );
	}

	if ( ref( $feed_links ) ne 'ARRAY' ) {
		my $responseCode = $col->{http_status_code};

		if ( $responseCode =~ /^20/ ) {
			$message = "Connection to source: OK. But retrieval of items FAILED.";	
		} else {
			$message = "Connection to source: FAILED. Response: " . $col->{http_status_line};
		}

	} else {
		$checkOk = 1;
		$message = "Connection and retrieval of items: OK";
	}

	return {
		params => {
			checkOk => $checkOk,
			message => $message,
			testOnly => $testOnly
		}
	};		
}

sub testMailServerConnection {
	my ( %kvArgs) = @_;
	my ( $message );
	my $checkOk = 0;

	my $imapUTF7 = Unicode::IMAPUtf7->new();
	
	my $server = $kvArgs{host};
	my $port = $kvArgs{port};
	my $protocol = $kvArgs{protocol};
	my $username = $kvArgs{username};
	my $password = $kvArgs{password};
	my $mailbox = $kvArgs{mailbox};
	my $archive_mailbox = $kvArgs{archive_mailbox};
	
	my $id = $kvArgs{id};
	my $testOnly = $kvArgs{testOnly}; 
	
	if ( $protocol =~ /(imap|imaps)/i ) {
		my $imap = Mail::IMAPClient->new();
		
		$imap->Server( $server );
		$imap->User( $username ) if ( $username );
		$imap->Password( $password ) if ( $password );
		$imap->Port( $port ) if ( $port );
		$imap->Ssl( 1 ) if ( $protocol =~ /^imaps$/i );
		$imap->Ignoresizeerrors( 1 );
	
		if ( $imap->connect() ) {
			
			my $originalMailbox = $mailbox;
			$mailbox = $imapUTF7->encode( decodeInput( \$mailbox ) );
			
			if ( $imap->exists( $mailbox ) ) {
				$message = "Connection to mailbox: OK. ";
				$checkOk = 1;
			} else {
				$message = "Connection to mailbox: FAILED. ";
			}

			$archive_mailbox = $imapUTF7->encode( decodeInput( \$archive_mailbox ) );

			if ( $imap->exists( $archive_mailbox ) ) {
				$message .= "Connection to archive mailbox: OK. ";
			} else {
				$message .= "Connection to archive mailbox: FAILED. ";
				$checkOk = 0;	
			}	
			$imap->close();
	
		} else {
			$message = "Unable to connect to server. " . $imap->LastError();
		}
	} else {
		
		my $ssl = ( $protocol =~ /pop3s/i ) ? 1 : 0;
		
		$port = ( !$port && $protocol =~ /pop3s/i ) ? 995 : 110;
		
		my $pop3 = Mail::POP3Client->new(
			HOST => $server,
			USESSL => $ssl,
			USER => $username,
			PASSWORD => $password, 
			PORT => $port
		);
		
		if ( $pop3->Connect() ) {
			$message = "Connection to server: OK.";
			$checkOk = 1;			
		} else {
			$message = "Connection to server: FAILED. " . $pop3->Message();
		}
		
		$pop3->Close();
	}	

	return {
		params => {
			checkOk => $checkOk,
			message => $message,
			id => $id,
			testOnly => $testOnly
		}
	};	
}

sub testTwitterConnection {
	my ( %kvArgs) = @_;
	my ( $message );
	my $checkOk = 0;

	my $testOnly = $kvArgs{testOnly};

	my $col = Taranis::Collector->new();

	my $fullurl = $kvArgs{protocol} . $kvArgs{host};
	$fullurl .= ':' . $kvArgs{port} if ( $kvArgs{port} && $kvArgs{port} != 80 );
	$fullurl .= $kvArgs{url};

	my $twitter = $col->{twitter};

	my $response = $twitter->get( decodeInput( \$fullurl ) );
	if ( $response->is_success ) {
		$checkOk = 1;
		$message = "Connection OK";		
	} else {
		$message = "Connection failed: " . $response->status_line;
	}

	return {
		params => {
			checkOk => $checkOk,
			message => $message,
			testOnly => $testOnly
		}
	};		
}

sub enableDisableSource {
	my ( %kvArgs) = @_;
	my ( $message, $id, $enable );
	my $enableOk = 0;

	my $session = $kvArgs{session};
	my $sr = Taranis::Sources->new();

	if ( $session->right("write") && $kvArgs{id} =~ /^\d+$/ && $kvArgs{enable} =~ /^(0|1)$/ ) {
		$id = $kvArgs{id};
		$enable = $kvArgs{enable};
		if ( !$sr->setSource( id => $id, enabled => $enable ) ) {
			$message = $sr->{errmsg};
		} else {
			$enableOk = 1;
		}
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			enableOk => $enableOk,
			message => $message,
			id => $id,
			enable => $enable
		}
	};	
}

## HELPERS 
sub getSourcesSettings {
	my ( %kvArgs ) = @_;
	my $session = $kvArgs{session};
	my $settings = {};
	
	my $ca = Taranis::Category->new();	
	my ( %uniqueCategory, @categories, @parsers );
	
	if ( $session->right( "particularization" ) ) {
		foreach my $category ( @{ $session->right("particularization") } ) {
	
			$category = lc( $category );
			
			if ( !exists( $uniqueCategory{ $category } ) ) {
				$uniqueCategory{ $category } = 1;
				my $categoryId = $ca->getCategoryId( $category );
				push @categories, { id => $categoryId, name => $category };
			}
		}
	} else {
		@categories = $ca->getCategory( is_enabled => 1 );
	}	
	
	$settings->{categories} = \@categories;
	
	# get all sources from icon dir
	my $iconDirAbsolutePath = Taranis::Config->getSetting("icondirectory_absolute");
	my @files; 	
	eval{
		my $dh;
		opendir $dh, $iconDirAbsolutePath;
		@files= sort (readdir $dh);
		closedir $dh;
	};
	
	if ( $@ ) {
		$settings->{sources} = [];
	} else {
	
		my @sources;
		foreach my $file (@files) {
			if ( $file !~ /^\./ && $file =~ /\.gif$/ ) {
				$file =~ s/\.gif$//i;
				push @sources, $file;
			}
		}
		$settings->{sources} = \@sources;
	}
	
	my $ps = Taranis::Parsers->new();
	$settings->{parsers} = $ps->getParsers();
	$settings->{icon_dir} = Taranis::Config->getSetting("icondirectory_relative");

	my $us = Taranis::Users->new();
	my $users = $us->getUsersList();
	my @users;
	while ( $us->nextObject() ) {
		my $user = $us->getObject();
		push @users, { username => $user->{username}, fullname => $user->{fullname} }
	}  

	$settings->{users} = \@users;
	
	return $settings;	
}

sub checkIconImage {
	my $fh = $_[0];
	my $source_name = $_[1];
 
	my ( $img_x , $img_y ) = Image::Size::imgsize($fh);		

	# check if the icon image is 72 x 30 pixels		
	if ( ($img_x eq 72) && ($img_y eq 30) ) { 

		my $icon_dir = Taranis::Config->getSetting("icondirectory_absolute");
		my $filename = $source_name.".gif";
		my $save_file = "$icon_dir$filename";
		my $newFh;
		open($newFh, ">", $save_file) or return 0;
		binmode $newFh;
		while(<$fh>) {
			print $newFh $_ or return 0;
		}
		close $newFh;

		return 1;
		
	} else {
		return 0;
	}
}
1;
