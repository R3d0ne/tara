#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;

use Taranis qw(:all);
use Taranis::Users;
use Taranis::Template;
use Taranis::Category;
use Taranis::AssessCustomSearch;
use Taranis::Assess;
use JSON;
use Digest::MD5 qw(md5 md5_hex md5_base64);

my @EXPORT_OK = qw( openDialogUserSettings changePassword saveSearch deleteSearch saveAssessRefreshSetting );

sub user_panel_export {
	return @EXPORT_OK;
}

sub openDialogUserSettings {
	my ( %kvArgs) = @_;
	my ( $vars );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $as = Taranis::Assess->new();
	my $us = Taranis::Users->new();
	my $cs = Taranis::AssessCustomSearch->new();
	
	my $userId = $session->{cgisession}->param("userid");

	my @allowedCategorieIds;
	my @assessCategoriesFromSession = @{ $session->getSessionUserSettings()->{assess_categories} };
		
	foreach my $categoryFromSession ( @assessCategoriesFromSession ) {
		push @allowedCategorieIds, $categoryFromSession->{id};
	}
		
	@{ $vars->{all_categories} } = @assessCategoriesFromSession;
	@{ $vars->{all_sources} } = $as->getDistinctSources( \@allowedCategorieIds );
		
	my $searches = $cs->loadCollection( created_by => $userId );
		
	foreach my $search ( @$searches ) {
		$search->{checku} = 1 if ( substr( $search->{uriw}, 0, 1 ) eq "1" );
		$search->{checkr} = 1 if ( substr( $search->{uriw}, 1, 1 ) eq "1" );
		$search->{checki} = 1 if ( substr( $search->{uriw}, 2, 1 ) eq "1" );
		$search->{checkw} = 1 if ( substr( $search->{uriw}, 3, 1 ) eq "1" );
	}
		
	$vars->{searches} = $searches;
		
	my $userSettings = $us->getUser( $userId );
	$vars->{assess_autorefresh} = $userSettings->{assess_autorefresh};

	$vars->{username} = $userId;
	my $dialogContent = $tt->processTemplateNoHeader( 'user_panel.tt', $vars, 1 );
	
	return { dialog => $dialogContent };
}

sub changePassword {
	my ( %kvArgs) = @_;
	my ( $message );
	
	my $session = $kvArgs{session};
	my $us = Taranis::Users->new();
	my $userId = $session->{cgisession}->param("userid");
	my $changeOk = 0;
	
	if ( $kvArgs{current_pwd} && $kvArgs{new_pwd} ) {
		if ( $us->checkPassword( password => $kvArgs{current_pwd}, username => $userId ) ) {
			if ( !$us->setUser( username => $userId, password => md5_base64( $kvArgs{new_pwd} ) ) ) {
				$message = $us->{errmsg};
			}
		} else {
			$message = "Username/password does not match current password.";
		}
	} else {
		$message = 'Invalid input';
	}
	
	$changeOk = 1 if ( !$message );	
	return { 
		params => {
			changeOk => $changeOk,
			message => $message
		}
	}
}

sub saveSearch {
	my ( %kvArgs) = @_;
	my ( $message );
	
	my $cs = Taranis::AssessCustomSearch->new();
	my $saveOk = 0;
	
	my $jsonString = $kvArgs{customSearch};
	
	$jsonString =~ s/&quot;/"/g;
	my $customSearch = from_json( $jsonString );

	$customSearch->{startdate} = formatDateTimeString( $customSearch->{startdate} );
	$customSearch->{enddate} = formatDateTimeString( $customSearch->{enddate} );
	
	if ( !$cs->setSearch( %$customSearch ) ) {
		$message = $cs->{errmsg};
	}
	
	$saveOk = 1 if ( !$message );	
	return { 
		params => {
			saveOk => $saveOk,
			message => $message,
			searchSettings => $customSearch
		}
	}	
}

sub deleteSearch {
	my ( %kvArgs) = @_;
	my ( $message );
	
	my $cs = Taranis::AssessCustomSearch->new();
	my $deleteOk = 0;
	
	my $searchId = $kvArgs{searchId};
	
	if ( !$cs->deleteSearch( $searchId ) ) {
		$message = $cs->{errmsg};
	}
	
	$deleteOk = 1 if ( !$message );	
	return { 
		params => {
			deleteOk => $deleteOk,
			message => $message,
			searchId => $searchId
		}
	}
}

sub saveAssessRefreshSetting {
	my ( %kvArgs) = @_;
	my ( $message );
	my $session = $kvArgs{session};
	
	my $us = Taranis::Users->new();
	my $saveOk = 0;
	
	my $assessAutoRefresh = ( $kvArgs{assess_autorefresh} =~ /^(1|0)$/ ) ? $kvArgs{assess_autorefresh} : 1;
	
	if ( !$us->setUser( username => $session->{cgisession}->param("userid"), assess_autorefresh => $assessAutoRefresh ) ) {
		$message = $us->{errmsg};
	}	
	
	$saveOk = 1 if ( !$message );	
	return { 
		params => {
			saveOk => $saveOk,
			message => $message
		}
	}
}

1;
