#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;

use Taranis qw(:all);
use Taranis::SoftwareHardware;
use Taranis::Template;
use POSIX;

my @EXPORT_OK = qw( 
	displaySoftwareHardware openDialogNewSoftwareHardware openDialogSoftwareHardwareDetails searchSoftwareHardware
	saveNewSoftwareHardware saveSoftwareHardwareDetails deleteSoftwareHardware getSoftwareHardwareItemHtml
);

sub software_hardware_export {
	return @EXPORT_OK;
}

sub displaySoftwareHardware {
	my ( %kvArgs) = @_;
	my ( $vars );

	my $session = $kvArgs{session};
	my $sh = Taranis::SoftwareHardware->new();
	my $tt = Taranis::Template->new();

	my @vendors = $sh->getDistinctList();
	$vars->{vendors} = \@vendors;

	my $types = $sh->getBaseTypes();
	foreach my $baseType ( keys %$types ) {
		if ( my $description = $sh->getSuperTypeDescription( $baseType ) ) {
			$types->{$baseType} .= " ($description->{description})"; 
		}
	}
	$vars->{base_types} = $types; 

	my @softwareHardwareList;
	my $resultCount = $sh->getListCount( producer => '', name => '' );
		
	$sh->getList( limit => '100', offset => '0' );
	while ( $sh->nextObject() ) {
		push @softwareHardwareList, $sh->getObject();
	}
	
	foreach my $product ( @softwareHardwareList ) {
		$product->{constituentGroups} = $sh->getConstituentUsage( $product->{id} );
	}
	
	$vars->{softwareHardware} = \@softwareHardwareList;
	$vars->{filterButton} = 'btn-software-hardware-search';
	$vars->{page_bar} = $tt->createPageBar( 1, $resultCount, 100 );

	$vars->{write_right} = $session->right("write");	
	$vars->{newItem} = 1;
	
	my $htmlContent = $tt->processTemplateNoHeader('software_hardware.tt', $vars, 1);
	my $htmlFilters = $tt->processTemplateNoHeader('software_hardware_filters.tt', $vars, 1);
	
	my @js = ('js/software_hardware.js', 'js/import_cpe.js', 'js/constituent_group.js');
	
	return { content => $htmlContent, filters => $htmlFilters, js => \@js };	
}

sub openDialogNewSoftwareHardware {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $sh = Taranis::SoftwareHardware->new();
	my $writeRight = $session->right("write");
	
	if ( $writeRight ) {

		my $types = $sh->getBaseTypes();
		foreach my $baseType ( keys %$types ) {
			
			if ( my $description = $sh->getSuperTypeDescription( $baseType ) ) {
				$types->{$baseType} .= " ($description->{description})"; 
			}
		}
		$vars->{base_types} = $types; 
		
		$tpl = 'software_hardware_details.tt';
	} else {
		$vars->{message} = 'No permission...';
		$tpl = 'dialog_no_right.tt';
	}
	
	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );

	return { 
		dialog => $dialogContent,
		params => { writeRight => $writeRight }
	};
}

sub openDialogSoftwareHardwareDetails {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl, $id );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $sh = Taranis::SoftwareHardware->new();
	
	my $writeRight = $session->right("write");	

	if ( $kvArgs{id} =~ /^\d+$/ ) {
		$id = $kvArgs{id};

		my $types = $sh->getBaseTypes();
		foreach my $baseType ( keys %$types ) {
			
			if ( my $description = $sh->getSuperTypeDescription( $baseType ) ) {
				$types->{$baseType} .= " ($description->{description})"; 
			}
		}
		$vars->{base_types} = $types; 
		
		$vars->{softwareHardwareItem} = $sh->getList( id => $id );
		$vars->{constituentGroups} = $sh->getConstituentUsage( $id );

		$vars->{id} = $id;

		$tpl = 'software_hardware_details.tt';
		
	} else {
		$vars->{message} = 'Invalid input supplied';
		$tpl = 'dialog_no_right.tt';
	}

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );
	
	return { 
		dialog => $dialogContent,
		params => { 
			writeRight => $writeRight,
			id => $id
		}  
	};
}
 
sub saveNewSoftwareHardware {
	my ( %kvArgs) = @_;
	my ( $message, $id );
	my $saveOk = 0;
	
	my $session = $kvArgs{session};
	my $sh = Taranis::SoftwareHardware->new();

	if ( $session->right("write") ) {
        if ( $sh->addObject(
				producer => $kvArgs{producer},
				name => $kvArgs{name},
				version => $kvArgs{version},
				monitored => $kvArgs{monitored},
				type => $kvArgs{type}
        	)
		) {
			$id = $sh->{dbh}->getLastInsertedId( "software_hardware" );
        } else {
            $message = $sh->{errmsg};
        }

		$saveOk = 1 if ( !$message );
		
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			saveOk => $saveOk,
			message => $message,
			id => $id,
			insertNew => 1
		}
	};
}

sub saveSoftwareHardwareDetails {
	my ( %kvArgs) = @_;
	my ( $message, $id );
	my $saveOk = 0;
	
	my $session = $kvArgs{session};

	if ( $session->right("write") && $kvArgs{id} =~ /^\d+$/ ) {
		my $sh = Taranis::SoftwareHardware->new();
		
		$id = $kvArgs{id};
		
		if (
			!$sh->setObject(
				producer => $kvArgs{producer},
				name => $kvArgs{name},
				version => $kvArgs{version},
				monitored => $kvArgs{monitored},
				type => $kvArgs{type},
				id => $id
			)
		) {
			$message = $sh->{errmsg};
		}

		$saveOk = 1 if ( !$message );
		
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			saveOk => $saveOk,
			message => $message,
			id => $id,
			insertNew => 0
		}
	};	
}

sub deleteSoftwareHardware {
	my ( %kvArgs) = @_;
	my ( $message, $id );
	my $deleteOk = 0;
	
	my $session = $kvArgs{session};
	my $sh = Taranis::SoftwareHardware->new();

	if ( $session->right("write") && $kvArgs{id} =~ /^\d+$/ ) {
		$id = $kvArgs{id};
		
		if ( $sh->setObject( deleted => 't', id => $id ) ) {
			$deleteOk = 1;
		} else {
			$message = $sh->{errmsg};			
		}
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			deleteOk => $deleteOk,
			message => $message,
			id => $id
		}
	};	
}

sub getSoftwareHardwareItemHtml {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $sh = Taranis::SoftwareHardware->new();
	
	my $id = $kvArgs{id};
	my $insertNew = $kvArgs{insertNew};
 
	my $softwareHardwareItem = $sh->getList( id => $id );
 
	if ( $softwareHardwareItem ) {

		$softwareHardwareItem->{constituentGroups} = $sh->getConstituentUsage( $id );

		$vars->{softwareHardwareItem} = $softwareHardwareItem;
		$vars->{write_right} =  $session->right("write");
		$vars->{newItem} = $insertNew;
		
		$tpl = 'software_hardware_item.tt';
	} else {
		$tpl = 'empty_row.tt';
		$vars->{message} = 'Could not find the item...';
	}

	my $itemHtml = $tt->processTemplateNoHeader($tpl, $vars, 1);

	return {
		params => { 
			itemHtml => $itemHtml,
			insertNew => $insertNew,
			id => $id
		}
	};
}

sub searchSoftwareHardware {
	my ( %kvArgs) = @_;
	my ( $vars, %search, @softwareHardwareList );

	my $session = $kvArgs{session};
	
	my $tt = Taranis::Template->new();
	my $sh = Taranis::SoftwareHardware->new();

	$search{producer} = $kvArgs{vendor_name};
	$search{type} = $kvArgs{product_type};
	$search{name} = $kvArgs{name};

	my $resultCount = $sh->getListCount(
		producer => $search{producer},
		type => $search{type},
		name => $search{name}
	);

	my $pageNumber = ( exists( $kvArgs{'hidden-page-number'} ) && $kvArgs{'hidden-page-number'} =~ /^\d+$/ )
		? $kvArgs{'hidden-page-number'}
		: 1;
	my $hitsperpage = ( exists( $kvArgs{hitsperpage} ) && $kvArgs{hitsperpage} =~ /^[1-9][0-9]{0,2}$/ ) 
		? $kvArgs{hitsperpage} 
		: 100;

	my $offset = ( $pageNumber - 1 ) * $hitsperpage;

	my $list = $sh->getList(
		producer => $search{producer},
		type => $search{type},
		name => $search{name},
		limit => $hitsperpage,
		offset => $offset
	);

	while ( $sh->nextObject() ) {
		push @softwareHardwareList, $sh->getObject();
	}
	
	foreach my $product ( @softwareHardwareList ) {
		$product->{constituentGroups} = $sh->getConstituentUsage( $product->{id} );
	}
	
	$vars->{softwareHardware} = \@softwareHardwareList;
	$vars->{filterButton} = 'btn-software-hardware-search';
	$vars->{page_bar} = $tt->createPageBar( $pageNumber, $resultCount, $hitsperpage );
	$vars->{write_right} = $session->right("write");	
	$vars->{newItem} = 1;
	
	my $htmlContent = $tt->processTemplateNoHeader('software_hardware.tt', $vars, 1);
	
	return { content => $htmlContent };	
}

1;
