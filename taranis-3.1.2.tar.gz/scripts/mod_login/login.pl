#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;

use Taranis::Users;
use Taranis::Session;
use Data::Dumper;

use Taranis::Role;
use Taranis::Config;
use Taranis::Template;
use Taranis qw(:all);
use CGI::Simple;

use ModPerl::Util;

my $tt    = Taranis::Template->new();
my $user  = Taranis::Users->new();
my $role 	= Taranis::Role->new();
my $query = CGI::Simple->new();
my $vars;

my %url_arg = $query->Vars();
if ( exists( $url_arg{ent} ) ) { $vars->{error} = "Entitlement error for $url_arg{ent}" }
if ( exists( $url_arg{cause} ) && $url_arg{cause} =~ /^expired$/ ) { $vars->{error} = 'Session Expired, please log in again' }
if ( exists( $url_arg{cause} ) && $url_arg{cause} =~ /^nosession$/ ) { $vars->{error} = 'No active session found, please log in.' }
my $goto_url = ( exists( $url_arg{'goto'} ) && $url_arg{'goto'} =~ /^\/taranis\/.*/ ) ? $url_arg{'goto'} : "/taranis/";

$vars->{goto_url} = $goto_url;

$vars->{webroot} = Taranis::Config->getSetting("webroot");
my $sso_setting = ( Taranis::Config->getSetting("sso") =~ /^on$/i ) ? 1 : 0;

my $useragent = $ENV{'HTTP_USER_AGENT'};

my $not_logged_in = 1;

for ( $ENV{REQUEST_METHOD} ) {
  if (/GET/) {
    
    if ( $sso_setting && $ENV{REMOTE_USER} ) {
    	$vars->{sso_user} = $ENV{REMOTE_USER};
    }
    
  } elsif (/POST/) {
  	
  	my $sso_user = ( $query->param("hid_sso_user") ) ? $ENV{REMOTE_USER} : undef;
  	
    my $username = encodeInput( \$query->param("username") ); 
    my $passwd   = encodeInput( \$query->param("password") );

		my $loadSettings = 0;

		if ( $sso_user ) {
		
			if ( !$user->{dbh}->checkIfExists(
																					{
																							username => $sso_user,
																							disabled => 0 
																					},
																					"users",
																					"IGNORE_CASE"
																				) 
			 ) {
				$vars->{error} = "User $sso_user doesn't exist.";
			} else {
				$loadSettings = 1;
				$username = $sso_user;
			}

		} elsif ( !$user->login( username => $username, password => $passwd ) ) {
      $vars->{error} = "Incorrect username or password";
		} else {
			$loadSettings = 1;
		}
		
		if ( $loadSettings && !$role->getRolesFromUser( username => $username ) ) {
    
    	$vars->{error} = "No roles configured for this user.";
    
    } elsif ( $loadSettings ) {
      my $session = Taranis::Session->new();
      $session->{cgisession}->param( 'userid', $username );

      # get dropdown menu-items (will be put into $session->{menuitems})
      # the menu items are valid throughout the session, any change in
      # the users role(s) requires a logout/login to be available.
      $session->{cgisession}->param( 'menuitem', $session->getMenuItems( $username ) );

      if (
           $user->setUser(
                           username  => $username,
                           datestart => nowstring(9),
                           datestop  => nowstring(9)
           )
        )
      {
        $session->setUserAction(
                                 username    => $username,
                                 entitlement => 'login',
                                 action      => "logged in",
                                 comment     => "at " . nowstring(7) . ' OK'
        );
        $not_logged_in = 0;
        print $query->redirect( $goto_url );
      }
    }
  }
}

if ( $not_logged_in ) {
	
	if ( $sso_setting && $ENV{REMOTE_USER} ) {
		$vars->{sso_user} = $ENV{REMOTE_USER};
	}	

  $tt->processTemplate( "login.tt", $vars );
}
