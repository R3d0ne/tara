#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:util);
use Taranis::Error;
use Taranis::Template;
use Taranis::Publication;
use Taranis::Publication::Advisory;
use Taranis::Analysis;
use Taranis::Assess;
use Taranis::Users;
use Taranis::Config;
use Taranis::Damagedescription;
use Taranis::SoftwareHardware;
use Taranis::Config::XMLGeneric;
use HTML::Entities;
use MIME::Parser;
use XML::SAX::ParserFactory;
use XML::Simple;
use XML::Validator::Schema;
use Encode;
use strict;
use JSON;

use Data::Dumper;

my @EXPORT_OK = qw(
	openDialogNewAdvisory openDialogAdvisoryDetails openDialogUpdateAdvisory openDialogPreviewAdvisory 
	saveAdvisoryDetails saveNewAdvisory saveUpdateAdvisory openDialogAdvisoryNotificationDetails
	setReadyForReview setAdvisoryStatus getAdvisoryPreview openDialogImportAdvisory
);

sub advisory_export {
	return @EXPORT_OK; 
}

sub openDialogNewAdvisory {
	my ( %kvArgs ) = @_;
	my ( $vars, $idString, $analysis);
	
	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();	
	
	my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{advisory}->{email};
	
	if ( $session->rightOnParticularization( $typeName ) && $session->right('write') ) {
		my $an = Taranis::Analysis->new();
		my $dd = Taranis::Damagedescription->new();
		my $pu = Taranis::Publication->new();
		my $usr = Taranis::Users->new();
		
		my $settings = getAdvisorySettings();
		
		my $userId = $session->{cgisession}->param('userid'); 
		
		my $analysisId = ( exists( $kvArgs{analysisId} ) && $kvArgs{analysisId} =~ /^\d{8}$/) ? $kvArgs{analysisId} : undef;
	
		$vars->{analysis_id} = $analysisId;
		$vars->{pub_type} = 'email';
				
		########## TAB GENERAL #########
		if ( $analysisId ) { 
			$analysis = $an->getRecordsById( table => 'analysis', id => $analysisId )->[0];

			if ( $analysis->{idstring} ) {
				my @ids = split( ' ', $analysis->{idstring} );
				foreach ( @ids ) {

					if ( $_ =~ /^CVE.*/i) {
						$idString .= $_.', ';
					}
				}
				
				$idString =~ s/, $//;
			}
		}
		
		@{ $vars->{damage_description} } = $dd->getDamageDescription();
		$vars->{advisory_id} = $settings->{advisoryPrefix} . '-' . nowstring(6) . '-' . $settings->{x};
		$vars->{advisory_version} = '1.00';
		$vars->{author} = $usr->getUser( $userId )->{fullname};
		$vars->{date_created} = nowstring(9);
		$vars->{cve_id} = $idString;
			
		######### TAB PLATFORM(s) & PRODUCT(s) #########
		if ( $analysisId ) {
			my $allSh = $pu->extractSoftwareHardwareFromCve( $analysis->{idstring} );
		
			my ( @platforms, @products, @platformIds, @productIds);
			
			foreach my $item ( @$allSh ) {
				if ( $item->{cpe_id} =~ /^cpe:\/o/i ) {
					push @platforms, $item;
					push @platformIds, $item->{id};
				} else {
					push @products, $item;
					push @productIds, $item->{id};
				}
			}
			
			$vars->{platforms} = \@platforms;
		 	$vars->{software_hardware} = \@products; 
		
			my $pre_json_obj;
			if ( @platformIds ) {
				$pre_json_obj = { ids => \@platformIds, columns => ['producer', 'name', 'version' ] }; 
				( $vars->{platforms_text}, undef ) = getPreviewPart( to_json( $pre_json_obj ) );
			}
	
			if ( @productIds ) {
				$pre_json_obj = { ids => \@productIds, columns => ['producer', 'name' ] };
				( $vars->{products_text}, undef ) = getPreviewPart( to_json( $pre_json_obj ) );
	
				$pre_json_obj = { ids => \@productIds, columns => ['version'] };
				( $vars->{versions_text}, undef ) = getPreviewPart( to_json( $pre_json_obj ) );
			} 
		}	
		
		######### TAB UPDATE / SUMMARY / CONSEQUENCES / DESCRIPTION / SOLUTION / TLPAMBER #########
		my @templates;
		$tt->getTemplate( type => $settings->{usableTypeIds} );
		while ( $tt->nextObject() ) {
			my $tpl = $tt->getObject();
			if ( exists( $settings->{nonUsableTemplates}->{ lc $tpl->{title} } ) ) {
				next;
			} else {
				push @templates, $tpl;	
			}
		}
	
		$vars->{advisory_templates} = \@templates;
		
		######### TAB LINKS #########
		$vars->{links} = $pu->getItemLinks( analysis_id => $analysisId );
				
		######### TAB PREVIEW #########
				
		$vars->{isNewAdvisory} = 1;
		
		my $dialogContent = $tt->processTemplateNoHeader( 'write_advisory.tt', $vars, 1 );	
		return { dialog => $dialogContent };	
	} else {
		$vars->{message} = 'No permission...';
		my $dialogContent = $tt->processTemplateNoHeader( 'dialog_no_right.tt', $vars, 1 );	
		return { dialog => $dialogContent };	
	}	
}

sub openDialogAdvisoryDetails {
	my ( %kvArgs ) = @_;
	my ( $vars );
	
	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	
	my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{advisory}->{email};
	
	if ( $session->rightOnParticularization( $typeName ) && $session->right('write') ) {	
		my $pu = Taranis::Publication->new();
		my $usr = Taranis::Users->new();
		my $dd = Taranis::Damagedescription->new();
		my $sh = Taranis::SoftwareHardware->new();
		my $er = Taranis::Error->new();
		my $settings = getAdvisorySettings();
		my $publicationId = $kvArgs{id};
		
		my $advisory = $pu->getPublicationDetails( table => 'publication_advisory',	'publication_advisory.publication_id' => $publicationId );
		$vars->{advisory} = $advisory;
	
		$vars->{pub_type} = ( $advisory->{version} > 1.00 ) ? 'update' : 'email';
		$vars->{isUpdate} = ( $advisory->{version} > 1.00 ) ? 1 : 0;

		if ( $advisory->{based_on} ) {
			$er->loadCollection( reference_id => $publicationId );
			while ( $er->nextObject() ) {
				push @{ $vars->{importNotifications} }, $er->getObject();
			}
		}
		
		########## TAB GENERAL ######### 	
		my $govcertId = ( $advisory->{govcertid} ) ? $advisory->{govcertid} : $settings->{advisoryPrefix} . '-' . nowstring(6) . '-' . $settings->{x};
		my $advisoryVersion = ( $advisory->{version} =~ /\d\.\d9/ ) ? $advisory->{version} . '0' : $advisory->{version};
	
		$vars->{advisory_heading} = $govcertId .': '. $advisory->{title};
		$vars->{advisory_id} = $govcertId;
		$vars->{advisory_version} = $advisoryVersion;
		$vars->{author}	= $usr->getUser( $advisory->{created_by} )->{fullname};
	
		@{ $vars->{damage_description} } = $dd->getDamageDescription();
		my @damageIds	= $pu->getLinkedToPublicationIds( 
			table => 'advisory_damage',
			select_column => 'damage_id',
			advisory_id => $advisory->{id}
		);
				
		for ( my $i = 0; $i < @{ $vars->{damage_description} }; $i++ ) {
			for ( my $j = 0; $j < @damageIds; $j++ ) {
				if ( $vars->{damage_description}->[$i]->{id} eq $damageIds[$j] ) {
					$vars->{damage_description}->[$i]->{selected} = 1;
				}
			}
		}
		
		########## TAB PLATFORMS #########
		$pu->getLinkedToPublication(
			join_table_1 => { platform_in_publication  => 'softhard_id' },
			join_table_2 => { software_hardware => 'id' },
			'pu.id' => $advisory->{publication_id}
		);
		
		my @platforms;						 
		while ( $pu->nextObject() ) {
			push @platforms, $pu->getObject() ;
		}
			
		for ( my $i = 0; $i < @platforms; $i++ ) {
			$platforms[$i]->{in_use} = $sh->{dbh}->checkIfExists( { soft_hard_id => $platforms[$i]->{id} }, 'soft_hard_usage' );
			$platforms[$i]->{description} =	$sh->getShType( base => $platforms[$i]->{type} )->{description};
		}
		
		$vars->{platforms} = \@platforms;
		$vars->{platforms_text} = $advisory->{platforms_text};
	
		########## TAB PRODUCTS #########
		$pu->getLinkedToPublication(
			join_table_1 => { product_in_publication => 'softhard_id' },
			join_table_2 => { software_hardware => 'id'	},
			'pu.id' => $advisory->{publication_id}
		);
		
		my @products;						 
		while ( $pu->nextObject() ) {
			push @products, $pu->getObject() ;
		}
	
		for ( my $i = 0; $i < @products; $i++ ) {
			$products[$i]->{in_use} = $sh->{dbh}->checkIfExists( { soft_hard_id => $products[$i]->{id} }, 'soft_hard_usage' );
			$products[$i]->{description} =	$sh->getShType( base => $products[$i]->{type} )->{description};
		}														 
		$vars->{software_hardware} = \@products;
		$vars->{products_text} = $advisory->{products_text};
		$vars->{versions_text} = $advisory->{versions_text};
		
		########## TABS UPDATE / SUMMARY / CONSEQUENCES / DESCRIPTION / SOLUTION / TLPAMBER #########
		my @templates;
		$tt->getTemplate( type => $settings->{usableTypeIds} );
		while ( $tt->nextObject() ) {
			my $tpl = $tt->getObject();
			if ( exists( $settings->{nonUsableTemplates}->{ lc $tpl->{title} } ) ) {
				next;
			} else {
				push @templates, $tpl;	
			}
		}
			
		$vars->{advisory_templates} = \@templates;
		
		########## TAB LINKS #########
			
		$advisory->{hyperlinks} =~ s/\r//g;		
		$advisory->{hyperlinks} =~ s/\n+/\n/g;
	
		@{ $vars->{links} } = split( "\n", $advisory->{hyperlinks} ); 
			
		########## TAB PREVIEW #########
	
		$vars->{show_statuschange_buttons} = ( 
				!( 
					$advisory->{damage} == 3 
					&& $advisory->{probability} == 3 
					&& !$settings->{publishLL}
				)
				&& $advisory->{status} != 3
			)
			? 1 : 0;
		
		$vars->{publishLL} = $settings->{publishLL};
		
		### SET opened_by OR RETURN locked = 1 ###
		if ( my $opened_by = $pu->isOpenedBy( $advisory->{publication_id} ) ) {
			$vars->{isLocked} = 1;
			$vars->{openedByFullname} = $opened_by->{fullname};
		} elsif( $session->right('write') ) {
			if ( $pu->openPublication( $session->{cgisession}->param('userid'), $advisory->{publication_id} ) ) {
				$vars->{isLocked} = 0;
			} else {
				$vars->{isLocked} = 1;
			}
		} else {
			$vars->{isLocked} = 1;
		}
		$vars->{isNewAdvisory} = 0;

		my $dialogContent = $tt->processTemplateNoHeader( 'write_advisory.tt', $vars, 1 );	
		return { 
			dialog => $dialogContent,
			params => { 
				publicationid => $publicationId,
				isLocked => $vars->{isLocked},
				isUpdate => $vars->{isUpdate}
			}
		};	
	} else {
		$vars->{message} = 'No permission...';
		my $dialogContent = $tt->processTemplateNoHeader( 'dialog_no_right.tt', $vars, 1 );	
		return { dialog => $dialogContent };	
	}	
}

sub openDialogUpdateAdvisory {
	my ( %kvArgs ) = @_;
	my $vars;

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();	
	
	my $publicationId = $kvArgs{id};
	my $writeRight = $session->right('write');
	my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{advisory}->{email};
	
	if ( $session->rightOnParticularization( $typeName ) && $writeRight ) {
		my $an = Taranis::Analysis->new();
		my $dd = Taranis::Damagedescription->new();
		my $pu = Taranis::Publication->new();
		my $usr = Taranis::Users->new();
		my $sh = Taranis::SoftwareHardware->new();
		
		my $settings = getAdvisorySettings();
		
		my $userId = $session->{cgisession}->param('userid'); 

		my $advisory = $pu->getPublicationDetails( 
			table => "publication_advisory",
			"publication_advisory.publication_id" => $publicationId
		);

		$advisory->{update} = "";
		$advisory->{based_on} = "";
		$vars->{advisory} = $advisory;

		########## TAB GENERAL ######### 	
			
		my $advisoryVersion = ( $advisory->{version} =~ /\d\.\d9/ ) ? $advisory->{version} + 0.01 . "0" : $advisory->{version} + 0.01;

		$vars->{advisory_heading} = $advisory->{govcertid} .": ". $advisory->{title};
		$vars->{advisory_id} = $advisory->{govcertid};
		$vars->{advisory_version} = $advisoryVersion;
		$vars->{author} = $usr->getUser( $userId )->{fullname};
		$vars->{date_created} = nowstring(9);
		$vars->{analysis_id} = $kvArgs{analysisId};
		
		### IDS ###
		my %ids;

		foreach ( split( ",", $advisory->{ids} ) ) {
			$_ =~ s/\s*//;
			if ( $_ =~ /^CVE.*/i ) {
				$ids{$_} = { 'new' => 0 };	
			}
		}

#TODO: create a list of the 'new' CVE id's and prompt user for action		
		# get CVE id's from linked analysis
#		$pu->getLinkedToPublication(
#			join_table_1 => { analysis_publication => "analysis_id" },
#			join_table_2 => { analysis => "id" },
#			"pu.id" => $advisory->{publication_id}																
#		);
#
#		while ( $pu->nextObject() ) {
#			foreach ( split( " ", $pu->getObject()->{idstring} ) ) {
#				if ( $_ =~ /^CVE.*/i ) {
#					if ( exists( $ids{$_} ) ) {
#						$ids{$_} = { 'new' => 0 };					
#					} else {
#						$ids{$_} = { 'new' => 1 };
#					}
#				}
#			}
#		}
	
		# when an update is created from an analysis, get the idstring from that analysis.
#		if ( $kvArgs{analysisId} =~ /^\d+$/ ) {
#			foreach ( split( " ", $an->getRecordsById( table => "analysis", id => $kvArgs{analysisId} )->[0]->{idstring} ) ) {
#				if ( $_ =~ /^CVE.*/i ) {
#					if ( exists( $ids{$_} ) ) {
#						$ids{$_} = { 'new' => 0 };					
#					} else {
#						$ids{$_} = { 'new' => 1 };
#					}
#				}				
#			}
#		}

		$vars->{cve_id} = join(", ",  sort keys %ids );
		$vars->{cve_id} =~ s/, $//;

		# for tab platforms & products, create an array with the new CVE-IDS		
		my @newCveIds;
		foreach my $id ( keys %ids ) {
			if ( $ids{$id}->{'new'} && $id =~ /^CVE.*/i) {
				push @newCveIds, $id;
			}
		}

		### DAMAGE DESCRIPTION ###
		@{ $vars->{damage_description} } = $dd->getDamageDescription();
		my @damageIds	= $pu->getLinkedToPublicationIds( 
			table => "advisory_damage",
			select_column => "damage_id",
			advisory_id => $advisory->{id}
		);

		for ( my $i = 0; $i < @{ $vars->{damage_description} }; $i++ ) {
			for ( my $j = 0; $j < @damageIds; $j++ ) {
				if ( $vars->{damage_description}->[$i]->{id} eq $damageIds[$j] ) {
					$vars->{damage_description}->[$i]->{selected} = 1;
				}
			}
		}
			
		########## TABS PLATFORMS  & PRODUCTS #########
		my ( @platforms, @products, @platformIds, @productIds);
		my ( %uniquePlatforms, %uniqueProducts );

		$vars->{platforms_text} = $advisory->{platforms_text};
		$vars->{products_text} = $advisory->{products_text};
		$vars->{versions_text} = $advisory->{versions_text};

		# current platforms taken from previous version
		$pu->getLinkedToPublication(
			join_table_1 => { platform_in_publication  => "softhard_id" },
			join_table_2 => { software_hardware => "id" },
			"pu.id" => $advisory->{publication_id}
		);

		while ( $pu->nextObject() ) {
			my $platform = $pu->getObject();
			push @platforms, $platform;
			$uniquePlatforms{ $platform->{cpe_id} } = 1;
		}
	
		# current products taken from previous version
		$pu->getLinkedToPublication(
			join_table_1 => { product_in_publication => "softhard_id" },
			join_table_2 => { software_hardware => "id" },
			"pu.id" => $advisory->{publication_id}
		);

		while ( $pu->nextObject() ) {
			my $product = $pu->getObject();
			push @products, $product;
			$uniqueProducts{ $product->{cpe_id} } = 1;
		}

		# possible new platforms and products depending on new CVE-IDS
		if ( @newCveIds ) {
			my $allSh = $pu->extractSoftwareHardwareFromCve( "@newCveIds" );
			foreach my $item ( @$allSh ) {
				if ( $item->{cpe_id} =~ /^cpe:\/o/i ) {
					if ( !exists( $uniquePlatforms{ $item->{cpe_id} } ) ) {
						push @platforms, $item;
						push @platformIds, $item->{id};
					}
				} else {
					if ( !exists( $uniqueProducts{ $item->{cpe_id} } ) ) {
						push @products, $item;
						push @productIds, $item->{id};
					}
				}
			}
				
			# add the platforms and products to the preview text of the previous advisory version
			my $pre_json_obj;
			if ( @platformIds ) {
				$pre_json_obj = { ids => \@platformIds, columns => ['producer', 'name', 'version' ] }; 
				$vars->{platforms_text} .= "\n" . getPreviewPart( to_json( $pre_json_obj ) );
			}
				
			if ( @productIds ) {
				$pre_json_obj = { ids => \@productIds, columns => ['producer', 'name' ] };
				$vars->{products_text} .= "\n" . getPreviewPart( to_json( $pre_json_obj ) );

				$pre_json_obj = { ids => \@productIds, columns => ['version'] };
				$vars->{versions_text} .= "\n" . getPreviewPart( to_json( $pre_json_obj ) );
			} 
		}
	
		for ( my $i = 0; $i < @platforms; $i++ ) {
			$platforms[$i]->{description} =	$sh->getShType( base => $platforms[$i]->{type} )->{description};
		}
			
		$vars->{platforms} = \@platforms;
	
		for ( my $i = 0; $i < @products; $i++ ) {
			$products[$i]->{description} =	$sh->getShType( base => $products[$i]->{type} )->{description};
		}														 
		$vars->{software_hardware} = \@products;
	
		########## TABS UPDATE / SUMMARY / CONSEQUENCES / DESCRIPTION / SOLUTION / TLPAMBER #########
		my @templates;
		$tt->getTemplate( type => $settings->{usableTypeIds} );
		while ( $tt->nextObject() ) {
			my $tpl = $tt->getObject();
			if ( exists( $settings->{nonUsableTemplates}->{ lc $tpl->{title} } ) ) {
				next;
			} else {
				push @templates, $tpl;	
			}
		}
			
		$vars->{advisory_templates} = \@templates;
		
		########## TAB LINKS #########
			
		my @linksPreviousVersion = split( "\n", $advisory->{hyperlinks} );
		my @itemLinks = @{ $pu->getItemLinks( publication_id => $advisory->{publication_id} ) };
		my @itemLinksNewAnalysis; 
		if ( $kvArgs{analysisId} =~ /^\d+$/i ) {
			@itemLinksNewAnalysis = @{ $pu->getItemLinks( analysis_id => $kvArgs{analysisId} ) };
		}
		
		my %uniqueLinks;
		foreach ( @linksPreviousVersion ) {
			$uniqueLinks{$_}->{address} = $_;
			$uniqueLinks{$_}->{check} = 1; 
		}
			
		foreach ( @itemLinks ) {
			if ( !exists( $uniqueLinks{$_} ) ) {
				$uniqueLinks{$_}->{address} = $_;
				$uniqueLinks{$_}->{check} = 0;
			} 
		}
		
		foreach ( @itemLinksNewAnalysis ) {
			if ( !exists( $uniqueLinks{$_} ) ) {
				$uniqueLinks{$_}->{address} = $_;
				$uniqueLinks{$_}->{check} = 0;
			} 
		}
			
		$vars->{links} = \%uniqueLinks;
			
		$vars->{uncheck_new_links} = 1;
		$vars->{isNewAdvisory} = 1;
		$vars->{isUpdate} = 1;
		$vars->{update_notes} = $advisory->{notes};
		
		my $dialogContent = $tt->processTemplateNoHeader( 'write_advisory.tt', $vars, 1 );	
		return { 
			dialog => $dialogContent,
			params => {	publicationid => $advisory->{publication_id} }
		};	
	} else {
		$vars->{message} = 'No permission...';
		my $dialogContent = $tt->processTemplateNoHeader( 'dialog_no_right.tt', $vars, 1 );	
		return { dialog => $dialogContent };	
	}	
	
}

sub openDialogImportAdvisory {
	my ( %kvArgs ) = @_;
	my ( $vars );
	
	my $importOk = 0;
	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();	
	
	my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{advisory}->{email};
	
	if ( $session->rightOnParticularization( $typeName ) && $session->right('write') ) {
		if ( 
			exists( $kvArgs{analysisId} ) 
			&& $kvArgs{analysisId} =~ /^\d{8}$/ 
			&& exists( $kvArgs{emailItemId} ) 
			&& $kvArgs{emailItemId} =~ /^\d+$/ 
		) {
			my $as = Taranis::Assess->new();
			my $pu = Taranis::Publication->new();
			my $pa = Taranis::Publication::Advisory->new();
			my $sh = Taranis::SoftwareHardware->new();
			my $usr = Taranis::Users->new();
			my $dd = Taranis::Damagedescription->new();

			my $mimeParser = MIME::Parser->new();
			my $outputDir = Taranis::Config->getSetting("downloadpath" ) || "/tmp"; 
			$mimeParser->output_dir( $outputDir );
			
			my $settings = getAdvisorySettings();

			my $userId = $session->{cgisession}->param('userid');
			$vars->{warning} = '';
			$vars->{analysis_id} = $kvArgs{analysisId};
			
			my $emailItem = $as->getMailItem( $kvArgs{emailItemId} );
			my $decodedMessage = HTML::Entities::decode( $emailItem->{body} );
			my $messageEntity;
			eval{ $messageEntity = $mimeParser->parse_data( $decodedMessage ) } if ( $decodedMessage );
			
			if ( $@ ) {
				$vars->{message} = $@;
			} else {
			
				my $attachments = $as->getAttachmentInfo( $messageEntity, undef );
				foreach my $attachmentName ( keys %$attachments ) {
	
					# only check XML attachments
					if ( $attachments->{$attachmentName}->{filetype} =~ /^xml$/i ) {
						my $advisoryXSD = Taranis::Config->getSetting("advisory_xsd");
						my $validator = ( $advisoryXSD ) ? XML::Validator::Schema->new( file => $advisoryXSD ) : undef;
						my $xmlParser = ( $validator ) ? XML::SAX::ParserFactory->parser( Handler => $validator ) : undef;
	
						my $attachment = $as->getAttachment( $messageEntity, $attachmentName );
						my $attachmentEntity;
						eval{ $attachmentEntity = $mimeParser->parse_data( $attachment ) } if ( $attachment );
	
						my $attachmentDecoded = decodeMimeEntity( $attachmentEntity, 1, 0 );
						
						# the XML is verified by a XML schema, which can be found in the 'advisory_xsd' setting in Taranis conf
						eval{ $xmlParser->parse_string( $attachmentDecoded ) };
	
						if ( $@ ) {
							$vars->{message} = $@;
	
						} else {

							# convert XML to perl datastructure
							my $xmlAdvisory = XMLin( $attachmentDecoded, SuppressEmpty => '', KeyAttr => [] );
	
							########## TAB MATRIX #########
							$vars->{advisory} = $xmlAdvisory->{rating}->{publisher_analysis};
							$vars->{advisory}->{damage} = $pa->{scale}->{ $xmlAdvisory->{meta_info}->{damage} };
							$vars->{advisory}->{probability} = $pa->{scale}->{ $xmlAdvisory->{meta_info}->{probability} };
	
							########## TAB GENERAL #########
							my $advisoyIDDetails = $pa->getAdvisoryIDDetailsFromXMLAdvisory( $xmlAdvisory );
							my $basedOnAdvisoryVersion = '1.00';

							my @xmlVersionHistory = ( ref ( $xmlAdvisory->{meta_info}->{version_history}->{version_instance} ) =~ /^ARRAY$/  ) 
								? @{ $xmlAdvisory->{meta_info}->{version_history}->{version_instance} }
								: $xmlAdvisory->{meta_info}->{version_history}->{version_instance};

							foreach my $versionInstance ( @xmlVersionHistory ) {
								$basedOnAdvisoryVersion = $versionInstance->{version} if ( $versionInstance->{version} > $basedOnAdvisoryVersion );
							}

							my $title = $pa->getTitleFromXMLAdvisory( $xmlAdvisory ); 	
							$vars->{advisory_heading} = $advisoyIDDetails->{newAdvisoryDetailsId} .": ". $title;
							$vars->{advisory_id} = $advisoyIDDetails->{newAdvisoryDetailsId};
							$vars->{advisory_version} = $advisoyIDDetails->{newAdvisoryVersion};
							$vars->{publication_previous_version_id} = $advisoyIDDetails->{publicationPreviousVersionId};
							$vars->{author} = $usr->getUser( $userId )->{fullname};
							$vars->{date_created} = nowstring(9);
							$vars->{advisory}->{title} = $title;
							$vars->{analysis_id} = $kvArgs{analysisId};
							$vars->{advisory}->{based_on} = $xmlAdvisory->{meta_info}->{reference_number} . ' ' . $basedOnAdvisoryVersion;

							### IDS ###
							my $idString = '';
							foreach my $typeId ( %{ $xmlAdvisory->{meta_info}->{vulnerability_identifiers} } ) {
								if ( ref ( $xmlAdvisory->{meta_info}->{vulnerability_identifiers}->{$typeId}->{id} ) =~ /^ARRAY$/ ) {
									foreach my $id ( @{ $xmlAdvisory->{meta_info}->{vulnerability_identifiers}->{$typeId}->{id} } ) {
										if ( $id ) {
											$idString .= "$id, ";
										}
									}
								} elsif ( $xmlAdvisory->{meta_info}->{vulnerability_identifiers}->{$typeId}->{id} ) {
									$idString .= "$xmlAdvisory->{meta_info}->{vulnerability_identifiers}->{$typeId}->{id}, ";
								}
							}
							$idString =~ s/, $//;
							$vars->{cve_id} = $idString;

							### DAMAGE DESCRIPTION ###
							@{ $vars->{damage_description} } = $dd->getDamageDescription();
							my $damageDescriptionDetails = $pa->getDamageDescriptionsFromXMLAdvisory( $xmlAdvisory );

							for ( my $i = 0; $i < @{ $vars->{damage_description} }; $i++ ) {
								for ( my $j = 0; $j < @{ $damageDescriptionDetails->{damageDescriptionIds} }; $j++ ) {
									if ( $vars->{damage_description}->[$i]->{id} eq $damageDescriptionDetails->{damageDescriptionIds}->[$j] ) {
										$vars->{damage_description}->[$i]->{selected} = 1;
									}
								}
							}

							foreach my $xmlDamageDescription ( @{ $damageDescriptionDetails->{newDamageDescriptions} } ) {
								$vars->{warning} .= encode( 'UTF-8', "Warning: damage description '$xmlDamageDescription' could not be found!<br>");
							}

							########## TABS PLATFORMS  & PRODUCTS #########
							$vars->{platforms_text} = encodeInput( \encode( 'UTF-8', $xmlAdvisory->{meta_info}->{system_information}->{systemdetail}->{affected_platforms_text} ) );
							$vars->{products_text} = encodeInput( \encode( 'UTF-8', $xmlAdvisory->{meta_info}->{system_information}->{systemdetail}->{affected_products_text} ) );
							$vars->{versions_text} = encodeInput( \encode( 'UTF-8', $xmlAdvisory->{meta_info}->{system_information}->{systemdetail}->{affected_products_versions_text} ) );

							my $softwareHardwareDetails = $pa->getSoftwareHardwareFromXMLAdvisory( $xmlAdvisory );
							for ( my $i = 0; $i < @{ $softwareHardwareDetails->{platforms} }; $i++ ) {
								$softwareHardwareDetails->{platforms}->[$i]->{description} = $sh->getShType( base => $softwareHardwareDetails->{platforms}->[$i]->{type} )->{description};
							}

							$vars->{platforms} = $softwareHardwareDetails->{platforms};

							for ( my $i = 0; $i < @{ $softwareHardwareDetails->{products} }; $i++ ) {
								$softwareHardwareDetails->{products}->[$i]->{description} =	$sh->getShType( base => $softwareHardwareDetails->{products}->[$i]->{type} )->{description};
							}
							$vars->{software_hardware} = $softwareHardwareDetails->{products};

							# log software/hardware which could not be linked to advisory
							foreach my $shProblem ( @{ $softwareHardwareDetails->{importProblems} } ) {
								$vars->{warning} .= "Warning: $shProblem <br>"; 
							}

							########## TABS UPDATE / SUMMARY / CONSEQUENCES / DESCRIPTION / SOLUTION / TLPAMBER #########
							my @templates;
							$tt->getTemplate( type => $settings->{usableTypeIds} );
							while ( $tt->nextObject() ) {
								my $tpl = $tt->getObject();
								if ( exists( $settings->{nonUsableTemplates}->{ lc $tpl->{title} } ) ) {
									next;
								} else {
									push @templates, $tpl;	
								}
							}

							$vars->{advisory_templates} = \@templates;
							$vars->{advisory}->{summary} = encodeInput( \encode( 'UTF-8', $xmlAdvisory->{content}->{abstract} ) ); 
							$vars->{advisory}->{consequences} = encodeInput( \encode( 'UTF-8', $xmlAdvisory->{content}->{consequences} ) );
							$vars->{advisory}->{description} = encodeInput( \encode( 'UTF-8', $xmlAdvisory->{content}->{description} ) );
							$vars->{advisory}->{solution} = encodeInput( \encode( 'UTF-8', $xmlAdvisory->{content}->{solution} ) );
							$vars->{advisory}->{update} = encodeInput( \encode( 'UTF-8', $xmlAdvisory->{content}->{update_information} ) );

							########## TAB LINKS #########
							my @linksFromXMLAdvisory = split( "\n", $pa->getLinksFromXMLAdvisory( $xmlAdvisory ) );
							$vars->{links} = \@linksFromXMLAdvisory;
							$vars->{uncheck_new_links} = 0;
	
							$vars->{isNewAdvisory} = 1;
							$vars->{isUpdate} = ( $advisoyIDDetails->{newAdvisoryVersion} > 1 ) ? 1 : 0;
						}
					}
				}
			}
		}

		my $dialogContent = $tt->processTemplateNoHeader( 'write_advisory.tt', $vars, 1 );	
		return { 
			dialog => $dialogContent,
			params => {}
		};
	} else {
		$vars->{message} = 'No permission...';
		my $dialogContent = $tt->processTemplateNoHeader( 'dialog_no_right.tt', $vars, 1 );	
		return { dialog => $dialogContent };	
	}
	
}

sub openDialogPreviewAdvisory {
	my ( %kvArgs ) = @_;
	my $vars;
	
	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();	
	
	my $publicationId = $kvArgs{id};
	my $writeRight = $session->right('write');
	my $executeRight = $session->right('execute');

	my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{advisory}->{email};
	
	if ( $session->rightOnParticularization( $typeName ) && $writeRight ) {
		my $pu = Taranis::Publication->new();
		my $us = Taranis::Users->new();
		my $tg = Taranis::Tagging->new();
		my $userId = $session->{cgisession}->param("userid");
		my $settings = getAdvisorySettings();
		
		my $advisory = $pu->getPublicationDetails( 
			table => "publication_advisory",
			"publication_advisory.publication_id" => $publicationId
		);

		$vars->{is_updated} = ( $advisory->{replacedby_id} ) ? 1 : 0; 
		
		$vars->{pub_type} = ( $advisory->{version} > 1.00 ) ? "update" : "email";
		
		$vars->{created_by_name} = ( $advisory->{created_by} ) ? $us->getUser( $advisory->{created_by}, 1 )->{fullname} : undef;
		$vars->{approved_by_name} = ( $advisory->{approved_by} ) ? $us->getUser( $advisory->{approved_by}, 1 )->{fullname} : undef;
		$vars->{published_by_name} = ( $advisory->{published_by} ) ? $us->getUser( $advisory->{published_by}, 1 )->{fullname} : undef; 
		my $userIsAuthor = ( $advisory->{created_by} eq $session->{cgisession}->param("userid") ) ? 1 : 0;

		$vars->{advisory} = $advisory;
		
		my $tags = $tg->getTagsByItem( $advisory->{id}, "publication_advisory" );
		$vars->{tags}	= "@$tags";

		### SET opened_by OR RETURN locked = 1 ###
		if ( my $opened_by = $pu->isOpenedBy( $advisory->{publication_id} ) ) {
			$vars->{isLocked} = 1;
			$vars->{openedByFullname} = $opened_by->{fullname};
		} elsif( $writeRight || $executeRight ) {
			if ( $pu->openPublication( $userId, $advisory->{publication_id} ) ) {
				$vars->{isLocked} = 0;
			} else {
				$vars->{message} = $pu->{errmsg};
				$vars->{isLocked} = 1;
			}
		} else {
			$vars->{isLocked} = 1;
		}
		
		my $noStatusChangeButtons = 0;
		if ( $advisory->{damage} == 3 && $advisory->{probability} == 3 && !$settings->{publishLL} ) {
			$noStatusChangeButtons = 1;
		}
		
		my $dialogContent = $tt->processTemplateNoHeader( 'write_advisory_preview.tt', $vars, 1 );	
		return { 
			dialog => $dialogContent,
			params => { 
				publicationid => $publicationId,
				isLocked => $vars->{isLocked},
				executeRight => $executeRight,
				userIsAuthor => $userIsAuthor,
				currentStatus => $advisory->{status},
				noStatusChangeButtons => $noStatusChangeButtons
			}
		};	
	} else {
		$vars->{message} = 'No permission...';
		my $dialogContent = $tt->processTemplateNoHeader( 'dialog_no_right.tt', $vars, 1 );	
		return { dialog => $dialogContent };	
	}
}

sub openDialogAdvisoryNotificationDetails {
	my ( %kvArgs ) = @_;
	my ( $vars );
	
	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $er = Taranis::Error->new();
	
	my $notification = $er->getError( $kvArgs{id} );
	
	my $notificationText = fileToString( $notification->{logfile} );
	$vars->{notificationText} = decodeInput( \$notificationText ) || "No logfile available.";
	
	my $dialogContent = $tt->processTemplateNoHeader( 'write_advisory_notification_details.tt', $vars, 1 );	
	return { 
		dialog => $dialogContent
	};	
}

sub saveNewAdvisory {
	my ( %kvArgs ) = @_;

	my ( $message, $publicationId, $advisoryId );
	my $session = $kvArgs{session};
	my $saveOk = 0;

	my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{advisory}->{email};
	
	if ( $session->rightOnParticularization( $typeName ) && $session->right('write') ) {
		
		my $pu = Taranis::Publication->new();
		my $tt = Taranis::Template->new();
		my $settings = getAdvisorySettings();
		
		my $advisoryLinks = ( ref( $kvArgs{advisory_links} ) =~ /^ARRAY$/ ) 
			? join( "\n", @{ $kvArgs{advisory_links} } )
			: $kvArgs{advisory_links};

		$advisoryLinks .= "\n" if ( $advisoryLinks && $kvArgs{additional_links} );
		$advisoryLinks .= $kvArgs{additional_links}; 
		$advisoryLinks =~ s/\r//g;
		$advisoryLinks =~ s/\n+/\n/g;
		
		my $typeId = $pu->getPublicationTypeId( $typeName )->{id};
		my $userId = $session->{cgisession}->param('userid');
		 
		my $analysisId = ( exists( $kvArgs{analysisId} ) && $kvArgs{analysisId} ) 
			? $kvArgs{analysisId}
			: undef;
	
		my $basedOn = ( exists( $kvArgs{based_on} ) ) ? $kvArgs{based_on} : undef;
		my $advisoryIdentifier = ( $kvArgs{advisory_id} ) ? $kvArgs{advisory_id} : $settings->{advisoryPrefix} . '-' . nowstring(6) . '-' . $settings->{x};
		my $advisoryVersion = ( exists( $kvArgs{advisory_version} ) ) ? $kvArgs{advisory_version} : '1.00'; 
		
		$pu->{dbh}->startTransaction();
		if (
			!$pu->addPublication(
				title => substr( $kvArgs{title}, 0, 50 ),
				created_by => $userId,
				type => $typeId,
				status => '0'
			)
			|| !( $publicationId = $pu->{dbh}->getLastInsertedId('publication') )
			|| (
				$analysisId
				&& !$pu->linkToPublication(
						table => 'analysis_publication',
						analysis_id => $analysisId,
						publication_id => $publicationId
				)
			)
			|| !$pu->linkToPublication( 
					table => 'publication_advisory',
					publication_id => $publicationId,
					version => $advisoryVersion,
					govcertid => $advisoryIdentifier,
					based_on => $basedOn,				 													 	 
					title => $kvArgs{title},
					probability => $kvArgs{probability},
					damage => $kvArgs{damage},
					ids => $kvArgs{cve_id},
					platforms_text => $kvArgs{platforms_txt},
					versions_text => $kvArgs{versions_txt},
					products_text => $kvArgs{products_txt},
					hyperlinks => $advisoryLinks,
					description => $kvArgs{tab_description_txt},
					consequences => $kvArgs{tab_consequences_txt},
					solution => $kvArgs{tab_solution_txt},
					tlpamber => $kvArgs{tab_tlpamber_txt},
					summary => $kvArgs{tab_summary_txt},
					ques_dmg_infoleak => $kvArgs{dmg_infoleak},
					ques_dmg_privesc => $kvArgs{dmg_privesc},
					ques_dmg_remrights => $kvArgs{dmg_remrights},
					ques_dmg_codeexec => $kvArgs{dmg_codeexec},
					ques_dmg_dos => $kvArgs{dmg_dos},
					ques_dmg_deviation => $kvArgs{dmg_deviation},
					ques_pro_solution => $kvArgs{pro_solution},
					ques_pro_expect => $kvArgs{pro_expect},
					ques_pro_exploited => $kvArgs{pro_exploited},
					ques_pro_userint => $kvArgs{pro_userint},
					ques_pro_complexity => $kvArgs{pro_complexity},
					ques_pro_credent => $kvArgs{pro_credent},
					ques_pro_access => $kvArgs{pro_access},
					ques_pro_details => $kvArgs{pro_details},
					ques_pro_exploit => $kvArgs{pro_exploit},
					ques_pro_standard => $kvArgs{pro_standard},
					ques_pro_deviation => $kvArgs{pro_deviation} 
				)
		) {
			$message = $pu->{errmsg};
		} else {
			$advisoryId = $pu->{dbh}->getLastInsertedId('publication_advisory');
	
			#### link products, platforms and damage descriptions to publication ####
			if ( $kvArgs{pd_left_column} ) {
				my @products = ( ref( $kvArgs{pd_left_column} ) =~ /^ARRAY$/ )
					? @{ $kvArgs{pd_left_column} }
					: $kvArgs{pd_left_column};
						
				foreach my $sh ( @products ) {
					if (
						!$pu->linkToPublication(
							table => 'product_in_publication',
							softhard_id => $sh,
							publication_id => $publicationId
						)
					) {
						$message = $pu->{errmsg};
					}
				}
			}
	
			if ( $kvArgs{pf_left_column} ) {
				my @platforms = ( ref( $kvArgs{pf_left_column} ) =~ /^ARRAY$/ )
					? @{ $kvArgs{pf_left_column} }
					: $kvArgs{pf_left_column};
	
				foreach my $pf ( @platforms ) {
					if (
						!$pu->linkToPublication(
							table => 'platform_in_publication',
							softhard_id => $pf,
							publication_id => $publicationId
						)
					) {
						$message = $pu->{errmsg};
					}
				}
			}
	
			if ( $kvArgs{damage_description} ) {
				my @damageDescriptions = ( ref( $kvArgs{damage_description} ) =~ /^ARRAY$/ )
					? @{ $kvArgs{damage_description} }
					: $kvArgs{damage_description};
				
				foreach my $dd ( @damageDescriptions ) {
					if (
						!$pu->linkToPublication(
							table => 'advisory_damage',
							damage_id => $dd,
							advisory_id => $advisoryId
						)
					) {
						$message = $pu->{errmsg};
					}				
				}
			}
		}

		# update replacedby_id of previous version advisory with new publication id
		if ( exists( $kvArgs{publication_previous_version_id} ) && $kvArgs{publication_previous_version_id} ) {
			if ( $kvArgs{publication_previous_version_id} && !$pu->setPublication( id => $kvArgs{publication_previous_version_id}, replacedby_id => $publicationId ) ) {
				$message = $pu->{errmsg};
			}
		}

		$pu->{dbh}->endTransaction();

		if ( !$message ) {
			my $advisoryType = ( $advisoryVersion > 1 ) ? 'update' : 'email';
			my $previewText = $tt->processPreviewTemplate( 'advisory', $advisoryType, $advisoryId, $publicationId, 0, 71 );
			my $xmlText = $pu->processPreviewXml( $advisoryId );
	
			if ( !$pu->setPublication( id => $publicationId, contents => $previewText, xml_contents => $xmlText ) ) {
				$message = $pu->{errmsg};
			}			
		}
			
		$saveOk = 1 if ( !$message );
	
	} else {
		$message = 'No persmission';
	}

	return {
		params => { 
			message => $message,
			saveOk => $saveOk,
			publicationId => $publicationId
		}
	};
}

sub saveAdvisoryDetails {
	my ( %kvArgs ) = @_;

	my ( $message );
	my $saveOk = 0;
	my $session = $kvArgs{session};
	my $publicationId = $kvArgs{pub_id};

	my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{advisory}->{email};

	if ( $session->rightOnParticularization( $typeName ) && $session->right('write') ) {
	
		my $pu = Taranis::Publication->new();
		my $tt = Taranis::Template->new();
	
		my $advisoryId = $kvArgs{adv_id};
	
		my $advisoryLinks = ( ref( $kvArgs{advisory_links} ) =~ /^ARRAY$/ ) 
			? join( "\n", @{ $kvArgs{advisory_links} } )
			: $kvArgs{advisory_links};
		
		$advisoryLinks .= "\n" if ( $advisoryLinks && $kvArgs{additional_links} );
		$advisoryLinks .= $kvArgs{additional_links};
		$advisoryLinks =~ s/\r//g;
		$advisoryLinks =~ s/\n+/\n/g;	
	    
		my @productIds = $pu->getLinkedToPublicationIds( 
			table => 'product_in_publication',
			select_column => 'softhard_id',
			publication_id => $publicationId
		);
	
		my @products;
		if ( $kvArgs{pd_left_column} ) {
			@products = ( ref( $kvArgs{pd_left_column} ) =~ /^ARRAY$/ )
				? @{ $kvArgs{pd_left_column} }
				: $kvArgs{pd_left_column};
		} 
	
		my ( $newProducts, $deleteProducts ) = addAndDelete( \@productIds, \@products );
	
		my @platformIds = $pu->getLinkedToPublicationIds( 
			table => 'platform_in_publication',
			select_column => 'softhard_id',
			publication_id => $publicationId
		);
	
		my @platforms;
		if ( $kvArgs{pf_left_column} ) { 
			@platforms = ( ref( $kvArgs{pf_left_column} ) =~ /^ARRAY$/ )
				? @{ $kvArgs{pf_left_column} }
				: $kvArgs{pf_left_column};
		}
		
		my ( $newPlatforms, $deletePlatforms ) = addAndDelete( \@platformIds, \@platforms );
		
		my @damageDescriptionIds = $pu->getLinkedToPublicationIds( 
			table => 'advisory_damage',
			select_column => 'damage_id',
			advisory_id => $advisoryId
		);
	
		my @damageDescriptions;
		if ( $kvArgs{damage_description} ) {
			@damageDescriptions = ( ref( $kvArgs{damage_description} ) =~ /^ARRAY$/ )
				? @{ $kvArgs{damage_description} }
				: $kvArgs{damage_description};
		}
	
		my ( $newDamageDescriptions, $deleteDamageDescriptions ) = addAndDelete( \@damageDescriptionIds, \@damageDescriptions );
		
		$pu->{dbh}->startTransaction();
		
		if ( 
			!$pu->setPublicationDetails(
				table => 'publication_advisory',
				where => { id => $advisoryId },
				title => $kvArgs{title},
				probability => $kvArgs{probability},
				damage => $kvArgs{damage},
				ids => $kvArgs{cve_id},
				hyperlinks => $advisoryLinks,
				platforms_text => $kvArgs{platforms_txt},
				versions_text => $kvArgs{versions_txt},
				products_text => $kvArgs{products_txt},
				description => $kvArgs{tab_description_txt},
				consequences => $kvArgs{tab_consequences_txt},
				solution => $kvArgs{tab_solution_txt},
				tlpamber => $kvArgs{tab_tlpamber_txt},
				summary => $kvArgs{tab_summary_txt},
				update => $kvArgs{tab_update_txt},
				ques_dmg_infoleak => $kvArgs{dmg_infoleak},
				ques_dmg_privesc => $kvArgs{dmg_privesc},
				ques_dmg_remrights => $kvArgs{dmg_remrights},
				ques_dmg_codeexec => $kvArgs{dmg_codeexec},
				ques_dmg_dos => $kvArgs{dmg_dos},
				ques_dmg_deviation => $kvArgs{dmg_deviation},
				ques_pro_solution => $kvArgs{pro_solution},
				ques_pro_expect => $kvArgs{pro_expect},
				ques_pro_exploited => $kvArgs{pro_exploited},
				ques_pro_userint => $kvArgs{pro_userint},
				ques_pro_complexity => $kvArgs{pro_complexity},
				ques_pro_credent => $kvArgs{pro_credent},
				ques_pro_access => $kvArgs{pro_access},
				ques_pro_details => $kvArgs{pro_details},
				ques_pro_exploit => $kvArgs{pro_exploit},
				ques_pro_standard => $kvArgs{pro_standard},
				ques_pro_deviation => $kvArgs{pro_deviation} 														
			) 
		) {
			$message = $pu->{errmsg};
		} else {
	
			#### link new products, platforms and damage descriptions to publication #### 		
			foreach my $product_id ( @$newProducts ) {
				if (
					!$pu->linkToPublication(
						table => 'product_in_publication',
						softhard_id => $product_id,
						publication_id => $publicationId
					)
				) {
					$message = $pu->{errmsg};
				}
			}
	
			foreach my $platform_id ( @$newPlatforms ) {
				if (
					!$pu->linkToPublication(
						table => 'platform_in_publication',
						softhard_id => $platform_id,
						publication_id => $publicationId
					)
				) {
					$message = $pu->{errmsg};
				}			
			}
		
			foreach my $damage_id ( @$newDamageDescriptions ) {
				if (
					!$pu->linkToPublication(
						table => 'advisory_damage',
						damage_id => $damage_id,
						advisory_id => $advisoryId
					)
				) {
					$message = $pu->{errmsg};
				}
			}
	
			#### unlink products, platforms and damage descriptions from publication #### 				
			foreach my $productId ( @$deleteProducts ) {
				if (
					!$pu->unlinkFromPublication(
						table => 'product_in_publication',
						softhard_id => $productId,
						publication_id => $publicationId
					)
				) {
					$message = $pu->{errmsg};
				}					
			}
	
			foreach my $platformId ( @$deletePlatforms ) {
				if (
					!$pu->unlinkFromPublication(
						table => 'platform_in_publication',
						softhard_id => $platformId,
						publication_id => $publicationId
					)
				) {
					$message = $pu->{errmsg};
				}					
			}
	
			foreach my $damageId ( @$deleteDamageDescriptions ) {
				if (
					!$pu->unlinkFromPublication(
						table => 'advisory_damage',
						damage_id => $damageId,
						advisory_id => $advisoryId
					)
				) {
					$message = $pu->{errmsg};
				}
			}
		}
		$saveOk = 1 if ( !$message );
		
		$pu->{dbh}->endTransaction();
			
		my $advisoryVersion = $pu->getPublicationDetails( 
				table => 'publication_advisory',
				'publication_advisory.id' => $advisoryId 
			)->{version};		
			
		my $publicationType = ( $advisoryVersion > 1.00 ) ? 'update' : 'email';
			
		my $previewText = $tt->processPreviewTemplate( 'advisory', $publicationType, $advisoryId, $publicationId, 0, 71 );
		my $xmlText = $pu->processPreviewXml( $advisoryId );
	
		if ( !$pu->setPublication( id => $publicationId, contents => $previewText, xml_contents => $xmlText ) ) {
			$message = 'Updating the advisory preview and XML test has failed. ' . $pu->{errmsg};
		}			
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			message => $message,
			saveOk => $saveOk,
			publicationId => $publicationId
		}
	};	
} 

sub saveUpdateAdvisory {
	my ( %kvArgs ) = @_;

	my ( $message, $newPublicationId );
	my $saveOk = 0;
	my $session = $kvArgs{session};
	my $publicationId = $kvArgs{pub_id};
	my $advisoryId = $kvArgs{adv_id};

	my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{advisory}->{email};
	
	if ( $session->rightOnParticularization( $typeName ) && $session->right('write') ) {
	
		my $pu = Taranis::Publication->new();
		my $tt = Taranis::Template->new();
		my $tg = Taranis::Tagging->new();
		
		my $userId = $session->{cgisession}->param('userid'); 
		
		my $advisory = $pu->getPublicationDetails( 
			table => "publication_advisory",
			"publication_advisory.id" => $advisoryId
		);
		
		my $advisoryLinks = ( ref( $kvArgs{advisory_links} ) =~ /^ARRAY$/ ) 
			? join( "\n", @{ $kvArgs{advisory_links} } )
			: $kvArgs{advisory_links};

		$advisoryLinks .= "\n" if ( $advisoryLinks && $kvArgs{additional_links} );
		$advisoryLinks .= $kvArgs{additional_links};
		$advisoryLinks =~ s/\r//g;
		$advisoryLinks =~ s/\n+/\n/g;	
			
		my $advisoryVersion = ( $advisory->{version} =~ /\d\.\d9/ ) ? $advisory->{version} + 0.01 . "0" : $advisory->{version} + 0.01;
			
		my @analysisIds = $pu->getLinkedToPublicationIds( 
			table => "analysis_publication",
			select_column => "analysis_id",
			publication_id => $publicationId
		);

		my %tags;

		$tg->loadCollection( "ti.item_id" => $advisoryId, "ti.item_table_name" => "publication_advisory" );
			
		while ( $tg->nextObject() ) {
			my $tag = $tg->getObject();
			$tags{ $tag->{id} } = 1;
		}
	
		$pu->{dbh}->startTransaction();
		
		if (
			!$pu->addPublication(
				title => substr( $kvArgs{title}, 0, 50 ),
				created_by => $userId,
				type => $advisory->{type},
				status => "0"
			)
			|| !( $newPublicationId = $pu->{dbh}->getLastInsertedId("publication") )
			|| !$pu->linkToPublication(
					table => "publication_advisory",
					publication_id => $newPublicationId,
					govcertid => $advisory->{govcertid},
					version => $advisoryVersion,
					title => $kvArgs{title},
					probability => $kvArgs{probability},
					damage => $kvArgs{damage},
					ids => $kvArgs{cve_id},
					platforms_text => $kvArgs{platforms_txt},
					versions_text => $kvArgs{versions_txt},
					products_text => $kvArgs{products_txt},
					hyperlinks => $advisoryLinks,
					description => $kvArgs{tab_description_txt},
					consequences => $kvArgs{tab_consequences_txt},
					solution => $kvArgs{tab_solution_txt},
					tlpamber => $kvArgs{tab_tlpamber_txt},
					summary => $kvArgs{tab_summary_txt},
					update => $kvArgs{tab_update_txt},
					ques_dmg_infoleak => $kvArgs{dmg_infoleak},
					ques_dmg_privesc => $kvArgs{dmg_privesc},
					ques_dmg_remrights => $kvArgs{dmg_remrights},
					ques_dmg_codeexec => $kvArgs{dmg_codeexec},
					ques_dmg_dos => $kvArgs{dmg_dos},
					ques_dmg_deviation => $kvArgs{dmg_deviation},
					ques_pro_solution => $kvArgs{pro_solution},
					ques_pro_expect => $kvArgs{pro_expect},
					ques_pro_exploited => $kvArgs{pro_exploited},
					ques_pro_userint => $kvArgs{pro_userint},
					ques_pro_complexity => $kvArgs{pro_complexity},
					ques_pro_credent => $kvArgs{pro_credent},
					ques_pro_access => $kvArgs{pro_access},
					ques_pro_details => $kvArgs{pro_details},
					ques_pro_exploit => $kvArgs{pro_exploit},
					ques_pro_standard => $kvArgs{pro_standard},
					ques_pro_deviation => $kvArgs{pro_deviation} 
				)
		) {
			$message = $pu->{errmsg};
		} else {

			my $newAdvisoryId = $pu->{dbh}->getLastInsertedId("publication_advisory");
	
			if ( $kvArgs{pd_left_column} && !$message ) {
				my @products = ( ref( $kvArgs{pd_left_column} ) =~ /^ARRAY$/ )
					? @{ $kvArgs{pd_left_column} }
					: $kvArgs{pd_left_column};

				foreach my $sh ( @products ) {
					if (
						!$pu->linkToPublication(
							table => "product_in_publication",
							softhard_id => $sh,
							publication_id => $newPublicationId
						)
					) {
							$message = $pu->{errmsg};
					}
				}
			} 

			if ( $kvArgs{pf_left_column} && !$message ) { 
				my @platforms = ( ref( $kvArgs{pf_left_column} ) =~ /^ARRAY$/ )
					? @{ $kvArgs{pf_left_column} }
					: $kvArgs{pf_left_column};

				foreach my $pf ( @platforms ) {
					if (
						!$pu->linkToPublication(
							table => "platform_in_publication",
							softhard_id => $pf,
							publication_id => $newPublicationId
						)
					) {
						$message = $pu->{errmsg};
					}
				}
			}

			if ( $kvArgs{damage_description} && !$message ) {
				my @damageDescriptions = ( ref( $kvArgs{damage_description} ) =~ /^ARRAY$/ )
					? @{ $kvArgs{damage_description} }
					: $kvArgs{damage_description};
					
				foreach my $dd ( @damageDescriptions ) {
					if (
						!$pu->linkToPublication(
							table => "advisory_damage",
							damage_id => $dd,
							advisory_id => $newAdvisoryId
						)
					) {
						$message = $pu->{errmsg};
					}				
				}
			}

			if ( $kvArgs{analysisId} =~ /^\d+$/ && !$message ) {
				if ( 
					!$pu->linkToPublication(
						table => "analysis_publication",
						analysis_id => $kvArgs{analysisId},
						publication_id => $newPublicationId
				 	) 
				) {
					$message = $pu->{errmsg};				 	
				}				
			}

			if ( @analysisIds && !$message ) {
				foreach ( @analysisIds ) {
					if ( $_ != $kvArgs{analysisId} ) {
						if ( 
							!$pu->linkToPublication(
								table => "analysis_publication",
								analysis_id => $_,
								publication_id => $newPublicationId
							) 
						) {
							$message = $pu->{errmsg};				 	
						}
					}				
				}
			}
	
			my $previewText = $tt->processPreviewTemplate( "advisory", "update", $newAdvisoryId, $newPublicationId, 0, 71 );
				
			if ( !$message && !$pu->setPublication( id => $newPublicationId, contents => $previewText ) ) {
				$message = $pu->{errmsg};
			}
							
			if ( !$message && !$pu->setPublication( id => $publicationId, replacedby_id => $newPublicationId ) ) {
				$message = $pu->{errmsg};
			}
		
			my @addTags = keys %tags;
			foreach my $tag_id ( @addTags ) {
				if ( !$tg->setItemTag( $tag_id, "publication_advisory", $newAdvisoryId ) ) {
					$message .= $tg->{errmsg};
				}
			}		
				
			$tg->removeItemTag( $advisoryId, "publication_advisory" );
		
			
			$saveOk = 1 if ( !$message );
		}
			
		$pu->{dbh}->endTransaction();
	} else {
		$message = 'No permission';
	}
	
	return {
		params => {
			message => $message,
			saveOk => $saveOk,
			publicationId => $newPublicationId,
			detailsId => $advisoryId 
		}
	};	
}

sub setAdvisoryStatus {
	my ( %kvArgs ) = @_;

	my ( $message );
	my $saveOk = 0;
	my $pu = Taranis::Publication->new();
	my $session = $kvArgs{session};
	my $settings = getAdvisorySettings();
	my $publicationId = $kvArgs{publicationId};
	my $newStatus = $kvArgs{status};
	my $userId = $session->{cgisession}->param('userid'); 
	
	my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{advisory}->{email};
	
	if ( 
		( $session->rightOnParticularization( $typeName ) && $session->right('write') )
		|| $newStatus =~ /^(0|1|2)$/ 
	) {

		my $advisory = $pu->getPublicationDetails( 
			table => 'publication_advisory',
			'publication_advisory.publication_id' => $publicationId 
		);

		my $currentStatus = $advisory->{status};
		if ((
				 ( $currentStatus eq '0' && $newStatus eq '1' ) || 
				 ( $currentStatus eq '1' && $newStatus eq '0' ) ||
				 ( $currentStatus eq '2' && $newStatus eq '0' ) ||
				 ( $currentStatus eq '1' && $newStatus eq '2' && $advisory->{created_by} ne $userId && $session->right('execute') )
			 ) 
			 && ( !( $advisory->{damage} == 3 && $advisory->{probability} == 3 && !$settings->{publishLL} ))
		) {

			if ( $newStatus eq '2' ) {
				if ( !$pu->setPublication( 
						id => $publicationId, 
						status => $newStatus,
						approved_on => nowstring(10),
						approved_by => $userId 
					) 
				) {
				
				$message = $pu->{errmsg};
				
				} else {
					$saveOk = 1;
				}			
			} else {
				if ( !$pu->setPublication( 
						id => $publicationId,
						status => $newStatus,
						approved_on => undef,
						approved_by => undef 
					)
				) {
					$message = $pu->{errmsg};
				} else {
					$saveOk = 1;
				}
			}				
		} else {
			$message = "This status change action is not permitted.";
		}

	} else {
		$message = 'No permission';
	}

	return {
		params => {
			message => $message,
			saveOk => $saveOk,
			publicationId => $publicationId
		}
	};
}

sub setReadyForReview {
	my ( %kvArgs ) = @_;

	my ( $message );
	my $saveOk = 0;
	my $pu = Taranis::Publication->new();
	my $tt = Taranis::Template->new();
	my $session = $kvArgs{session};
	my $settings = getAdvisorySettings();
	my $publicationId = $kvArgs{publicationId};
	my $advisoryId = $kvArgs{advisoryId};
	
	my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{advisory}->{email};
		
	if ( $session->rightOnParticularization( $typeName ) && $session->right('write') ) {

		my $email = $tt->processPreviewTemplate( 'advisory', 'email', $advisoryId, $publicationId, 0, 71 );
		
		my $advisory = $pu->getPublicationDetails( 
			table => 'publication_advisory',
			'publication_advisory.id' => $advisoryId 
		);

		if ( 
			$advisory->{damage} == 3 
			&& $advisory->{probability} == 3 
			&& !$settings->{publishLL} 
		) { 
			$message = "The advisory is scaled as LL (low probability, low damage), therefor cannot be send. To send LL advisories set configuration option 'publish_LL_advisory' to 'yes'.";
		} elsif ( 
			!$pu->setPublication(
				id => $publicationId,
				contents => $email,
				status => 1
			)
		) {
			$message = $pu->{errmsg};
		} else {
			$saveOk = 1;
		}
	}
	
	return {
		params => {
			message => $message,
			saveOk => $saveOk,
			publicationId => $publicationId
		}
	};	
}

sub getAdvisoryPreview {
	my ( %kvArgs ) = @_;

	my ( $message );
	my $pu = Taranis::Publication->new();
	my $tt = Taranis::Template->new();
	my $session = $kvArgs{session};
	my $settings = getAdvisorySettings();

	my $publicationId = $kvArgs{publicationId};
	my $advisoryId = $kvArgs{advisoryId};
	my $publicationType = $kvArgs{publicationType};
	my $previewText;
	
	if ( $publicationType eq "xml" ) {
		$previewText = $pu->processPreviewXml( $advisoryId );
	} else {
		$previewText = $tt->processPreviewTemplate( "advisory", $publicationType, $advisoryId, $publicationId, 0, 71 );	
	}
	
	$message = $tt->{errmsg};
	
	return {
		params => { 
	 		previewText => $previewText,
	 		message => $message,
	 		publicationId => $publicationId
	 	}
	 };	
}

## HELPERS ##
sub getAdvisorySettings {
	my $tt = Taranis::Template->new();
	my $settings = {};
	$settings->{advisoryPrefix} = Taranis::Config->getSetting('advisory_prefix');
	$settings->{publishLL} = ( Taranis::Config->getSetting('publish_LL_advisory') =~ /^yes$/ ) ? 1 : 0;
	
	my $advisoryIdLength = Taranis::Config->getSetting('advisory_id_length');
	$advisoryIdLength = 3 if ( !$advisoryIdLength || $advisoryIdLength !~ /^\d+$/ );
	my $x = '';
	for ( my $i = 1; $i <= $advisoryIdLength; $i++ ) { $x .= 'X'; }
	$settings->{x} = $x;
	
	my $publicationTemplate = Taranis::Config::XMLGeneric->new('publication_templates', 'email', 'templates');
	my %nonUsableTemplates;
	my @usableTemplateTypeNames;
	foreach my $val ( values %{$publicationTemplate->loadCollection()} ) {
		foreach ( %$val ) {
	
			if ( $_ =~ /^(email|update|taranis_xml)$/ ) {
				push @usableTemplateTypeNames, $val->{$_};
			}		
			
			$nonUsableTemplates{ lc $val->{$_} } = 1 if ( $val->{$_} );
		}
	}
	$settings->{nonUsableTemplates} = \%nonUsableTemplates;
	$settings->{usableTypeIds} = $tt->getTypeIds( @usableTemplateTypeNames );

	return $settings;
}

sub addAndDelete {
	my ( $currentIds, $inputIds ) = @_;

	my @new;
	my @delete;
	my %idsHash;

	foreach my $id (@$currentIds) {
		$idsHash{$id} = $id;
	}

	my %newIdsHash;
	foreach my $id ( @$inputIds ) {
		$newIdsHash{$id} = $id;
		if ( !exists( $idsHash{$id} ) ) {
			push( @new, $id );
		}
	}

	foreach my $id (@$currentIds) {
		if ( !exists( $newIdsHash{$id} ) ) { push( @delete, $id ) }
	}
	return \@new, \@delete;	
}

1;
