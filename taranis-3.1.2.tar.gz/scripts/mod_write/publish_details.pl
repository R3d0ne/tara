#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Template;
use Taranis::Publish;
use Taranis::CallingList;
use Taranis qw(:all);
use JSON;
use strict;

my @EXPORT_OK = qw( 
	openDialogPublishingDetails saveCallDetails	downloadPublishDetails 
	setCallLockState releaseAllCallLocks adminRemoveCallLock 
);

sub publish_details_export {
	return @EXPORT_OK; 
}

sub openDialogPublishingDetails {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl );

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $pb = Taranis::Publish->new(); 
	my $cl = Taranis::CallingList->new();
	
	my $executeRight = $session->right("execute"); 

	my $publicationId = $kvArgs{id};
	my $publicationType= $kvArgs{pt};
	
	if ( $executeRight && $publicationId =~ /^\d+$/ ) {

		my $userId = $session->{cgisession}->param("userid");

		$vars->{is_admin} = $session->getUserRights( 
				entitlement => "admin_generic", 
				username => $userId 
			)->{admin_generic}->{write_right};	
		
		my $publishDetails = $pb->getPublishDetails( $publicationId, $publicationType );
	
		$vars->{details} = $publishDetails;
		$vars->{user} = $userId;
		$vars->{calling_list} = $cl->getCallingList( publication_id => $publicationId );
		
		$tpl = 'publish_details.tt';
	} else {
		$vars->{message} = 'No permission...';
		$tpl = 'dialog_no_right.tt';
	}

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );

	return { 
		dialog => $dialogContent,
		params => { 
			executeRight => $executeRight,
			publicationId => $publicationId,
			publicationType => $publicationType,
			canUnlock => $vars->{is_admin}
		}  
	};	
}

sub saveCallDetails {
	my ( %kvArgs ) = @_;
	my ( $message, $list, $callId );
	my $session = $kvArgs{session};	

	my $tt = Taranis::Template->new();
	my $pb = Taranis::Publish->new(); 
	my $cl = Taranis::CallingList->new();
	my $saveOk = 0;
	
	if ( $session->right("execute") && $kvArgs{id} =~ /^\d+$/ ) {

		$callId = $kvArgs{id};
		my $comments = $kvArgs{comments};
		my $isCalled = $kvArgs{isCalled};
		my $publicationId = $kvArgs{publicationId};

		if ( $cl->updateCallingList( id => $callId, comments => $comments, is_called => $isCalled, locked_by => undef ) ) {
			$list = $cl->getPublicationLists( publicationId => $publicationId );
		} else {
			$message = $cl->{errmsg};
		}
	} else {
		$message = 'No permission.';
	}
	
	$saveOk = 1 if ( !$message );
	
	return {
		params => {
			list => $list,
			saveOk => $saveOk,
			message => $message,
			callId => $callId
		}
	};	
}

sub downloadPublishDetails {
	my ( %kvArgs ) = @_;
	my ( $vars );
	my $session = $kvArgs{session};	

	my $tt = Taranis::Template->new();
	my $pb = Taranis::Publish->new(); 

	my $publicationId = $kvArgs{id};
	my $publicationType= $kvArgs{pt};
		
	my $publishDetails = $pb->getPublishDetails( $publicationId, $publicationType );

	$vars->{details} = $publishDetails;
	print "Content-disposition: attachment; filename=\"publishing_details.txt\";\n"
		. "Content-Type: text/plain;\n\n"
		. $tt->processTemplateNoHeader( "publish_details_savefile.tt", $vars, 1 );

	return {}
}

sub setCallLockState {
	my ( %kvArgs ) = @_;
	my ( $message, $list, $callId, $lockState );
	my $session = $kvArgs{session};	

	my $tt = Taranis::Template->new();
	my $pb = Taranis::Publish->new(); 
	my $cl = Taranis::CallingList->new();
	
	my $lockSetOk = 0;
	my $isLocked = 0;
	
	if ( 
		$session->right("execute") 
		&& $kvArgs{id} =~ /^\d+$/ 
		&& $kvArgs{publicationId} =~ /^\d+$/ 
		&& $kvArgs{'state'} =~ /^(set|release)$/ 
	) {
		
		my $userId = $session->{cgisession}->param("userid");
		my $publicationId = $kvArgs{publicationId};
		$lockState = $kvArgs{'state'};
		$callId = $kvArgs{id};
				
		$list = $cl->getPublicationLists( publicationId => $publicationId );

		foreach my $call ( @$list ) {
			if ( $call->{id} == $callId ) {
				if ( $call->{locked_by} && $call->{locked_by} ne $userId ) {
					$isLocked = 1;
				} else {
					undef $call->{locked_by};
				}
			}	
		}
		
		if ( !$isLocked ) {
			my $lockedBy = ( $lockState =~ /^set$/ ) ? $userId : undef;
			if ( !$cl->updateCallingList( id => $callId, locked_by => $lockedBy ) ) {
				$message = $cl->{errmsg};					
			}
		}

	} else {
		$message = 'No permission.';
	}
	
	$lockSetOk = 1 if ( !$message );
	
	return {
		params => {
			lockSetOk => $lockSetOk,
			message => $message,
			list => $list,
			callId => $callId,
			isLocked => $isLocked,
			lockState => $lockState
		}
	};	
}

sub releaseAllCallLocks {
	my ( %kvArgs ) = @_;
	my ( $message );
	my $session = $kvArgs{session};	

	my $tt = Taranis::Template->new();
	my $pb = Taranis::Publish->new(); 
	my $cl = Taranis::CallingList->new();
	my $saveOk = 0;
	
	if ( $session->right("execute") && $kvArgs{publicationId} =~ /^\d+$/ ) {
		my $publicationId = $kvArgs{publicationId};
		$cl->updateCallingList( publicationId => $publicationId, user => $session->{cgisession}->param("userid"), locked_by => undef );
	} else {
		$message = 'No permission.';
	}
	
	$saveOk = 1 if ( !$message );
	
	return {};
}

sub adminRemoveCallLock {
	my ( %kvArgs ) = @_;
	my ( $message, $list, $callId );
	my $session = $kvArgs{session};	

	my $tt = Taranis::Template->new();
	my $pb = Taranis::Publish->new(); 
	my $cl = Taranis::CallingList->new();
	my $removeOk = 0;
	
	if ( $session->right("execute") && $kvArgs{publicationId} =~ /^\d+$/ && $kvArgs{id} =~ /^\d+$/ ) {
		my $publicationId = $kvArgs{publicationId};
		$callId = $kvArgs{id};
		
		if ( $session->getUserRights( entitlement => "admin_generic", username => $session->{cgisession}->param("userid") )->{admin_generic}->{write_right} ) {
			
			if ( !$cl->updateCallingList( id => $callId, locked_by => undef ) ) {
				$message = $cl->{errmsg};					
			}				
		} else {
			$message = "You do not have the right privileges for this action.";					
		}
		
		$list = $cl->getPublicationLists( publicationId => $publicationId );

	} else {
		$message = 'No permission.';
	}

	$removeOk = 1 if ( !$message );

	return {
		params => {
			removeOk => $removeOk,
			message => $message,
			callId => $callId,
			list => $list
		}
	};
}

1;
