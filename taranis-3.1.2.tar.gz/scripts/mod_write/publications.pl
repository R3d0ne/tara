#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:all);
use Taranis::Template;
use Taranis::Publication;
use strict;

use Data::Dumper;

my @EXPORT_OK = qw(displayPublicationOptions displayPublications deletePublication searchPublications getPublicationItemHtml closePublication);

sub publications_export {
	return @EXPORT_OK;
}

my $tt = Taranis::Template->new();
my $pu = Taranis::Publication->new();
 
my %page_options = (
	advisory => {
		id_column_name		=> "Advisory ID", 
		title_column_name	=> "Advisory title", 
		table				=> "publication_advisory",
		type_id				=> [ "govcertid", "version_str" ],
		title_content		=> ["pub_title"],																		
		particularization	=> "advisory (email)",
		page_title			=> "Advisory"
	},
	eos => { 
		id_column_name		=> "Publication", 
		title_column_name	=> "Timeframe", 
		table				=> "publication_endofshift",
		type_id				=> [ "pub_title"],
		title_content		=> ["timeframe_str"],                                    
		particularization	=> "end-of-shift (email)",
		page_title			=> "End-of-shift"
	},
	eow	=> { 
		id_column_name		=> "Publication", 
		title_column_name	=> "Created on", 
		table				=> "publication_endofweek",
		type_id				=> [ "pub_title"],
		title_content		=> ["created_on_str"],																		
		particularization	=> "end-of-week (email)",
		page_title			=> "End-of-week"
	}
);

my %statusDictionary = ( 
	0 => 'pending',
	1 => 'ready4review',
	2 => 'approved',
	3 => 'published',
	4 => 'approved'
);


sub displayPublicationOptions {
	my ( %kvArgs) = @_;
	my ( $vars );
	
	my $htmlContent = $tt->processTemplateNoHeader('publications_options.tt', $vars, 1);
	
	my @js = (
		'js/tagging.js',
		'js/datevalidation.js',
		'js/publications.js',
		'js/publish_details.js'		
	);
	
	return { content => $htmlContent,  filters => '<div></div>', js => \@js };
}


sub displayPublications {
	my ( %kvArgs) = @_;
	my ( $tpl );
	
	my $session = $kvArgs{session};
	
	my $pageNumber = ( exists( $kvArgs{'hidden-page-number'} ) && $kvArgs{'hidden-page-number'} =~ /^\d+$/ )
		? $kvArgs{'hidden-page-number'}
		: 1;

	my $type = ( exists( $page_options{ $kvArgs{pub_type} } ) ) ? $kvArgs{pub_type} : "advisory";

	my $vars = getPublicationsSettings( session => $session, type => $type ); 
		
	if ( $vars->{hasRightsForPublication} ) {
		$vars->{publications} = getPublicationResults(
			pageNumber => $pageNumber, 
			table => $page_options{ $type }->{table},
			type => $type 
		);

		$vars->{filterButton} = 'btn-publications-search';
		$vars->{page_bar} = $tt->createPageBar( $pageNumber, $pu->{result_count}, 100 );
		$vars->{newItem} = 1;
		$vars->{page_title} = $page_options{ $type }->{page_title};

		$tpl = 'publications.tt';
	} else {
		$tpl = 'no_permission.tt';
	}

	my $htmlContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );
	my $htmlFilters = $tt->processTemplateNoHeader('publications_filters.tt', $vars, 1);
	
	my @js = (
		'js/jquery.timepicker.min.js',
		'js/tagging.js',
		'js/datevalidation.js',
		'js/publications.js',
		'js/publications_filters.js',
		'js/publications_advisory.js',
		'js/publications_eow.js',
		'js/publications_eos.js',
		'js/publications_common_actions.js',
		'js/publish_details.js',
		'js/tab_in_textarea.js'
	);
	
	return { content => $htmlContent, filters => $htmlFilters, js => \@js };
}

sub searchPublications {
	my ( %kvArgs ) = @_;
	my ( $tpl );
	my $session = $kvArgs{session};
	
	my $keywords = ( exists( $kvArgs{searchkeywords} ) ) ? $kvArgs{searchkeywords} : '';
	my $startDate = ( exists( $kvArgs{startdate} ) ) ? $kvArgs{startdate} : '';
	my $endDate = ( exists( $kvArgs{enddate} ) ) ? $kvArgs{enddate} : '';
	my $status = ( exists( $kvArgs{status} ) ) ? $kvArgs{status} : '';
	
	my $type = ( exists( $page_options{ $kvArgs{pub_type} } ) ) ? $kvArgs{pub_type} : "advisory";
		
	my $pageNumber = ( exists( $kvArgs{'hidden-page-number'} ) && $kvArgs{'hidden-page-number'} =~ /^\d+$/ )
		? $kvArgs{'hidden-page-number'}
		: 1;

	my $hitsperpage = ( exists( $kvArgs{hitsperpage} ) && $kvArgs{hitsperpage} =~ /^[1-9][0-9]{0,2}$/ ) ? $kvArgs{hitsperpage} : 100;

	my $vars = getPublicationsSettings( session => $session, type => $type ); 

	if ( $vars->{hasRightsForPublication} ) {
		$vars->{publications} = getPublicationResults(
			pageNumber => $pageNumber, 
			table => $page_options{ $type }->{table},
			type => $type,
			startDate => $startDate,
			endDate => $endDate,
			status => $status,
			hitsperpage => $hitsperpage,
			keywords => $keywords
		);

		$vars->{filterButton} = 'btn-publications-search';
		$vars->{page_bar} = $tt->createPageBar( $pageNumber, $pu->{result_count}, $hitsperpage );
		$vars->{newItem} = 1;

		$tpl = 'publications.tt';
	} else {
		$tpl = 'no_permission.tt';
	}

	my $htmlContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );
	
	return { content => $htmlContent };
}

sub closePublication {
	my ( %kvArgs ) = @_;
	my $session = $kvArgs{session};

	my $userid = $session->{cgisession}->param("userid");
	my $id = $kvArgs{id};

	my $is_admin = $session->getUserRights( 
		entitlement => "admin_generic", 
		username => $userid 
	)->{admin_generic}->{write_right};
	
	my $openedBy = $pu->isOpenedBy( $id );
	
	# closeByAdmin needs to be set explicitly
	if ( 
		( exists( $openedBy->{opened_by} ) && $openedBy->{opened_by} eq $userid ) 
		|| ( $is_admin && exists( $kvArgs{closeByAdmin} ) && $kvArgs{closeByAdmin} == 1 ) 
	) {
		$pu->closePublication( $id );
	}
	
	return {
		params => {
			id => $id
		}
	};
}

sub deletePublication {
	my ( %kvArgs ) = @_;
	my $session = $kvArgs{session};
	my ( $message );
	my $deleteOk = 0;
	my $multiplePublicationsUpdated = 0;
	my $previousVersion = '';
	
	undef $pu->{previousVersionId};
	undef $pu->{multiplePublicationsUpdated};
	
	if ( $kvArgs{del} =~ /^\d+$/ && $session->right('write') ) {
		if ( !$pu->deletePublication( $kvArgs{del}, $kvArgs{pubType} ) ) {
			$message = $pu->{errmsg};	
		} else {
			$deleteOk = 1;
		}
	}
	if ( defined( $pu->{previousVersionId} ) && $pu->{previousVersionId} ) {
		$previousVersion = $pu->{previousVersionId};
		$pu->{previousVersionId} = undef;
	}
	
	$multiplePublicationsUpdated = ( defined( $pu->{multiplePublicationsUpdated} ) && $pu->{multiplePublicationsUpdated} ) ? 1 : 0;
	
	return {
		params => {
			deleteOk => $deleteOk,
			message => $message,
			publicationid => $kvArgs{publicationId},
			previousVersion => $previousVersion,
			multiplePublicationsUpdated => $multiplePublicationsUpdated
		}
	}
}


sub getPublicationItemHtml {
	my ( %kvArgs ) = @_;
	my ( $vars, $tpl, $publicationStatus );
	
	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	
	my $publicationId = $kvArgs{id};
	my $pubType = $kvArgs{pubType};
	my $insertNew = $kvArgs{insertNew};

	my $table = $page_options{$pubType}->{table};
	my $publication = $pu->getPublicationDetails( table => $table, $table . ".publication_id" => $publicationId );
 
	if ( $publication ) {
		$publicationStatus = $statusDictionary{ $publication->{status} };
		$vars = getPublicationsSettings( session => $session, type => $pubType );
		
		foreach ( @{ $page_options{ $pubType }->{type_id} } ) {
			$publication->{specific_id} .= ( $publication->{ $_ } ) ? $publication->{ $_ } . " " : "N/A ";
		}

		foreach ( @{ $page_options{ $pubType }->{title_content} } ) {
			$publication->{title_content} .= ( $publication->{ $_ } ) ? $publication->{ $_ } . " " : "N/A ";
		}
			
		$publication->{statusDescription} = $statusDictionary{ $publication->{status} };

		$vars->{newItem} = $insertNew;
		$vars->{publication} = $publication;
		
		$tpl = 'publications_item.tt';
	} else {
		$tpl = 'empty_row.tt';
		$vars->{message} = 'Could not find the item...';
	}

	my $publicationItemHtml = $tt->processTemplateNoHeader($tpl, $vars, 1);

	return {
		params => { 
			itemHtml => $publicationItemHtml,
			publicationId => $publicationId,
			insertNew => $insertNew,
			publicationStatus => $publicationStatus
		}
	};
}


### HELPERS ###
sub getPublicationResults {
	my ( %kvArgs ) = @_;
	
	my $table = $kvArgs{table};
	my $pageNumber = $kvArgs{pageNumber}; 
	my $hitsPerPage = ( exists( $kvArgs{hitsperpage} ) && $kvArgs{hitsperpage} =~ /^\d+$/ ) ? $kvArgs{hitsperpage} : 100;
	my $type = $kvArgs{type};
	my $keywords = ( exists( $kvArgs{keywords} ) ) ? $kvArgs{keywords} : '';  
	my $startDate = ( exists( $kvArgs{startDate} ) && validateDateString( $kvArgs{startDate} ) ) ?  formatDateTimeString( $kvArgs{startDate} ) : '';
	my $endDate = ( exists( $kvArgs{endDate} ) && validateDateString( $kvArgs{endDate} ) ) ?  formatDateTimeString( $kvArgs{endDate} ): '';
	
	my $publicationType = $pu->getPublicationTypeId( $page_options{ $type }->{particularization} );
	my $typeId = ( $publicationType ) ? $publicationType->{id} : undef;
	
	if ( !$typeId ) {
		logErrorToSyslog("getPublicationResults: type id not found for type '$type', could be configuration error...");
		return [];
	}
	
	my @status = ();
	if ( exists( $kvArgs{status} ) ) {
		if ( ref( $kvArgs{status} ) =~ /^ARRAY$/ ) {
			@status = @{ $kvArgs{status} };
		} else {
			push @status, $kvArgs{status};
		}
	}
	
	my $publications = $pu->loadPublicationsCollection( 
		table => $table,
		status => \@status,
		start_date => $startDate,
		end_date => $endDate,
		date_column	=> "created_on",
		hitsperpage => $hitsPerPage,
		offset => ( $pageNumber - 1 ) * $hitsPerPage,
		search => $keywords,
		publicationType => $typeId
	);
																		
	foreach my $publication ( @$publications ) {
		foreach ( @{ $page_options{ $type }->{type_id} } ) {
			$publication->{specific_id} .= ( $publication->{ $_ } ) ? $publication->{ $_ } . " " : "N/A ";
		}
		
		foreach ( @{ $page_options{ $type }->{title_content} } ) {
			$publication->{title_content} .= ( $publication->{ $_ } ) ? $publication->{ $_ } . " " : "N/A ";
		}
		
		$publication->{statusDescription} = $statusDictionary{ $publication->{status} };
	}

	return $publications;
}

sub getPublicationsSettings {
	my ( %kvArgs ) = @_;
	my $session = $kvArgs{session};
	my $settings = {};
	
	my $type = $kvArgs{type}; 
	
	my $hasRightsForPublication = 0;
	if ( ref( $page_options{$type}->{particularization} ) eq 'ARRAY' ) {
		foreach my $particularization ( @{ $page_options{$type}->{particularization} } ) {
			if ( !$hasRightsForPublication ) {
				$hasRightsForPublication = $session->rightOnParticularization( $particularization );
			}
		}
	} else {
		$hasRightsForPublication = $session->rightOnParticularization( $page_options{$type}->{particularization} );	
	}

	$settings->{pub_type} = $type;
	$settings->{page_columns} = $page_options{ $type };
	$settings->{write_right} = $session->right("write");
	$settings->{execute_right} = $session->right("execute");
	$settings->{is_admin} = $session->getUserRights( 
		entitlement => "admin_generic", 
		username => $session->{cgisession}->param("userid") 
	)->{admin_generic}->{write_right};
	
	$settings->{pageSettings} = $session->getSessionUserSettings();
	$settings->{hasRightsForPublication} = $hasRightsForPublication;
	
	return $settings;
}

1;
