#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:util);
use Taranis::Session;	
use Taranis::Template;
use Taranis::Config;
use Taranis::Publication;
use Taranis::Users;
use strict;
use JSON;
use POSIX;

use Data::Dumper;

my @EXPORT_OK = qw(
	openDialogNewEos openDialogEosDetails openDialogPreviewEos 
	saveEosDetails saveNewEos setEosStatus
	getPublicationsAndVTNews getMediaExposureItems
);

sub eos_export {
	return @EXPORT_OK; 
}

sub openDialogNewEos {
	my ( %kvArgs ) = @_;
	my ( $vars, $tpl);
	
	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();	
	my $pu = Taranis::Publication->new();
	
	my $typeName = Taranis::Config->new( Taranis::Config->getSetting('publication_templates') )->{eos}->{email};
	
	if ( $session->rightOnParticularization( $typeName ) ) {
		
		my $us = Taranis::Users->new();
		my $users = $us->getUsersList();
		my @users;
		while ( $us->nextObject() ) {
			my $user = $us->getObject();
			push @users, { username => $user->{username}, fullname => $user->{fullname} }
		}  
	
		$vars->{users} = \@users;
		$vars->{organisation} = Taranis::Config->getSetting('organisation');
		
		$vars->{write_right} = $session->right('write');
		$vars->{isNewEos} = 1;
		$vars->{publication_type_id} = $pu->getPublicationTypeId( $typeName )->{id};
		
		$tpl = 'write_eos.tt';
	} else {
		$vars->{message} = 'No permission...';
		$tpl = 'dialog_no_right.tt';
	}

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );	
	return { dialog => $dialogContent };	
}

sub openDialogEosDetails {
	my ( %kvArgs ) = @_;
	my ( $vars, $tpl );
	
	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $pu = Taranis::Publication->new();	
	
	my $publicationId = $kvArgs{id};
	
	my $typeName = Taranis::Config->new( Taranis::Config->getSetting('publication_templates') )->{eos}->{email};
		
	if ( $session->rightOnParticularization( $typeName ) ) {
		$vars->{eos} = $pu->getPublicationDetails( 
			table => 'publication_endofshift',
			'publication_endofshift.publication_id' => $publicationId
		);

		### SET opened_by OR RETURN locked = 1 ###
		if ( my $opened_by = $pu->isOpenedBy( $publicationId ) ) {
			$vars->{isLocked} = 1;
			$vars->{openedByFullname} = $opened_by->{fullname};
		} elsif(  $session->right('write') ) {
			if ( $pu->openPublication( $session->{cgisession}->param('userid'), $publicationId ) ) {
				$vars->{isLocked} = 0;
			} else {
				$vars->{isLocked} = 1;
			}
		} else {
			$vars->{isLocked} = 1;
		}

		my $us = Taranis::Users->new();
		my $users = $us->getUsersList();
		my @users;
		while ( $us->nextObject() ) {
			my $user = $us->getObject();
			push @users, { username => $user->{username}, fullname => $user->{fullname} }
		}  
	
		$vars->{users} = \@users;
		$vars->{organisation} = Taranis::Config->getSetting('organisation');
		
		$vars->{write_right} = $session->right('write');
		$vars->{publication_type_id} = $pu->getPublicationTypeId( $typeName )->{id};

		$tpl = 'write_eos.tt';
	} else {
		$vars->{message} = 'No permission...';
		$tpl = 'dialog_no_right.tt';
	}

	my $dialogContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );	
	return { 
		dialog => $dialogContent,
		params => { 
			publicationid => $publicationId,
			isLocked => $vars->{isLocked} 
		} 
	};	
}

sub openDialogPreviewEos {
	
	my ( %kvArgs ) = @_;
	my $vars;
	
	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();	
	
	my $publicationId = $kvArgs{id};
	my $writeRight = $session->right('write');
	my $executeRight = $session->right('execute');
	my $userId = $session->{cgisession}->param('userid');

	my $typeName = Taranis::Config->new( Taranis::Config->getSetting('publication_templates') )->{eos}->{email};

	if ( $session->rightOnParticularization( $typeName ) ) {

		my $pu = Taranis::Publication->new();
		my $tg = Taranis::Tagging->new();
		my $us = Taranis::Users->new();
		
		my $eos = $pu->getPublicationDetails( 
			table => 'publication_endofshift',
			'publication_endofshift.publication_id' => $publicationId 
		);

		$vars->{eos_id} = $eos->{id};
		$vars->{publication_id} = $eos->{publication_id};
		$vars->{eos_heading} = $eos->{pub_title} . ' created on '
			. substr( $eos->{created_on_str}, 6, 2 ) . '-' 
			. substr( $eos->{created_on_str}, 4, 2 ) . '-' 
			. substr( $eos->{created_on_str}, 0, 4 );

		$vars->{created_by_name} = ( $eos->{created_by} ) ? $us->getUser( $eos->{created_by}, 1 )->{fullname} : undef;
		$vars->{approved_by_name} = ( $eos->{approved_by} ) ? $us->getUser( $eos->{approved_by}, 1 )->{fullname} : undef;
		$vars->{published_by_name} = ( $eos->{published_by} ) ? $us->getUser( $eos->{published_by}, 1 )->{fullname} : undef; 

		$vars->{preview} = $eos->{contents};
		$vars->{current_status} = $eos->{status};
		
		my $tags = $tg->getTagsByItem( $eos->{id}, 'publication_endofshift' );
		$vars->{tags}	= "@$tags";
		
		### SET opened_by OR RETURN locked = 1 ###
		if ( my $openedBy = $pu->isOpenedBy( $eos->{publication_id} ) ) {
			$vars->{isLocked} = 1;
			$vars->{openedByFullname} = $openedBy->{fullname};
		} elsif( $writeRight || $executeRight ) {
			if ( $pu->openPublication( $userId, $eos->{publication_id} ) ) {
				$vars->{isLocked} = 0;
			} else {
				$vars->{isLocked} = 1;
			}
		} else {
			$vars->{isLocked} = 1;
		}
		
		my $dialogContent = $tt->processTemplateNoHeader( 'write_eos_preview.tt', $vars, 1 );	
		return { 
			dialog => $dialogContent,
			params => { 
				publicationid => $publicationId,
				isLocked => $vars->{isLocked},
				executeRight => $executeRight,
				currentStatus => $eos->{status}
			}
		};	
	} else {
		$vars->{message} = 'No permission...';
		my $dialogContent = $tt->processTemplateNoHeader( 'dialog_no_right.tt', $vars, 1 );	
		return { dialog => $dialogContent };	
	}
}

sub saveNewEos {
	my ( %kvArgs ) = @_;
	my ( $message, $publicationId, $eosId );

	my $saveOk = 0;
	my $session = $kvArgs{session};
	my $userId = $session->{cgisession}->param('userid');
	
	my $tt = Taranis::Template->new();	
	my $pu = Taranis::Publication->new();

	my $typeName = Taranis::Config->new( Taranis::Config->getSetting('publication_templates') )->{eos}->{email};

	if ( $session->rightOnParticularization( $typeName ) && $session->right('write') ) {

		my $timeframe = getTimeframe( \%kvArgs );
      
		if ( $timeframe->{error} ) {
			$message = $timeframe->{error};
		} else { 

			my $typeId = $pu->getPublicationTypeId( $typeName )->{id};
	  
			$pu->{dbh}->startTransaction();

			if (
				!$pu->addPublication(
					title => 'End-of-Shift',
					created_by => $userId,
					type => $typeId,
					status => '0'
	                               )
				|| !( $publicationId = $pu->{dbh}->getLastInsertedId('publication') )
				|| !$pu->linkToPublication(
						table => 'publication_endofshift',
						handler => $kvArgs{handler} || undef,
						first_co_handler => $kvArgs{first_co_handler} || undef,
						second_co_handler => $kvArgs{second_co_handler} || undef,
						timeframe_begin => $timeframe->{begin},
						timeframe_end => $timeframe->{end},
						general_info => $kvArgs{general_info},
						vulnerabilities_threats => $kvArgs{vulnerabilities_threats},
						incident_info => $kvArgs{incident_info},
						community_news => $kvArgs{community_news},
						media_exposure => $kvArgs{media_exposure},
						tlp_amber => $kvArgs{tlp_amber},
						publication_id => $publicationId
					) 
				|| !( $eosId = $pu->{dbh}->getLastInsertedId('publication_endofshift') )
			) {
				$message = $pu->{errmsg};
			} else {
				my $previewText = $tt->processPreviewTemplate( 'eos', 'email', $eosId, $publicationId, 0, 0 );
	
				if ( !$pu->setPublication( 
					id => $publicationId, 
					contents => $previewText 
				)) {
					$message = $pu->{errmsg};
				} else {
					$saveOk = 1;  
				}
			}
			$pu->{dbh}->endTransaction();
		}
	} else {
		$message = 'No persmission';
	}
	
	return {
		params => { 
			message => $message,
			saveOk => $saveOk,
			publicationId => $publicationId
		}
	};	
}

sub saveEosDetails {
	my ( %kvArgs ) = @_;
	my ( $message, $publicationId, $eosId );

	my $saveOk = 0;
	my $session = $kvArgs{session};
	my $userId = $session->{cgisession}->param('userid');

	my $tt = Taranis::Template->new();	
	my $pu = Taranis::Publication->new();

	my $typeName = Taranis::Config->new( Taranis::Config->getSetting('publication_templates') )->{eos}->{email};

	if ( $session->rightOnParticularization( $typeName ) && $session->right('write') ) {

		my $typeId = $pu->getPublicationTypeId( $typeName )->{id};
		$publicationId = $kvArgs{pub_id};
		$eosId = $kvArgs{eos_id};

		my $timeframe = getTimeframe( \%kvArgs );

		if ( $timeframe->{error} ) {
			$message = $timeframe->{error};
		} else {

			$pu->{dbh}->startTransaction();
	      
			if ( !$pu->setPublicationDetails(
				table => "publication_endofshift",
				where => { id => $eosId },
				handler => $kvArgs{handler} || undef,
				first_co_handler => $kvArgs{first_co_handler} || undef,
				second_co_handler => $kvArgs{second_co_handler} || undef,
				timeframe_begin => $timeframe->{begin},
				timeframe_end => $timeframe->{end},
				general_info => $kvArgs{general_info},
				vulnerabilities_threats => $kvArgs{vulnerabilities_threats},
				incident_info => $kvArgs{incident_info},
				community_news => $kvArgs{community_news},
				media_exposure => $kvArgs{media_exposure},
				tlp_amber => $kvArgs{tlp_amber}
			) ) {
				$message = $pu->{errmsg};
			} else {
				my $previewText = $tt->processPreviewTemplate( 'eos', 'email', $eosId, $publicationId, 0, 71 );
				if ( !$pu->setPublication( 
					id => $publicationId, 
					contents => $previewText,
					type => $typeId
				)) {
					$message = $pu->{errmsg};
				} else {
					$saveOk = 1;
				}
			}
			$pu->{dbh}->endTransaction();
		}
	}

	return {
		params => { 
			message => $message,
			saveOk => $saveOk,
			publicationId => $publicationId
		}
	};
}

sub getPublicationsAndVTNews {
	my ( %kvArgs ) = @_;

	my $message;
	my $sentPublications = '';
	
	my $pu = Taranis::Publication->new();
	my $tt = Taranis::Template->new();
	my $publicationId = $kvArgs{publicationid};
	my $session = $kvArgs{session};

	my $beginDate = $kvArgs{begin_date};
	my $endDate   = $kvArgs{end_date};
	my $beginTime = $kvArgs{begin_time};
	my $endTime   = $kvArgs{end_time};
	my $publicationTypeId = $kvArgs{publicationTypeId};
      
	# check if dates have format 'dd-mm-yyyy'
	foreach my $date ( $beginDate, $endDate ) {
		if ( $date !~ /^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[012])-(19|20)\d\d$/ ) {
			$message = "Invalid date format supplied. Please specify a date by 'dd-mm-yyyy'.";
		}
	}

	# check if times have format 'HH:MM'
	foreach my $time ( $beginTime, $endTime ) {
		if ( $time !~ /^([01][0-9]|2[0-4]):[0-5][0-9]$/ ) {
			$message = "Invalid time format supplied. Please specify a time by 'HH:MM'.";
		}
	}

	# check if publication_type_id is a number
	if ( $publicationTypeId !~ /^\d+$/ ) {
		$message = "Cannot collect selected news items, because of invalid input.";
	}
      
	if ( !$message ) {
		$beginDate = formatDateTimeString( $beginDate ) . ' ' . $beginTime;
		$endDate = formatDateTimeString( $endDate ) . ' ' . $endTime;

		# collect advisories within timeframe			  
		my $advisories = $pu->loadPublicationsCollection( 
			table => 'publication_advisory',
			status => [3],
			start_date => $beginDate,
			end_date => $endDate,
			date_column => 'published_on',
			hitsperpage => 100,
			offset => 0,
			search => '',
			order_by => 'govcertid, version'
		);
		
		# hash to be used to convert int values to readable damage/probability level
		my %level = ( 1 => 'H', 2 => 'M', 3 => 'L' );

		# create standard markup for advisories. Example: NCSC-2012-0001 [v1.00][M/M] My advisory title
		foreach my $publication ( @$advisories ) {

			$sentPublications .= $publication->{govcertid} . ' '
				. $publication->{version_str}
				. '[' . $level{ $publication->{probability} } . '/'
				. $level{ $publication->{damage} } . '] '
				. $publication->{pub_title} ."\n";
		}

		# collect News items within timeframe
		my $as = Taranis::Assess->new();
		my $newsItems = $as->getItemsAddedToPublication( $beginDate, $endDate, $publicationTypeId, 'vuln_threats' );

		# create standard markup for alerts. Example:
		# - newsitem title
		# newsitem description
		# newsitem link
		foreach my $newsItem ( @$newsItems ) {
			$sentPublications .= '&minus; ' . $newsItem->{title} ."\n" . $newsItem->{description} ."\n" . $newsItem->{'link'} . "\n";
        }
	}

	return {
		params => {
			message => $message,
			publicationId => $publicationId,
			sentPublications => $sentPublications
		}
	};	
	
}

sub getMediaExposureItems {
	my ( %kvArgs ) = @_;

	my $message;
	my $mediaExposureItems = '';
	
	my $as = Taranis::Assess->new();
	my $tt = Taranis::Template->new();
	my $publicationId = $kvArgs{publicationid};
	my $session = $kvArgs{session};

	my $beginDate = $kvArgs{begin_date};
	my $endDate   = $kvArgs{end_date};
	my $beginTime = $kvArgs{begin_time};
	my $endTime   = $kvArgs{end_time};
	my $publicationTypeId = $kvArgs{publicationTypeId};
      
	# check if dates have format 'dd-mm-yyyy'
	foreach my $date ( $beginDate, $endDate ) {
		if ( $date !~ /^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[012])-(19|20)\d\d$/ ) {
			$message = "Invalid date format supplied. Please specify a date by 'dd-mm-yyyy'.";
		}
	}

	# check if times have format 'HH:MM'
	foreach my $time ( $beginTime, $endTime ) {
		if ( $time !~ /^([01][0-9]|2[0-4]):[0-5][0-9]$/ ) {
			$message = "Invalid time format supplied. Please specify a time by 'HH:MM'.";
		}
	}

	# check if publication_type_id is a number
	if ( $publicationTypeId !~ /^\d+$/ ) {
		$message = "Cannot collect selected news items, because of invalid input.";
	}
      
	if ( !$message ) {
		$beginDate = formatDateTimeString( $beginDate ) . ' ' . $beginTime;
		$endDate = formatDateTimeString( $endDate ) . ' ' . $endTime;

		# collect Media Exposure items within timeframe
		my $newsItems = $as->getItemsAddedToPublication( $beginDate, $endDate, $publicationTypeId, 'media_exposure' );

		foreach my $newsItem ( @$newsItems ) {
			$mediaExposureItems .= '&minus; ' . $newsItem->{title} ."\n" . $newsItem->{description} ."\n" . $newsItem->{'link'} . "\n" ;
		}
	}

	return {
		params => {
			message => $message,
			publicationId => $publicationId,
			mediaExposureItems => $mediaExposureItems
		}
	};
}

sub setEosStatus {
	my ( %kvArgs ) = @_;

	my ( $message );
	my $saveOk = 0;
	my $pu = Taranis::Publication->new();
	my $session = $kvArgs{session};
	my $publicationId = $kvArgs{publicationId};
	my $newStatus = $kvArgs{status};
	my $userId = $session->{cgisession}->param('userid'); 
	
	my $typeName = Taranis::Config->new( Taranis::Config->getSetting('publication_templates') )->{eos}->{email};
	
	if ( 
		( $session->rightOnParticularization( $typeName ) && $session->right('write') )
		|| $newStatus =~ /^(0|1|2)$/ 
	) {

		my $eos = $pu->getPublicationDetails( 
			table => 'publication_endofshift',
			'publication_endofshift.publication_id' => $publicationId 
		);

		my $currentStatus = $eos->{status};
		if (
			 ( $currentStatus eq '0' && $newStatus eq '1' ) || 
			 ( $currentStatus eq '1' && $newStatus eq '0' ) ||
			 ( $currentStatus eq '2' && $newStatus eq '0' ) ||
			 ( $currentStatus eq '1' && $newStatus eq '2' && $session->right('execute') )
		) {

			if ( $newStatus eq '2' ) {
				if ( !$pu->setPublication( 
						id => $publicationId, 
						status => $newStatus,
						approved_on => nowstring(10),
						approved_by => $userId 
					) 
				) {
				
				$message = $pu->{errmsg};
				
				} else {
					$saveOk = 1;
				}			
			} else {
				if ( !$pu->setPublication( 
						id => $publicationId,
						status => $newStatus,
						approved_on => undef,
						approved_by => undef 
					)
				) {
					$message = $pu->{errmsg};
				} else {
					$saveOk = 1;
				}
			}				
		} else {
			$message = 'This status change action is not permitted.';
		}
	} else {
		$message = 'No permission';
	}

	return {
		params => {
			message => $message,
			saveOk => $saveOk,
			publicationId => $publicationId
		}
	};	
}


sub getTimeframe {
	my ( $timeframeData )= @_;
	
	my $timeframe = { begin => undef, end => undef, error => undef };
  
	my $timeframeBeginDate = $timeframeData->{timeframe_begin_date};
	my $timeframeEndDate = $timeframeData->{timeframe_end_date};
	my $timeframeBeginTime = $timeframeData->{timeframe_begin_time};
	my $timeframeEndTime = $timeframeData->{timeframe_end_time};
      
	# check if dates have format 'dd-mm-yyyy'
	foreach my $date ( $timeframeBeginDate, $timeframeEndDate ) {
		if ( $date !~ /^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[012])-(19|20)\d\d$/ ) {
			$timeframe->{error} = "Invalid date format supplied. Please specify a date by 'dd-mm-yyyy'.";
		}
	}

	# check if times have format 'HH:MM'
	foreach my $time ( $timeframeBeginTime, $timeframeEndTime ) {
		if ( $time !~ /^([01][0-9]|2[0-4]):[0-5][0-9]$/ ) {
			$timeframe->{error} = "Invalid time format supplied. Please specify a time by 'HH:MM'.";
		}
	}
	$timeframe->{begin} = formatDateTimeString( $timeframeBeginDate ) . ' ' . $timeframeBeginTime;
	$timeframe->{end} = formatDateTimeString( $timeframeEndDate ) . ' ' . $timeframeEndTime;

	return $timeframe; 
}

1;
