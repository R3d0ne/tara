#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:all);
use Taranis::Session;
use Taranis::Template;
use Taranis::Analysis;
use Taranis::Publication;
use strict;


my @EXPORT_OK = qw(openDialogAnalysisToPublication openDialogAnalysisToPublicationUpdate searchPublicationsAnalysisToPublication);

sub analysis2publication_export {
	return @EXPORT_OK; 
}

sub openDialogAnalysisToPublication {
	my ( %kvArgs ) = @_;
	my ( $vars, $tpl );
	my $session = $kvArgs{session};	
	
	my $an = Taranis::Analysis->new();
	my $tt = Taranis::Template->new();
	$vars->{analysis_id} = $kvArgs{id};
	
	my $advisory_right = 0;
	
	if ( $session->right("write") ) {
		if ( $session->right("particularization") ) {
			foreach my $right ( @{ $session->right("particularization") } ) {
				if ( lc ( $right ) eq "advisory (email)" ) {
					$advisory_right = 1;
				}
			} 
		}	else {
			$advisory_right = 1;
		}

		$vars->{linkedAdvisories} = $an->getLinkedAdvisories( 'pu.status' => { '!=' => 3 }, 'ap.analysis_id' => $kvArgs{id} );
		$vars->{linkedItems} = $an->getLinkedItemsContainingAdvisories( 'ia.analysis_id' => $kvArgs{id} );
		
		$tpl = 'analysis2publication.tt';
	} else {
		$tpl = 'dialog_no_right.tt';
		$vars->{message} = 'Sorry, you do not have enough privileges for this action...';
	}
	
	
	$vars->{advisory_right} = $advisory_right;
	
	my $dialogContent = $tt->processTemplateNoHeader($tpl, $vars, 1);
	
	my @js = (
			'js/publications.js',
			'js/publications_advisory.js',
			'js/publications_common_actions.js'
	);
		
	return { 
		dialog => $dialogContent,
		params => {id => $kvArgs{id} },
		js => \@js
	};
}

sub openDialogAnalysisToPublicationUpdate {
	my ( %kvArgs ) = @_;
	my ( $vars, $tpl );
	my $session = $kvArgs{session};	
	
	my $tt = Taranis::Template->new();
	my $an = Taranis::Analysis->new();
	my $pu = Taranis::Publication->new();
	
	my $publicationRight = 0;

	my $publicationType = $kvArgs{pubclicationType};
	
	if ( $publicationType =~ /^(advisory)$/ ) {
	
		if ( $session->right("write") ) {
			if ( $session->right("particularization") ) {
				foreach my $right ( @{ $session->right("particularization") } ) {
					if ( lc ( $right ) eq "advisory (email)" && $publicationType =~ /^advisory$/ ) {
						$publicationRight = 1;
					}
				} 
			}	else {
				$publicationRight = 1;		
			}
		}
		
		$vars->{publication_right} = $publicationRight;
	} 

	if ( $publicationRight ) {
		if ( $kvArgs{analysisId} =~ /^\d+$/ ) {
			
			my $analysis = $an->getRecordsById( table => "analysis", id => $kvArgs{analysisId} )->[0];
			
			my @cve_ids;
			if ( $analysis->{idstring} ) {
				my @ids = split( " ", $analysis->{idstring} );
				foreach ( @ids ) {
					if ( $_ =~ /^CVE.*/i) {
						push @cve_ids, $_;
					}
				}
			}	
			
			if ( @cve_ids && $publicationType =~ /^advisory$/ ) {
				$vars->{advisories_id_match} = $pu->getRelatedPublications( \@cve_ids, 'advisory' );	
			}
			$vars->{publication_type} = $publicationType;
			$vars->{publications_no_match} = $pu->getRelatedPublications( undef, $publicationType );
			$vars->{analysis_id} = $kvArgs{analysisId};
			$vars->{analysis_heading} = $analysis->{title};
			
		} else {
			$vars->{message} = "No valid ID supplied.";
		}
		
		$tpl = 'analysis2publication_update.tt';
	} else {
		$tpl = 'dialog_no_right.tt';
		$vars->{message} = 'Sorry, you do not have enough privileges for this action...';
	}
	
	my $dialogContent = $tt->processTemplateNoHeader($tpl, $vars, 1);
	
	return { 
		dialog => $dialogContent,
		params => { id => $kvArgs{analysisId} } 
	};
} 

sub searchPublicationsAnalysisToPublication {
	my ( %kvArgs ) = @_;
	my $message;
	my $session = $kvArgs{session};	
	
	my $pu = Taranis::Publication->new();

	my $search = $kvArgs{search};
	my $publicationType = $kvArgs{publicationtype};
	my $id = $kvArgs{id};
			
	my $publications = $pu->searchPublishedPublications( $search, $publicationType );
			
	$message = $pu->{errmsg};

	return {
		params => {
			id => $id,
			publications => $publications,
			message => $message
		}
	};
}

1;
