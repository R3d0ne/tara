#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:util);
use Taranis::Assess;
use Taranis::Publication;
use Taranis::SoftwareHardware;
use Taranis::Session;
use Taranis::Template;
use strict;
use Encode;
use JSON;

use Data::Dumper;

my @EXPORT_OK = qw(searchSoftwareHardwareWrite getPublicationTemplate getTemplateText getPulicationPreview savePublicationNotes);

sub common_actions_export {
	return @EXPORT_OK; 
}

sub searchSoftwareHardwareWrite {
	my ( %kvArgs ) = @_;
	
	my $session = $kvArgs{session};
	
	my $sh = Taranis::SoftwareHardware->new();
	
	my $search = $kvArgs{search};
	my $publicationType = $kvArgs{publicationtype};
	my $publicationId = $kvArgs{publicationid};
	
	my $searchType = $kvArgs{searchtype};

	my @types = ( 'o' );

	if ( $searchType =~ /^platforms$/ ) {
		$sh->searchSH( search => $search, types => \@types );
	} else {
		$sh->searchSH( search => $search, not_type => [ 'o', 'w' ] );
	}

	my @sh_data;
	while ( $sh->nextObject() ) {
		my $record = $sh->getObject();
		$record->{version} = '' if ( !$record->{version} );
		push( @sh_data, $record );
	}	
	
	return { 
		params => { 
			data => \@sh_data,
			pubType => $publicationType,
			searchType => $searchType,
			publicationId => $publicationId
		}
	};
}


sub getPublicationTemplate {
	my ( %kvArgs ) = @_;
	my $message;
	my $templateOk = 0;
	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();	

	my $templateId = $kvArgs{templateid};
	my $tab = $kvArgs{tab};
	my $publicationId = $kvArgs{publicationid};
	my $publicationType = $kvArgs{publicationType};
	
	$tt->getTemplate( id => $templateId );
	my $template = $tt->{dbh}->fetchRow()->{tpl};
	
	my $template_fields = $tt->processPublicationTemplate( $template, $tab );
	
	if ( $tt->{tpl_error} ) {
		$message = $tt->{tpl_error};
	} else {
		$templateOk = 1;
	}
	
	return {
		params => { 
			template => $template_fields,
			tab => $tab,
			templateOk => $templateOk,
			publicationId => $publicationId,
			message => $message,
			publicationType => $publicationType
		}
	};
}

sub getTemplateText {
	my ( %kvArgs ) = @_;
	my $message;
	my $templateOk = 0;

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();	
	
	my $tab = $kvArgs{tab};
	my $publicationId = $kvArgs{publicationid};
	
	my $json_str = $kvArgs{templateData};

	$json_str =~ s/&quot;/"/g;
	
	my $templateText = $tt->processPublicationTemplateText( $json_str, $tab );

	if ( $tt->{tpl_error} ) {
		$message = $tt->{tpl_error};
	} else {
		$templateOk = 1;		
	}
	
	return {
		params => { 
			templateText => $templateText,
			tab => $tab,
			templateOk => $templateOk,
			publicationId => $publicationId,
			message => $message,
		}
	};
}

sub getPulicationPreview {
	my ( %kvArgs ) = @_;
	my ( $message, $previewText );
	my $previewOk = 0;

	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();	
	my $pu = Taranis::Publication->new();	
	my $tab = $kvArgs{tab};
  
	my $userid = $session->{cgisession}->param("userid");
	my $json = $kvArgs{publicationJson};

	$json =~ s/&quot;/"/g;

	my $formData = from_json( $json );

	my $publicationId = $kvArgs{publicationid};
	my $publication = $kvArgs{publication};
	my $publicationType = $kvArgs{publication_type};
	my $line_width = ( defined $kvArgs{line_width} ) ? $kvArgs{line_width} : 71;

	if ( $publicationType =~ /^xml$/i ) {
		$previewText = $pu->processPreviewXmlRT( $formData );
	} else {
		$previewText = $tt->processPreviewTemplateRT( 
			publication => $publication,
			publication_type => $publicationType,
			formData => $formData,
			line_width => $line_width
		);
	}
                                      
	if ( $previewText ) { 
		$previewOk = 1;
	} else {
		$message = $tt->{errmsg};
	}
	
	return {
		params => {
			message => $message,
			previewOk => $previewOk,
			publicationId => $publicationId,
			previewText => $previewText
		}
	};
}

sub savePublicationNotes {
	my ( %kvArgs ) = @_;

	my ( $message, $table );
	my $saveOk = 0;
	my $pu = Taranis::Publication->new();
	my $session = $kvArgs{session};
	my $publicationId = $kvArgs{publicationId};
	my $notes = $kvArgs{notes};
	
	for ( $kvArgs{publicationType} ) {
		if (/^advisory$/) { $table = 'publication_advisory'; }
	}

	if ( $pu->setPublicationDetails( table => $table, where => { publication_id => $publicationId }, notes => $notes ) ) {
		$saveOk = 1;
	} else {
		$message = $pu->{errmsg};
	}

	return {
		params => {
			message => $message,
			saveOk => $saveOk,
			publicationId => $publicationId
		}
	};
}


1;
