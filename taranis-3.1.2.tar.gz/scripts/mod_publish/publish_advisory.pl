#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:util);
use Taranis::Session;
use Taranis::Template;
use Taranis::Config;
use Taranis::Publication;
use Taranis::Publish;
use Taranis::Constituent_Group;
use Taranis::CallingList;
use Encode;
use strict;

use Data::Dumper;

my @EXPORT_OK = qw(
	openDialogPublishAdvisory getConstituentList closeAdvisoryPublication 
	checkPGPSigning publishAdvisory printCallingList saveCallingList
);

sub publish_advisory_export {
	return @EXPORT_OK;
}

sub openDialogPublishAdvisory {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl, $advisoryId );

	my $tt = Taranis::Template->new();
	my $pu = Taranis::Publication->new();
	my $pb  = Taranis::Publish->new();
	my $session = $kvArgs{session};
	
	my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{advisory}->{email};
	my $hasPublicationRights = $session->rightOnParticularization( $typeName );
	
	my $lockOk = 0;
	
	if ( $hasPublicationRights ) {
		my $publicationId = $kvArgs{id};
		
		my $checkProducts = 0;
		my $publication = $pu->getPublicationDetails(
			table => "publication_advisory",
			"publication_advisory.publication_id" => $publicationId
		);			

		# lock the advisory
		my $advisoryId = ( $publication->{govcertid} =~ /.*X+$/i ) ? $pb->getNextAdvisoryId() : $publication->{govcertid};
		my $pubclicationType = ( $publication->{version} > 1.00 ) ? "update" : "email";

		my $userId = $session->{cgisession}->param("userid");
		
		my $basedOnId = ( $publication->{based_on} ) ? ( $publication->{based_on} =~ /(.*?) \d\.\d\d$/ )[0] : undef;
		
		# check if advisory is locked
		if ( $pb->{dbh}->checkIfExists( { status => 4, type => $publication->{type} }, "publication" ) ) {
			$vars->{message} = "Advisory is locked";
			$lockOk = 0;

		# check if there are previous unsent versions
		} elsif ( $basedOnId && @{ $pu->loadPublicationsCollection( 
			table => 'publication_advisory',
			status => [0,1,2,4],
			based_on => { ilike => $basedOnId . ' %' },
			version => { '<' => $publication->{version} },
		) } ) {
			$vars->{message} = "Previous version(s) of the advisory have not been sent yet. Please sent or delete previous versions before sending the advisory.";
			$lockOk = 0;
		} else {

			if ( $basedOnId && @{ $pu->loadPublicationsCollection( 
				table => 'publication_advisory',
				status => [0,1,2,4],
				based_on => { ilike => $basedOnId . ' %' },
				version => { '>' => $publication->{version} },
			) } ) {
				$vars->{warning} = "Warning: There are newer unsent versions of the advisory.";
			}
			
			$pu->{dbh}->startTransaction();
			if ( $publicationId =~ /^\d+$/
				&& $pu->setPublication( id => $publicationId, status => 4, published_on => nowstring(9), opened_by => $userId )
				&& $pu->setPublicationDetails( table => 'publication_advisory', where => { publication_id => $publicationId }, 'govcertid' => $advisoryId )
			) {
          		my $publicationText;
          		if ( $publicationText = $tt->processPreviewTemplate( 'advisory', $pubclicationType, $publication->{id}, $publicationId, 0, 71 ) ) {
					if ( $pu->setPublication( id => $publicationId, contents => $publicationText ) ) {
						$lockOk = 1;
					} else {
						$lockOk = 0;
						$vars->{message} = $pu->{errmsg};
					}
          		} else {
					$lockOk = 0;
					$vars->{message} = $tt->{errmsg};
          		}
			} else {
				$lockOk = 0;
				$vars->{message} = $pu->{errmsg};
			}
			$pu->{dbh}->endTransaction();
		
			$pu->getLinkedToPublication(
				join_table_1 => { product_in_publication => "softhard_id" },
				join_table_2 => { software_hardware => "id" },
				"pu.id" => $publicationId
			);
		
			while ( $pu->nextObject() ) {
				$checkProducts = 1;
				push @{ $vars->{ products } }, $pu->getObject();
			}
		
			$pu->getLinkedToPublication(
				join_table_1 => { platform_in_publication => "softhard_id" },
				join_table_2 => { software_hardware => "id" },
				"pu.id" => $publicationId
			);			
		
			while ( $pu->nextObject() ) {
				push @{ $vars->{ platforms } }, $pu->getObject();
			}
		
			$vars->{check_products} = $checkProducts;
			$vars->{publication_id}	= $publication->{publication_id};
			$vars->{advisory_id} = $publication->{id};
	
			$vars->{advisory_heading} = "PUBLISH -- " . $advisoryId . " [v" . $publication->{version} . "]";
		}

		my $dialogContent = $tt->processTemplateNoHeader( 'publish_sh_selection.tt', $vars, 1 );
			
		return { 
			dialog => $dialogContent,
			params => {
				lockOk => $lockOk,
				publicationId => $publicationId,
				advisoryId => $advisoryId
			} 
		};	
	} else {
		$vars->{message} = 'No permission...';
		my $dialogContent = $tt->processTemplateNoHeader( 'dialog_no_right.tt', $vars, 1 );	
		return { dialog => $dialogContent };	
	}	
}

sub getConstituentList {
	my ( %kvArgs) = @_;
	my ( $vars, $tpl, $publicationId );

	my $tt = Taranis::Template->new();
	my $pu = Taranis::Publication->new();
	my $pb  = Taranis::Publish->new();
	my $session = $kvArgs{session};

	my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{advisory}->{email};
	my $hasPublicationRights = $session->rightOnParticularization( $typeName );
	
	if ( $hasPublicationRights ) {
		$publicationId = $kvArgs{id};
		my $selectionType = $kvArgs{selectionType};
		
		my $publication = $pu->getPublicationDetails(
			table => "publication_advisory",
			"publication_advisory.publication_id" => $publicationId
		);

		my @groups = @{ $pb->getConstituentGroupsForPublication( $publication->{type} ) };
		
		my @selectedGroups;

		if ( $selectionType =~ /^OR$/i ) {
			
			my @shList = ( ref( $kvArgs{sh} ) =~ /^ARRAY$/ )
				? @{ $kvArgs{sh} }
				: $kvArgs{sh};

			@selectedGroups = @{ $pb->getConstituentGroupIdsForPublication( $publicationId, @shList ) };
		} else {
			
			my $json_andSelection = $kvArgs{shList};
			$json_andSelection =~ s/&quot;/"/g;

			my $selections = from_json( $json_andSelection );

			@selectedGroups = @{ $pb->getConstituentGroupIdsForPublicationAndSelection( $publicationId, $selections ) };
		}
		
		GROUP_LOOP: 
		foreach my $group ( @groups ) {
			foreach my $id ( @selectedGroups ) {
				if ( $group->{id} eq $id ) {
					$group->{selected} = 1;
					next GROUP_LOOP;
				} else {
					$group->{selected} = 0;
				}
			}
		}
		
		$vars->{groups} = \@groups;
		$vars->{advisory_heading} = "PUBLISH -- " . $publication->{govcertid} . " [v" . $publication->{version} . "]";
		$vars->{preview} = $publication->{contents};
		$vars->{publication_id} = $publication->{publication_id};
	
		my $isHighHigh = ( $publication->{damage} =~ /^1$/ && $publication->{probability} =~ /^1$/ ) ? 1 : 0;

		my $dialogContent = $tt->processTemplateNoHeader( 'publish_advisory.tt', $vars, 1 );
		return { 
			dialog => $dialogContent,
			params => { 
				publicationId => $publicationId,
				isHighHigh => $isHighHigh
			} 
		};
	} else {
		$vars->{message} = 'No permission...';
		my $dialogContent = $tt->processTemplateNoHeader( 'dialog_no_right.tt', $vars, 1 );
		return { dialog => $dialogContent };
	}
}

sub closeAdvisoryPublication {
	my ( %kvArgs) = @_;
	my ( $message, $govcertId, $publicationType );
	
	my $releaseOk = 0;
	my $tt = Taranis::Template->new();
	my $pu = Taranis::Publication->new();
	my $session = $kvArgs{session};
	my $publicationId = $kvArgs{id};

	my $userId = $session->{cgisession}->param("userid");
	
	my $isAdmin = $session->getUserRights(
		entitlement => "admin_generic", 
		username => $userId 
	)->{admin_generic}->{write_right};

	my $advisory = $pu->getPublicationDetails( 
		table => "publication_advisory",
		"publication_advisory.publication_id" => $publicationId
	);

	if ( ( defined $kvArgs{releaseLock} && $isAdmin ) || ( $advisory->{opened_by} =~ $userId ) ) {
		my ( $status, $approvedBy );
		if ( exists( $kvArgs{setToPending} ) ) {
			$status = 0;
			$approvedBy = undef;
		} else {
			$status = 2;
			$approvedBy = $advisory->{approved_by};
		}
		
		if ( $advisory->{version} > 1.00 ) {
			$govcertId = $advisory->{govcertid};
			$publicationType = 'update';
		} else {
			my $advisoryPrefix = Taranis::Config->getSetting("advisory_prefix");
			my $advisoryIdLength = Taranis::Config->getSetting("advisory_id_length");
		
			my $x = "";
			for ( my $i = 1; $i <= $advisoryIdLength; $i++ ) { $x .= "X"; }																							 
			$govcertId = $advisoryPrefix . "-" . nowstring(6) . "-" . $x;
			$publicationType = 'email';
		}
		
		$pu->{dbh}->startTransaction();
		my $result;
		if ( $publicationId =~ /^\d+$/
			&& $pu->setPublication( id => $publicationId, status => $status, published_on => undef, published_by => undef, opened_by => undef, approved_by => $approvedBy )
			&& $pu->setPublicationDetails( table => "publication_advisory", where => { id => $advisory->{id} }, govcertid => $govcertId )
		) {
			my $advisoryText = $tt->processPreviewTemplate( "advisory", $publicationType, $advisory->{id}, $publicationId, 0, 71 );
			
			if ( $pu->setPublication( id => $publicationId, contents => $advisoryText ) ) {			
				$releaseOk = 1;
			} else {
				$message = "lock_release_failed";
			}
		} else {
			$message = "lock_release_failed";
		}
		$pu->{dbh}->endTransaction();
	} else {
		$message = 'Only admin users can unlock advisories!';
	}
		
	return {
		params => {
			message => $message,
			releaseOk => $releaseOk,
			publicationId => $publicationId
		}
	};
}

sub publishAdvisory {
	my ( %kvArgs) = @_;
	my ( $message, $vars );

	my $tt = Taranis::Template->new();
	my $pu = Taranis::Publication->new();
	my $pb = Taranis::Publish->new();
	my $cg = Taranis::Constituent_Group->new();
	my $cl = Taranis::CallingList->new();
	my $session = $kvArgs{session};
	
	my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{advisory}->{email};
	my $hasPublicationRights = $session->rightOnParticularization( $typeName );
	
	if ( $hasPublicationRights ) {
	
		my $publicationId = $kvArgs{id};
	
		my $advisoryText = $kvArgs{advisory_preview};
	
		my @groups = ( ref( $kvArgs{groups} ) =~ /^ARRAY$/ )
			? @{ $kvArgs{groups} }
			: $kvArgs{groups};
	
		my $publication = $pu->getPublicationDetails(
			table => "publication_advisory",
			"publication_advisory.publication_id" => $publicationId
		); 
	
		my $xmlText = $pu->processPreviewXml( $publication->{id} );
	
		my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{advisory}->{email};
		my $typeIdAdvisoryEmail = $pu->getPublicationTypeId( $typeName )->{id};
	
		$typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{advisory}->{taranis_xml};
		my $typeIdAdvisoryXml = $pu->getPublicationTypeId( $typeName )->{id};
	
		my $isHighHigh = 0;
		if ( 
			scalar( @groups ) eq 0
			|| !$pu->setPublication( 
					id => $publicationId, 
					contents => $advisoryText, 
					xml_contents => $xmlText, 
					status => 3,
					published_by => $session->{cgisession}->param("userid"),
					published_on => nowstring(10),
					opened_by => undef
				)	
		) {
			$vars->{message} = $pu->{errmsg} if ( $pu->{errmsg} ); 
			$vars->{message} .= " Advisory has not been sent.";
		} else {
	
			# get those who want to receive advisory emails
			my @wantEmail = @{ $pb->getIndividualsForSending( $typeIdAdvisoryEmail, \@groups ) };
			my @allIndividuals = @wantEmail;
	
			# get those who want to receive advisory in xml
			my @wantXml = @{ $pb->getIndividualsForSending( $typeIdAdvisoryXml, \@groups ) };
	
			#create a list of individuals which want to receive both email and, and a list for email only
			my @xmlAndEmail;
			my @emailOnly;
	
			EMAIL: 
			foreach my $e ( @wantEmail ) {
				foreach my $x ( @wantXml ) {
					if ( $e->{id} eq $x->{id} ) {
						push @xmlAndEmail, $x;
						undef $e;
						next EMAIL;
					}
				}
			}
	
			foreach ( @wantEmail ) {
				if ( $_ ) {
					push @emailOnly, $_;
				}
			}
	
			my %level = ( 1 => "H", 2 => "M", 3 => "L" );
	
			my $subject = $publication->{govcertid} 
				. " [v" . $publication->{version} . "]"
				. " [" . $level{ $publication->{probability} }
				. "/" . $level{ $publication->{damage} } . "]"
				. " " . decodeInput( \$publication->{title} );
		
			my @addresses;
			my @individualIds;
			my @results;
			my $sendingFailed = 0;
				
			# send advisory without XML attachment
			for ( my $i = 0; $i < @emailOnly; $i++ ) {
				push @addresses, $emailOnly[$i]->{emailaddress};
				push @individualIds, $emailOnly[$i]->{id};
			}
	
			if ( scalar( @addresses ) > 0 ) {
				my $response = $pb->sendPublication(
					addresses => \@addresses,
					subject => $subject,
					msg => decodeInput( \$advisoryText ),
					attach_xml => 0,
					pub_type => 'advisory'
				);
	
				if ( $response ne "OK" ) {
					$sendingFailed = 1;
				}
	
				my %result = ( 	
					response => $response, 
					inc_xml => 0 
				); 
					
				for ( my $i = 0; $i < @addresses; $i++ ) {
					push @{ $result{addresses} }, $addresses[$i];
					push @{ $result{ids} }, $individualIds[$i];										
				}
	
				push @results, \%result;
		
				undef @addresses;
				undef @individualIds;
			}
	
			my @addressesXml;
			my @individualIdsXml;
			
			# send advisory with XML attachment
			for ( my $i = 0; $i < @xmlAndEmail; $i++ ) {
				push @addressesXml, $xmlAndEmail[$i]->{emailaddress};
				push @individualIdsXml, $xmlAndEmail[$i]->{id};
			}
	
			if ( scalar( @addressesXml ) > 0 ) {
	
				my $xmlFilename = $publication->{govcertid} . $publication->{version};
				$xmlFilename =~ s/\.|\-//g;				
	
				my $response = $pb->sendPublication(
					addresses => \@addressesXml,
					subject => $subject,
					msg => decodeInput( \$advisoryText ),
					attach_xml	=> 1,
					xml_description => $xmlFilename,
					xml_filename => $xmlFilename ,
					xml_content => decodeInput( \$xmlText ),
					pub_type => 'advisory'
				);
	
				if ( $response ne "OK" ) {
					$sendingFailed = 1;
				}																						
	
				my %result = ( 	
					response => $response, 
					inc_xml => 1 
				); 
	
				for ( my $i = 0; $i < @addressesXml; $i++ ) {
					push @{ $result{addresses} }, $addressesXml[$i];
					push @{ $result{ids} }, $individualIdsXml[$i];										
				}
	
				push @results, \%result;
		
				undef @addressesXml;
				undef @individualIdsXml;
			}
	
			if ( $sendingFailed eq 0 ) {
				$vars->{results} = "Your message was successfully sent to the following addresses: \n\n";
		
				my $updatedAnalysisCount = $pb->setAnalysisToDoneStatus( $publicationId, $publication->{govcertid} );
	
				if ( !$pb->{errmsg} ) {
					$vars->{analysisUpdated} = $updatedAnalysisCount;
				} else {
					$vars->{analysisUpdateError} = $pb->{errmsg};
				}
	
				# in case of a High/High advisory create a callinglist
				if ( $publication->{damage} == 1 && $publication->{probability} == 1 ) {
					my %softwareHardwareIds;
					$pu->getLinkedToPublication(
						join_table_1 => { platform_in_publication  => 'softhard_id' },
						join_table_2 => { software_hardware => 'id' },
						'pu.id' => $publicationId
					);

					while ( $pu->nextObject() ) {
						my $platform = $pu->getObject();
						$softwareHardwareIds{ $platform->{id} } = 1;
					}

					$pu->getLinkedToPublication(
						join_table_1 => { product_in_publication  => 'softhard_id' },
						join_table_2 => { software_hardware => 'id' },
						'pu.id' => $publicationId
					);

					while ( $pu->nextObject() ) {
						my $product = $pu->getObject();
						$softwareHardwareIds{ $product->{id} } = 1;
					}
					
					foreach my $groupId ( @groups ) {
						if ( $cg->callForHighHigh( $groupId ) ) {
							my $addToCallingList = 0;
							my @groupSoftwareHardwareUsage = $cg->getSoftwareHardwareIds( $groupId ); 
							
							GROUPSOFTWAREHARDWARE:
							foreach my $groupSoftwareHardware ( @groupSoftwareHardwareUsage ) {
								if ( exists( $softwareHardwareIds{ $groupSoftwareHardware } ) ) {
									$addToCallingList = 1;
									last GROUPSOFTWAREHARDWARE;
								}
							}

							if ( $addToCallingList && !$cl->addCallingList( publication_id => $publicationId, group_id => $groupId ) ) {
								$vars->{callingListError} = $pb->{errmsg};
							}
						}
					}
				}
		
				foreach my $result ( @results ) {
					foreach my $id ( @{ $result->{ids} } ) {
						$pb->setSendingResult( 
							channel => 1,
							constituent_id => $id,
							publication_id => $publicationId,
							result => $result->{response}
						);
						
						if ( $result->{inc_xml} ) {
							$pb->setSendingResult( 
								channel => 5,
								constituent_id => $id,
								publication_id => $publicationId,
								result => $result->{response}
							);
						}
					}
					
					foreach my $address ( @{ $result->{addresses} } ) {
						$vars->{results} .= "- " . $address . " " . $result->{response} . "\n";
					}
				}

				# update all advisories with same based_on ID
				if ( $publication->{based_on} ) {
					my $basedOnId = ( $publication->{based_on} =~ /(.*?) \d\.\d\d$/ )[0];
					
					if ( 
						!$pu->setPublicationDetails( 
							table => "publication_advisory", 
							where => { based_on => { ilike => $basedOnId . ' %' }, deleted => 0 },
							govcertid => $publication->{govcertid} ) ) 
					{
						logErrorToSyslog( $pu->{errmsg} );
					}
				}
					
			} else {
				closeAdvisoryPublication( id => $publicationId, session => $session ); 
	
				$vars->{results} = "Your message has not been sent: \n\n";
	
				foreach my $result ( @results ) {
					foreach my $address ( @{ $result->{addresses} } ) {
						$vars->{results} .= "- " . $address . " " . $result->{response} . "\n";
					}
				}
			}
				
			$vars->{advisory_heading} = "PUBLISH -- " . $publication->{govcertid} . " [v" . $publication->{version} . "]";
	
			$isHighHigh = 1 if ( $publication->{damage} eq 1 && $publication->{probability} eq 1 ); 
		}
	
		my $dialogContent = $tt->processTemplateNoHeader( 'publish_advisory_result.tt', $vars, 1 );
			
		return { 
			dialog => $dialogContent,
			params => {
				publicationId => $publicationId,
				isHighHigh => $isHighHigh
			} 
		};
	} else {
		$vars->{message} = 'No permission...';
		my $dialogContent = $tt->processTemplateNoHeader( 'dialog_no_right.tt', $vars, 1 );	
		return { dialog => $dialogContent };	
	}	
}

sub printCallingList {
	my ( %kvArgs) = @_;
	my ( $message, $vars );

	my $tt = Taranis::Template->new();
	my $cl = Taranis::CallingList->new();
	my $session = $kvArgs{session};
	my $publicationId = $kvArgs{id};

	my $timeOfDay = ( defined( $kvArgs{t} ) && $kvArgs{t} =~ /(day|night)/ ) ? $kvArgs{t} : undef;

	$vars->{calling_list} = $cl->getCallingList( publication_id => $publicationId, time_of_day => $timeOfDay );
	
	my $callingList = $tt->processTemplateNoHeader( "publish_advisory_call_list.tt", $vars, 1 );

	return { params => { callingList => $callingList } };
}

sub saveCallingList {
	my ( %kvArgs) = @_;
	my ( $message, $vars );

	my $tt = Taranis::Template->new();
	my $cl = Taranis::CallingList->new();
	my $session = $kvArgs{session};
	my $publicationId = $kvArgs{id};

	my $timeOfDay = ( defined( $kvArgs{t} ) && $kvArgs{t} =~ /(day|night)/ ) ? $kvArgs{t} : undef;

	$vars->{calling_list} = $cl->getCallingList( publication_id => $publicationId, time_of_day => $timeOfDay );
	
	print "Content-disposition: attachment; filename=\"callinglist.txt\";\n"
		. "Content-Type: text/plain;\n\n"
		. $tt->processTemplateNoHeader( "publish_call_list_savefile.tt", $vars, 1 );

	return {};	
}

1;
