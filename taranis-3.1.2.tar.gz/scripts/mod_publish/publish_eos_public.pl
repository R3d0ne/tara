#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:util);
use Taranis::Template;
use Taranis::Config;
use Taranis::Publication;
use Taranis::Publish;
use Taranis::Users;
use strict;

use Date::Format;
use Date::Parse;

my @EXPORT_OK = qw(	openDialogPublishEos_public publishEosPublic );

sub publish_eos_public_export {
	return @EXPORT_OK;
}

# - session (session object)
# - id (integer)
sub openDialogPublishEos_public {
	my ( %kvArgs) = @_;
	my ( $vars );

	my $tt = Taranis::Template->new();
	my $pu = Taranis::Publication->new();
	my $pb = Taranis::Publish->new();
	my $session = $kvArgs{session};

	my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{eos}->{email_public};
	my $hasPublicationRights = $session->rightOnParticularization( $typeName );

	if ( $hasPublicationRights ) {
		my $publicationId = $kvArgs{id};

		my $publication = $pu->getPublicationDetails(
			table => "publication_endofshift",
			"publication_endofshift.publication_id" => $publicationId
		);

		my $timeframeBegin = time2str("%A %d-%m-%Y %H:%M", str2time($publication->{timeframe_begin}) );
		my $timeframeEnd = time2str("%A %d-%m-%Y %H:%M", str2time($publication->{timeframe_end}) );
		  
		$vars->{eos_heading} = "END OF SHIFT - $timeframeBegin - $timeframeEnd"; 
		$vars->{preview} = $publication->{contents};
		$vars->{publication_id} = $publication->{publication_id};
		$vars->{eos_id} = $publication->{id};
		$vars->{publicationType} = 'eos_public';
		
		my $dialogContent = $tt->processTemplateNoHeader( 'publish_eos.tt', $vars, 1 );

		return { 
			dialog => $dialogContent,
			params => {
				publicationId => $publicationId,
			} 
		};
	} else {
		$vars->{message} = 'No permission...';
		my $dialogContent = $tt->processTemplateNoHeader( 'dialog_no_right.tt', $vars, 1 );	
		return { dialog => $dialogContent };	
	}	
}

sub publishEosPublic {
	my ( %kvArgs) = @_;
	my ( $message, $vars );

	my $tt = Taranis::Template->new();
	my $pu = Taranis::Publication->new();
	my $pb = Taranis::Publish->new();
	my $session = $kvArgs{session};
	my $us = Taranis::Users->new(); 

	my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{eos}->{email_public};
	my $hasPublicationRights = $session->rightOnParticularization( $typeName );

	if ( $hasPublicationRights ) {

		my $publicationId = $kvArgs{id};
		my $eosText = $kvArgs{eos_preview};
	
		my $publication = $pu->getPublicationDetails(
			table => "publication_endofshift",
			"publication_endofshift.publication_id" => $publicationId
		);

		my $timeframeBegin = time2str("%A %d-%m-%Y %H:%M", str2time( $publication->{timeframe_begin} ) );
		my $timeframeEnd = time2str("%A %d-%m-%Y %H:%M", str2time( $publication->{timeframe_end} ) );
		
		my $typeId = $pu->getPublicationTypeId( $typeName )->{id};
	
		my $userId = $session->{cgisession}->param("userid");
		
		if ( 
			!$pu->setPublication( 
					id => $publicationId, 
					contents => $eosText, 
					status => 3, 
					published_by => $userId,
					published_on => nowstring(10) 
				)	
		) {
			$vars->{message} = $pu->{errmsg} if ( $pu->{errmsg} ); 
			$vars->{message} .= " End-of-shift has not been sent.";
		}	else {
	
			my $pgpSigningSetting = Taranis::Config->getSetting("pgp_signing_endofshift");
			
			my $subject = "End-of-Shift - $timeframeBegin - $timeframeEnd";
			
			my ( @addresses, @individualIds, @results );
			my $sendingFailed = 0;
			my $user = $us->getUser( $session->{cgisession}->param("userid") );
	
			my $response = $pb->sendPublication(
				subject => $subject,
				msg => decodeInput( \$eosText ),
				attach_xml => 0,
				pub_type => 'eos_public',
				from_name => $user->{mailfrom_sender}
			);

	
			if ( $response ne "OK" ) {
				$vars->{results} = "Your message has not been sent: \n\n";

				if ( $pgpSigningSetting =~ /^ON$/i ) {
					$eosText =~ s/^-----BEGIN.*Hash:(?:.*?)\n(.*)-----BEGIN PGP SIGNATURE-----.*$/$1/is;
					$eosText =~ s/^- //gm;
		      	}
	
				if ( !$pu->setPublication( 
						id => $publicationId, 
						contents => trim( $eosText ),
						status => 2, 
						published_by => undef,
						published_on => undef 
					)
				) {
					$vars->{message} = $pu->{errmsg} if ( $pu->{errmsg} ); 
					$vars->{message} .= " End-of-shift has not been sent.";
				}	

			} else {
				$vars->{results} .= "Your message was successfully sent to the End-of-Shift public list. \n\n";
			}

			$vars->{eos_heading} = "END-OF-SHIFT - $timeframeBegin - $timeframeEnd";
		}
		
		my $dialogContent = $tt->processTemplateNoHeader( 'publish_eos_result.tt', $vars, 1 );
			
		return { 
			dialog => $dialogContent,
			params => {
				publicationId => $publicationId,
			} 
		};
	} else {
		$vars->{message} = 'No permission...';
		my $dialogContent = $tt->processTemplateNoHeader( 'dialog_no_right.tt', $vars, 1 );	
		return { dialog => $dialogContent };	
	}	
}
1;
