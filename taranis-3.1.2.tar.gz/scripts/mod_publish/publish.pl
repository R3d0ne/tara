#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:util);
use Taranis::Session;
use Taranis::Template;
use Taranis::Publication;
use Taranis::Publish;
use strict;

use Data::Dumper;

my @EXPORT_OK = qw(displayPublishOptions displayPublish checkPGPSigning);

sub publish_export {
	return @EXPORT_OK;
}

my %pageOptions = (
	advisory => { 
		id_column_name 		=> "Advisory ID", 
		title_column_name 	=> "Advisory title", 
		table 				=> "publication_advisory",
		type_id 			=> ["govcertid", "version_str"],
		title_content 		=> ["pub_title"],
		particularization 	=> "advisory (email)",
		page_title 			=> "Advisory Email",
		pgp_setting			=> "pgp_signing_advisory"
	},
	eos => { 
		id_column_name 		=> "Publication", 
		title_column_name 	=> "Timeframe", 
		table 				=> "publication_endofshift",
		type_id 			=> ["pub_title"],
		title_content 		=> ["timeframe_str"],                                    
		particularization 	=> "end-of-shift (email)",
		page_title 			=> "End-of-Shift Confidential",
		pgp_setting			=> "pgp_signing_endofshift"
	},
	eos_public => { 
		id_column_name		=> "Publication", 
		title_column_name	=> "Timeframe", 
		table				=> "publication_endofshift",
		type_id				=> [ "pub_title"],
		title_content		=> ["timeframe_str"],                                    
		particularization	=> "end-of-shift (email public)",
		page_title			=> "End-of-Shift Public",
		pgp_setting			=> "pgp_signing_endofshift"		
	}, 	
	eow => { 
		id_column_name 		=> "Publication", 
		title_column_name 	=> "Created on", 
		table 				=> "publication_endofweek",
		type_id 			=> ["pub_title"],
		title_content 		=> ["created_on_str"],
		particularization 	=> "end-of-week (email)",
		page_title 			=> "End-of-Week",
		pgp_setting			=> "pgp_signing_endofweek"
	},
);

sub displayPublishOptions {
	my ( %kvArgs) = @_;
	my ( $vars );
	my $tt = Taranis::Template->new();
	
	my $htmlContent = $tt->processTemplateNoHeader('publish_options.tt', $vars, 1);
	
	my @js = ('js/publish.js');
	
	return { content => $htmlContent,  filters => '<div></div>', js => \@js };
}

# - session (session object)
# - hidden-page-number (integer)
# - pub_type (publication type)
sub displayPublish {
	my ( %kvArgs) = @_;
	my ( $tpl );
	
	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	my $pu = Taranis::Publication->new();
		
	my $pageNumber = ( exists( $kvArgs{'hidden-page-number'} ) && $kvArgs{'hidden-page-number'} =~ /^\d+$/ )
		? $kvArgs{'hidden-page-number'}
		: 1;

	my $type = ( exists( $pageOptions{ $kvArgs{pub_type} } ) ) ? $kvArgs{pub_type} : "advisory";

	my $publicationType = $pu->getPublicationTypeId( $pageOptions{ $type }->{particularization} );
	my $typeId = ( $publicationType ) ? $publicationType->{id} : undef;
	
	if ( !$typeId ) {
		logErrorToSyslog("displayPublish: type id not found for type '$type', could be configuration error...");
		return { content => '<div>type id not found for type</div>', filters => '<div></div>' };
	}	
	
	my $vars = getPublishSettings( session => $session, type => $type );

	if ( $vars->{hasRightsForPublish} ) {

		my $publications = $pu->loadPublicationsCollection( 
			status => [2],
			table => $pageOptions{ $type }->{table},
			hitsperpage => 100,
			offset => ( $pageNumber - 1 ) * 100,	
			date_column	=> "created_on",
			search => "",
			publicationType => $typeId																						
		);
	
		foreach my $publication ( @$publications ) {
			foreach ( @{ $pageOptions{ $type }->{type_id} } ) {
				$publication->{specific_id} .= ( $publication->{ $_ } ) ? $publication->{ $_ } . " " : "N/A";	
			}
			
			foreach ( @{ $pageOptions{ $type }->{title_content} } ) {
				$publication->{title_content} .= ( $publication->{ $_ } ) ? $publication->{ $_ } . " " : "N/A ";
			}
		}

		$vars->{publications} = $publications;
		$vars->{pub_type} = $type;
  		$vars->{page_title} = $pageOptions{ $type }->{page_title};
		$vars->{page_columns} = $pageOptions{ $type };
		$vars->{numberOfResults} = $pu->{result_count};

		$tpl = 'publish.tt';
	} else {
		$tpl = 'no_permission.tt';
	}

	my $htmlContent = $tt->processTemplateNoHeader( $tpl, $vars, 1 );
	my $htmlFilters = $tt->processTemplateNoHeader('publish_filters.tt', $vars, 1);
	
	my @js = (
		'js/publish_advisory.js',
		'js/publish_eow.js',
		'js/publish_eos.js',
		'js/publish_eos_public.js',
		'js/publish.js'
	);
	
	return { 
		content => $htmlContent, 
		filters => $htmlFilters, 
		js => \@js
	};
}

# - session (session object)
# - id (integer)
# - publicationType (text)
# - publicationText (text)
sub checkPGPSigning {
	my ( %kvArgs) = @_;
	my ( $message );
	my $pgpSigningOk = 0;
	
	my $publicationId = $kvArgs{id};
	my $publicationType = $kvArgs{publicationType};	
	my $publicationText = $kvArgs{publicationText};

	$publicationText =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	$publicationText =~ s/&#39;/'/g;
	
	my $pgpSigningSetting = Taranis::Config->getSetting( $pageOptions{ $publicationType }->{pgp_setting} );

	my $pu = Taranis::Publication->new();
	my $table = $pageOptions{ $publicationType }->{table};
	my $publication = $pu->getPublicationDetails( 
		table => $table,
		$table . ".publication_id" => $publicationId
	);
	
	my $from_db = decodeInput( \$publication->{contents} );
	$from_db =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	
	if ( $pgpSigningSetting !~ /^ON$/i ) {

		$from_db =~ s/\s//g;
		$publicationText =~ s/\s//g;
		
		if ( $from_db ne decodeInput( \$publicationText ) ) {
			$message = "The contents of the publication have been changed.\nThe publication cannot be sent with these changes.";
		} else {
			$pgpSigningOk = 1;		
		}

  	} else {
	
		$message = "The publication has not been signed with PGP.";
			
		if ( $publicationText =~ /^-----BEGIN PGP SIGNED MESSAGE-----\nHash:(?:.*?)\n(.*)-----BEGIN PGP SIGNATURE-----(.*)-----END PGP SIGNATURE-----$/is ) {
			my $org = $1;
			$org =~ s/\s//g;
	
			# PGP adds '- ' to a line when a line starts with '--', this is corrected below
			my $pgpComparisonReady = "";
			foreach my $line ( split( "\n", $from_db ) ) {
				if ( $line =~ /^-/ ) {
					$line = "- " . $line;
				} 
				$pgpComparisonReady .= $line ;
			}
			
			$pgpComparisonReady =~ s/\s//g;

			if ( $pgpComparisonReady ne decodeInput( \$org ) ) {			
				$message = "The contents of the publication have been changed.\nThe publication cannot be sent with these changes.";
			} else {
				$pgpSigningOk = 1;		
			}
		}
  	}
  	
  	return { 
  		params => {
  			message => $message,
  			pgpSigningOk => $pgpSigningOk,
  			publicationId => $publicationId
  		}
  	};
}


## HELPER SUB ##
sub getPublishSettings {
	my ( %kvArgs ) = @_;
	my $session = $kvArgs{session};
	my $settings = {};
	
	my $type = $kvArgs{type}; 

	my $hasRightsForPublish = 0;
	if ( ref( $pageOptions{$type}->{particularization} ) eq 'ARRAY' ) {
		foreach my $particularization ( @{ $pageOptions{$type}->{particularization} } ) {
			if ( !$hasRightsForPublish ) {
				$hasRightsForPublish = $session->rightOnParticularization( $particularization );
			}
		}
	} else {
		$hasRightsForPublish = $session->rightOnParticularization( $pageOptions{$type}->{particularization} );	
	}

	$settings->{pub_type} = $type;
	$settings->{page_columns} = $pageOptions{ $type };
	$settings->{write_right} = $session->right("write");
	$settings->{execute_right} = $session->right("execute");
	$settings->{is_admin} = $session->getUserRights( 
		entitlement => "admin_generic", 
		username => $session->{cgisession}->param("userid") 
	)->{admin_generic}->{write_right};
	
	$settings->{pageSettings} = $session->getSessionUserSettings();
	$settings->{hasRightsForPublish} = $hasRightsForPublish;

	return $settings;
}


1;
