#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:util);
use Taranis::Session;
use Taranis::Template;
use Taranis::Config;
use Taranis::Publication;
use Taranis::Publish;
use Taranis::Users;
use strict;

my @EXPORT_OK = qw(	openDialogPublishEow publishEow );

sub publish_eow_export {
	return @EXPORT_OK;
}

# - session (session object)
# - id (integer)
sub openDialogPublishEow {
	my ( %kvArgs) = @_;
	my ( $vars );

	my $tt = Taranis::Template->new();
	my $pu = Taranis::Publication->new();
	my $pb = Taranis::Publish->new();
	my $session = $kvArgs{session};

	my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{eow}->{email};
	my $hasPublicationRights = $session->rightOnParticularization( $typeName );

	if ( $hasPublicationRights ) {
		my $publicationId = $kvArgs{id};

		my $publication = $pu->getPublicationDetails(
			table => "publication_endofweek",
			"publication_endofweek.publication_id" => $publicationId
		);

		my @groups = @{ $pb->getConstituentGroupsForPublication( $publication->{type} ) };

		$vars->{groups} = \@groups;
		$vars->{eow_heading} = "PUBLISH -- END OF WEEK"; 
		$vars->{preview} = $publication->{contents};
		$vars->{publication_id} = $publication->{publication_id};
		$vars->{eow_id} = $publication->{id};

		my $dialogContent = $tt->processTemplateNoHeader( 'publish_eow.tt', $vars, 1 );

		return { 
			dialog => $dialogContent,
			params => {
				publicationId => $publicationId,
			} 
		};
	} else {
		$vars->{message} = 'No permission...';
		my $dialogContent = $tt->processTemplateNoHeader( 'dialog_no_right.tt', $vars, 1 );	
		return { dialog => $dialogContent };	
	}	
}

sub publishEow {
	my ( %kvArgs) = @_;
	my ( $message, $vars );

	my $tt = Taranis::Template->new();
	my $pu = Taranis::Publication->new();
	my $pb = Taranis::Publish->new();
	my $session = $kvArgs{session};
	my $us = Taranis::Users->new(); 

	my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{eow}->{email};
	my $hasPublicationRights = $session->rightOnParticularization( $typeName );

	if ( $hasPublicationRights ) {

		my $publicationId = $kvArgs{id};
		my $eowText = $kvArgs{eow_preview};
		my @groups = $kvArgs{groups};
	
		my $publication = $pu->getPublicationDetails(
			table => "publication_endofweek",
			"publication_endofweek.publication_id" => $publicationId
		); 
			
	
		my $typeId = $pu->getPublicationTypeId( $typeName )->{id};
	
		if ( 
			scalar( @groups ) eq 0
			|| !$pu->setPublication( 
					id => $publicationId, 
					contents => $eowText, 
					status => 3, 
					published_by => $session->{cgisession}->param("userid"),
					published_on => nowstring(10) 
				)	
		) {
			$vars->{message} = $pu->{errmsg} if ( $pu->{errmsg} ); 
			$vars->{message} .= " End-of-week has not been sent. (Maybe no groups were selected for sending)";
		}	else {
	
			# get those who want to receive eow emails
			my @wantEmail = @{ $pb->getIndividualsForSending( $typeId, \@groups ) };
			my $pgpSigningSetting = Taranis::Config->getSetting("pgp_signing_endofweek");
			
			my $subject = "End-of-Week";
			my ( @addresses, @individualIds, @results );
			my $sendingFailed = 0;
			my $user = $us->getUser( $session->{cgisession}->param("userid") );
	
			# send eow to 10 persons at a time
			for ( my $i = 0; $i < @wantEmail; $i++ ) {
				if ( ( $i % 10 == 9 ) || ( ( scalar( @wantEmail ) - $i ) <  2 )  ) {
					push @addresses, $wantEmail[$i]->{emailaddress};
					push @individualIds, $wantEmail[$i]->{id};
	
					my $response = $pb->sendPublication(
						addresses => \@addresses,
						subject => $subject,
						msg => decodeInput( \$eowText ),
						attach_xml => 0,
						pub_type => 'eow',
						from_address => $user->{mailfrom_email},
						from_name => $user->{mailfrom_sender}
					);
	
					if ( $response ne "OK" ) {
						$sendingFailed = 1;
					}
	
					my %result = ( response => $response ); 
	
					for ( my $i = 0; $i < @addresses; $i++ ) {
						push @{ $result{addresses} }, $addresses[$i];
						push @{ $result{ids} }, $individualIds[$i];
					}
						
					push @results, \%result;
	
					undef @addresses;
					undef @individualIds;
				} else {
					push @addresses, $wantEmail[$i]->{emailaddress};
					push @individualIds, $wantEmail[$i]->{id};
				}
			}
	
			if ( $sendingFailed eq 0 ) {
				$vars->{results} = "Your message was successfully sent to the following addresses: \n\n";
	
				foreach my $result ( @results ) {
					foreach my $id ( @{ $result->{ids} } ) {
						$pb->setSendingResult( 
							channel => 1,
							constituent_id => $id,
							publication_id => $publicationId,
							result => $result->{response}
						);
					}
					
					foreach my $address ( @{ $result->{addresses} } ) {
						$vars->{results} .= "- " . $address . " " . $result->{response} . "\n";
					}
				}
			} else {
				$vars->{results} = "Your message has not been sent: \n\n";
	
				foreach my $result ( @results ) {
					foreach my $address ( @{ $result->{addresses} } ) {
						$vars->{results} .= "- " . $address . " " . $result->{response} . "\n";
					}
				}
		
				if ( $pgpSigningSetting =~ /^ON$/i ) {
					$eowText =~ s/^-----BEGIN.*Hash:(?:.*?)\n(.*)-----BEGIN PGP SIGNATURE-----.*$/$1/is;
					$eowText =~ s/^- //gm;
		      	}
	
				if ( !$pu->setPublication( 
						id => $publicationId, 
						contents => trim( $eowText ),
						status => 2, 
						published_by => undef,
						published_on => undef 
					)
				) {
					$vars->{message} = $pu->{errmsg} if ( $pu->{errmsg} ); 
					$vars->{message} .= " End-of-week has not been sent.";
				}	
			}
					
			$vars->{eow_heading} = "END-OF-WEEK";
				
		}
		
		my $dialogContent = $tt->processTemplateNoHeader( 'publish_eow_result.tt', $vars, 1 );
			
		return { 
			dialog => $dialogContent,
			params => {
				publicationId => $publicationId,
			} 
		};
	} else {
		$vars->{message} = 'No permission...';
		my $dialogContent = $tt->processTemplateNoHeader( 'dialog_no_right.tt', $vars, 1 );	
		return { dialog => $dialogContent };	
	}	
}

#sub closeEowPublication {
#	my ( %kvArgs) = @_;
#	my ( $message, $publicationType );
#	
#	my $releaseOk = 0;
#	my $tt = Taranis::Template->new();
#	my $pu = Taranis::Publication->new();
#	my $session = $kvArgs{session};
#	my $publicationId = $kvArgs{id};
#
#	my $userId = $session->{cgisession}->param("userid");
#	
#	my $isAdmin = $session->getUserRights(
#		entitlement => "admin_generic", 
#		username => $userId 
#	)->{admin_generic}->{write_right};
#
#	my $eow = $pu->getPublicationDetails( 
#		table => "publication_endofweek",
#		"publication_endofweek.publication_id" => $publicationId
#	);
#
#	if ( ( defined $kvArgs{releaseLock} && $isAdmin ) || ( $eow->{opened_by} =~ $userId ) ) {
#		my ( $status, $approvedBy );
#		if ( exists( $kvArgs{setToPending} ) ) {
#			$status = 0;
#			$approvedBy = undef;
#		} else {
#			$status = 2;
#			$approvedBy = $eow->{approved_by};
#		}
#		
#		$pu->{dbh}->startTransaction();
#		my $result;
#		if ( $publicationId =~ /^\d+$/
#			&& $pu->setPublication( id => $publicationId, status => $status, published_on => undef, published_by => undef, opened_by => undef, approved_by => $approvedBy )
#		) {
#			$releaseOk = 1;
#		} else {
#			$message = "lock_release_failed";
#		}
#		$pu->{dbh}->endTransaction();
#	} else {
#		$message = 'Only admin users can unlock this publication!';
#	}
#		
#	return {
#		params => {
#			message => $message,
#			releaseOk => $releaseOk,
#			publicationId => $publicationId
#		}
#	};	
#}

1;
