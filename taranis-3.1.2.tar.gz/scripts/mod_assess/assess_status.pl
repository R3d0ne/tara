#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Assess;
use URI::Escape;
use strict;

my @EXPORT_OK = qw(setStatus);

sub assess_status_export {
	return @EXPORT_OK; 
}

sub setStatus {
	my ( %kvArgs ) = @_;

	my ( $message, @ids, $status );
	my $session = $kvArgs{session};	
	my $statusIsSet = 0;
	my $as = Taranis::Assess->new();

	my $statusDictionary = { 'read' => 1, 'important' => 2 }; 

	if ( $session->right("write") ) {

		if ( exists( $kvArgs{status} ) && $kvArgs{status} =~ /^(read|important)$/i ) {
			$status = lc( $kvArgs{status} );
			if ( ref( $kvArgs{id} ) =~ /^ARRAY$/ ) {
				@ids = @{ $kvArgs{id} };
			} else {
				push @ids, $kvArgs{id};
			}
	
			$as->{dbh}->startTransaction();
			foreach my $id ( @ids ) {
				$id = uri_unescape( $id );
				if ( $as->setItemStatus( digest => $id, status => $statusDictionary->{ $status } ) ) {
				  $statusIsSet = 1;
				} else {
				  $message = $as->{errmsg};
				}
			}
			$as->{dbh}->endTransaction();
			
		} else {
			$message = "Illegal action!! (assess_status)";
		}	

	} else {
		$message = "Sorry, you do not have enough privileges to to change item status...";
	}
	
	return { 
		params => { 
			message => $message,
			status => $status,
			status_is_set => $statusIsSet,
			ids => \@ids
		}
	};
}

1;
