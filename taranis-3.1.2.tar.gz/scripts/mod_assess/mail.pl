#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:all);
use Taranis::Config;
use Taranis::Assess;
use Taranis::Template;
use Taranis::Users;
use URI::Escape;
use Mail::Sender;
use MIME::Parser;
use HTML::Entities;
use Encode; 
use strict;

my @EXPORT_OK = qw(displayMailAction sendMail);

sub mail_export {
	return @EXPORT_OK; 
}

sub displayMailAction {
	my ( %kvArgs ) = @_;
	my ( $vars, $tpl );
	my $session = $kvArgs{session};	

	my $as = Taranis::Assess->new();
	my $tt = Taranis::Template->new();
	
	my $digest = ( exists( $kvArgs{digest} ) ) ? uri_unescape( $kvArgs{digest} ) : undef;
	if ( $session->right("execute") ) {
		
		if ( my $item = $as->getItem( $digest ) ) {
			
			my $cfg	= Taranis::Config->new();		
			my $description = $item->{description};
	
			if ( $item->{is_mail} ) {
				
				my $parser = MIME::Parser->new();
				my $parserOutputDir = $cfg->{mimeparser_outputdir} || '/tmp';

				$parser->output_dir( $parserOutputDir );
				
				my $emailId = $item->{'link'};
				
				$emailId =~ s/.*?([0-9]*)$/$1/;
				
				my $emailItem = $as->getMailItem( $emailId );
				
				my $decodedMessage = HTML::Entities::decode( $emailItem->{body} );
				
				my $entity;
				eval{ $entity = $parser->parse_data( $decodedMessage ) } if ( $decodedMessage );
		
				$description = trim( HTML::Entities::encode( decodeMimeEntity( $entity, 1, 1 ) ) );
			}

			my @mailto_addressess = split( ";", $cfg->{maillist} ); 
				for ( my $i = 0; $i < @mailto_addressess; $i++ ) {
				$mailto_addressess[$i] = trim( $mailto_addressess[$i] );
			}
	
			my $user = Taranis::Users->new();
			my $user_settings = $user->getUser( $session->{cgisession}->param("userid") );	
	
			$vars->{item_id}		 = $digest;
			$vars->{result} 		 = "";
			$vars->{mailto} 		 = \@mailto_addressess;
			$vars->{mailfrom_sender} = $user_settings->{mailfrom_sender};
			$vars->{mailfrom_email}  = $user_settings->{mailfrom_email};
			$vars->{title} 			 = $item->{title}; 
			$vars->{body} 			 = $description;
			
			if ( $item->{is_mail} ) {
				my $uriHost = $ENV{'HTTP_REFERER'};
				$vars->{'link'} = $uriHost . 'assess/show_mail/displayMail/';
			}
			
			 $vars->{'link'} .= $item->{'link'};
			 
		} else {
			$vars->{message} = $as->{errmsg};
		}
		
		$tpl = 'mail.tt';
		
	} else {
		$tpl = 'dialog_no_right.tt';
		$vars->{message} = 'Sorry, you do not have enough privileges to send this email...';
	}

	my $dialogContent = $tt->processTemplateNoHeader($tpl, $vars, 1);

	return { dialog => $dialogContent };		
}

sub sendMail {
	my ( %kvArgs ) = @_;
	my $session = $kvArgs{session};	
	my $message;
		
	if ( $session->right("execute") ) {

		my $as = Taranis::Assess->new();
		my $cfg = Taranis::Config->new();
		my $user = Taranis::Users->new();
		my $user_settings = $user->getUser( $session->{cgisession}->param("userid") );
	
		my $item_id = uri_unescape( $kvArgs{item_id} );

		my $isMailed = 0;

		my @addresses = ( ref( $kvArgs{mailto} ) =~ /^ARRAY$/ ) ? @{ $kvArgs{mailto} } : $kvArgs{mailto};

		foreach my $address ( @addresses ) {

			my $from = encode( "MIME-Header", HTML::Entities::decode( $user_settings->{mailfrom_sender} ) );
			
			my $sender = new Mail::Sender {
				smtp => $cfg->{smtpserver},
				user => $cfg->{smtpuser},
				pass => $cfg->{smtppass},
				port => $cfg->{smtpport},
				from =>  $from . " <". $user_settings->{mailfrom_email} . ">"
			};

			if ( ref( $sender ) ) {

				$sender->Open({
					to		=> $address,
					subject => encode( "MIME-Header", HTML::Entities::decode( $kvArgs{subject} ) ),
					ctype 	=> 'text/plain',
					charset => 'UTF-8'
				});
				$sender->SendLineEnc( decodeInput( \$kvArgs{description} ) );
				$sender->Close();
		
				if ( !$sender->{error} ) {
					$message .= "E-mail to " . $address . " was succesfully sent!<br>";
					$isMailed = 1;
				} else {
					$message = "Error for address ". $address ." : " . $Mail::Sender::Error . "<br>";
				}
			} else {
				$message .= "Error for address ". $address ." : " . $Mail::Sender::Error . "<br>";
			}
		}
		
		
		if ( $isMailed ) {
			if ( !$as->setIsMailedFlag( $item_id ) ) {
				$message .= "Error updating statistics mailed setting: " . $as->{errmsg} . "<br>";
			}
		}
		
	} else {
		$message = '<div id="dialog-error">Sorry, you do not have enough privileges to send this email...</div>';
	}

	my $dialogContent = '<div class="dialog-form-wrapper block">' . $message . '</div>';
	return { dialog => $dialogContent };
	
}
1;
