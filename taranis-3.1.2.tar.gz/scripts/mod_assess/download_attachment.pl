#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Assess;
use Taranis::Config;
use Taranis qw(:all);
use strict;
use MIME::Parser;
use HTML::Entities;

my @EXPORT_OK = qw(downloadAttachment);

sub download_attachment_export {
	return @EXPORT_OK; 
}

sub downloadAttachment {
	my ( %kvArgs ) = @_;
	my $session = $kvArgs{session};

	my ( $messageEntity, $attachmentEntity );
	my $parser = MIME::Parser->new();
	
	my $outputDir = Taranis::Config->getSetting("downloadpath" ) || "/tmp"; 
	$parser->output_dir( $outputDir );

	my $as = Taranis::Assess->new();
	
	my $mailItemId = $kvArgs{id};
	my $attachmentName = $kvArgs{attachmentName};

	my $message = $as->getMailItem( $mailItemId );

	my $decodedMessage = HTML::Entities::decode( $message->{body} );

	eval{ $messageEntity = $parser->parse_data( $decodedMessage ) } if ( $decodedMessage );

	my $attachment = $as->getAttachment( $messageEntity, $attachmentName );

	eval{ $attachmentEntity = $parser->parse_data( $attachment ) } if ( $attachment );
	
	my $attachmentDecoded = decodeMimeEntity( $attachmentEntity, 1, 0 );

	my $head = $attachmentEntity->head();
	
	my $contentType	= $head->get( 'content-type' );
	my $contentDisposition = $head->get( 'content-disposition' );
	my $contentTransferEncoding = $head->get( 'content-transfer-encoding' );

	$contentType =~ s/\n//g;
	$contentDisposition =~ s/\n//g if ( $contentDisposition );
	$contentTransferEncoding =~ s/\n//g if ( $contentTransferEncoding );
	
	if ( $contentType =~ /^(image|audio|video)/i || !$contentDisposition ) {
		$contentDisposition = "attachment; filename=\"$attachmentName\"";
	}
	
	print "Content-disposition: " . $contentDisposition . "\n"
		. "Content-transfer-encoding: " . $contentTransferEncoding . "\n"
		. "Content-type: " . $contentType . "\n\n"
		. $attachmentDecoded;

	return {};
}
1;
