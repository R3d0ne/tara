#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Assess;
use Taranis::Analysis;
use Taranis::Template; 
use URI::Escape;
use JSON;
use strict;

my @EXPORT_OK = qw(addAnalysis displayBulkAnalysis);

sub assess_bulk_export {
	return @EXPORT_OK; 
}

sub displayBulkAnalysis {
	my ( %kvArgs ) = @_;
	my ( $message, $vars );
	my $session = $kvArgs{session};	
	my $tt = Taranis::Template->new();

	my $analysis_rights = $session->getUserRights( 
		entitlement => "analysis", 
		username => $session->{cgisession}->param("userid") 
	)->{analysis};
	
	$vars->{hasClusteredItems} = $kvArgs{hasClusteredItems};
	
	if ( $analysis_rights->{particularization} ) {
		@{ $vars->{analysis_status_options} } = sort( @{ $analysis_rights->{particularization} } );
	} else {
		@{ $vars->{analysis_status_options} } = sort( @{$session->getSessionUserSettings()->{analysis_status_options} } ); 
	}

	my $dialogContent = $tt->processTemplateNoHeader('status_selection.tt', $vars, 1);
	
	return { dialog => $dialogContent };
}

sub addAnalysis {
	my ( %kvArgs ) = @_;
	my ( $message, @ids, @updateItems );
	my $session = $kvArgs{session};	
	my $analysisAddedd = 0;
	
	if ( $kvArgs{action} =~ /^(bulk|multiple)$/i ) {
		if ( $session->right("write") ) {
	
			my $as = Taranis::Assess->new();
			my $an = Taranis::Analysis->new();	
	
			$an->{dbh}->startTransaction();
			
			my $analysis_id;
	
			@ids = @{ $kvArgs{id} };
			my $status = $kvArgs{'bulk-analysis-status'};
			my $cntr = 0;
			
			foreach my $unescapedId ( @ids ) {
				my $id = uri_unescape( $unescapedId );
				push @updateItems, $id;
				$cntr++;
		
				if ( ( $cntr == 1 ) || ( $kvArgs{action} =~ /^multiple$/i ) ) {
		     	
					my $item = $as->getItem( $id );
		
					if ( !$an->addObject( 
						table => "analysis", 
						title => $item->{title}, 
						comments => $item->{description},
						status => $status, 
						rating => 4
						) 
					) {
						$message = $an->{errmsg};
					} else {
						$analysis_id = $an->getNextAnalysisID() - 1;
					}
				}
				
				if ( exists( $kvArgs{clusterItemMapping} ) ) {
					my $jsonClusterItemMapping = $kvArgs{clusterItemMapping};
					$jsonClusterItemMapping =~ s/&quot;/"/g;
					my $clusterItemMapping = from_json( $jsonClusterItemMapping );

					if ( exists( $clusterItemMapping->{$unescapedId} ) ) {
					
						foreach my $clusterItemId ( @{ $clusterItemMapping->{$unescapedId} } ) {
							push @updateItems, uri_unescape( $clusterItemId );
							if ( !$an->linkToItem( uri_unescape( $clusterItemId ), $analysis_id ) ) {
								$message = $an->{errmsg};
							}
						}
					}
				}
				
				if ( !$an->linkToItem( $id, $analysis_id ) ) {
					$message = $an->{errmsg};
				} else {
					$analysisAddedd = 1;
				}
			}
			$an->{dbh}->endTransaction();
	
		} else {
			$message = "Sorry, you do not have enough privileges to do a bulk or multiple analysis...";
		}
	} else {
		$message = "Illegal bulk analysis action!";
	}
		
	return { 
		params => { 
			message => $message,
			analysis_is_added => $analysisAddedd,
			ids => \@updateItems
		}
	};
}

1;
