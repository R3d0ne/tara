#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;
use Taranis::Template;
use Taranis::Assess;
use Taranis::Config;
use URI::Escape;
use MIME::Parser;
use HTML::Entities;

my @EXPORT_OK = qw(displayMail);

sub show_mail_export {
	return @EXPORT_OK; 
}

sub displayMail {
	my ( %kvArgs ) = @_;
	my ( $vars, $tpl );
	my $session = $kvArgs{session};	

	my $as = Taranis::Assess->new();
	my $tt = Taranis::Template->new();

	my $id = ( exists( $kvArgs{id} ) && $kvArgs{id} =~ /^\d+$/ ) ? $kvArgs{id} : undef;

	if ( my $item = $as->getMailItem( $id ) ) {
		if ( $session->rightOnParticularization( $item->{category} ) ) {

			my $parser = MIME::Parser->new();
			my $outputDir = Taranis::Config->getSetting('downloadpath' ) || '/tmp'; 
			$parser->output_dir( $outputDir );		

			my $decodedMessage = HTML::Entities::decode( $item->{body} );
			
			my $entity;
			eval{ $entity = $parser->parse_data( $decodedMessage ) } if ( $decodedMessage );
		
			$vars->{id} = $id;
			$vars->{attachments} = $as->getAttachmentInfo( $entity, undef );
	
			$vars->{text} = trim( HTML::Entities::encode( decodeMimeEntity( $entity, 1, 1 ) ) );
			$vars->{originalText} = trim( $item->{body} ); 
			$vars->{title} = $item->{title};
			
			$tpl = 'show_mail.tt';
		} else {
			$tpl = 'dialog_no_right.tt';
			$vars->{message} = 'Sorry, you do not have enough privileges to view this email...';
		}
	} else {
		$tpl = 'show_mail.tt';
		$vars->{message} = $as->{errmsg};
	}
	
	my $dialogContent = $tt->processTemplateNoHeader($tpl, $vars, 1);
	
	return { dialog => $dialogContent };
}

1;
