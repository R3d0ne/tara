#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::MetaSearch;
use Taranis::Template;
use Time::Local;
use Taranis qw(:all);
use strict;

#TODO: retrieve the required js files from scripts or config	
my @js = (
	'js/jquery.hoverIntent.minified.js',
	'js/jquery.timepicker.min.js',
	'js/datevalidation.js',		
	'js/tagging.js',
	'js/assess.js', 
	'js/assess_details.js', 
	'js/assess_filters.js',
	'js/assess2analyze.js',
	'js/analyze.js', 
	'js/analyze_filters.js',
	'js/analyze_details.js',
	'js/analysis2publication.js',
	'js/publications.js',
	'js/publications_filters.js',
	'js/publications_advisory.js',
	'js/publications_eow.js',
	'js/publications_eos.js',
	'js/publications_common_actions.js',
	'js/publish_details.js',
	'js/tab_in_textarea.js'
);

my @EXPORT_OK = qw( doMetaSearch showAdvancedSearchSettings doAdvancedMetaSearch );

sub meta_search_export {
	return @EXPORT_OK;
}

sub doMetaSearch {
	my ( %kvArgs ) = @_;	
	my ( $vars );
	
	my $ms = Taranis::MetaSearch->new();
	my $tt = Taranis::Template->new();
#	my $ca = Taranis::Category->new();
	my $us = Taranis::Users->new();
	
	my $session = $kvArgs{session};

	my $searchOk = 0;
	my $hitsperpage = 100;
	my $resultCount = 0;
	
	my $searchString = $kvArgs{search};
	my $searchSettings = $ms->dissectSearchString( $searchString );

	my $pageNumber = ( exists( $kvArgs{'hidden-page-number'} ) && $kvArgs{'hidden-page-number'} =~ /^\d+$/ )
		? $kvArgs{'hidden-page-number'}
		: 1;
	
	if ( $searchSettings ) {
		my %searchDBSettings;
		$searchDBSettings{item}->{archive} = 0;
		$searchDBSettings{analyze}->{searchAnalyze} = 1;
		$searchDBSettings{publication}->{searchAllProducts} = 1;
		$searchDBSettings{publication_advisory}->{status} = 3;
		$searchDBSettings{publication_endofweek}->{status} = 3;
		$searchDBSettings{publication_endofshift}->{status} = 3;
		
		if ( $vars->{search_results} = $ms->search( $searchSettings, \%searchDBSettings ) ) {
			$searchOk = 1;
		}	else {
			$vars->{error} = $ms->{errmsg};
		}
	
		$resultCount = ( $searchOk ) ? scalar( @{ $vars->{search_results} } ) : 0;
		
		if ( $searchOk ) {

			my $startLength = ( $pageNumber - 1 ) * $hitsperpage;
			my $endOffset =  $pageNumber * $hitsperpage; 

			splice( @{ $vars->{search_results} }, $endOffset );	
			splice( @{ $vars->{search_results} }, 0, $startLength );
		}
		$vars->{filterButton} = 'btn-metasearch';
		$vars->{page_bar} = $tt->createPageBar( $pageNumber, $resultCount, $hitsperpage );
	}

	foreach my $status ( sort split( ",", Taranis::Config->getSetting("analyze_status_options") ) ) {
		push @{ $vars->{an_status} }, trim( $status );
	}

	@{ $vars->{item_categories} } = @{ $session->getSessionUserSettings()->{assess_categories} };
	@{ $vars->{item_sources} } = $ms->getDistinctSources();

	$us->getUsersList();
	while ( $us->nextObject() ) {
		push @{ $vars->{publication_users} }, $us->getObject();
	}

	my $htmlContent = $tt->processTemplateNoHeader( 'meta_search.tt', $vars, 1 );
	my $htmlFilters = $tt->processTemplateNoHeader( 'meta_search_filters.tt', $vars, 1 );

	return { 
		content => $htmlContent, 
		filters => $htmlFilters,
		js => \@js, 
		params => {
			advisoryPrefix => $session->getSessionUserSettings()->{advisory_prefix},
			keywords => $ms->{keywords} || []
		}
	};
}

sub showAdvancedSearchSettings {
	my ( %kvArgs ) = @_;	
	my ( $vars );
	
	my $ms = Taranis::MetaSearch->new();
	my $tt = Taranis::Template->new();
	my $us = Taranis::Users->new();
	
	my $session = $kvArgs{session};

	foreach my $status ( sort split( ",", Taranis::Config->getSetting("analyze_status_options") ) ) {
		push @{ $vars->{an_status} }, trim( $status );
	}

	@{ $vars->{item_categories} } = @{ $session->getSessionUserSettings()->{assess_categories} };
	@{ $vars->{item_sources} } = $ms->getDistinctSources();

	$us->getUsersList();
	while ( $us->nextObject() ) {
		push @{ $vars->{publication_users} }, $us->getObject();
	}

	my $htmlContent = $tt->processTemplateNoHeader( 'meta_search.tt', $vars, 1 );
	my $htmlFilters = $tt->processTemplateNoHeader( 'meta_search_filters.tt', $vars, 1 );

	return { 
		content => $htmlContent, 
		filters => $htmlFilters,
		js => \@js
	};
}

sub doAdvancedMetaSearch {
	my ( %kvArgs ) = @_;	
	my ( $vars );
	
	my $ms = Taranis::MetaSearch->new();
	my $tt = Taranis::Template->new();
#	my $ca = Taranis::Category->new();
	my $us = Taranis::Users->new();
	
	my $session = delete $kvArgs{session};

	my $searchOk = 0;
	my $hitsperpage = 100;
	my $resultCount = 0;

	my $searchString = $kvArgs{search};
	my $searchSettings = $ms->dissectSearchString( $searchString );

	my $pageNumber = ( exists( $kvArgs{'hidden-page-number'} ) && $kvArgs{'hidden-page-number'} =~ /^\d+$/ )
		? $kvArgs{'hidden-page-number'}
		: 1;
	
	if ( $searchSettings ) {

		my %searchDBSettings;

		if ( exists( $kvArgs{startdate} ) && exists( $kvArgs{enddate} )  ) {
			my $startDate = $kvArgs{startdate};
			my $endDate = $kvArgs{enddate};

			if ( $startDate =~ /^\d\d-\d\d-\d{4}$/ && $endDate =~ /^\d\d-\d\d-\d{4}$/ ) {
				
				for ( $startDate, $endDate ) {
					my $checkDate = $_;
					
					$checkDate =~ s/-//g;
					my ( $day, $month, $year ) = unpack( "A2 A2 A4", $checkDate );
		
					eval{ 
					    timelocal(0,0,0,$day, $month-1, $year);
					} or goto ENDCHECKDATE;
				}

				$searchDBSettings{startDate} = $startDate;
				$searchDBSettings{endDate} 	 = $endDate;
			}
			ENDCHECKDATE:	
		}
		
		my %allowedFields = (
			as => [ 'category', 'source', 'status', 'archive' ],
			an => [ 'status', 'rating', 'searchAnalyze' ],
			pr => [ 'status', 'created_by', 'approved_by', 'published_by' ],
			adv => [ 'probability', 'damage', 'searchAdvisory' ],
			eow => [ 'searchEndOfWeek' ],
			eos => [ 'searchEndOfShift' ]
		);

		my $searchAssess = ( exists( $kvArgs{as_searchAssess} ) ) ? 1 : 0;
		my $searchPublications = ( exists( $kvArgs{pr_searchAllProducts} ) ) ? 1 : 0;
		
		FIELD:foreach my $field ( keys %kvArgs ) {
			next if ( 
				$field eq 'search' 
				|| $field eq 'startdate' 
				|| $field eq 'enddate' 
				|| $field eq 'hidden-page-number'  
				|| $kvArgs{$field} eq '' 
			);
			
			my $setting;
			
			$field =~ /^(.*?)_(.*)/i;
			
			my $prefix = $1;
			my $column_name = $2;

			for ( $prefix ) {
				if (/as/) {
					if ( $searchAssess && grep( /^$column_name$/, @{ $allowedFields{as} } ) ) {
						$setting = "item";	
					} else {
						next FIELD;
					}
				} elsif (/an/) {
					if ( grep( /^$column_name$/, @{ $allowedFields{an} } ) ) {
						$setting = "analyze";
					} else {
						next FIELD;
					}
				} elsif (/pr/) {
					if ( $searchPublications && grep( /^$column_name$/, @{ $allowedFields{pr} } ) ) {
						$setting = "publication";
					} else {
						next FIELD;
					}
				} elsif (/adv/) {
					if ( $searchPublications && grep( /^$column_name$/, @{ $allowedFields{adv} } ) ) {
						$setting = "publication_advisory";	
					} else {
						next FIELD;
					}
				} elsif (/eow/) {
					if ( $searchPublications && grep( /^$column_name$/, @{ $allowedFields{eow} } ) ) {
						$setting = "publication_endofweek";
					} else {
						next FIELD;
					}
				} elsif (/eos/) {
					if ( $searchPublications && grep( /^$column_name$/, @{ $allowedFields{eos} } ) ) {
						$setting = "publication_endofshift";
					} else {
						next FIELD;
					}
				}
			}

			$searchDBSettings{$setting}->{$column_name} = $kvArgs{$field};
		}
		$searchDBSettings{publication}->{searchAllProducts} = 0;
		
		if ( $vars->{search_results} = $ms->search( $searchSettings, \%searchDBSettings ) ) {
			$searchOk = 1;
		}	else {
			$vars->{error} = $ms->{errmsg};
		}

		$resultCount = ( $searchOk ) ? scalar( @{ $vars->{search_results} } ) : 0;
		
		if ( $searchOk ) {

			my $startLength = ( $pageNumber - 1 ) * $hitsperpage;
			my $endOffset =  $pageNumber * $hitsperpage; 

			splice( @{ $vars->{search_results} }, $endOffset );	
			splice( @{ $vars->{search_results} }, 0, $startLength );
		}
		$vars->{filterButton} = 'btn-meta-search-advanced-search';
		$vars->{page_bar} = $tt->createPageBar( $pageNumber, $resultCount, $hitsperpage );
	}

	my $htmlContent = $tt->processTemplateNoHeader( 'meta_search.tt', $vars, 1 );
	
	return { 
		content => $htmlContent, 
		js => \@js, 
		params => {
			advisoryPrefix => $session->getSessionUserSettings()->{advisory_prefix},
			keywords => $ms->{keywords} || []
		}
	};	
	
}


1;
