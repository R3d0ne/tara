#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:all);
use Taranis::Template;
use Taranis::Assess;
use Taranis::Category;
use Taranis::Config;
use Taranis::Config::XMLGeneric;
use LWP::UserAgent;
use XML::FeedPP;
use Date::Parse;
use JSON;
use strict;
use File::Basename;
 
use Data::Dumper;

my @EXPORT_OK = qw( getBigScreenSettings getScreen );

sub get_screen_export {
	return @EXPORT_OK;
}

getBuienRadarXML();

sub getBigScreenSettings {
	my ( %kvArgs) = @_;
	my $session = $kvArgs{session};
	
	my $vars;
	my $tt = Taranis::Template->new();

	my $currentFilePath = dirname(__FILE__);
	my $cfg = Taranis::Config->new( $currentFilePath . "/../../../conf/taranis.conf.bigscreen.xml" );

	my $timer = ( $cfg->{screenTimer} ) ? $cfg->{screenTimer} : '10s';
	$vars->{autoDetectResolution} = $cfg->{autoDetectResolution};

	my $resolution = ( $cfg->{screenResolution} ) ? $cfg->{screenResolution} : '1280x768';
	my $numberOfScreens = keys %{ $cfg->{screenOrder} };
	
	return {
		params => {
			timer => $timer,
			autoDetectResolution => $cfg->{autoDetectResolution},
			resolution => $resolution,
			numberOfScreens => $numberOfScreens
		}
	};
}

sub getScreen {
	my ( %kvArgs) = @_;
	my $session = $kvArgs{session};

	my $currentFilePath = dirname(__FILE__);
	my $cfg = Taranis::Config->new( $currentFilePath . "/../../../conf/taranis.conf.bigscreen.xml" );	
	my $display_screen = $kvArgs{screen};
	
	my ( %screens , $screenData );
	
	foreach ( keys %{ $cfg->{screenOrder} } ) {
		my $key = $_;
		$_ =~ s/screen(.+)/$1/i;
		$screens{$_} = $cfg->{screenOrder}->{$key};
	}
	
	my $ref = $screens{ $display_screen };
	my $sub = \&$ref; 

	eval {
		$screenData = $sub->( $cfg );
	};
	
	if ( $@ ) {
#		logdit $@;
	}

	return {
		params => { screenData => $screenData }
	}
}

sub welcomeScreen {
	my ( $cfg ) = @_;
	my $screenData;
	$screenData->{func} = 'welcomeScreen';
	
	$screenData->{screenTitle} = $cfg->{welcomeScreen}->{screenTitle};
	$screenData->{welcomeText} = $cfg->{welcomeScreen}->{welcomeText};
	$screenData->{welcomeTextSize} = $cfg->{welcomeScreen}->{welcomeTextSize};
	$screenData->{welcomeTextAlign} = $cfg->{welcomeScreen}->{welcomeTextAlign};

	return $screenData;
}

sub securityNews {
	my ( $cfg ) = @_;
	
	return assessItems( $cfg, 'securityNews', 'security-news' );
}

sub securityVulnerability {
	my ( $cfg ) = @_;

	return assessItems( $cfg, 'securityVulnerability', 'security-vuln' );
}

sub news {
	my ( $cfg ) = @_;
	
	return assessItems( $cfg, 'news', 'news' );
}

sub symposiumNews {
	my ( $cfg ) = @_;
	my $screenData;
	$screenData->{func} = 'symposiumNews';

	my $am = Taranis::Config::XMLGeneric->new( "announcementsconfig", "announcementId", "announcements", 0 );

	my $symposiumNews = $am->loadCollectionBySearchField( 'type', 'symposiumNews', 'EXACT_MATCH' );
	
	my @sortedNews;
	if ( $symposiumNews ) {
		@sortedNews = reverse sort { $$a{'created'} cmp $$b{'created'} } @$symposiumNews;
	}
	
	$screenData->{symposiumNews} = ( @sortedNews ) ? \@sortedNews : [ { title => "There is no news at this time.", description => "" } ];

	return $screenData;
}

sub announcements {
	my ( $cfg ) = @_;
	my $screenData;
	$screenData->{func} = 'announcements';

	my $am = Taranis::Config::XMLGeneric->new( "announcementsconfig", "announcementId", "announcements", 0 );
	
	my $announcements = $am->loadCollectionBySearchField( 'type', 'announcement', 'EXACT_MATCH' );
	
	my @sortedAnnouncements;
	
	if ( $announcements ) {
		@sortedAnnouncements = reverse sort { $$a{'created'} cmp $$b{'created'} } @$announcements;
	}
	
	$screenData->{announcementTextSize} = $cfg->{announcementTextSize};
	
	$screenData->{announcements} = ( @sortedAnnouncements ) ? \@sortedAnnouncements : [ { title => "There are no announcements at this time.", description => "" } ]; 

	return $screenData;
}

sub taranisDemo {
	my ( $cfg ) = @_;
	my $screenData;
	$screenData->{func} = 'taranisDemo';
	
	return $screenData;	
}

sub cloudSecurity {
	my ( $cfg ) = @_;
	my $screenData;
	$screenData->{func} = 'cloudSecurity';
	
	return $screenData;	
}

sub cloudNews {
	my ( $cfg ) = @_;
	my $screenData;
	$screenData->{func} = 'cloudNews';
	
	return $screenData;	
}

sub cloudICT {
	my ( $cfg ) = @_;
	my $screenData;
	$screenData->{func} = 'cloudICT';

	return $screenData;	
}

sub twitter {
	my ( $cfg ) = @_;
	my $screenData;
	my @newsItems;
	
	my $as = Taranis::Assess->new();
	
	my $startDate = nowstring(13); # yesterday
	my $endDate = nowstring(5); # today

	my %allItems;

 	$as->loadAssessCollection( 	
		status => [ 0, 2, 3 ],
		limit => 10, 
		offset => 1,
		source => ['Twitter']
	);
		
	while ( $as->nextObject() ) {
		my $record = $as->getObject();
		my $date = substr( $record->{item_date}, 6, 4 ) 
			. substr( $record->{item_date}, 3, 2 )
			. substr( $record->{item_date}, 0, 2 )
			. substr( $record->{item_date}, 11, 2 )
			. substr( $record->{item_date}, 14, 2 )
			. substr( $record->{item_date}, 17, 2 );
		
		$allItems{ $date . $record->{digest} } = $record;
	}

 	$as->loadAssessCollection( 	
		status => [ 2 ],
		limit => 10, 
		offset => 1
	);
		
	while ( $as->nextObject() ) {
		my $record = $as->getObject();
		my $date = substr( $record->{item_date}, 6, 4 ) 
			. substr( $record->{item_date}, 3, 2 )
			. substr( $record->{item_date}, 0, 2 )
			. substr( $record->{item_date}, 11, 2 )
			. substr( $record->{item_date}, 14, 2 )
			. substr( $record->{item_date}, 17, 2 );
		
		$allItems{ $date . $record->{digest} } = $record;
	}

	foreach my $item ( reverse sort keys %allItems ) {
		push @newsItems, $allItems{ $item };
	}

	if ( !@newsItems ) {
		push @newsItems, { title => "There are no items to display.", description => "", source => "GOVCERT.NL" };
	}

	$screenData->{textSize} = $cfg->{announcementTextSize};
	$screenData->{items} = \@newsItems;
	$screenData->{func} = 'twitter';

	return $screenData;	
}

sub nsAnnouncements {
	my ( $cfg ) = @_;
	my $screenData;
	$screenData->{func} = 'nsAnnouncements';

	my @announcements;
	
	my $source = 'http://www.ns.nl/storingen/index.rss';

	my $feed;
	eval{
		$feed = XML::FeedPP->new( $source );
	};
  
	if ( $@ ) {
		push @announcements, { title => '', description => "$source is niet bereikbaar of is geen valide XML.", date => nowstring(7) };
	}

	if ( $feed ) {
		foreach my $item ( $feed->get_item() ) {
			my $description = $item->description();
			$description =~ s/(\s)\s+/$1/g;
			$description =~ s/(\n+)/<br>/g;
			push @announcements, { title => $item->title() . ' - ', description => $description, date => $item->{pubDate} };
		}
	}

	if ( !@announcements ) {
		push @announcements, { title => '', description => 'Er zijn momenteel geen verstoringen.', date => nowstring(7) };
	}
	$screenData->{items} = \@announcements;

	return $screenData;	
}

sub buienRadar {
	my ( $http_header, $cfg ) = @_;
	my $screenData;
	my @days;
	$screenData->{func} = 'buienRadar';

	my $currentFilePath = dirname(__FILE__);
	my $weather = Taranis::Config->new( $currentFilePath . "/../../../tmp/buienRadar.xml" )->{weergegevens};
	
	my $foreCast = $weather->{verwachting_meerdaags};
	
	foreach my $key ( sort keys %$foreCast ) {
		if ( $key =~ /dag-plus/i ) {
			$foreCast->{$key}->{datum} =~ s/^(.*?) .*/$1/;
			$foreCast->{$key}->{dayId} = $key;
			
			push @days, $foreCast->{$key};
		}
	}
	
	$screenData->{foreCast} = \@days;
	
	$screenData->{current} = $weather->{actueel_weer}->{weerstations}->{weerstation}->{6344};

	$screenData->{current}->{datum} =~ s/.*(\d\d:\d\d):\d\d.*/vandaag om $1/;
	
	return $screenData;
}

sub getBuienRadarXML {
	
	my $ua = LWP::UserAgent->new();
	
	if ( my $proxy_host = Taranis::Config->getSetting("proxy_host") ) {
		$ua->proxy(['http', 'https'], $proxy_host);	
	}
	
	my $userAgentString = Taranis::Config->getSetting("useragent_string");
	
	$ua->agent( $userAgentString );	
	
	my $reqHead = HTTP::Request->new( HEAD => 'http://xml.buienradar.nl/' );
	my $resHead = $ua->request( $reqHead );
	
	if ( $resHead->is_success() ) {

		my $currentFilePath = dirname(__FILE__);
		my $buienRadarLastModified = str2time( $resHead->headers()->{'last-modified'} );
		
		my @buienRadeFileInfo = stat( $currentFilePath . "/../../../tmp/buienRadar.xml" );
		
		# 7200 = 2 hours ; 3600 = 1 hour
		if ( !@buienRadeFileInfo || ( $buienRadarLastModified - $buienRadeFileInfo[10] > 3600 ) ) {
			my $reqGet = HTTP::Request->new( GET => 'http://xml.buienradar.nl/' );
			my $resGet = $ua->request( $reqGet, $currentFilePath . "/../../../tmp/buienRadar.xml" );
#			logdit "DOWNLOADED NEW BUIENRADAR";		
		}
	}
}

sub assessItems {
	my ( $cfg, $subName, $assessCategory ) = @_;
	my $screenData;
	my @newsItems;
	
	my $as = Taranis::Assess->new();
	my $ca = Taranis::Category->new();
	
	my $categoryId = $ca->getCategoryId( lc( $assessCategory ) );
	
	my $startDate = nowstring(13); # yesterday
	my $endDate = nowstring(5); # today
	
	my $sources = $cfg->{$subName}->{sources};

	if ( $sources && ref( $sources ) ne 'ARRAY' ) {
		my $temp_save = $sources;
		undef $sources;
		push @$sources, $temp_save;
	}
	
	if ( $sources ) {
		my $loadSources = ( $sources->[0] =~ /^__ALL_SOURCES__$/ ) ? undef : $sources; 
		
	 	$as->loadAssessCollection( 	
			category => [$categoryId], 
			status => [ 0, 1, 2, 3 ],
			limit => 10, 
			offset => 1,
			source => $loadSources,		
			startdate => $startDate, 
			enddate => $endDate 
		);

		while ( $as->nextObject() ) {
			push @newsItems, $as->getObject();
		}
	}

	if ( !$sources || !@newsItems ) {
		push @newsItems, { title => "There is no news to display.", description => "", source => "GOVCERT.NL" };
	}

	$screenData->{textSize} = $cfg->{announcementTextSize};

	$screenData->{items} = \@newsItems;
	$screenData->{func} = $subName;
	
	return $screenData;
}

1;
