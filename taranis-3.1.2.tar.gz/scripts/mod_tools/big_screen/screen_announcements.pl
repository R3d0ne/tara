#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:all);
use Taranis::Template;
use Taranis::Config::XMLGeneric;
use strict;
 
my @EXPORT_OK = qw(
	deleteAnnouncement openDialogAnnouncementDetails openDialogNewAnnouncement
	saveAnnouncementDetails saveNewAnnouncement
);

sub screen_announcements_export {
	return @EXPORT_OK;
}

sub openDialogNewAnnouncement {
	my ( %kvArgs) = @_;	
	my $session = $kvArgs{session};
	my $vars;
	
	my $tt = Taranis::Template->new();

	my $dialogContent = $tt->processTemplateNoHeader('screen_announcements.tt', $vars, 1);

	return { 
		dialog => $dialogContent,
		params => {	writeRight => $session->right('write') }
	};	
}

sub openDialogAnnouncementDetails {
	my ( %kvArgs) = @_;	
	my $session = $kvArgs{session};
	my $vars;
	
	my $tt = Taranis::Template->new();
	my $am = Taranis::Config::XMLGeneric->new("announcementsconfig", "announcementId", "announcements");
	
	my $announcement = $am->getElement( $kvArgs{id} );
	$vars->{title} = $announcement->{title};
	$vars->{description} = $announcement->{description};
	$vars->{type} = $announcement->{type};
	$vars->{created} = $announcement->{created};
	$vars->{id} = $announcement->{announcementId};

	my $dialogContent = $tt->processTemplateNoHeader('screen_announcements.tt', $vars, 1);

	return { 
		dialog => $dialogContent,
		params => { 
			writeRight => $session->right('write'),
			id => $kvArgs{id},
		}
	};
}

sub saveNewAnnouncement {
	my ( %kvArgs) = @_;	
	my $session = $kvArgs{session};
	
	my $am = Taranis::Config::XMLGeneric->new("announcementsconfig", "announcementId", "announcements");

	my ( $message, $screenAnnouncementHtml );
	my $saveOk = 0;

	my $id = rand();
	$id =~ s/\.//g;
		
	until ( !$am->checkIfExists( $id ) ) {
		$id = rand();
		$id =~ s/\.//g;			
	}
		
	if ( !$am->addElement(
		announcementId => $id,
		title => $kvArgs{title},
		description => $kvArgs{description},
		type => $kvArgs{type},
		created => nowstring(7)
		)
	) {
		$message = $am->{errmsg};
	} else {
		$saveOk = 1;
		my $vars;
		my $tt = Taranis::Template->new();
		$vars->{announcement} = {
			announcementId => $id,
			title => $kvArgs{title},
			description => $kvArgs{description},
			type => $kvArgs{type},
			created => nowstring(7)
		}; 
		$vars->{write_right} = 1;
		$vars->{newItem} = 1;
		$screenAnnouncementHtml = $tt->processTemplateNoHeader('screen_settings_item.tt', $vars, 1);			
	}

	return { 
		params => {
			saveOk => $saveOk,
			message => $message,
			itemHtml => $screenAnnouncementHtml,
			insertNew => 1
		}
	};	
}

sub saveAnnouncementDetails {
	my ( %kvArgs) = @_;	
	my $session = $kvArgs{session};
	my ( $message, $vars, $screenAnnouncementHtml );
	
	my $saveOk = 0;
	
	if ( $session->right('write') ) {
		my $tt = Taranis::Template->new();
		my $am = Taranis::Config::XMLGeneric->new("announcementsconfig", "announcementId", "announcements");

		if ( !$am->setElement( 
			announcementId => $kvArgs{id},
			title => $kvArgs{title},
			description => $kvArgs{description},
			type => $kvArgs{type},
			orig_announcementId => $kvArgs{id}
			) 
		 ) {
			$message = $am->{errmsg };
	
		} else {
			$saveOk = 1;
		}
	
		$vars->{announcement} = {
			announcementId => $kvArgs{id},
			title => $kvArgs{title},
			description => $kvArgs{description},
			type => $kvArgs{type},
			created => $kvArgs{created}
		}; 
		$vars->{write_right} = 1;
	
		$screenAnnouncementHtml = $tt->processTemplateNoHeader('screen_settings_item.tt', $vars, 1);			
	} else {
		$message = 'No permission';
	}
	
	return { 
		params => {
			saveOk => $saveOk,
			message => $message,
			itemHtml => $screenAnnouncementHtml,
			id => $kvArgs{id}			
		}
	};
}

sub deleteAnnouncement {
	my ( %kvArgs) = @_;	
	my $session = $kvArgs{session};
	my $message;
	my $deleteOk = 0;
	
	my $am = Taranis::Config::XMLGeneric->new("announcementsconfig", "announcementId", "announcements");
	
	if ( $kvArgs{id} && $session->right("write") ) {
		if ( $am->checkIfExists( $kvArgs{id} ) ) {
			if (!$am->deleteElement( $kvArgs{id} ) ) {
				$message = $am->{errmsg};
			} else {
				$deleteOk = 1;
			}
		}
	}	
	
	return {
		params =>{
			message => $message,
			deleteOk => $deleteOk,
			id => $kvArgs{id}
		}
	};
}
1;
