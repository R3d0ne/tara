#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Config::XMLGeneric;
use Taranis::Config;
use Taranis::Sources;
use Taranis::Template;
use Taranis::Category;
use Taranis qw(:all);
use File::Basename;
use strict;

use Data::Dumper;

my @EXPORT_OK = qw( displayBigScreenAnnouncementAndSettings openDialogScreenSettings saveScreenSettings );

sub screen_settings_export {
	return @EXPORT_OK;
}

sub displayBigScreenAnnouncementAndSettings {
	my ( %kvArgs) = @_;	
	my $session = $kvArgs{session};
	
	my $vars;
	my $tt = Taranis::Template->new();

	my $am = Taranis::Config::XMLGeneric->new("announcementsconfig", "announcementId", "announcements");

	my $write_right = $session->right("write");

	my $unsortedAnnouncements = $am->loadCollection(); 

	if ( $unsortedAnnouncements ) {
		my @sortedAnnouncements = reverse sort { $$a{'created'} cmp $$b{'created'} } @$unsortedAnnouncements;
		$vars->{announcements} = \@sortedAnnouncements;
	} else {
		$vars->{announcements} = [];
	}

	$vars->{write_right} = $session->right("write");
	$vars->{newItem} = 1;
	
	my $htmlContent = $tt->processTemplateNoHeader( 'screen_settings.tt', $vars, 1 );
	my $htmlFilters = $tt->processTemplateNoHeader( 'screen_settings_filters.tt', $vars, 1 );
	
	my @js = (
		'js/screen_settings.js',
		'js/screen_announcements.js'
	);
	
	return { content => $htmlContent, filters => $htmlFilters, js => \@js };
}

sub openDialogScreenSettings {
	my ( %kvArgs) = @_;	
	my $session = $kvArgs{session};
	
	my $vars;
	my $tt = Taranis::Template->new();
	my $writeRight = $session->right('write');

	my $currentFilePath = dirname(__FILE__);
	my $screenConfigFile = $currentFilePath . "/../../../conf/taranis.conf.bigscreen.xml";
		
	my $cfg = Taranis::Config->new( $screenConfigFile );

	@{ $vars->{screensAvailable} } = sort @{ $cfg->{screensAvailable}->{screen} };
	
	my $src = Taranis::Sources->new();
	
	my $securityNewsSources = getSources( 'security-news', $src );
	my $securityVulnerabilitySources = getSources( 'security-vuln', $src );
	my $newsSources = getSources( 'news', $src );

	$vars->{securityNewsSources} = $securityNewsSources;
	$vars->{securityVulnerabilitySources} = $securityVulnerabilitySources;
	$vars->{newsSources} = $newsSources;

	my @screenOrder;
	
	foreach my $screen ( sort keys %{ $cfg->{screenOrder} } ) {
		push @screenOrder, $cfg->{screenOrder}->{$screen};
	}

	$vars->{selectedSNSources} = ( $cfg->{securityNews}->{sources} =~ /^__ALL_SOURCES__$/ ) 
		? $securityNewsSources 
		: $cfg->{securityNews}->{sources};
	$vars->{selectedSVSources} = ( $cfg->{securityVulnerability}->{sources} =~ /^__ALL_SOURCES__$/ ) 
		? $securityVulnerabilitySources 
		: $cfg->{securityVulnerability}->{sources};
	$vars->{selectedNewsSources} = ( $cfg->{news}->{sources} =~ /^__ALL_SOURCES__$/) 
		? $newsSources 
		: $cfg->{news}->{sources};

	@{ $vars->{screenOrder} } = @screenOrder;
	
	$vars->{resolution} = $cfg->{screenResolution};
	$vars->{timer} = $cfg->{screenTimer};
	$vars->{autoDetectResolution} = $cfg->{autoDetectResolution};
	$vars->{announcementTextSize} = $cfg->{announcementTextSize};
	
	$vars->{welcomeTitle} = $cfg->{welcomeScreen}->{screenTitle};
	$vars->{welcomeText} = $cfg->{welcomeScreen}->{welcomeText};
	$vars->{welcomeTextSize} = $cfg->{welcomeScreen}->{welcomeTextSize};
	$vars->{welcomeTextAlign} = $cfg->{welcomeScreen}->{welcomeTextAlign};
	$vars->{write_right} = $writeRight;
	
	my $dialogContent = $tt->processTemplateNoHeader('screen_settings_details.tt', $vars, 1);

	return { 
		dialog => $dialogContent,
		params => {	
			writeRight => $writeRight,
			resolution => $vars->{resolution},
			timer => $vars->{timer},
			announcementTextSize => $vars->{announcementTextSize},
			welcomeTextSize => $vars->{welcomeTextSize}
		}
	};
}

sub saveScreenSettings {
	my ( %kvArgs) = @_;	
	my $session = $kvArgs{session};
	my $message;
	
	my $saveOk = 0;

	if ( $session->right('write') ) {
		my %saveSettings;

		my $screenOrderJson = $kvArgs{screenOrder};
		$screenOrderJson =~ s/\&quot;/"/g;

		my $screens = from_json( $screenOrderJson );
	
		my $screenCount = 0;
		foreach my $screen ( @$screens ) {
			$screenCount++;
			my $screenNr = 'screen' . $screenCount;
			$saveSettings{screenOrder}->{$screenNr} = $screen;
		}

		# general settings
		$saveSettings{screenResolution} = ( $kvArgs{resolution} ) ? $kvArgs{resolution} : '1280x768';
		$saveSettings{screenTimer} = $kvArgs{timer};
		$saveSettings{autoDetectResolution} = ( $kvArgs{autoDetectResolution} ) ? 1 : 0;
		$saveSettings{announcementTextSize} = $kvArgs{announcementTextSize};

		my $currentFilePath = dirname(__FILE__);
		my $screenConfigFile = $currentFilePath . "/../../../conf/taranis.conf.bigscreen.xml";
			
		my $cfg = Taranis::Config->new( $screenConfigFile );
		
		$saveSettings{screensAvailable}->{screen} = $cfg->{screensAvailable}->{screen};

		# welcomeScreen settings
		$saveSettings{welcomeScreen}->{screenTitle} = $kvArgs{welcomeTitle}; 
		$saveSettings{welcomeScreen}->{welcomeText} = $kvArgs{welcomeText};
		$saveSettings{welcomeScreen}->{welcomeTextSize} = $kvArgs{welcomeTextSize};
		$saveSettings{welcomeScreen}->{welcomeTextAlign} = $kvArgs{welcomeTextAlign};

		my $src = Taranis::Sources->new();

		my $securityNewsSources = @{ getSources( 'security-news', $src ) };
		my $securityVulnerabilitySources = @{ getSources( 'security-vuln', $src ) };
		my $newsSources = @{ getSources( 'news', $src ) };

		##############################################################################
		# if all sources for this category are selected we use the sourcename 
		# '__ALL_SOURCES__' which implies all sources. This applies to securityNews,
		# securityVulnerability and new settings.
		##############################################################################  

		# securityNews settings
		my @selectedSecurityNewsSources;
		if ( $kvArgs{selectedSNSources} ) {
			@selectedSecurityNewsSources = ( ref( $kvArgs{selectedSNSources} ) =~ /^ARRAY$/ )
				? @{ $kvArgs{selectedSNSources} }
				: $kvArgs{selectedSNSources};
		} 
		
		if ( $securityNewsSources == @selectedSecurityNewsSources ) {
			push @{ $saveSettings{securityNews}->{sources} }, '__ALL_SOURCES__';
		} else {
			foreach my $source ( @selectedSecurityNewsSources ) {
				push @{ $saveSettings{securityNews}->{sources} }, $source;
			}
		}
	
		# securityVulnerability settings
		my @selectedSecurityVulnerabilitySources;
		if ( $kvArgs{selectedSVSources} ) {
			@selectedSecurityVulnerabilitySources = ( ref( $kvArgs{selectedSVSources} ) =~ /^ARRAY$/ )
				? @{ $kvArgs{selectedSVSources} }
				: $kvArgs{selectedSVSources};
		}
				
		if ( $securityVulnerabilitySources == @selectedSecurityVulnerabilitySources ) {
			push @{ $saveSettings{securityVulnerability}->{sources} }, '__ALL_SOURCES__';
		} else {
			foreach my $source ( @selectedSecurityVulnerabilitySources ) {
				push @{ $saveSettings{securityVulnerability}->{sources} }, $source;
			}
		}

		# news settings
		my @selectedNewsSources;
		if ( $kvArgs{selectedNewsSources} ) {
			@selectedNewsSources = ( ref( $kvArgs{selectedNewsSources} ) =~ /^ARRAY$/ )
				? @{ $kvArgs{selectedNewsSources} }
				: $kvArgs{selectedNewsSources};
		}		
		
		my $selectedNewsSourcesCount = () = $kvArgs{selectedNewsSources};
		if ( $newsSources == @selectedNewsSources ) {
			push @{ $saveSettings{news}->{sources} }, '__ALL_SOURCES__';
		} else {
			foreach my $source ( @selectedNewsSources ) {
				push @{ $saveSettings{news}->{sources} }, $source;
			}
		}
  	
		$saveSettings{file} = $screenConfigFile;

		if ( !$cfg->saveSettings( %saveSettings ) ) {
			$message = $cfg->{errmsg};
		} else {
			$saveOk = 1;	
		}

	} else {
		$message = 'No permission';
	}
	
	return { 
		params => {
			saveOk => $saveOk,
			message => $message,
		}
	};
}

## HELPER
sub getSources {
	my ( $category, $src ) = @_;
	
	my $ca = Taranis::Category->new();
	my $categoryId = $ca->getCategoryId( lc ( $category ) );
	
	my @sources;
	
	foreach my $source ( @{ $src->getSources( category => $categoryId ) } ) {
		push @sources, $source->{sourcename} if ( !grep( /^$source->{sourcename}$/, @sources ) );		
	}	
	
	return \@sources
}

1;
