#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;
use Taranis::Config;
use Taranis::Template;
use Taranis qw(:all);
use LWP::UserAgent;
use JSON;
use Net::hostent;
use Socket;

use Data::Dumper;

my @EXPORT_OK = qw(displayWhois getWhoisHost doWhoisLookup);

sub whois_export {
	return @EXPORT_OK;
}

sub displayWhois {
	my ( %kvArgs) = @_;	
	my $session = $kvArgs{session};
	
	my $vars;
	my $tt = Taranis::Template->new();
	$vars->{body_multiple} = 0;
	$vars->{body_result}   = 0;
	$vars->{body_error}    = 0;
	
	my $htmlContent = $tt->processTemplateNoHeader( 'whois.tt', $vars, 1 );
	my $htmlFilters = $tt->processTemplateNoHeader( 'whois_filters.tt', $vars, 1 );
	
	my @js = ('js/whois.js');
	
	return { content => $htmlContent, filters => $htmlFilters, js => \@js };
}

sub getWhoisHost {
	my ( %kvArgs) = @_;	
	
	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();
	
	my ( $host, $whoisPage, $vars );

	my $whoisHost = $kvArgs{whois};

	$whoisHost =~ s/\ //gi;
	$whoisHost =~ s/http\:\/\///gi;
	
	if (index($whoisHost, "/") > -1) {
		$whoisPage = substr( $whoisHost, index( $whoisHost, "/" ) );
		$whoisHost = substr( $whoisHost, 0, index( $whoisHost, "/" ) );
	}
	
	$whoisHost =~ s/($whoisHost)\/.*$/$1/;

	eval{ 
		$host = gethost( $whoisHost );
	};
	
	if ( $host ) {
		my @hostIpNumbers;
	
		if ( @{ $host->addr_list } > 1 ) {

			for my $addr ( @{ $host->addr_list } ) {
				push @hostIpNumbers, inet_ntoa( $addr );
			}
		} else {
			push @hostIpNumbers, inet_ntoa( $host->addr );
		}
	
		my %host_ipnrs = map( { $_ => 1 } @hostIpNumbers );
		my @ips = sort keys %host_ipnrs;
	
		$vars->{body_multiple} = 1;
		$vars->{body_result}   = 0;
		$vars->{body_error}    = 0;
		$vars->{ips}           = \@ips;
		$vars->{whois_page}    = $whoisPage;
		$vars->{whois_host}	   = $whoisHost;		
	} else {
		$vars->{body_error} = 1;
	}
	
	my $htmlContent = $tt->processTemplateNoHeader( 'whois.tt', $vars, 1 );
	my $htmlFilters = $tt->processTemplateNoHeader('whois_filters.tt', $vars, 1);
	
	my @js = ('js/whois.js');
	
	return { content => $htmlContent, filters => $htmlFilters, js => \@js };
	
}

sub doWhoisLookup {
	my ( %kvArgs) = @_;	
	
	my ( $vars, @whoisResults, $idx1, $idx2 );
	my $session = $kvArgs{session};
	my $tt = Taranis::Template->new();

	my $userAgent = LWP::UserAgent->new();
	my $userAgentString = Taranis::Config->getSetting("useragent_string");
	
	$userAgent->proxy( [ 'http', 'https' ], Taranis::Config->getSetting("proxy_host") );
	$userAgent->agent( $userAgentString );
	
	my @no_proxy = map { trim $_ } split( /,/, Taranis::Config->getSetting("no_proxy") );
	$userAgent->no_proxy(@no_proxy);
	$userAgent->timeout( Taranis::Config->getSetting("timeout") );

	my $whoisIp = $kvArgs{whois};
	my $whoisPage = $kvArgs{page};
	my $whoisHost = $kvArgs{host};
	my $myIp = $ENV{'REMOTE_ADDR'};

	$vars->{body_result} = 1;
	$vars->{body_multiple} 	= 0;
	$vars->{body_error} = 0;
    $vars->{get_ip} = $myIp;
    $vars->{get_whois_ip} = $whoisIp;

### Whois #1: Team Cymru
	my $cymru = httpPOST (
		"http://asn.cymru.com/cgi-bin/whois.cgi",
		"action=do_whois&addr=" . $myIp . "&family=ipv4&method_whois=whois&flag_cc=cc&bulk_paste=" . $whoisIp . "&submit_paste=Submit",
		$userAgent
	);
	$idx1 = index(uc($cymru), "<PRE>") + 51;
	$idx2 = index(uc($cymru), "</PRE>");
	$cymru = substr($cymru, $idx1+5, $idx2 - $idx1 - 5);
	push @whoisResults, { source => "Cymru", output => $cymru };

### Whois #2: RIPE
	my $ripe = httpGET("http://apps.db.ripe.net/whois/search?source=ripe&query-string=" . $whoisIp, { 'Accept' => 'application/json' }, $userAgent);
	my $ripeResponse = from_json($ripe);
       
	my $ripeOutput = '<div><table style="border: none !important; font-family: courier; font-size: 11px; color: #666">';
		foreach my $object ( @{ $ripeResponse->{'whois-resources'}->{objects}->{object} } ) {
			foreach my $attribute ( @{ $object->{attributes}->{attribute} } ) {
				$ripeOutput .= '<tr><td style="border: none;padding-right: 10px;">' . $attribute->{name} . '</td>';
				$ripeOutput .= '<td style="border: none;">' . $attribute->{value} .'</td></tr>';
			}
			$ripeOutput .= "<tr><td>&nbsp;</td><td>&nbsp;</td></tr>";
		}
	$ripeOutput =~ s/^(.*?)<tr><td>&nbsp;<\/td><td>&nbsp;<\/td><\/tr>$/$1/;
	$ripeOutput .= '</table></div>';
	push @whoisResults, { source => "RIPE", output => $ripeOutput };

### Whois #3: ARIN
	my $arin = httpGET ("http://whois.arin.net/rest/ip/" . $whoisIp, undef, $userAgent);

	$arin =~ s/<registrationDate>/Registration date\:/gi;
	$arin =~ s/<\/registrationDate>/\n/gi;
	$arin =~ s/<ref>/Reference\:/gi;
	$arin =~ s/<\/ref>/\n/gi;
	$arin =~ s/<endAddress>/End Address\:/gi;
	$arin =~ s/<\/endAddress>/\n/gi;
	$arin =~ s/<handle>/Handle\:/gi;
	$arin =~ s/<\/handle>/\n/gi;
	$arin =~ s/<name>/Name\:/gi;
	$arin =~ s/<\/name>/\n/gi;
	$arin =~ s/<netBlocks>//gi;
	$arin =~ s/<\/netBlocks>//gi;
	$arin =~ s/<netBlock>/\nNetblock\:/gi;
	$arin =~ s/<\/netBlock>/\n/gi;
	$arin =~ s/<cidrLength>/\nCIDR Length\:/gi;
	$arin =~ s/<\/cidrLength>/\n/gi;
	$arin =~ s/<startAddress>/Start Address\:/gi;
	$arin =~ s/<updateDate>/Update Date\:/gi;
	$arin =~ s/<description>/Description\:/gi;
	$arin =~ s/<\/description>/\n/gi;
	$arin =~ s/<type>/Type\:/gi;
	$arin =~ s/<\/type>/\n/gi;
	$arin =~ s/<\/netBlock>/\n/gi;
	$arin =~ s/<\//<\/\n/gi;
	$arin =~ s/<orgRef(.*?)\/orgRef>//gi;
	$arin =~ s/<parentNetRef(.*?)\/parentNetRef>//gi;
	$arin =~ s/<version(.*?)\/version>//gi;
	$arin =~ s/<(.*?)>//gi;

	if ( $arin ) {
		push @whoisResults, { source => "ARIN", output => $arin };
	}

### Whois #5: APNIC
	my $apnic = httpPOST (
		"http://wq.apnic.net/apnic-bin/whois.pl",
		"searchtext=" . $whoisIp . "&whois=Go",
		$userAgent
	);
	$idx1 = index(uc($apnic), "<PRE>");
	$idx2 = index(uc($apnic), "</PRE><DIV");
	$apnic = substr($apnic, $idx1 + 5, $idx2 - $idx1 - 5);
	$apnic =~ s/<(.*?)>//gi;
	if (index(uc($apnic), "RANGE ARE NOT REGISTERED") > -1) { $apnic = ""; }
	if (index(uc($apnic), "DOES NOT CONTAIN") > -1) { $apnic = ""; }
	if (index(uc($apnic), "NOT ALLOCATED TO APNIC") > -1) { $apnic = ""; }
	if (index(uc($apnic), "PLEASE SEARCH ONE OF THE") > -1) { $apnic = ""; }
	if ( $apnic ) {
		push @whoisResults, { source => "APNIC", output => $apnic };
	}

### Whois #6: LACNIC
	my $lacnic = httpPOST (
		"http://lacnic.net/cgi-bin/lacnic/whois?lg=EN",
		"query=" . $whoisIp . "&Submit=Whois+Search",
		$userAgent
	);
	$idx1 = index(uc($lacnic), "<PRE>");
	$idx2 = index(uc($lacnic), "</PRE>");
	$lacnic = substr($lacnic, $idx1 + 5, $idx2 - $idx1 - 5);
	$lacnic =~ s/<(.*?)>//gi;
	if (index(uc($lacnic), "THIS INFORMATION HAS BEEN PARTIALLY MIRRORED") > -1) { $lacnic = ""; }
	if (index(uc($lacnic), "ARIN RESOURCE:") > -1) { $lacnic = ""; }
	if (index(uc($lacnic), "RIPENCC RESOURCE:") > -1) { $lacnic = ""; }
	if (index(uc($lacnic), "AFRINIC RESOURCE:") > -1) { $lacnic = ""; }
	if (index(uc($lacnic), "APNIC RESOURCE:") > -1) { $lacnic = ""; }
	if ( $lacnic ) {
		push @whoisResults, { source => "LACNIC", output => $lacnic };
	}

### Whois #7: Robtex
#	my $robtex = httpGET ("http://www.robtex.com/ip/" . $whoisIp . ".html", undef, $userAgent);
#	my $idx = index ($robtex, "<table class=\"t\" sum");
#	$robtex = substr ($robtex, $idx + 10);
#	$idx = index ($robtex, "td0");
#	my $records = "";
#	while ($idx > 0) {
#		$robtex = substr ($robtex, $idx + 3);
#		$idx = index ($robtex, "/dns/");
#		$robtex = substr ($robtex, $idx + 5);
#		$idx = index ($robtex, ".html");
#		$records = $records . "- " . substr ($robtex, 0, $idx) . "<br/>";
#		$robtex = substr ($robtex, $idx + 5);
#		$idx = index ($robtex, "td0");
#	}
#	if ($records ne "") {
#		$records = "Passive DNS results for " . $whoisIp . ":<br /><br />".  $records;
#		push @whoisResults, { source => "Robtex", output => $records };
#	}

### Whois #8: Get domain WHOIS (if applicable)
#	if ($whoisHost ne $whoisIp) {
#		my $whois_host_tmp =  $whoisHost;
#		my $count = ($whois_host_tmp =~ tr/\.//);
#		while ($count > 1) {
#			$idx1 = index($whois_host_tmp, ".");
#			$whois_host_tmp = substr($whois_host_tmp, $idx1+1);
#			$count = ($whois_host_tmp =~ tr/\.//);
#		}
#		my $domwhois = httpGET ("http://www.whois-search.com/whois/" . $whois_host_tmp, undef, $userAgent);
#		$idx1 = index ($domwhois, "<pre>");
#		$idx2 = index ($domwhois, "</pre>");
#		$domwhois = trim(substr($domwhois, $idx1 + 5, $idx2 - $idx1 - 6));
#		$domwhois =~ s/\/text2image/http\:\/\/www.whois-search.com\/text2image/gi;
#		push @whoisResults, { source => "WhoisSearch", output => $domwhois };
#	}

### Whois #9: analyze malicious page
	my $page = httpGET ("http://" . $whoisHost . $whoisPage, undef, $userAgent);
	$page =~ s/'/"/gi;
	my $uc_page = uc($page);
	my @indexes;
	my $i = 0;
	for ($i = 0; $i < length($page); $i++) {
		if (substr($uc_page, $i, 6) eq " SRC=\"") { 
			push @indexes, { index => ($i + 6) } 
		};
	}         
	for ($i = 0; $i < length($page); $i++) {
		if (substr($uc_page, $i, 6) eq "HREF=\"") { 
			push @indexes, { index => ($i + 6) } 
		};
	}         

	my $idx = 0;
	my $tmp = "";
	my $link = "";
	my @links;
	foreach ( @indexes ) { 
		$tmp = substr ($page, $_->{index});
		$idx = index ($tmp, "\"");
		$link = substr ($tmp, 0, $idx); 
		if (substr (uc($link), 0, 4) ne "HTTP") { 
			if (substr ($link, 0, 1) eq "/") {
				$link = "http://" . $whoisHost . $link; 
			} else {
				my $lastslash = 0;
				if (length($whoisPage) == 0) { $whoisPage = "/"; }
				for (my $i = 0; $i < length ($whoisHost . $whoisPage); $i++) {
					if (substr ($whoisHost . $whoisPage, $i, 1) eq "/") {
						$lastslash = $i;
					}
				}
				$link = "http://" . substr ($whoisHost . $whoisPage, 0, $lastslash) . $link; 
			}
		}
		push @links, $link;
	}
	@links = sort(@links);

	my $linktext = "Links on 'http://" . $whoisHost . $whoisPage . "':<br/><br/>";
	my $prev_link = "";
	foreach ( @links ) {
		if ($prev_link ne $_) {
			my $printlink = $_;
			if ( length( $printlink ) > 85) { 
				$printlink = substr ($printlink, 0, 85) . "[...]"; 
			}
			$linktext .= "- <a href=\"" . $_ . "\">" . $printlink . "</a><br/>"; 
		}
		$prev_link = $_;
	}
	push @whoisResults, { source => "Taranis", output => $linktext };

### Final step: Notice-and-Take Down (NTD) mail
	my $body = "";
	foreach ( @whoisResults ) {
		$body .= $_->{output};
	}
	my $input_tmp = $body;
	my $abuse_to = "";

	while ( $input_tmp =~ m/abuse\@(.*?)(\..*?)?\.(net|com|jp|edu|arpa|it|uk|de|nl|ca|br|au|tw|fr|us|se|dk|be|mil|mx|org|pl|fi|es|ch|no|at|ar|gov|il|ru|hk|sg|nz|tr|cz|hu|pt|za|kr|gr|cl|cn|ro|co|ee|ie|my|is|th|sk|ae|ua|uy|in|pe|do|id|cc|hr|bg|lt|ve|si|lv|biz|lu|ph|yu|eg|cy|gt|to|su|nu|info|pk|sa|int|tv|md|lb|cr|py|bm|ke|ws|tt|pa|ni|bo|ma|bn|mt|ac|kg|tz|am|pf|kz|zw|by|nc|sv|mu|vi|aw|mk|mz|ec|na|kw|bz|ge|fo|li|gl|jo|hn|bw|lk|zm|ad|ba|ag|ky|cu|cx|rw|jm|sz|bh|gi|as|ng|st|uz|tc|bt|la|np|kh|mg|mc|om|bj|fm|dm|sn|gy|mv|tm|vu|ir|fj|bf|gp|sm|coop|sb|ai|pg|ck|hm|sh|vn|mq|name|aero|bs|sc|al|tk|ms|bb|vg|gs|tn|ml|cd|az|ci|gn|ne|ye|an|ls|je|aq|gu|gw|mo|ug|nf|pr|sy|tg|dj|tj|gh|im|gg|ly|kn|nr|cg|dz|qa|lc|mn|tf|va|mr|bi|gb|ga|re|gd|mw|sr|ao|ki|mp|io|museum|cm|gm|td|km|tp|et|lr|cf|cv|mh|pn|pro|af|vc|gq|mm|pm|sl|bd|er|gf|iq|pw|so|bv|fk|ht|sd|sj|um|wf|yt|zr)/g) {
		my $email = $&;
		$email = trim( $email );
		if ( ( $abuse_to ) && ( index( $abuse_to, $email ) == -1 ) ) { 
			$abuse_to .= "; "; 
		}
		if ( index( $abuse_to, $email ) == -1 ) { 
			$abuse_to .= $&; 
		}
	}
	$abuse_to =~ s/\n//gi;
	$abuse_to = "<unknown>" if ( !$abuse_to );

	$vars->{abuse} = { source => "Taranis", cymru => $cymru, abuse_to => $abuse_to };
	$vars->{whois_ip} = $whoisIp;
	$vars->{whois_page} = $whoisPage;
	$vars->{abuse_mail} = $tt->processTemplateNoHeader( "abuse.tt", $vars, 'noprint' );
	push @whoisResults, { source => "Taranis", output => $vars->{abuse_mail} };

	$vars->{results} = \@whoisResults;

	my $htmlContent = $tt->processTemplateNoHeader( 'whois.tt', $vars, 1 );
	
	return { content => $htmlContent };
}

## HELPERS
sub httpGET {
	my ( $url, $headerSetting, $userAgent ) = @_;
	my $req = HTTP::Request->new( GET => $url );
	if ( $headerSetting ) {
		$req->header( %$headerSetting );
	}
	my $res = $userAgent->request($req);
  
	if ( $res->is_success ) {
		return $res->content;
	} else {
		return "ERROR: " . $res->status_line;
	}
}

sub httpPOST {
	my ( $url, $data, $userAgent ) = @_;
	my $req = HTTP::Request->new( POST => $url );
	$req->content_type('application/x-www-form-urlencoded');
 	$req->content($data);

	my $res = $userAgent->request($req);

	if ( $res->is_success ) {
		return $res->content;
	} else {
		return "ERROR: " . $res->status_line;
	}
}


1;
