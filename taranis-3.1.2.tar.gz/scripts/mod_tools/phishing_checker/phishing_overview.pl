#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Template;
use Digest::MD5 qw(md5_base64);
use strict;

use Data::Dumper;

my @EXPORT_OK = qw(displayPhishingOverview deletePhishingItem addPhishingItem);

sub phishing_overview_export {
	return @EXPORT_OK;
}

sub displayPhishingOverview {
	my ( %kvArgs) = @_;	
	my ( @items, $vars );
	my $session = $kvArgs{session};
	
	my $tt = Taranis::Template->new();

	my $sql = "SELECT * FROM phish";
	$session->{dbh}->prepare( $sql );
	$session->{dbh}->executeWithBinds();
	
	while ( $session->{dbh}->nextRecord() ) {
		my $record = $session->{dbh}->getRecord();
		my $item;

		$item->{status}  = "uninitialized";
		if ( $record->{hash} ne "" ) {
			$item->{status} = "online";
		}
		$item->{dt_laststatus} = $record->{datetime_added};
		if ( ( $record->{datetime_hash_change} ne "" ) && ( $record->{counter_hash_change} >= 2 ) ) {
			$item->{status} = "hashchange";
			$item->{dt_laststatus} = $record->{datetime_hash_change};
		}
		if ( ( $record->{datetime_down} ne "" ) && ( $record->{counter_down} >= 2 ) ) {
			$item->{status} = "offline";
			$item->{dt_laststatus} = $record->{datetime_down};
		}
  
		$item->{dt_laststatus} = substr( $item->{dt_laststatus}, 6, 2 ) . "-" . substr( $item->{dt_laststatus}, 4, 2 ) .
			"-" . substr( $item->{dt_laststatus}, 0, 4 ) . " " . substr( $item->{dt_laststatus}, 8, 2 ) .
			":" . substr( $item->{dt_laststatus}, 10, 2 ) . ":" . substr( $item->{dt_laststatus}, 12, 2 );
      
		$item->{dt_added} = $record->{datetime_added};
  
		$item->{dt_added} = substr( $item->{dt_added}, 6, 2 ) . "-" . substr( $item->{dt_added}, 4, 2 ) .
			"-" . substr( $item->{dt_added}, 0, 4 ) . " " . substr( $item->{dt_added}, 8, 2 ) .
			":" . substr( $item->{dt_added}, 10, 2 ) . ":" . substr( $item->{dt_added}, 12, 2 );

		$item->{url} = $record->{url};
		
		my $urlHash = md5_base64( $item->{url} );
		$urlHash =~ s/[+\/=]//g;
		$item->{urlHash} = $urlHash;
		
		push @items, $item;		  	
	}

	if ( $session->{cgisession}->param("phishing_error" ) ) {
		$vars->{error} = $session->{cgisession}->param("phishing_error");
		$session->{cgisession}->clear("phishing_error");	
	}

	$vars->{phishingItems} = \@items;
	$vars->{newItem} = 1;
	
	my $htmlContent = $tt->processTemplateNoHeader( 'phishing_overview.tt', $vars, 1 );
	
	my $htmlFilters = $tt->processTemplateNoHeader('phishing_filters.tt', $vars, 1);
	
	my @js = ('js/phishing.js');
	
	return { content => $htmlContent, filters => $htmlFilters, js => \@js };
}

sub addPhishingItem {
	my ( %kvArgs) = @_;	
	my ( $message, $itemHtml, $vars, %phishingItem );
	my $session = $kvArgs{session};
	
	my $addOk = 0;

	if ( !$session->{dbh}->checkIfExists( { url => $kvArgs{url} }, "phish" ) ) {
		my %insert = ( url => $kvArgs{url}, datetime_added => nowstring( 2 ), counter_down => 0, counter_hash_change => 0 );
		
		my ( $stmnt, @bind ) = $session->{sql}->insert( "phish", \%insert );
				
		$session->{dbh}->prepare( $stmnt );
		$session->{dbh}->executeWithBinds( @bind );
		$addOk = 1;
		
		my $dt = nowstring( 2 );
		$phishingItem{url} = $kvArgs{url};
		$phishingItem{dt_added} = substr( $dt, 6, 2 ) . "-" . substr( $dt, 4, 2 ) .
			"-" . substr( $dt, 0, 4 ) . " " . substr( $dt, 8, 2 ) .
			":" . substr( $dt, 10, 2 ) . ":" . substr( $dt, 12, 2 );
		$phishingItem{dt_laststatus} = $phishingItem{dt_added};
		$phishingItem{status} = 'uninitialized';
		my $urlHash = md5_base64( $kvArgs{url} );
		$urlHash =~ s/[+\/=]//g;
		$phishingItem{urlHash} = $urlHash;

	} else {
		$message = "URL already exists!";
	}
	
	if ( $addOk ) {
		my $tt = Taranis::Template->new();
		$vars->{newItem} = 1;
		$vars->{phishingItem} = \%phishingItem;
		$itemHtml = $tt->processTemplateNoHeader( 'phishing_item.tt', $vars, 1 );		
	}

	return {
		params => {
			message => $message,
			addOk => $addOk,
			url => $kvArgs{url},
			itemHtml => $itemHtml
		}
	};
}

sub deletePhishingItem {
	my ( %kvArgs) = @_;	
	my ( $message );

	my $session = $kvArgs{session};
	my $deleteOk = 0;

	my $url = $kvArgs{url};
	my $urlHash = $kvArgs{urlhash};

	if ( $session->{dbh}->checkIfExists( { url => $url }, "phish" ) ) {
		my ( $stmnt, @bind ) = $session->{sql}->delete( "phish", {url => $url} );

		$session->{dbh}->prepare( $stmnt );
		$session->{dbh}->executeWithBinds( @bind );
		$deleteOk = 1;
	} else {
		$message = "URL does not exist!";
	}

	return {
		params => {
			message => $message,
			deleteOk => $deleteOk,
			urlHash => $urlHash
		}
	};	
}

1;
