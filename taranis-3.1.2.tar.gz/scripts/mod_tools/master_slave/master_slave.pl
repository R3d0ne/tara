#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;
use Fcntl qw(:flock :seek);
use JSON;
use Taranis::Template;
use Taranis::Config;

my @EXPORT_OK = qw(displayMasterSlave setMasterSlave);

sub master_slave_export {
	return @EXPORT_OK;
}

my $master_slave_file = Taranis::Config->getSetting("master_slave_file");

sub displayMasterSlave {
	my ( %kvArgs) = @_;	
	my $session = $kvArgs{session};
	
	my $master_slave_setting = "Unknown setting!";
	my $vars;
	my $tt = Taranis::Template->new();

	if ( $master_slave_file ) {
		my $fh;
		open( $fh, "<", $master_slave_file );
		my @raw_setting=<$fh>;
		close( $fh );

		if ( "@raw_setting" =~ /^(master|slave)$/) {
			$master_slave_setting = "@raw_setting";
		} 
	} 

	$vars->{master_slave_setting} = lc( $master_slave_setting );
	$vars->{write_right} = $session->right("write");

	my $htmlContent = $tt->processTemplateNoHeader( 'master_slave.tt', $vars, 1 );
	my $htmlFilters = $tt->processTemplateNoHeader( 'master_slave_filters.tt', $vars, 1 );
	
	my @js = ('js/master_slave.js');
	
	return { content => $htmlContent, filters => $htmlFilters, js => \@js };
}

sub setMasterSlave {
	my ( %kvArgs) = @_;	
	my $session = $kvArgs{session};
	my ( $message, $newSetting );
	
	my $changeOk = 0;
	
	if ( $kvArgs{set} =~ /^(master|slave)$/ && $master_slave_file ) {
  		
		eval{
			my $fh;
			open( $fh,">", $master_slave_file) || die("Cannot open file for writing: $master_slave_file");

			flock($fh, LOCK_EX);
			seek($fh, 0, SEEK_SET);
			print $fh $kvArgs{set};
			close($fh);   		
		};
  		
		if ( $@ ) {
			$message = $@;
		} else {
			$changeOk = 1;
			$newSetting = lc( $kvArgs{set} );
		}    
  	} else {
        $message = "Unknown setting given, cannot change master/slave setting.";
  	}

	return {
		params => {
			changeOk => $changeOk,
			message => $message,
			newSetting => $newSetting
		}
	};
}

1;

