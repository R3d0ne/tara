#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;

# to load this file when the server starts, add this to httpd.conf:
# PerlRequire /path/to/startup.pl

# make sure we are in a sane environment.
$ENV{MOD_PERL} or die "GATEWAY_INTERFACE not Perl!";

use ModPerl::Registry;
use Apache::DBI;
#use Apache::AuthDBI;

use lib qw(/opt/taranis/pm);
use Taranis qw (:all);
use Taranis::Config;
use Taranis::Analysis;;
use Taranis::Assess;
use Taranis::Config::XMLGeneric;
use Taranis::Constituent_Group;
use Taranis::Constituent_Individual;
use Taranis::Damagedescription;
use Taranis::Database;
use Taranis::Entitlement;
use Taranis::Publication;
use Taranis::Publicationtype;
use Taranis::Role;
use Taranis::Session;
use Taranis::SoftwareHardware;
use Taranis::Template;
use Taranis::Users;


    my $cfg      = Taranis::Config->new();
    my $user     = $cfg->{'dbuser'};
    my $name     = $cfg->{'dbname'};
    my $pass     = $cfg->{'dbpasswd'};
    my $dbhost   = $cfg->{'dbhost'};
    my $dbi      = $cfg->{'dbi'};
    my $dbdriver = $cfg->{'dbdriver'};
    my $dbport   = $cfg->{'dbport'};
#    my $dbh      = DBI->connect( "$dbi:$dbdriver:dbname=$name;host=$dbhost",
#                            "$user", "$pass", { AutoCommit => 1 } );
                            
# optional configuration for Apache::DBI.pm:

# choose debug output: 0 = off, 1 = quiet, 2 = chatty
#$Apache::DBI::DEBUG = 2;

# configure all connections which should be established during server startup.
# keep in mind, that if the connect does not succeeed, your server won't start
# until the connect times out (database dependent) !
# you may use a DSN with attribute settings specified within
Apache::DBI->connect_on_init("$dbi:$dbdriver(AutoCommit=>1):dbname=$name;host=$dbhost;port=$dbport", "$user", "$pass");

# configure the ping behavior of the persistent database connections
# you may NOT not use a DSN with attribute settings specified within
# $timeout = 0  -> always ping the database connection (default)
# $timeout < 0  -> never  ping the database connection
# $timeout > 0  -> ping the database connection only if the last access
#                  was more than timeout seconds before
#Apache::DBI->setPingTimeOut("dbi:driver:database", $timeout);


# optional configuration for Apache::AuthDBI.pm:

# choose debug output: 0 = off, 1 = quiet, 2 = chatty
#$Apache::AuthDBI::DEBUG = 2;

# set lifetime in seconds for the entries in the cache
#Apache::AuthDBI->setCacheTime(0);

# set minimum time in seconds between two runs of the handler which cleans the cache
#Apache::AuthDBI->setCleanupTime(-1);

# use shared memory of given size for the cache
#Apache::AuthDBI->initIPC(50000);


use ModPerl::MethodLookup;
ModPerl::MethodLookup::preload_all_modules();
#use ModPerl::Registry();

1;
