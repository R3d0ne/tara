#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;
use lib qw(/opt/taranis/pm);
use Taranis qw(:all);
use Taranis::Database;
use Taranis::Config;
use Taranis::Collector;
use Digest::MD5 qw(md5 md5_hex md5_base64);
use Mail::Sender;

my $dbh = Taranis::Database->new();
my $cfg = Taranis::Config->new();
my $collector = Taranis::Collector->new();

my $phish = &checkPhish;

print "phish result: $phish\n";

sub checkPhish {

  my $table  = 'phish';
  my $select = '*';
  my $return_result = 1;
  my %where;
  my ( $stmnt, @bind ) = $dbh->{sql}->select( $table, $select, \%where );

  $dbh->prepare( $stmnt );
  $dbh->executeWithBinds( @bind );

  if ( defined( $dbh->{db_error_msg} ) ) {
    print "ERROR: " . $dbh->{db_error_msg} . "\n";
    return 0;
  }

  my @phish_results;
  while ( $dbh->nextRecord ) {
    push @phish_results, $dbh->getRecord();
  }

  my $index_total       = -1;
  my $phishdownkeysfile = $cfg->{phishdownkeysfile};
  my $fh;
  open( $fh, "<", $phishdownkeysfile ) or die "I Can't read $phishdownkeysfile, $!\n";
  my @downkeys = <$fh>;
  close $fh;

  foreach my $record ( @phish_results ) {
    my ( $datetime_down, $datetime_hash_change );
    $collector->{this_source} = $record;
    print "Checkphish checking: $record->{url}\n";
    
    my $result = encodeInput ( \$collector->getSourceData( $record->{url} ) );
		
    $result =~ s /\n/<newline>/gi;
    my $md5_now = md5_base64( $result );

		$index_total = -1;
    foreach my $downkey ( @downkeys ) {
    	$downkey =~ s/\n//g;
      if ( index( uc( $result ), uc( $downkey ) ) > -1 ) {
        $index_total = $index_total + index( uc( $result ), uc( $downkey ) );
      }
    }

    ### Check current status of phishing website
    my $counter_down        = $record->{counter_down};
    my $counter_hash_change = $record->{counter_hash_change};

    my $status_before = "online";
    if ( $counter_down >= 2 ) { $status_before = "down"; }
    if ( ( $counter_hash_change >= 2 ) && ( $counter_down < 2 ) ) {
      $status_before = "hash changed";
    }

    if ( ( $index_total > -1 ) || ( $result eq "0" ) ) {
      $counter_down = $record->{counter_down};
      $counter_down++;
      if ( $counter_down >= 2 ) {
        if ( $record->{datetime_down} eq "" ) {
          $datetime_down = nowstring(2);
        } else {
          $datetime_down = $record->{datetime_down};
        }
      }
    } else {
      $counter_down  = 0;
      $datetime_down = 0;
    }

    my $md5_orig = $record->{hash};

    if ( $md5_now ne $md5_orig ) {
      if ( $md5_orig eq "" ) {
        $counter_hash_change  = 0;
        $datetime_hash_change = 0;

        %where = ( url => $record->{url} );
        my %db_args = ( hash => $md5_now );

        my ( $stmnt, @bind ) = $dbh->{sql}->update( $table, \%db_args, \%where );
        $dbh->prepare($stmnt);
        $dbh->executeWithBinds(@bind);

        if ( defined( $dbh->{db_error_msg} ) ) {
          print "ERROR: " . $dbh->{db_error_msg} . "\n";
          return 0;
        }

      } else {
        $counter_hash_change = $record->{counter_hash_change};
        $counter_hash_change++;
        if ( $counter_hash_change >= 2 ) {
          if ( $record->{datetime_hash_change} eq "" ) {
            $datetime_hash_change = nowstring(2);
          } else {
            $datetime_hash_change = $record->{datetime_hash_change};
          }
        }
      }
    } else {
      $counter_hash_change  = 0;
      $datetime_hash_change = 0;
    }

    my %where = ( url => $record->{url} );
    my %db_args = (
                    datetime_down        => $datetime_down,
                    datetime_hash_change => $datetime_hash_change,
                    counter_down         => $counter_down,
                    counter_hash_change  => $counter_hash_change
    );

    my ( $stmnt, @bind ) = $dbh->{sql}->update( $table, \%db_args, \%where );
    $dbh->prepare($stmnt);
    $dbh->executeWithBinds(@bind);

    if ( defined( $dbh->{db_error_msg} ) ) {
      print "ERROR: " . $dbh->{db_error_msg} . "\n";
      return 0;
    }

    my $status_change = "";
    if ( $counter_down == 2 ) {
      $status_change =
        "The status for " . $record->{url} . " changed from '" . $status_before . "' to 'down'\n\n";
    }
    if ( ( $counter_hash_change == 2 ) && ( $status_change eq "" ) && ( $counter_down < 2 ) ) {
      $status_change =
          "The status for "
        . $record->{url}
        . " changed from '"
        . $status_before
        . "' to 'hash changed'\n\n";
    }

    if ( ( $counter_down == 0 ) && ( $status_before eq "down" ) && ( $status_change eq "" ) ) {
      $status_change =
        "The status for " . $record->{url} . " changed from 'offline' to 'online'\n\n";
    }

    if ( $status_change ne "" ) {
      my $mailmessage = $status_change . "\n=== CONTENTS ===\n$result\n================\n";
      
      $mailmessage = decodeInput( \$mailmessage );

			my $sender = new Mail::Sender {
				smtp => $cfg->{smtpserver},
				user => $cfg->{smtpuser},
				pass => $cfg->{smtppass},
				port => $cfg->{smtpport},
				from => "\"Taranis\" <". $cfg->{phishfrom} . ">"
			};

			if ( ref( $sender ) ) {
				$sender->Open({
					to 			=> $cfg->{phishto},
					subject => "[Taranis] Status change for phish " . $record->{url},
					ctype 	=> 'text/plain',
					charset => 'UTF-8',
					encoding => "Quoted-printable"
				});
				$sender->SendEnc( $mailmessage );
				$sender->Close();
				
				if ( !$sender->{error} ) {
					print "E-mail to " . $cfg->{phishto} . " was succesfully sent!\n";
				} else {
					$return_result = 0;
					print "Error for address ". $cfg->{phishto} .": " . $Mail::Sender::Error . "\n";
				}
			} else {
				$return_result = 0;
				print "Error for address ". $cfg->{phishto} .": " . $Mail::Sender::Error . "\n";
				
			}				
    }
  }
  return $return_result;
}
