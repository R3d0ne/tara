#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use lib qw(/opt/taranis/pm);

use Data::Dumper;
use Taranis::Config;
use Taranis::Database;
use Taranis qw(:util);
use LWP::UserAgent;
use XML::XPath;
use strict;
use sigtrap 'handler' => \&sig_handler, 'normal-signals';

my $ua = LWP::UserAgent->new;
my $dbh = Taranis::Database->new();

my $proxy_host 	= Taranis::Config->getSetting("proxy_host");
#my $nvdcve_url 	= Taranis::Config->getSetting("nvdcve_url");
my $download_path = Taranis::Config->getSetting("downloadpath");
my $pidfile = $download_path . 'cpe_download.PID';
my $userAgentString = Taranis::Config->getSetting("useragent_string");

# to turn logging off set to 0
my $logging_enabled = 1; 

if (-e $pidfile) {
  open (IN, "$pidfile") or logthis ("can't read PID file") && die ;
  my $PID = <IN>;
  close IN;
  logthis (nowstring(7). " Another cpe_download process with ID $PID is allready running");
  exit;
} else {
  open (OUT, ">$pidfile") or logthis ("can't create PID file") && die ;
  print OUT "$$";
  close OUT;
}


$ua->proxy(['http', 'https'], $proxy_host);
$ua->agent($userAgentString);

my $sql = "SELECT * FROM download_files where name ='cpe_download'";

$dbh->prepare( $sql );
$dbh->executeWithBinds();
my @files;
while ( $dbh->nextRecord() ) {
	push @files, $dbh->getRecord();
}

$sql = "UPDATE download_files SET last_change = ? where filename = ?;";
$dbh->prepare( $sql );

foreach ( @files ) {
#	my $req = HTTP::Request->new( HEAD => $nvdcve_url.$_->{filename} );
	my $req = HTTP::Request->new( HEAD => $_->{file_url} );
	my $res = $ua->request( $req );

	if ( $res->is_success ) {
		if ( $res->headers->{"last-modified"} ne $_->{last_change} ) {
#			$req = HTTP::Request->new( GET => $nvdcve_url.$_->{filename} );
			$req = HTTP::Request->new( GET => $_->{file_url} );
			$res = $ua->request( $req, $download_path.$_->{filename} );
			
			if ( $res->is_success ) {
				$dbh->executeWithBinds( $res->headers->{"last-modified"}, $_->{filename} );
				logthis( nowstring(7)." $_->{filename} Download OK ");
				saveToDatabase( $_->{filename} );
				logthis( nowstring(7)." Saving to database DONE.");				
			} else {
			 logthis( nowstring(7)." Error GET request: " . $res->status_line );
			 $dbh->close();
			}  						
		} else {
			logthis( nowstring(7)." No changes since last download for $_->{filename}" );
		}
		
	} else {
	 logthis( nowstring(7)." Error HEAD request: " . $res->status_line );
	 $dbh->close();
	}  	
}

unlink $pidfile;


sub saveToDatabase {
	my $file = shift;
	my $xp = XML::XPath->new( filename => $download_path.$file );
	my $dbh2 = Taranis::Database->new();
	
	my %cve_cpe_list;

	foreach my $cve_entry ( $xp->find('//entry')->get_nodelist ) {
		my $cve_id = $cve_entry->find('@id')->string_value;
		my @cpe_list;
		
########################### VULNERABLE SOFTWARE / HARDWARE ###########################	
		if ( $cve_entry->find('vuln:vulnerable-software-list')->size ne 0 ) {
			
			for ( my $i = 0; $i < $cve_entry->find('vuln:vulnerable-software-list/vuln:product')->size ; $i++ ) {
	    	push @cpe_list, $cve_entry->find('vuln:vulnerable-software-list/vuln:product')->get_node( $i )->string_value."\n";
	    }
		}
	
########################### PLATFORMS ###########################	
		if ( $cve_entry->find('vuln:vulnerable-configuration')->size ne 0 ) {
			
			if ( $cve_entry->find('vuln:vulnerable-configuration')->size > 1 ) {
				foreach my $node ( $cve_entry->find('vuln:vulnerable-configuration')->get_nodelist ) {
	
					for ( my $l = 0; $l < $node->find('cpe-lang:logical-test/cpe-lang:logical-test/cpe-lang:fact-ref')->size; $l++ ) {
						if ( $node->find('cpe-lang:logical-test/cpe-lang:logical-test/cpe-lang:fact-ref/@name')->get_node( $l )->string_value =~ /^cpe:\/o/i ) {					
							push @cpe_list, $node->find('cpe-lang:logical-test/cpe-lang:logical-test/cpe-lang:fact-ref/@name')->get_node( $l )->string_value;
						}	
					}
	
				}
			} elsif ( $cve_entry->find('vuln:vulnerable-configuration/cpe-lang:logical-test/cpe-lang:logical-test/cpe-lang:fact-ref')->size ne 0 ) {
					
					for ( my $i = 0; $i < $cve_entry->find('vuln:vulnerable-configuration/cpe-lang:logical-test/cpe-lang:logical-test/cpe-lang:fact-ref')->size; $i++) {
						if ( $cve_entry->find('vuln:vulnerable-configuration/cpe-lang:logical-test/cpe-lang:logical-test/cpe-lang:fact-ref/@name')->get_node( $i )->string_value =~ /^cpe:\/o/i ) {
							push @cpe_list, $cve_entry->find('vuln:vulnerable-configuration/cpe-lang:logical-test/cpe-lang:logical-test/cpe-lang:fact-ref/@name')->get_node( $i )->string_value;
						}
					}			
				
			} elsif ( $cve_entry->find('vuln:vulnerable-configuration/cpe-lang:logical-test/cpe-lang:fact-ref')->size ne 0 ) {
	
				for ( my $j = 0; $j < $cve_entry->find('vuln:vulnerable-configuration/cpe-lang:logical-test/cpe-lang:fact-ref')->size; $j++) {
					if ( $cve_entry->find('vuln:vulnerable-configuration/cpe-lang:logical-test/cpe-lang:fact-ref/@name')->get_node( $j )->string_value =~ /^cpe:\/o/i ) {
						push @cpe_list, $cve_entry->find('vuln:vulnerable-configuration/cpe-lang:logical-test/cpe-lang:fact-ref/@name')->get_node( $j )->string_value;	
					}
				}
				
			}
			
		}
###################################################################	

		my %unique_list;
		foreach ( sort @cpe_list ) {
			$unique_list{trim($_)} = 1;
		}
	
		@{ $cve_cpe_list{ $cve_id } } = keys %unique_list;
		
	}
	
	my $sql = "INSERT INTO cpe_cve VALUES(?,?);";

	foreach my $cve ( keys %cve_cpe_list ) {
		for ( my $j = 0; $j < @{ $cve_cpe_list{$cve} }; $j++ ) {
			if ( !$dbh2->checkIfExists( { cve_id => $cve, cpe_id => trim( $cve_cpe_list{$cve}[$j] ) }, "cpe_cve" ) ) {
				$dbh2->prepare( $sql );
				$dbh2->executeWithBinds( $cve, trim( $cve_cpe_list{$cve}[$j] ) );
				if ( $dbh2->{db_error_msg} ) {
					my $error = $dbh2->{db_error_msg};
					logthis( nowstring(7).$error );
				} 
			}
		}
	}
}

sub sig_handler {
    unlink $pidfile;
    die "died";    
}

sub logthis {
  my $regel = shift;
	
	if ( $logging_enabled ) {
  	open( OUT, ">>".$download_path."cpe_download.log" );
  	print OUT "$regel\n";
  	close OUT;
	}
}
