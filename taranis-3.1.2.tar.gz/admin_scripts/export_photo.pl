#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use lib qw(/opt/taranis/pm);

use Getopt::Long;
use Taranis::Database;
use Taranis::CsvBuilder;
use Data::Dumper;
use Tie::IxHash;
use strict; 

my ( %where );
tie my %join, "Tie::IxHash";

my $print2screen = 0;
my ( $result, $file, $constituent, $producer, $product, $product_export ) = undef;

my $quote_all = 0;
my $sep_char = ',';

GetOptions( 
						'o=s' => \$file,
						'p' 	=> \$print2screen,
						'c=s' => \$constituent,
#						'pr=s' => \$producer,
#						'pt=s' => \$product,
						's=s'	=> \$sep_char,
						'q'		 => \$quote_all,
						'pe'	=> \$product_export
					);


my %softwareHardwareType = ( 'a' => 'Applicatie', 'h' => 'Hardware', 'o' => 'Operating System' );

if ( ( $file || $print2screen ) && !$@ && 
		( 
#		( !$product_export && ( $constituent || $producer || $product ) ) || 
#		( $product_export && ( !$constituent || !$producer || !$product ) ) ||
#		( !$product_export && !$constituent && !$producer && !$product )
		( !$product_export && $constituent ) || 
		( $product_export && !$constituent ) ||
		( !$product_export && !$constituent ) 
		) 
	) {

	my $csv = Taranis::CsvBuilder->new( 
																			sep_char => $sep_char, 
																			quote_all => $quote_all ,
																			file => $file
																		);
	
	my $dbh = Taranis::Database->new();
	my $sql = $dbh->{sql};
	
	if ( $product_export ) {
		my ( $stmnt, @bind ) = $sql->select( "software_hardware sh", "producer, name, description, cpe_id", { deleted => 0, base => [ 'o', 'h', 'a' ] }, "producer, name, description, cpe_id" );
		
		%join = ( "JOIN soft_hard_type AS sht" 	=> {"sh.type" => "sht.base"} );
						
		$stmnt = $dbh->sqlJoin( \%join, $stmnt );
		
		$stmnt =~ s/(.*)(ORDER BY.*)/$1 GROUP BY sh.producer, sh.name, sht.description, sh.cpe_id $2/i;

		$dbh->prepare( $stmnt );
		$dbh->executeWithBinds( @bind );
		
		if ( defined( $dbh->{db_error_msg} ) ) {
			$result = $dbh->{db_error_msg};
		} else {
			
			$csv->addLine( "Leverancier", "Product", "CPE", "Type" );
			
			while ( $dbh->nextRecord() ) {
				my $record = $dbh->getRecord();
				
				$record->{name} =~ s/\s+/ /g;
				
				$csv->addLine( $record->{producer}, $record->{name}, $record->{cpe_id}, $record->{description} );
			}
		}		
		
	} else {
		$where{"cg.name"} 		= { -ilike => $constituent } if ( $constituent ) ;
#		$where{"sh.producer"} = { -ilike => "%" . $producer . "%" 	 } if ( $producer ) ;
#		$where{"sh.name"} 		= { -ilike => "%" . $product . "%" 		 } if ( $product ) ;
		$where{deleted}				= 0;
		
		my ( $stmnt, @bind ) = $sql->select( "software_hardware AS sh", "sh.producer, sh.name AS product, sht.description, sh.cpe_id", \%where, "sh.producer, sh.name, sht.description, sh.cpe_id" );
		%join = (
						 "JOIN soft_hard_usage AS shu" 	=> {"sh.id" 	=> "shu.soft_hard_id"}, 
						 "JOIN constituent_group AS cg" => {"cg.id" 	=> "shu.group_id" 	 },
						 "JOIN soft_hard_type AS sht" 	=> {"sh.type" => "sht.base"				 }
						);
						
		$stmnt = $dbh->sqlJoin( \%join, $stmnt );
		
		$stmnt =~ s/(.*)(ORDER BY.*)/$1 GROUP BY sh.producer, sh.name, sht.description, sh.cpe_id $2/i;
		
		$dbh->prepare( $stmnt );
		$dbh->executeWithBinds( @bind );
		
		if ( defined( $dbh->{db_error_msg} ) ) {
			$result = $dbh->{db_error_msg};
		} else {
			
			$csv->addLine( "Leverancier", "Product", "CPE", "Type" );
			
			while ( $dbh->nextRecord() ) {
				my $record = $dbh->getRecord();
				
				$record->{product} =~ s/\s+/ /g;
				
				$csv->addLine( $record->{producer}, $record->{product}, $record->{cpe_id}, $record->{description} );
			}
		}
	}
	
	if ( $print2screen ) {
		print $csv->print_csv()
	}
	
	if ( $file ) {
		if ( $csv->csv2file() ) {
			$result = $file . " created.\n";
		} else {
			$result = $csv->print_error();
		}
	}
} else {
	$result = 
"Output options:
 -o 	[filename]	print to file
 -p 			print to screen
Search options:
 -c 	[name]		search constituent(s)
 -pe			export empty photo (cannot be used with other search options)
Format options:
 -q			quote all fields
 -s	[separator]	specify separator character (default is comma -> , )\n";
}

# -pr 	[producer]	search producer(s)
# -pt	[product]	search product(s)

print $result;
