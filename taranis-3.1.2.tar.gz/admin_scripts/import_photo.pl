#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use lib qw(/opt/taranis/pm);
use Taranis::Database;
use Data::Dumper;
use strict;
use Text::CSV;

my ( $doTest, $constituentName, $constituentId, $csvFile, $skippedImport, $imported, $deletedCurrentPhoto, $printSkipped, $printFile ) = undef;
my ( @import, @duplicateCsvRecords );

$skippedImport = 0;
$imported = 0;
$deletedCurrentPhoto = 0;

# \033[0m 		normal font
# \033[1m			bold font

## DO A TEST RUN ?

while ( $doTest !~ /^(y|n)$/i ) {
	print "Perform test run (photo will not be changed) [y|n]: ";
	$doTest = <STDIN> ;
	$doTest =~ s/^\s*//;
	$doTest =~ s/\s*$//;
}

$doTest = ( $doTest =~ /y/i ) ? 1 : 0;

my $dbh = Taranis::Database->new();
my $dbh2 = Taranis::Database->new();
my $sql = $dbh->{sql};

## SPECIFY CONSTITUENT NAME AND CHECK IT EXISTS, IF SO SET CONSITUENT ID

while ( !$constituentId ) {
	print "Constituent name: ";
	$constituentName = <STDIN> ;
	$constituentName =~ s/^\s*//;
	$constituentName =~ s/\s*$//;
	
	my ( $stmnt, @bind ) = $sql->select( 'constituent_group', 'id', { name => { -ilike => $constituentName }, status => 0 } );
	
	$dbh->prepare( $stmnt );
	$dbh->executeWithBinds( @bind );
	
	my $constituentData = $dbh->fetchRow(); 
	if ( $constituentData ) {
		$constituentId = $constituentData->{id};	
	} else {
		print "Constituent '$constituentName' does not exist.\n";
	}
}

## SPECIFY CSV FILE AND READ FILE

my $csv = Text::CSV->new();
my %csvRecordCheck;

while ( !$csvFile ) {
	print "CSV file: ";
	$csvFile = <STDIN>;
	$csvFile =~ s/^\s*//;
	$csvFile =~ s/\s*$//;

	if ( open (CSV, "<", $csvFile ) ) {
		
		print "\n\033[1mACTION: reading CSV file...\n\033[0m";
		
		while (<CSV>) {
			
			if ( $csv->parse($_) ) {

				my @fieds = $csv->fields();
				my $checkString = lc( $fieds[0] ) . lc( $fieds[1] ) . lc( $fieds[2] );
				
				if ( exists( $csvRecordCheck{ $checkString } ) ) {
					push @duplicateCsvRecords, { producer => $fieds[0], name => $fieds[1], type => $fieds[2] };						
				} else {
					$csvRecordCheck{ $checkString } = 1;
					push @import, { producer => $fieds[0], name => $fieds[1], type => $fieds[2] };
				}

			} else {
				my $err = $csv->error_input;
				print "Failed to parse line: $err";
				undef $csvFile;
			}
			
		}
	} else {
		print $! . "\n";
		undef $csvFile;
	}
	print "\n";
	close CSV;
	
	if ( @duplicateCsvRecords ) {
		print "duplicate records found in csv: \n";
		print "+" . createDashedLine() . "+\n";
		foreach my $duplicate ( @duplicateCsvRecords ) {
			
			print "| " . $duplicate->{producer} . calcSpaces( $duplicate->{producer}, 80 ) . 
						"|\n| " . $duplicate->{name} . calcSpaces( $duplicate->{name}, 80 ) . 
						"|\n| " . $duplicate->{type} . calcSpaces( $duplicate->{type}, 80 ) . "|\n";
			print "+" . createDashedLine() . "+\n";
			
		}
	}
}

# CHECK IF EVERY IMPORT ITEM HAS EXACTLY ONE RECORD

my ( $importCheckStmnt, @importCheckBind ) = $sql->select( 'software_hardware', 'COUNT(*) as cnt', { producer => { -ilike => 'dummy' } , name => { -ilike => 'dummy' }, deleted => 0 } );

my ( $shInUseStmnt, @shInUseBind ) = $sql->select( 'soft_hard_usage shu', 'COUNT(shu.*) as cnt', { producer => { -ilike => 'dummy' } , name => { -ilike => 'dummy' }, deleted => 0 } );
my %join = ( 'JOIN software_hardware sh' => { 'shu.soft_hard_id' => 'sh.id' } );

$shInUseStmnt = $dbh2->sqlJoin( \%join, $shInUseStmnt );

$dbh->prepare( $importCheckStmnt );
$dbh2->prepare( $shInUseStmnt );

print "number of records: " . scalar( @import ) . "\n";
my @skipped;
my @notInUse;
print "\n\033[1mACTION: checking if import software/hardware exists...\n\n\033[0m";
for ( my $i = 0; $i < scalar( @import ); $i++ ) {
	my $record = $import[$i];

	undef @importCheckBind;

	push @importCheckBind, 0, $record->{name}, $record->{producer};

	$dbh->executeWithBinds( @importCheckBind );
	
	my $cnt = $dbh->fetchRow();
	
	if ( $cnt && $cnt->{cnt} eq 1 ) {
		
		$dbh2->executeWithBinds( @importCheckBind );
		
		my $usageCount = $dbh2->fetchRow();
		push @notInUse, $record if ( !$usageCount->{cnt} );

	} else {
		if ( !$cnt || $cnt->{cnt} eq 0 ) {
			print "+" . createDashedLine() . "+\n" if ( !$skippedImport );
			print	"| " . $record->{producer} . calcSpaces( $record->{producer}, 80 ) . 
						"|\n| " . $record->{name} . calcSpaces( $record->{name}, 80 ) .
						"|\n| Not found in database" . calcSpaces( "Not found in database", 80 ) . 
						"|\n";
			print "+" . createDashedLine() . "+\n";						
			
			$import[$i]->{skippedReason} = "Not found in database";
			push @skipped, splice( @import, $i, 1 );
			$i--;
	
			$skippedImport++;
		} else {
			print "+" . createDashedLine() . "+\n" if ( !$skippedImport );
			print "| " . $record->{producer} . calcSpaces( $record->{producer}, 80 ) . 
						"|\n| " . $record->{name} . calcSpaces( $record->{name}, 80 ) .
						"|\n| Found $cnt->{cnt} times in database" . calcSpaces( "Found $cnt->{cnt} times in database", 80 ) .
						"|\n";			
			print "+" . createDashedLine() . "+\n";
			
			$import[$i]->{skippedReason} = "Found $cnt->{cnt} times in database";
			push @skipped, splice( @import, $i, 1 );
			$i--;

			$skippedImport++;
		}
	}
}

print "Skipped: \033[1m" . $skippedImport . "\033[0m\n" if ( $skippedImport );
print "Software/hardware not in use by other constituents: \033[1m" . scalar @notInUse . "\033[0m\n" if ( @notInUse );
print "Number of records to import: \033[1m" . scalar( @import ) . "\033[0m\n";

## IF ERRORS FOUND ASK TO PROCEED

if ( $skippedImport ) {
	my $proceed;
	while ( $proceed !~ /^(y|n)$/i ) {
		print "$skippedImport records of import file cannot be imported. Proceed?[y|n]: ";
		$proceed = <STDIN>;
		$proceed =~ s/^\s*//i;
		$proceed =~ s/\s*$//i;
	}
	
	print "quit import\n\n" and exit if ( $proceed =~ /n/i );
}

my $deletePhoto = 0;

## CHECK IF CONSTITUENT STILL HAS LINKED SOFTWARE OR HARDWARE

print "\n\033[1mACTION: checking for existing photo for $constituentName ...\n\033[0m";
if ( $dbh->checkIfExists( { group_id => $constituentId }, 'soft_hard_usage' ) ) {
	print "Current photo details:\n";
	
	my ( $stmnt, @bind ) = $sql->select( 'software_hardware sh', 'sh.producer, sh.name AS product, sht.description', 
																			 { 'shu.group_id' => $constituentId }, 
																			 'sh.producer, sh.name, sht.description' 
																		 );
	
	my %join = (
	 						 "JOIN soft_hard_usage AS shu" 	=> {"sh.id" 	=> "shu.soft_hard_id"}, 
						 	 "JOIN soft_hard_type AS sht" 	=> {"sh.type" => "sht.base"				 }
							);																	 

	$stmnt = $dbh->sqlJoin( \%join, $stmnt );
	
	$dbh->prepare( $stmnt );
	$dbh->executeWithBinds( @bind );
	
	print "+" . createDashedLine() . "+\n";
	
	while ( $dbh->nextRecord() ) {
		my $record = $dbh->getRecord();
		
		print "| " . $record->{producer} . calcSpaces( $record->{producer}, 80 ) . 
					"|\n| " . $record->{product} . calcSpaces( $record->{product}, 80 ) . 
					"|\n| " . $record->{description} . calcSpaces( $record->{description}, 80 ) . "|\n";
		print "+" . createDashedLine() . "+\n";
		$deletedCurrentPhoto++;
	}
	
	my $action;
	while ( $action !~ /^(q|d)$/i ) {
		print "A photo with\033[1m $deletedCurrentPhoto\033[0m items of constituent $constituentName already exists. Do you want to delete (and insert new photo) or quit import? [d|q]: ";
		$action = <STDIN>;
		$action =~ s/^\s*//i;
		$action =~ s/\s*$//i;	
		
	}
	print "quit import\n\n" and exit if ( $action =~ /q/i );
	
	$deletePhoto = 1;
	
} else {
	print "no photo found\n";
}

undef $dbh->{db_error_msg};
$dbh->startTransaction() if ( !$doTest );

## DELETE PHOTO

if ( $deletePhoto ) {
	print "\n\033[1mACTION: deleting photo...\n\033[0m";
 
	my ( $stmnt, @bind ) = $sql->delete( 'soft_hard_usage', { group_id => $constituentId } );
	$dbh->prepare( $stmnt );
		
	$dbh->executeWithBinds( @bind ) if ( !$doTest );
	
	if ( $dbh->{db_error_msg} ) {
		print $dbh->{db_error_msg} . "\n";
		print "Sorry, database error, going to quit import\n\n";
		$dbh->endTransaction() if ( !$doTest );
		exit;
	}
	print "...no worries, this is a test run, nothing is deleted yet...\n" if ( $doTest );
}
	
## IMPORT PHOTO

print "\n\033[1mACTION: importing photo...\033[0m\n\n";

my $importStmnt =	"INSERT INTO soft_hard_usage ( group_id, soft_hard_id ) 
									 VALUES ( $constituentId, ( SELECT id FROM software_hardware 
														 								  WHERE producer ilike ?
																		 					AND name ilike ?
																		 					AND deleted = 'f' 
																						 ) );"; 

foreach my $record ( @import ) {
	if ( $record ) {

		my @bind = ( $record->{producer}, $record->{name} );
		
		$dbh->prepare( $importStmnt );

		$dbh->executeWithBinds( @bind ) if ( !$doTest );
		
		if ( $dbh->{db_error_msg} ) {
			print $dbh->{db_error_msg} . "\n";
			print "Sorry, database error, going to quit import\n\n";
			print "Error with record: @bind\n\n";
			$dbh->endTransaction() if ( !$doTest );
			exit;
		} else {
			$imported++;
			print "imported '$record->{producer} $record->{name}'\n";
		}
	}
}
print "...no worries, this is a test run, nothing is imported yet...\n" if ( $doTest );

$dbh->endTransaction() if ( !$doTest );

my $duplicates = scalar @duplicateCsvRecords;
my $notInUseCount = scalar @notInUse;
print "\033[1mSTATS --> imported: $imported, skipped: $skippedImport, deleted: $deletedCurrentPhoto, duplicates in csv: $duplicates, not in use: $notInUseCount\n\033[0m";

if ( @skipped || @notInUse ) {

	while ( $printSkipped !~ /^(y|n)$/i ) {
		print "Print skipped records and records not in use by other constituents to file? [y|n]: ";
		$printSkipped = <STDIN> ;
		$printSkipped =~ s/^\s*//;
		$printSkipped =~ s/\s*$//;
	}
	
	if ( $printSkipped =~ /y/i ) {

		while ( !$printFile ) {
			print "Print file: ";
			$printFile = <STDIN>;
			$printFile =~ s/^\s*//;
			$printFile =~ s/\s*$//;
		
			if ( open ( PRINTFILE, ">", $printFile ) ) {
				
				print "\n\033[1mACTION: printing to file...\n\033[0m";
				
				if ( @skipped ) {
					print PRINTFILE "IMPORT SCRIPT SKIPPED RECORDS FOR " . $constituentName . "\n\n";
					print PRINTFILE "+" . createDashedLine() . "+\n"; 
					
					foreach my $skip ( @skipped ) {
						
						print PRINTFILE "| " . $skip->{producer} . calcSpaces( $skip->{producer}, 80 );
						print PRINTFILE	"|\n| " . $skip->{name} . calcSpaces( $skip->{name}, 80 ); 
						print PRINTFILE "|\n| " . $skip->{type} . calcSpaces( $skip->{type}, 80 );
						print PRINTFILE "|\n| " . $skip->{skippedReason} . calcSpaces( $skip->{skippedReason}, 80 ) . "|\n";
						print PRINTFILE "+" . createDashedLine() . "+\n";					
	
					}
				}

				if ( @notInUse ) {
					print PRINTFILE "\n\n" if ( @skipped );
					print PRINTFILE "IMPORT SCRIPT RECORDS NOT IN USE BY OTHER CONSTITUENTS \n\n";
					print PRINTFILE "+" . createDashedLine() . "+\n"; 
					
					foreach my $niu ( @notInUse ) {
						
						print PRINTFILE "| " . $niu->{producer} . calcSpaces( $niu->{producer}, 80 );
						print PRINTFILE	"|\n| " . $niu->{name} . calcSpaces( $niu->{name}, 80 ); 
						print PRINTFILE "|\n| " . $niu->{type} . calcSpaces( $niu->{type}, 80 ) . "|\n";
						print PRINTFILE "+" . createDashedLine() . "+\n";					
	
					}
				}
				
			} else {
				print $! . "\n";
				undef $printFile;
			}
			print "\n";
			close PRINTFILE;
		}
	} 
}

print "END OF IMPORT\n\n";

sub calcSpaces {
	my ( $string, $maxLength) = @_;
	
	my $spaceLength = $maxLength - length( $string ); 
	
	my $space = "";
	if ( $spaceLength > 0 ) {
		for( my $i = 0; $i < $spaceLength; $i++ ) {
			$space .= " ";
		}
	}
	return $space;
}

sub createDashedLine {
	my $line = "";
	for ( my $i = 0; $i <= 80; $i++ ) {
		$line .= "-";
	}
	return $line;
}
