#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;
use lib qw(/opt/taranis/pm );
use Taranis::Database;

use POSIX;

  #######################################################################
  ## Description : archives all records based on the date entered by
  ##               the user
  ## Input       : date (yyyymmdd) -- user input via keyboard
  ## Output      : nothing
  #######################################################################

  my ( $date, $error, $ord, $year, $month, $day, $yesorno, $query );

  while ( $date eq "" ) {
    print "Enter the 'archive to' date (yyyymmdd): ";
    $date = <>;
    if ( length($date) != 9 ) {
      print "-- Invalid date (format is yyyymmdd)\n";
      $date = "";
    }
    $error = "";
    if ( $date ne "" ) {
      for ( my $i = 0 ; $i < 8 ; $i++ ) {
        $ord = ord( substr( $date, $i, 1 ) );
        if ( $ord < 48 || $ord > 57 ) {
          $error = "-- Invalid date, just only numbers (format is yyyymmdd)\n";
        }
      }
      if ( $error ne "" ) {
        print $error;
        $date = "";
      }
    }
    $error = "";
    if ( $date ne "" ) {
      $year  = substr( $date, 0, 4 );
      $month = substr( $date, 4, 2 );
      $day   = substr( $date, 6, 2 );
      if ( $year < 2000 || $year > 2100 ) {
        $error = "-- Invalid year (" . $year . ")";
        print $error. "\n";
      }
      if ( $month < 1 || $month > 12 ) {
        $error = "-- Invalid month (" . $month . ")";
        print $error. "\n";
      }
      if ( $day < 1 || $day > 31 ) {
        $error = "-- Invalid date (" . $day . ")";
        print $error. "\n";
      }
      if ( $error ne "" ) {
        $date = "";
      }
    }
    if ( $date ne "" ) {
      print "Are you sure you want to archive all records before " 
        . $day . "-" 
        . $month . "-"
        . $year
        . " (y/n)? ";
      $yesorno = <>;
      if ( uc( substr( $yesorno, 0, 1 ) ) eq "Y" ) {
      	print "RECORD COUNT BEFORE ARCHIVING: \n";
      	countRecords();
      	
        my $dbh = Taranis::Database->new();
        
        $dbh->startTransaction();
        
        chomp $date;
        
        print "Step #1: archiving email_item records   ... ";

        $query = "INSERT INTO email_item_archive ( SELECT email_item.* FROM email_item" 
        . " JOIN item ON item.digest = email_item.digest"
        . " LEFT OUTER JOIN item_analysis ON item.digest = item_analysis.item_id"
        . " LEFT OUTER JOIN item_publication_type ON item_publication_type.item_digest = item.digest"
        . " WHERE item.is_mail = 't'" 
        . " AND item.created < '$date'"
        . " AND item_publication_type.item_digest IS NULL"
        . " AND item_analysis.item_id IS NULL)";        

        if ($dbh->do($query)) {
            print "done\n";  
        } else {
          print "DB Error: " . $dbh->{db_error_msg} . "\n";
          $dbh->endTransaction();
          print "RECORD COUNT AFTER ARCHIVING: \n";
          countRecords();
          exit;
        }

        print "Step #2: delete archived email items    ... ";

        $query = "DELETE FROM email_item WHERE digest IN (SELECT digest FROM email_item_archive)";
        
        if ($dbh->do($query)) {
            print "done\n";  
        } else {
          print "DB Error: " . $dbh->{db_error_msg} . "\n";
          $dbh->endTransaction();
          print "RECORD COUNT AFTER ARCHIVING: \n";
          countRecords();
          exit;
        }
                      
        print "Step #3: archiving feed records         ... ";

        $query = "INSERT INTO item_archive" 
        . " SELECT * FROM item WHERE created < '$date'"
        . " AND digest IN "
        . " (SELECT item.digest FROM item" 
        . " LEFT OUTER JOIN item_analysis ON item_analysis.item_id = item.digest" 
        . " LEFT OUTER JOIN item_publication_type ON item_publication_type.item_digest = item.digest"
        . " WHERE item_analysis.item_id IS NULL"
        . " AND item_publication_type.item_digest IS NULL)";
            
        if ($dbh->do($query)) {
            print "done\n";  
        } else {
          print "DB Error: " . $dbh->{db_error_msg} . "\n";
          $dbh->endTransaction();
          print "RECORD COUNT AFTER ARCHIVING: \n";
          countRecords();
          exit;
        }

        print "Step #4: deleting archived feed records ... ";

        $query = "DELETE FROM item WHERE digest IN"
        . " (SELECT i2.digest FROM item i2"
        . " LEFT OUTER JOIN item_analysis ON item_analysis.item_id = i2.digest"
        . " LEFT OUTER JOIN item_publication_type ON item_publication_type.item_digest = i2.digest"
        . " WHERE i2.created < '$date'"
        . " AND item_publication_type.item_digest IS NULL"
        . " AND item_analysis.item_id IS NULL)";
            
        if ($dbh->do($query)) {
            print "done\n";  
        } else {
          print "DB Error: " . $dbh->{db_error_msg} . "\n";
          $dbh->endTransaction();
          print "RECORD COUNT AFTER ARCHIVING: \n";
          countRecords();
          exit;
        }

        print "Step #5: archiving ID's                 ... ";
        
        $query = "INSERT INTO identifier_archive SELECT * FROM identifier WHERE identifier.digest NOT IN (SELECT item.digest FROM item);";
        
        if ($dbh->do($query)) {
            print "done\n";  
        } else {
          print "DB Error: " . $dbh->{db_error_msg} . "\n";
          $dbh->endTransaction();
          print "RECORD COUNT AFTER ARCHIVING: \n";
          countRecords();
          exit;
        }

        print "Step #6: delete archived ID's           ... ";

		$query = "DELETE FROM identifier WHERE identifier.digest NOT IN (SELECT item.digest FROM item);";
            
        if ($dbh->do($query)) {
            print "done\n";  
        } else {
          print "DB Error: " . $dbh->{db_error_msg} . "\n";
          $dbh->endTransaction();
          print "RECORD COUNT AFTER ARCHIVING: \n";
          countRecords();
          exit;
        }

#        print "Step #7: emptying distinct tables       .";
#        
#        $query = "DELETE FROM distinct_source_archive";
#        if ($dbh->do($query)) {
#        print ".";  
#        } else {
#          print "DB Error: " . $dbh->{db_error_msg} . "\n";
##          $dbh->endTransaction();
#          print "RECORD COUNT AFTER ARCHIVING: \n";
#          countRecords();
#          exit;
#        }
#        $query = "DELETE FROM distinct_id_archive";
#        if ($dbh->do($query)) {
#            print ". done\n";  
#        } else {
#          print "DB Error: " . $dbh->{db_error_msg} . "\n";
##          $dbh->endTransaction();
#          print "RECORD COUNT AFTER ARCHIVING: \n";
#          countRecords();
#          exit;
#        }
#
#        print "Step #8: filling distinct tables        .";
#        
#        $query = "INSERT INTO distinct_source_archive SELECT distinct(source) FROM item_archive ORDER BY source";
#        if ($dbh->do($query)) {
#            print ".";  
#        } else {
#          print "DB Error: " . $dbh->{db_error_msg} . "\n";
##          $dbh->endTransaction();
#          print "RECORD COUNT AFTER ARCHIVING: \n";
#          countRecords();
#          exit;
#        }
#        $query = "INSERT INTO distinct_id_archive SELECT distinct(identifier) FROM identifier_archive ORDER BY identifier";
#        if ($dbh->do($query)) {
#            print ". done\n";  
#        } else {
#          print "DB Error: " . $dbh->{db_error_msg} . "\n";
##          $dbh->endTransaction();
#          print "RECORD COUNT AFTER ARCHIVING: \n";
#          countRecords();
#          exit;
#        }
		
		$dbh->endTransaction();
        print "RECORD COUNT AFTER ARCHIVING: \n";
        countRecords();
		
        print "\n\nArchiving successfully completed!\n\n";
      } else {
        print "Archiving cancelled!\n";
      }
    }
  }

print "--END--\n\n";

sub countRecords {
	my $dbh2 = Taranis::Database->new();
	
	for ( ['item', 'item_archive'], ['email_item', 'email_item_archive'], ['identifier', 'identifier_archive'] ) {
		my $tablePair = $_;
		
		my $pairCount = 0;
		my $count = 0;
		foreach my $table ( @$tablePair ) {
			
			my $query = "SELECT COUNT(*) AS counted FROM $table ;";
			$dbh2->prepare( $query );
			
			if ( $dbh2->executeWithBinds() ) {
				$count = $dbh2->fetchRow()->{counted};
			}
			my $spaces = '';
			for ( my $i = 0; $i < 40 - ( length($count) + length($table) ); $i++ ) { $spaces .= ' ' }
			print $table . $spaces . $count . "\n";
			
			$pairCount += $count;
		}
	
		my $spaces = '';
		for ( my $i = 0; $i < 35 - length($pairCount); $i++ ) { $spaces .= ' '; }
		print 'TOTAL' . $spaces . $pairCount . "\n\n";
	}
}
