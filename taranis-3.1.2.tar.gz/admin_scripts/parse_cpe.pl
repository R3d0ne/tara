#!/usr/bin/perl -w
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use lib qw(/opt/taranis/pm);
use strict;

use POSIX;
use Getopt::Long;
use Taranis::Database;
use SQL::Abstract;
use XML::XPath;
use XML::XPath::XMLParser;

no warnings;

use Data::Dumper;

my ( $file, $logfile, $force, $skip );
my $help = 0;

GetOptions(
            "file=s"    => \$file,
            "help"      => \$help,
            "logfile=s" => \$logfile,
            "skip"      => \$skip
);

my $usage = <<"EOL";
Usage:
  $0 --file </path/to/input_file> --logfile </path/to/logfile> --skip
  
This script is for initial filling and updating the software_hardware DB table.
use --skip to skip deprecated (according to CPE Dictionary) records.
EOL

die $usage if $help;
if ( !$file ) { die "Sigh!\n" . $usage }

if ( !-e $file ) { die "$file does not exist\n" }
if ( !-r $file ) { die "$file not readable\n" }
print "start\n";

my $dbh = Taranis::Database->new();

$dbh->{PrintError} = 1;
$dbh->{RaiseError} = 1;

my $table = 'software_hardware';
my %where;

my $logto = $logfile || '/tmp/cpe-insert.log';

my $xp = XML::XPath->new( filename => $file );


my $nodeset = $xp->findvalue('/cpe-list/cpe-item/@name|/cpe-list/cpe-item/title');

open( LOG, ">$logto" );
my $now = strftime( "%a %d %B %Y %T", localtime(time) );
print LOG "-----START--------->>$now<<>>\n";

my ( $exists, $err, $count, $deprecated ) = 0;

foreach my $cpe ( $xp->find('//cpe-item')->get_nodelist ) {

    my $cpe_name = $cpe->find('@name')->string_value;
    my ( $prefix, $part, $vendor, $product, $version, $update, $edition, $language ) =
      split( /:/, $cpe_name );
       
    if ( $cpe->find('@deprecated')->string_value =~ /true/ ) {
        $deprecated++;
        # option --skip will skip the deprecated elements
        print LOG "deprecated record skipped >  $vendor - $product - $version - $cpe_name\n";
        next if $skip;
    }

    my $title = $cpe->find('title[@xml:lang="en-US"]');

# I want to keep this xpath expression for future reference
# my $component = $cpe->find('//meta:component-tree/meta:vendor[@value = "' . $vendor  .'" ]//meta:product/@value');
    
    $part =~ s/\///;

    $version = undef if ( !defined($version) );
    $title =~ s/^$vendor\s//i;
    $title =~ s/\s$version$//i;	

    
    
    my %args = (
                 deleted   => 0,
                 monitored => 0,
                 name      => $title,
                 producer  => $vendor,
                 type      => $part,
                 version   => $version,
                 cpe_id    => $cpe_name 
    );

    my %check = (
                  cpe_id   => $cpe_name
    );

    if ( $dbh->checkIfExists( \%check, $table ) ) {
        $exists++;
        my ( $stmnt, @bind ) = $dbh->{sql}->select( $table, "id", \%where);
        $dbh->prepare($stmnt);
        

        $dbh->executeWithBinds(@bind);
        if ( defined( $dbh->{db_error_msg} ) ) {
           print $dbh->{db_error_msg} . "\n" ;
        }
        my $row = $dbh->fetchRow();
        my $id = $row->{id};
        
#        my %Uwhere;
#        $Uwhere{id} = $row->{id};
#        my %Uargs = (       
#                 name      => $title,
#                 producer  => $vendor,
#                 type      => $part,
#                 version   => $version,
#                 cpe_id    => $cpe_name 
#       );
#        my ( $Ustmnt, @Ubind ) = $dbh->{sql}->update( $table, \%Uargs, \%Uwhere );
#        my $sth = $dbh->prepare($Ustmnt);
#        my $ret = $dbh->executeWithBinds(@Ubind);
#        if ( defined( $dbh->{db_error_msg} ) ) {
#           print $dbh->{db_error_msg} . "\n" ;
#        }    

        # hier gaat soms iets heel erg fout met Combinatie DB en Xpath.
        # Het hele DOM wordt in een van de values van %Uargs geplaatst 
        # en de boel stort in elkaar!!
        # dus we gaan over op manual en wordt de update op de ouderwetse manier in
        # elkaar gesleuteld.
        my $new_cpe_name = $cpe_name;
        $new_cpe_name =~ s/%28/\(/;
        $new_cpe_name =~ s/%29/\)/;
       my $sql = "UPDATE software_hardware SET cpe_id = " . "'" . $new_cpe_name . "'" . ", name = " . "'" . $title . "'" . ", producer = ". "'" . $vendor . "'" . ", type = " . "'" . $part . "'" . ", version = ". "'" . $version. "'" . " WHERE ( id = ". "'" .$id. "'" . " )";
       $dbh->do($sql);
    
        print LOG "$count record update >  $vendor - $title - $version - $cpe_name\n";
    } else {
        my ( $stmnt, @bind ) = $dbh->{sql}->insert( $table, \%args );
        if ( defined( $dbh->{db_error_msg} ) ) {
           print $dbh->{db_error_msg} . "\n" ;
        }        
        my $sth = $dbh->prepare($stmnt);
        if ( defined( $dbh->executeWithBinds(@bind) ) > 0 ) {
            ++$count;
            print LOG "$count record insert > $vendor - $title - $version - $cpe_name\n";
        } else {
            $err++;
            my $errstr = $sth->errstr;
            chomp $errstr;
            print LOG "ERR: $count " . $errstr . "--> $vendor - $title - $version - $cpe_name\n";
        }
    }

}

$now = strftime( "%a %d %B %Y %T", localtime(time) );
my $final_thought = "new inserted: $count, errors: $err, exists (updated): $exists, deprecated: $deprecated\n";
print "$final_thought\n";
print LOG "$final_thought\n";
print LOG "-----END--------->>$now<<\n";
close LOG;

=head1 NAME 

parse_cpe.pl

=head1 SYNOPSYS

Fill and update Taranis software_hardware table.

Takes input from XML CPE dictionary.
e.g. official-cpe-dictionary_v2.2.xml to be found at
http://nvd.nist.gov/cpe.cfm

=head1 QUICK START

parse_cpe.pl --skip --file <filename> --logfile <filename>

If no logfile option is given will log to /tmp/cpe-insert.log

The --skip option will skip records that are marked as deprecated (according to CPE Dictionary).

=head1 AUTHOR

jeroen
Apr 1, 2009

=cut
