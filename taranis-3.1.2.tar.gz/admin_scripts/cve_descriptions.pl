#!/usr/bin/perl
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use lib qw(/opt/taranis/pm);
use Taranis qw (:all);
use Taranis::Config;
use Taranis::Database;
use LWP::UserAgent::ProgressBar;
use Term::ProgressBar;
use IO::Uncompress::AnyUncompress qw(anyuncompress $AnyUncompressError);
use XML::XPath;
use XML::XPath::XMLParser;
use Data::Dumper;

my $download_path = Taranis::Config->getSetting("downloadpath");
my $userAgentString = Taranis::Config->getSetting("useragent_string");
my $dbh = Taranis::Database->new();

my $select = 'select distinct identifier from identifier';
$dbh->prepare($select);
$dbh->executeWithBinds();
my @identifiers;

while ( $dbh->nextRecord() ) {
  push( @identifiers, $dbh->getRecord()->{identifier} );
}
my %identifiers = map ( { $_ => 1 } @identifiers );

my $ua         = LWP::UserAgent::ProgressBar->new();
my $proxy_host = Taranis::Config->getSetting("proxy_host");
$ua->proxy( [ 'http', 'https' ], $proxy_host );
my @no_proxy = map { trim $_ } split( /,/, Taranis::Config->getSetting("no_proxy") );

$ua->no_proxy(@no_proxy);
$ua->agent( $userAgentString );
$ua->timeout( Taranis::Config->getSetting("timeout") );
$ua->protocols_allowed( [ 'http', 'https' ] );

my $sql = "SELECT * FROM download_files where name ='cve_description'";
$dbh->prepare($sql);
$dbh->executeWithBinds();
my $config_data;
while ( $dbh->nextRecord() ) {
  $config_data = $dbh->getRecord();
}

my $req = HTTP::Request->new( HEAD => $config_data->{file_url} );
my $res = $ua->request($req);

if ( $res->is_success ) {
  if ( $res->headers->{"last-modified"} ne $config_data->{last_change} ) {
    my $url = $config_data->{file_url};
    print "Downloading\n";
    $res = $ua->get_with_progress($url);
    if ( $res->is_success ) {
      my $result_file = $config_data->{save_to} . $config_data->{filename};
      open OUT, ">$result_file" or die "can't open $result_file for writing, $!\n";
      print OUT $res->content;
      close OUT;
      my $output = $result_file;
      $output =~ s/\.gz$//;
      my $unzip_status = anyuncompress $result_file => $output
        or die "uncompress failed: $AnyUncompressError\n";
      unlink $result_file;
      my @count = split( ' ', `grep '<item' $output |wc` );
      my $records = $count[0];
      print "$records records to process\n";
      my $progress = Term::ProgressBar->new(
                                             {
                                               name  => 'Processing',
                                               count => $records,
                                               ETA   => 'linear'
                                             }
      );

      my $xp      = XML::XPath->new( filename => $output );
      my $dbtable = 'identifier_description';
      my $line    = 0;
      foreach my $cve ( $xp->find('//item')->get_nodelist ) {
        $line++;
        my $cve_id      = $cve->find('@name')->string_value;
        my $description = $cve->find('desc')->string_value;
        my $type        = substr( $cve->find('@type')->string_value, 0, 3 );
        my $phase       = $cve->find('phase')->string_value;
        my $phase_date  = $cve->find('phase/@date')->string_value;
        my $status      = $cve->find('status')->string_value;
        $progress->update($line);
        my %checkdata = ( identifier => $cve_id );

        if ( $dbh->checkIfExists( \%checkdata, $dbtable ) ) {
          my %args = (
                       description => $description,
                       type        => $type,
                       phase       => $phase,
                       phase_date  => $phase_date ? $phase_date : '19000101',
                       status      => $status
          );

          my ( $stmnt, @bind ) = $dbh->{sql}->update( $dbtable, \%args, \%checkdata );
          my $sth = $dbh->prepare($stmnt);
          $dbh->executeWithBinds(@bind);

          if ( defined( $dbh->{db_error_msg} ) ) {
            print $dbh->{db_error_msg} . "\n";
            exit;
          }
        } else {
          my %args = (
                       identifier  => $cve_id,
                       description => $description,
                       type        => $type,
                       phase       => $phase,
                       phase_date  => $phase_date ? $phase_date : '19000101',
                       status      => $status
          );

          my ( $stmnt, @bind ) = $dbh->{sql}->insert( $dbtable, \%args );
          my $sth = $dbh->prepare($stmnt);
          my $res = $dbh->executeWithBinds(@bind);

          if ( defined( $dbh->{db_error_msg} ) ) {
            print $dbh->{db_error_msg} . "\n";
            exit;
          }
        }
      }

      # Update DB date stamp
      my $last_change = $res->headers->{"last-modified"};
      $sql = "UPDATE download_files SET last_change ='". $last_change. "' WHERE name ='cve_description'";
      $dbh->execute($sql);
      unlink $output;
    } else {
      print $res->status_line . "\n";
    }
  } else {
    print "File at Mitre is unchanged, no action needed\n";
  }
}

##############

