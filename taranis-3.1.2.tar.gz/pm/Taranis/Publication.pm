package Taranis::Publication;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:all);
use Taranis::Database;
use Taranis::Template;
use Taranis::Users;
use Taranis::Config;
use Taranis::Damagedescription;
use Taranis::SoftwareHardware;
use Taranis::Tagging;
use SQL::Abstract;
use XML::Simple;
use Tie::IxHash;
use strict;
use JSON;

use Data::Dumper;

use constant ADVISORY => qw( 
	consequences description govcertid hyperlinks ids solution summary title update notes tlpamber
);
use constant EOW 			=> qw( closing introduction newondatabank newsitem );
use constant EOS      => qw(
  handler first_co_handler second_co_handler general_info vulnerabilities_threats incident_info community_news media_exposure tlp_amber );

sub new {
	shift @_;
	
	my $self = {
		errmsg 	=> undef,
		dbh 		=> Taranis::Database->new(),
		sql 		=> SQL::Abstract->new(),
		result_count => undef
	};
	bless $self;
	return $self;	
}

sub addPublication {
	my ( $self, %args ) = @_;
	undef $self->{errmsg};
	
	my ( $stmnt, @bind ) = $self->{sql}->insert( "publication", \%args );

	$self->{dbh}->prepare( $stmnt );
	if ( defined( $self->{dbh}->executeWithBinds( @bind ) ) > 0 ) {
		return 1;
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}
}

sub setPublication {
	my ( $self, %args ) = @_;
	undef $self->{errmsg};
	my $where;

	if ( defined( $args{where} ) ) {
		$where = delete( $args{where} );
	} else {
		$where = { id => delete( $args{id} ) };
	}

	my ( $stmnt, @bind ) = $self->{sql}->update( "publication", \%args, $where );	

	$self->{dbh}->prepare( $stmnt );
	
	my $result = $self->{dbh}->executeWithBinds( @bind );
	if ( defined( $result ) && ( $result !~ m/(0E0)/i ) ) {		
		if ( $result > 0 ) {
			return 1;
		} elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			return 0;
		}
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg} || "Action failed, corresponding id not found in database.(2)";
		return 0;		
	}	
}

sub deletePublication {
	my ( $self, $id, $type ) = @_;
	undef $self->{errmsg};

	my $tg = Taranis::Tagging->new();
	
	if ( $type eq "advisory" ) {
		
		my $publication = $self->getPublicationDetails(
			table => "publication_advisory",
			"publication_advisory.id" => $id
		);

		my $is_update = $self->{dbh}->checkIfExists( { replacedby_id => $publication->{publication_id} }, "publication" );

		my $previousVersion;
		my %tags;

		if ( $is_update ) {
			$previousVersion = $self->getPublicationDetails(
				table => "publication_advisory",
				"pu.replacedby_id" => $publication->{publication_id}
			);
			
			$self->{previousVersionId} = $previousVersion->{publication_id};
			
			$tg->loadCollection( "ti.item_id" => $id, "ti.item_table_name" => "publication_advisory" );
	
			while ( $tg->nextObject() ) {
				my $tag = $tg->getObject();
				$tags{ $tag->{id} } = 1;
			}
		}
		
		my $newerVersions;
		if ( $publication->{replacedby_id} ) {
			$newerVersions = $self->getNextVersions( $publication->{replacedby_id} );
		}

		my $result;
		$self->{dbh}->startTransaction();
		
		my $check_1;
		if ( $is_update ) {
			$check_1 = $self->setPublication( 
				where => { replacedby_id => $publication->{publication_id} },
				replacedby_id => $publication->{replacedby_id}
			);
		} else {
			$check_1 = 1;
		}
		
		# update the version numbers with -0.01 of advisories with a higher version number.
		if ( $newerVersions && @$newerVersions ) {
			foreach my $newerPublication ( @$newerVersions ) {
				$self->setPublicationDetails(
					table => "publication_advisory",
					where => { publication_id => $newerPublication->{id} },
					version => \'version::decimal - 0.01'
				);
				$self->{multiplePublicationsUpdated} = 1;
			}
		}
		
		if ( !$check_1
			|| !$self->setPublicationDetails( 
				table => "publication_advisory",
				where => { id => $id }, 
				deleted => 1
			) 
			|| !$self->setPublication( 
				where => { id => $publication->{publication_id} }, 
				replacedby_id => undef
			)
		) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg} if ( $self->{dbh}->{db_error_msg} );
			$result = 0;																
		} else {
			$result = 1;
		}
		
		$tg->removeItemTag( $id, "publication_advisory" );
		
		if ( $is_update ) {
		my @addTags = keys %tags;
			foreach my $tag_id ( @addTags ) {
				if (  !$tg->setItemTag( $tag_id, "publication_advisory", $previousVersion->{id}  ) ) {
					$self->{errmsg} .= $tg->{errmsg};
				}
			}
		}
		
		$self->{dbh}->endTransaction();
		return $result;
		
	} elsif ( $type eq "eow" || $type eq "eos" ) {
		
		
		my $table = ( $type eq "eow" ) ? "publication_endofweek" : "publication_endofshift";
		
		$self->{dbh}->startTransaction();
		
		$tg->removeItemTag( $id, $table );
		
		my ( $stmnt, @bind ) = $self->{sql}->delete( $table, { id => $id } );
		
		$self->{dbh}->prepare( $stmnt );
		my $result = $self->{dbh}->executeWithBinds( @bind );
	
		$self->{dbh}->endTransaction();
		
		if ( $result !~ m/(0E0)/i ) {		
			if ( $result > 0 ) {
				return 1;
			} elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
				$self->{errmsg} = $self->{dbh}->{db_error_msg};
				return 0;
			} 
		} else {
			$self->{errmsg} = "Delete failed, publication not found.";
			return 0;
		}	
	}
}

sub linkToPublication {
	my ( $self, %link_data ) = @_;
	undef $self->{errmsg};
	
	my $table = delete $link_data{table};

	my ( $stmnt, @bind ) = $self->{sql}->insert( $table, \%link_data );

	$self->{dbh}->prepare( $stmnt );
	if ( defined( $self->{dbh}->executeWithBinds( @bind ) ) > 0 ) {
		return 1;
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}		
}

sub unlinkFromPublication {
	my ( $self, %where ) = @_;
	undef $self->{errmsg};
	
	my $table = delete $where{table};

	my ( $stmnt, @bind ) = $self->{sql}->delete( $table, \%where );

	$self->{dbh}->prepare( $stmnt );
	my $result = $self->{dbh}->executeWithBinds( @bind );

	if ( $result !~ m/(0E0)/i ) {		
		if ( $result > 0 ) {
			return 1;
		} elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			return 0;
		} 
	} else {
		$self->{errmsg} = "Delete failed, no record found in '$table'.";
		return 0;
	}	
}

sub getLinkedToPublication {
	my ( $self, %searchFields ) = @_;
	undef $self->{errmsg};
	
	my $join_table_1 = delete $searchFields{join_table_1};
	my $join_table_2 = delete $searchFields{join_table_2};
	
	my $join_table1_name = [ keys %$join_table_1 ]->[0];
	my $join_table2_name = [ keys %$join_table_2 ]->[0];
	
#	my %where = $self->{dbh}->createWhereFromArgs( %searchFields );
	
	my ( $stmnt, @bind ) = $self->{sql}->select( "publication AS pu", $join_table2_name.".*", \%searchFields );
	
	tie my %join, "Tie::IxHash";
	%join = ( "JOIN ".$join_table1_name => 
								{ "pu.id"	=> $join_table1_name.".publication_id" },
						"JOIN ".$join_table2_name => 
								{ $join_table1_name.".".$join_table_1->{ $join_table1_name } => $join_table2_name.".".$join_table_2->{ $join_table2_name } }
					);
	 					
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

  $self->{dbh}->prepare( $stmnt );
  my $result = $self->{dbh}->executeWithBinds(@bind);

  $self->{errmsg} = $self->{dbh}->{db_error_msg};
  return $result;
}

sub getLinkedToPublicationIds {
	my ( $self, %args ) = @_;
	undef $self->{errmsg};
	my @ids;
	
	my $table 				 = delete $args{table};
	my $select_column  = delete $args{select_column};
	my $publication_id = delete $args{publication_id};
	my $advisory_id		 = delete $args{advisory_id};
	
	my %where = ( $publication_id ) ? ( publication_id => $publication_id ) : ( advisory_id => $advisory_id );
	
	my ( $stmnt, @bind ) = $self->{sql}->select( $table, $select_column, \%where );
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	while ( $self->nextObject() ) {
		push @ids, $self->getObject()->{$select_column};
	}
	return @ids;
}

#TODO: sanitizeInpu moet uit modules en direct bij 'onvangst' worden gedaan
sub loadPublicationsCollection {
	my ( $self, %searchFields ) = @_;
	undef $self->{errmsg};
	my %where;

	my ( @publications, @search_columns, @search, @nests );
	my $select;
	
	my $table = delete $searchFields{table};
	my $order_by = ( $searchFields{order_by} ) ? delete $searchFields{order_by} : "pu.status, pu.published_on DESC, pu.created_on DESC";
	
	my @search_status = @{ $searchFields{status} } if ( exists $searchFields{status}  );
	delete $searchFields{status};

	my $start_date = delete $searchFields{start_date};
	my $end_date 	 = delete $searchFields{end_date};

	my $date_column = delete $searchFields{date_column};

	my $limit  = ( exists $searchFields{hitsperpage} ) ? sanitizeInput( "only_numbers", delete ( $searchFields{hitsperpage} ) ) : undef;
	my $offset = ( exists $searchFields{offset} ) ? sanitizeInput( "only_numbers", delete ( $searchFields{offset} ) ) : undef;

	if ( $start_date && $end_date ) {
		if ( $start_date =~ /\d\d:\d\d$/ ) {
		   $where{$date_column} = {-between => [$start_date, $end_date] };
		} else {
			 $where{$date_column} = {-between => [$start_date." 000000", $end_date." 235959"] };
		}
	}
	
	if ( @search_status ) {
		my @status;
		foreach (  @search_status ) {
			push @status, status => $_;
			if ( $_ eq 2 ) {
				push @status, status => 4;	
			}
		}
		push @nests, \@status;
	}	
		
	for ( $table ) {
		if (/^publication_advisory$/)  { 
			@search_columns = ADVISORY;
			$select = "publication_advisory.title AS pub_title, '[v' || version || ']' AS version_str, " ;
			$where{deleted} = 0;
			$where{based_on} = delete( $searchFields{based_on} ) if ( exists( $searchFields{based_on} ) && $searchFields{based_on} );
		}
		if (/^publication_endofweek$/) { 
			@search_columns = EOW;
			$select = "pu.title AS pub_title, to_char(created_on, 'Dy DD Mon YYYY') AS created_on_str, " ; 
		}
		if (/^publication_endofshift$/) { 
			@search_columns = EOS;
			$select = "pu.title AS pub_title, to_char(publication_endofshift.timeframe_begin, 'Dy DD Mon YYYY HH24:MI - ') ||  to_char(publication_endofshift.timeframe_end, 'Dy DD Mon YYYY HH24:MI') AS timeframe_str, " ;
			$where{type} = $searchFields{publicationType} if ( exists( $searchFields{publicationType} ) && $searchFields{publicationType} );
		}
	}

	$where{version} = delete( $searchFields{version} ) if ( exists( $searchFields{version} ) && $searchFields{version} );

	if ( $searchFields{search} ne "" ) {
		push @search, "pu.contents" => { -ilike => "%".$searchFields{search}."%" };
		foreach ( @search_columns ) {
			push @search, $table.".".$_ => {-ilike => "%".$searchFields{search}."%" }; 
		}
		push @nests, \@search;
	}
	
	$where{-and} = \@nests if ( @nests );
	
	$select .= $table.".*,".$table.".id AS details_id, pu.*, us.fullname";
	
	my ( $stmnt, @bind ) = $self->{sql}->select( "publication AS pu", $select, \%where, $order_by );
	
	my %join = ( 
		"JOIN ".$table => { $table.".publication_id" => "pu.id" },
		"LEFT JOIN users us" => { "us.username" => "pu.opened_by" }
	);
						 
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{result_count} = $self->{dbh}->setResultCount( $stmnt, @bind );

	$stmnt .= " LIMIT $limit OFFSET $offset" if ( defined( $limit ) && defined( $offset ) );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
  
	$self->{errmsg} = $self->{dbh}->{db_error_msg};
  
	while ( $self->nextObject() ) {
		push @publications, $self->getObject();
	}
	return \@publications;
}

sub getPublicationDetails {
	my ( $self, %args ) = @_;
	undef $self->{errmsg};
	my $details;
	
	my $table = delete $args{table};
	my %where = $self->{dbh}->createWhereFromArgs( %args );

	my $select = $table.".*,
		pu.contents, 
		pu.status, 
		pu.title AS pub_title,
		pu.created_by,
		pu.approved_by,
		pu.published_by,
		pu.type,
		pu.replacedby_id,
		pu.type,
		pu.opened_by,
		to_char(created_on, 'YYYYMMDD') AS created_on_str, 
		to_char(published_on, 'YYYYMMDD') AS published_on_str, 
		to_char(approved_on, 'YYYYMMDD') AS approved_on_str";

	for ( $table ) {
		if (/^publication_advisory$/)  { 
			$select .= ", publication_advisory.title AS pub_title, '[v' || version || ']' AS version_str" ;
		}
		if (/^publication_endofweek$/) { 
			$select .= ", pu.title AS pub_title, to_char(created_on, 'Dy DD Mon YYYY') AS created_on_str" ; 
		}
		if (/^publication_endofshift$/) { 
			$select .= ", pu.title AS pub_title, to_char(publication_endofshift.timeframe_begin, 'Dy DD Mon YYYY HH24:MI - ') ||  to_char(publication_endofshift.timeframe_end, 'Dy DD Mon YYYY HH24:MI') AS timeframe_str" ; 
		}
	}
	
	$select .=  ", " . $table . ".id AS details_id";
	
	my ( $stmnt, @bind ) = $self->{sql}->select( $table, $select, \%where );
	my %join = ( "JOIN publication AS pu" => { "pu.id" => $table.".publication_id" } );
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	
	$self->{dbh}->executeWithBinds( @bind );
	$self->{errmsg} = $self->{dbh}->{db_error_msg};	
	
	while ( $self->nextObject() ) {
		$details = $self->getObject();
	}
	
	return $details;
}

sub setPublicationDetails {
	my ( $self, %details ) = @_;
	undef $self->{errmsg};
	
	my $table = delete $details{table};
	my $where = delete $details{where};

	my ( $stmnt, @bind ) = $self->{sql}->update( $table, \%details, $where );

	$self->{dbh}->prepare( $stmnt );
	my $result = $self->{dbh}->executeWithBinds( @bind );
	if ( defined( $result ) && ( $result !~ m/(0E0)/i ) ) {		
		if ( $result > 0 ) {
			return 1;
		} elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			return 0;
		}
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg} || "Action failed, corresponding id not found in database. (1)";
		return 0;		
	}
}

sub getLatestPublishedPublicationDate {
  my ( $self, %where ) = @_;
  undef $self->{errmsg};
  
  $where{status} = 3;
  
  my $select = "MAX( to_char(published_on, 'YYYYMMDD HH24MI')) AS published_on_str";

  my ( $stmnt, @bind ) = $self->{sql}->select( 'publication', $select, \%where );
  
  $self->{dbh}->prepare( $stmnt );
  
  $self->{dbh}->executeWithBinds( @bind );
  $self->{errmsg} = $self->{dbh}->{db_error_msg}; 
  
  return $self->{dbh}->fetchRow();
}

sub getLatestAdvisoryVersion {
	my ( $self, %settings ) = @_;
	
	my $govcertId = $settings{govcertId};
	
	my $subSelect = "MAX(version)";
	my %subWhere = ( "pa2.govcertid" => $govcertId, "pa2.deleted" => 0 );
	
	my ( $subStmnt, @subBind ) = $self->{sql}->select( "publication_advisory pa2", $subSelect, \%subWhere );
	
	my %where = (
								"pa1.govcertid" => $govcertId,
								"pa1.version" => \[ "IN ($subStmnt)" => @subBind ] 
							);
	
	my ( $stmnt, @bind ) = $self->{sql}->select( "publication_advisory pa1", 'pa1.*', \%where );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	my $advisory = $self->{dbh}->fetchRow();
	
	$self->{errmsg} = $self->{db_error_msg};

	return $advisory;	
}

sub extractSoftwareHardwareFromCve {
	my ( $self, $idstring ) = @_;
	undef $self->{errmsg};
	my ( @sh_list, @cve_ids );
	
	my @ids = split( " ", $idstring );
	
	foreach ( @ids ) {
		if ( $_ =~ /^CVE.*/i ) {
			push @cve_ids, uc( $_ );
		}
	}

	# return if there aren't any CVE id's
	if ( !@cve_ids ) {
		return;
	}
	
	my %where = ( 
								"cc.cve_id"  => \@cve_ids,
								"sh.deleted" => 0 
							);
							
	my ( $stmnt, @bind ) = $self->{sql}->select( "software_hardware AS SH", "DISTINCT sht.description, sh.*", \%where, "sh.name, sh.version" );

	my $join = { "JOIN cpe_cve AS cc" 				=> { "sh.cpe_id" => "cc.cpe_id"},
							 "JOIN soft_hard_type AS sht" => { "sh.type" 	 => "sht.base" }
						 };
	$stmnt = $self->{dbh}->sqlJoin( $join, $stmnt );	

	$self->{dbh}->prepare( $stmnt );

	$self->{dbh}->executeWithBinds( @bind );
			
	while ( $self->nextObject() ) {
		push @sh_list, $self->getObject();
	}
	
	return \@sh_list;
}

sub nextObject {
	my ( $self ) = @_;
	return $self->{dbh}->nextRecord;
}

sub getObject {
	my ( $self ) = @_;
	return $self->{dbh}->getRecord;		
}

sub getPublicationTypeId {
	my ( $self, $type_name ) = @_;
	undef $self->{errmsg};
	my ( $stmnt, @bind ) = $self->{sql}->select( "publication_type", "id", { title => { -ilike => $type_name } } );
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );

	my $id = $self->{dbh}->fetchRow();
	
	$self->{errmsg} = $self->{db_error_msg};
	return $id;
}

sub getItemLinks {
	my ( $self, %args ) = @_;
	undef $self->{errmsg};
	my @links;
	my %where;
	tie my %join, "Tie::IxHash";
	
	
	if ( exists( $args{analysis_id} ) ) {	
		%where = ( "an.id" => $args{analysis_id}, "item.is_mail" => 'f' );
		%join  = ( "JOIN item_analysis AS ia" => { "ia.item_id" => "item.digest" 	 },
							 "JOIN analysis AS an"			=> { "an.id" 		 => "ia.analysis_id" }
						 );		
	} elsif ( exists( $args{publication_id} ) ) {
		%where = ( "ap.publication_id" => $args{publication_id}, "item.is_mail" => 'f' );
		%join  = ( "JOIN item_analysis AS ia" 			 => { "ia.item_id" => "item.digest" 	 },
							 "JOIN analysis AS an"						 => { "an.id" 		 => "ia.analysis_id" },
							 "JOIN analysis_publication AS ap" => { "an.id" 		 => "ap.analysis_id" }
						 );		
	}
	
	my ( $stmnt, @bind ) = $self->{sql}->select( "item", "item.link", \%where, "item.link" );
	
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );
	
	$self->{dbh}->prepare( $stmnt );
  $self->{dbh}->executeWithBinds(@bind);
	
	while ( $self->nextObject() ) {
		push @links, $self->getObject()->{"link"};
	}
	
	$self->{errmsg} = $self->{dbh}->{db_error_msg};

	return \@links;
}

sub processPreviewTemplatePart {
	my ( $self, $json_str, $table ) = @_;
	undef $self->{errmsg};
	my $preview_part;

	my $input_object = decode_json( $json_str );
	
	my $ids 				 = $input_object->{ids};
	my $columns 		 = $input_object->{columns};
	my $destination = $input_object->{destination};
	
	@$ids 	  = sanitizeInput( "only_numbers", @$ids 	 );
	$table    = sanitizeInput( "db_naming"	  , $table   );
	@$columns = sanitizeInput( "db_naming"		, @$columns );
	
	if ( @$ids ) {
		my @where = ( id => \@$ids ); 
		my $select = "DISTINCT ";
		foreach ( @$columns ) {
			$select .= "$_, ";
		}
		$select =~ s/,\s+$//;
		
		my ( $stmnt, @bind ) = $self->{sql}->select( $table, $select, \@where, $columns->[0] );
	
		$self->{dbh}->prepare( $stmnt );
		$self->{dbh}->executeWithBinds( @bind );
			
		DB_OBJECT:	while ( $self->nextObject() ) {
									my $part = $self->getObject();
									my $temp_save;
									foreach ( @$columns ) {
										$temp_save .= ucfirst( $part->{$_} )." " if ( $_ );
									}
									if ( $temp_save =~ /^\s*$/ ) {
										next DB_OBJECT;
									} else {
	
										# delete double occurrences of producer
										my $firstword = substr( $temp_save, 0, index( $temp_save, " " ) );
										if ( $temp_save =~ /^$firstword\s$firstword\s.*/i ) {
											$temp_save =~ s/^$firstword\s(.*)/$1/i;	
										}
										########################################
										$preview_part .= trim( $temp_save ) . "\n";	
									}
								}
		
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		
		$preview_part =~ s/\n$//;
	} else {
		$preview_part = "";
	}
	return $preview_part, $destination;	
}

sub processPreviewXml {
	my ( $self, $advisory_id ) = @_;
	undef $self->{errmsg};
	my $usr =  Taranis::Users->new();
	my $dd = Taranis::Damagedescription->new();
	
	my $publication =	$self->getPublicationDetails( 
		table => "publication_advisory",
		"publication_advisory.id" => $advisory_id 
	);
	my @test =  keys %$publication;																							 		

	my $advisory = XMLin(
		Taranis::Config->getSetting("advisory_xml_template"),
		KeepRoot   => 1,
		ForceArray => 1
	);

	my %advisoryScale = ( 1 => "high", 2 => "medium", 3 => "low" );
	
	my $organisation = Taranis::Config->getSetting("organisation");
	
	### SIMPLE CONVERSIONS ###
	$publication->{update_information} = $publication->{update};
	$publication->{abstract} = $publication->{summary};
	$publication->{tlp_amber} = $publication->{tlpamber};
	$publication->{reference_number} = $publication->{govcertid};
#	$publication->{issuer} = $usr->getUser( $publication->{created_by} )->{fullname};
	$publication->{issuer} .= "$organisation" if ( $organisation );
	$publication->{date} = $publication->{published_on_str};
	$publication->{damage} = $advisoryScale{ $publication->{damage} };
	$publication->{probability} = $advisoryScale{ $publication->{probability} };
	
	### START FILLING THE GAPS ###
	foreach my $element ( %{ $advisory->{xml_advisory}->[0] } ) {
	
		# XMLSimple treats elements named 'content' differently,
		# because of this a check for 'HASH' or 'ARRAY' must be done first
		if ( ref($element) eq "HASH" ) {
			foreach ( keys %$element ) {
				
				if ( /additional_resources/ ) {
					
					my @hyperlinks = split( "\n", $publication->{hyperlinks} );
					my $resource_element = $element->{$_}->[0]->{resource};
					
					for ( my $i = 0 ; $i < @hyperlinks ; $i++ ) {
						$resource_element->[$i] = $hyperlinks[$i];
					}
				
				} elsif ( /disclaimer/ ) {
					next;
				} else {
					$element->{$_}->[0] = $publication->{$_};
				}
			}
	
		} elsif ( ref($element) eq "ARRAY" ) {
	
			foreach my $key ( keys %{ $element->[0] } ) {
	
				if ( $key =~ /vulnerability_identifiers/ ) {
					my $cve_cnt = 0;
					
					my %unique_ids;					
					foreach ( split( ",", $publication->{ids} ) ) {
						$_ =~ s/\s*//;
						$unique_ids{ trim( $_ ) } = 1;
					}
					
					$self->getLinkedToPublication( 
						 join_table_1 => { analysis_publication => "analysis_id" },
						 join_table_2 => { analysis => "id" },
						 "pu.id" => $publication->{publication_id}
					);					
					my @idstrings;
					while ( $self->nextObject() ) {
						foreach ( split( " ", $self->getObject()->{idstring} ) ) {
							$unique_ids{ trim( $_ ) } = 1;
						}
					}
					
					my @ids = sort keys %unique_ids;
					
					for (@ids) {
						if (/^CVE.*/) {
							$element->[0]->{$key}->[0]->{cve}->[0]->{id}->[$cve_cnt] = $_;
							$cve_cnt++;
						}
					}
				}	elsif ( $key =~ /version_history/) {
					my $current_version = { version => $publication->{version}, 
						date => $publication->{published_on_str}, 
						update => $publication->{update}
					};
					my $previous_versions = $self->getPreviousVersions( $publication->{publication_id } );
					my @versions = @$previous_versions;
					push @versions, $current_version;
					
					for ( my $i = 0; $i < @versions; $i++ ) {
						$element->[0]->{$key}->[0]->{version_instance}->[$i]->{date}->[0] = $versions[$i]->{date};
						$element->[0]->{$key}->[0]->{version_instance}->[$i]->{version}->[0] = $versions[$i]->{version};
						$element->[0]->{$key}->[0]->{version_instance}->[$i]->{change_descr}->[0] = $versions[$i]->{update};
					}
				}	elsif ( $key =~ /vulnerability_effect/) {
					my @damage_ids	= $self->getLinkedToPublicationIds( 
						table => "advisory_damage",
						select_column => "damage_id",
						advisory_id => $advisory_id
					);
					if ( @damage_ids ) {
						my @damage_descriptions	= $dd->getDamageDescription( id => \@damage_ids );					
						
						for ( my $i = 0; $i < @damage_descriptions; $i++ ) {
							$element->[0]->{$key}->[0]->{effect}->[$i] = $damage_descriptions[$i]->{description};
						}
					}
				}	elsif ( $key =~ /system_information/) {
					for ( keys %{ $element->[0]->{$key}->[0]->{systemdetail}->[0] } ) {
						if(/^affected_product$/) {
							$self->getLinkedToPublication(
								join_table_1 => { "product_in_publication" => "softhard_id" },
								join_table_2 => { "software_hardware" => "id" },
								"pu.id" => $publication->{publication_id}
							);
							my $i = 0;
							while ( $self->nextObject() ) {
								my $product = $self->getObject();
								foreach my $productDetail ( 'producer', 'name', 'version', 'cpe_id' ) {
									$element->[0]->{$key}->[0]->{systemdetail}->[0]->{$_}->[0]->{product}->[$i]->{$productDetail}->[0] = $product->{$productDetail};
								}
								$i++;
							}
						} elsif (/^affected_platform$/) {
							$self->getLinkedToPublication(
								join_table_1 => { "platform_in_publication" => "softhard_id" },
								join_table_2 => { "software_hardware" => "id" },
								"pu.id" => $publication->{publication_id}
							);
							my $i = 0;
							while ( $self->nextObject() ) {
								my $platform = $self->getObject();
								foreach my $productDetail ( 'producer', 'name', 'version', 'cpe_id' ) {
									$element->[0]->{$key}->[0]->{systemdetail}->[0]->{$_}->[0]->{platform}->[$i]->{$productDetail}->[0] = $platform->{$productDetail};
								}								
								$i++;
							}							

						} elsif (/^affected_platforms_text$/) {
							$element->[0]->{$key}->[0]->{systemdetail}->[0]->{$_}->[0] = $publication->{platforms_text} if ( $publication->{platforms_text} );
						} elsif (/^affected_products_text$/) {
							$element->[0]->{$key}->[0]->{systemdetail}->[0]->{$_}->[0] = $publication->{products_text} if ( $publication->{products_text} );
						} elsif (/^affected_products_versions_text$/) {
							$element->[0]->{$key}->[0]->{systemdetail}->[0]->{$_}->[0] = $publication->{versions_text} if ( $publication->{versions_text} );
						}
					}
				} elsif ( $key =~ /publisher_analysis/) {
					for ( keys %{ $element->[0]->{$key}->[0] } ) {
						$element->[0]->{$key}->[0]->{$_}->[0] = $publication->{$_}
					}
				} elsif ( $key =~ /availability/ ) {
					next; # data for availability already in blank XML file.
				} elsif ( $key =~ /taranis_version/ ) {
					next;
				} else {
					$element->[0]->{$key}->[0] = $publication->{$key};
				}
			}
		}
	}
 
	my $xml = XMLout(
		$self->setCdata( $advisory ),
		KeepRoot => 1,
		NoSort => 1,
		XMLDecl => '<?xml version="1.0" encoding="UTF-8"?>'
	);

	# decoding is done because XMLout does html encoding 
	return decodeInput( \$xml );

}

sub processPreviewXmlRT {
	my ( $self, $formData ) = @_;
	undef $self->{errmsg};
	my $usr = Taranis::Users->new();
	my $dd = Taranis::Damagedescription->new();
	my $sh = Taranis::SoftwareHardware->new();

	my $advisory = XMLin(
		Taranis::Config->getSetting("advisory_xml_template"),
		KeepRoot => 1,
		ForceArray => 1
	);

	my %advisoryScale = ( 1 => "high", 2 => "medium", 3 => "low" );
	
	my $organisation = Taranis::Config->getSetting("organisation");
	
	### SIMPLE CONVERSIONS ###
	$formData->{update_information} = $formData->{update};
	$formData->{abstract} = $formData->{summary};
	$formData->{tlp_amber} = $formData->{tlpamber};
	$formData->{reference_number} = $formData->{govcertid};
#	$formData->{issuer} = $formData->{created_by};
	$formData->{issuer} .= "$organisation" if ( $organisation );
	$formData->{date} = '';
	$formData->{damage} = $advisoryScale{ $formData->{damage} };
	$formData->{probability} = $advisoryScale{ $formData->{probability} };
	
	### START FILLING THE GAPS ###
	foreach my $element ( %{ $advisory->{xml_advisory}->[0] } ) {
	
		#	XMLSimple treats elements named 'content' differently,
		# because of this a check for 'HASH' or 'ARRAY' must be done first
		if ( ref($element) eq "HASH" ) {
			foreach ( keys %$element ) {
				
				if ( /additional_resources/ ) {
					
					my @hyperlinks = split( "\n", $formData->{hyperlinks} );
					my $resource_element = $element->{$_}->[0]->{resource};
					
					for ( my $i = 0 ; $i < @hyperlinks ; $i++ ) {
						$resource_element->[$i] = $hyperlinks[$i];
					}
				
				} elsif ( /disclaimer/ ) {
					next;
				} else {
					$element->{$_}->[0] = $formData->{$_};
				}
			}
	
		} elsif ( ref($element) eq "ARRAY" ) {
	
			foreach my $key ( keys %{ $element->[0] } ) {
	
				if ( $key =~ /vulnerability_identifiers/ ) {
					my $cve_cnt = 0;
					
					my %unique_ids;					
					foreach ( split( ",", $formData->{ids} ) ) {
						$_ =~ s/\s*//;
						$unique_ids{ trim( $_ ) } = 1;
					}
					
					$self->getLinkedToPublication( 
						 join_table_1 => { analysis_publication => "analysis_id" },
						 join_table_2 => { analysis => "id" },
						 "pu.id" => $formData->{publication_id}
					);					
					my @idstrings;
#TODO: check of de IDS van analysis wel worden weggehaald als die uit de advisory zijn gehaald.
					while ( $self->nextObject() ) {
						foreach ( split( " ", $self->getObject()->{idstring} ) ) {
							$unique_ids{ trim( $_ ) } = 1;
						}
					}
					
					my @ids = sort keys %unique_ids;
					
					for (@ids) {
						if (/^CVE.*/) {
							$element->[0]->{$key}->[0]->{cve}->[0]->{id}->[$cve_cnt] = $_;
							$cve_cnt++;
						}
					}
				}	elsif ( $key =~ /version_history/) {
					my $current_version = { 
						version => $formData->{version}, 
						date => $formData->{published_on_str}, 
						update => $formData->{update}
					};
					my $previous_versions = $self->getPreviousVersions( $formData->{publication_id } );
					my @versions = @$previous_versions;
					push @versions, $current_version;
					
					for ( my $i = 0; $i < @versions; $i++ ) {
						$element->[0]->{$key}->[0]->{version_instance}->[$i]->{date}->[0] = $versions[$i]->{date};
						$element->[0]->{$key}->[0]->{version_instance}->[$i]->{version}->[0] = $versions[$i]->{version};
						$element->[0]->{$key}->[0]->{version_instance}->[$i]->{change_descr}->[0] = $versions[$i]->{update};
					}
				}	elsif ( $key =~ /vulnerability_effect/) {
					
					if ( @{ $formData->{damageIds} } ) {
						my @damage_descriptions	= $dd->getDamageDescription( id => \@{ $formData->{damageIds} } );					
						
						for ( my $i = 0; $i < @damage_descriptions; $i++ ) {
							$element->[0]->{$key}->[0]->{effect}->[$i] = $damage_descriptions[$i]->{description};
						}
					}
				}	elsif ( $key =~ /system_information/) {
					for ( keys %{ $element->[0]->{$key}->[0]->{systemdetail}->[0] } ) {
						if(/^affected_product$/) {
							if ( @{ $formData->{products} } ) {

								my $products = $sh->loadCollection( id => \@{ $formData->{products} } );	

								my $i = 0;
								foreach my $product ( @$products ) {
									foreach my $productDetail ( 'producer', 'name', 'version', 'cpe_id' ) {
										$element->[0]->{$key}->[0]->{systemdetail}->[0]->{$_}->[0]->{product}->[$i]->{$productDetail}->[0] = $product->{$productDetail};
									}
									$i++;
								}
							}
						} elsif (/^affected_platform$/) {
							if ( @{ $formData->{platforms} } ) {
							
								my $platforms = $sh->loadCollection( id => \@{ $formData->{platforms} } );	

								my $i = 0;
								foreach my $platform ( @$platforms ) {
									foreach my $productDetail ( 'producer', 'name', 'version', 'cpe_id' ) {
										$element->[0]->{$key}->[0]->{systemdetail}->[0]->{$_}->[0]->{platform}->[$i]->{$productDetail}->[0] = $platform->{$productDetail};
									}
									$i++;
								}
							}				
						} elsif (/^affected_platforms_text$/) {
							$element->[0]->{$key}->[0]->{systemdetail}->[0]->{$_}->[0] = $formData->{platforms_text} if ( $formData->{platforms_text} );
						} elsif (/^affected_products_text$/) {
							$element->[0]->{$key}->[0]->{systemdetail}->[0]->{$_}->[0] = $formData->{products_text} if ( $formData->{products_text} );
						} elsif (/^affected_products_versions_text$/) {
							$element->[0]->{$key}->[0]->{systemdetail}->[0]->{$_}->[0] = $formData->{versions_text} if ( $formData->{versions_text} );
						}
					}
				} elsif ( $key =~ /publisher_analysis/) {
					for ( keys %{ $element->[0]->{$key}->[0] } ) {
						$element->[0]->{$key}->[0]->{$_}->[0] = $formData->{$_}
					}
				} elsif ( $key =~ /availability/ ) {
					next; # data for availability already in blank XML file.
				} elsif ( $key =~ /taranis_version/ ) {
					next;
				} else {
					$element->[0]->{$key}->[0] = $formData->{$key};
				}
			}
		}
	}
	
	my $xml = XMLout(
		$self->setCdata( $advisory ),
		KeepRoot => 1,
		NoSort => 1,
		XMLDecl => '<?xml version="1.0" encoding="UTF-8"?>'
	);

	# decoding is done because XMLout does html encoding 
	return decodeInput( \$xml );
}

# sub 'setCdata' is used by processPreviewXml
sub setCdata {
	my ( $self, $arg ) = @_;
	if ( ref( $arg ) eq 'ARRAY' ) {
		for ( my $i = 0; $i < @$arg; $i++ ) {
			if ( ref( $arg->[$i] ) eq 'HASH' || ref( $arg->[$i] ) eq 'ARRAY' ) {
				$arg->[$i] = $self->setCdata( $arg->[$i] );
			} else {
				if ( $arg->[$i] !~ /^\d*$/ ) {
					$arg->[$i] = "<![CDATA[". $arg->[$i] ."]]>" if ( $arg->[$i] );
				}
			}
		}		
	} elsif ( ref( $arg ) eq 'HASH' ) {
		foreach ( keys %$arg ) {
			if ( ref( $arg->{$_} ) eq 'HASH' || ref( $arg->{$_} ) eq 'ARRAY' ) {
				$arg->{$_} = $self->setCdata( $arg->{$_} );
			} else {
				if ( $_ eq "xmlns:xsi" || $_ eq "xsi:noNamespaceSchemaLocation" ) {
					next;
				} else {
					if ( $arg->{$_} !~ /^\d*$/ ) {
						$arg->{$_} = "<![CDATA[". $arg->{$_} ."]]>" if ( $arg->{$_} );
					}
				}
			}
		}
	} else {
		if ( $arg !~ /^\d*$/ ) {
			$arg = "<![CDATA[". $arg ."]]>";
		}
	}
	return $arg;	
}

# sub 'getPreviousVersions' is used by processPreviewXml
sub getPreviousVersions {
	my ( $self, $publication_id ) = @_;
	undef $self->{errmsg};
	my @versions;

	my ( $stmnt, $pub_id ) = $self->{sql}->select( "publication pu", "pu.id AS pub_id, replacedby_id, version, update, to_char(published_on, 'YYYYMMDD') AS date", { replacedby_id => $publication_id } );
	my %join = ( "JOIN publication_advisory pa" => { "pa.publication_id" => "pu.id" } );
	$stmnt = $self->{dbh}->sqlJoin(  \%join, $stmnt );
	
	$self->{dbh}->prepare( $stmnt );
	while ( $pub_id ) {
		$self->{dbh}->executeWithBinds( $pub_id );
		my $version = $self->{dbh}->fetchRow();
		push @versions, $version if ( $version );
		$pub_id = ( $version->{replacedby_id} ) ? $version->{pub_id} : 0;		
	}
	return \@versions;	
}

sub getNextVersions {
	my ( $self, $replacedById ) = @_;
	my @publications;
	my $stmnt = "SELECT * FROM publication WHERE id = ?;";
	
	$self->{dbh}->prepare( $stmnt );

	while ( $replacedById ) {
		$self->{dbh}->executeWithBinds( $replacedById );
		my $publication = $self->{dbh}->fetchRow();
		push @publications, $publication if ( $publication );
		
		$replacedById = ( $publication->{replacedby_id} ) ? $publication->{replacedby_id} : 0;
	}

	return \@publications;
}

sub getRelatedPublications {
	my ( $self, $cve_ids, $publicationType ) = @_;
	undef $self->{errmsg};
	my @publications;
	my  %where;
		
	if ( $cve_ids ) {
		foreach ( @$cve_ids ) {
			$_ = "%" . $_ . "%";
		}
	 %where = ( ids => { -ilike, $cve_ids } );
	}

	$where{"pu.status"} = 3;
	$where{"replacedby_id"} = undef; # will create SQL 'replacedby_id IS NULL'
	
	my $stmnt;
	my @bind;

	( $stmnt, @bind ) = $self->{sql}->select( "publication_advisory pa", "govcertid AS named_id, pa.id AS details_id, pa.title AS publication_title, version, publication_id", \%where, "govcertid DESC, version DESC" );

	my %join = ( "JOIN publication pu" => { "pu.id" => "pa.publication_id" } );	
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	while ( $self->nextObject() ) {
		push @publications, $self->getObject();
	}

  $self->{errmsg} = $self->{dbh}->{db_error_msg};
  
	return \@publications;
}

sub searchPublishedPublications {
	my ( $self, $search, $publicationType ) = @_;
	undef $self->{errmsg};
	my ( @publications, @bind );
	my $stmnt;
	my %join;
	
	my %where = ( status => 3, replacedby_id => undef );
	
	$where{-or} = [
									contents => { -ilike => "%".$search."%" },
								  ids			 => { -ilike => "%".$search."%" },
								  notes		 => { -ilike => "%".$search."%" },
								];

	( $stmnt, @bind ) = $self->{sql}->select( "publication pu", "pa.id AS details_id, pa.govcertid AS named_id, pa.version, pa.title AS publication_title, pa.publication_id", \%where, "pa.govcertid DESC, pa.version DESC" );
	%join = ( "JOIN publication_advisory pa" => { "pa.publication_id" => "pu.id" } );
		
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	while ( $self->nextObject() ) {
		push @publications, $self->getObject();
	}

  $self->{errmsg} = $self->{dbh}->{db_error_msg};
  
	return \@publications;	
}

sub getDistinctPublicationTypes {
	my $self = shift;
	my @types;
		
	my $stmnt = "SELECT DISTINCT title FROM publication_type ORDER BY title DESC;";
	
	$self->{dbh}->prepare($stmnt);
	$self->{dbh}->executeWithBinds();
	
	while ( $self->nextObject() ) {
		push( @types, $self->getObject()->{title} );
	}
	
	return @types;
}

sub openPublication {
	my ( $self, $username, $id ) = @_;
	return $self->setPublication( id => $id, opened_by => $username );
}

sub closePublication {
	my ( $self, $id ) = @_;
	return $self->setPublication( id => $id, opened_by => undef );
}

sub isOpenedBy {
	my ( $self, $id ) = @_;
	undef $self->{errmsg};
	
	my ( $stmnt, @bind ) = $self->{sql}->select( "publication AS p", "p.opened_by, us.fullname", { id => $id } );

	my %join = ( "JOIN users AS us" => { "us.username" => "p.opened_by" } );
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	$self->{errmsg} = $self->{dbh}->{db_error_msg} if ( $self->{dbh}->{db_error_msg} );
	
	return $self->{dbh}->fetchRow();
}

sub releaseLock {
	my ( $self, $lockInfo ) = @_;	

	my $publication  = $lockInfo->{publication};
	my $setToPending = $lockInfo->{setToPending};
	my $line_width	 = 71;
	
	my $table = "publication_advisory";
	
	my $tt = Taranis::Template->new();	
	
	my ( $namedPublicationId, $pub_type, $namedPublicationIdColumn, $main_pub_type );

	my $advisoryPrefix = Taranis::Config->getSetting("advisory_prefix");
	my $advisoryIdLength = Taranis::Config->getSetting("advisory_id_length");

	my $x = "";
	for ( my $i = 1; $i <= $advisoryIdLength; $i++ ) { $x .= "X"; }

	$namedPublicationId = ( $publication->{version} =~ /.*00$/ ) 
		? $advisoryPrefix . "-" . nowstring(6) . "-" . $x 
		: $publication->{govcertid};

	$pub_type = ( $publication->{version} > 1.00 ) ? "update" : "email";
	$namedPublicationIdColumn = "govcertid";
	$main_pub_type = "advisory";
		
	my %publicationSettings = ( id => $publication->{publication_id}, status => 2, published_on => undef, published_by => undef );
	
	$publicationSettings{status} = 0 if ( $setToPending );
	
	$self->{dbh}->startTransaction();
	if ( $publication->{publication_id} =~ /^\d+$/
		&& $self->setPublication( %publicationSettings )	
		&& $self->setPublicationDetails( 
			table => $table, 
			where => { id => $publication->{id} }, 
			$namedPublicationIdColumn => $namedPublicationId 
		)
	) {

		my $publication_txt = $tt->processPreviewTemplate( 
			$main_pub_type, 
			$pub_type, 
			$publication->{id}, 
			$publication->{publication_id}, 
			0, 
			$line_width 
		);
		
		if ( !$self->{errmsg} && $self->setPublication( id => $publication->{publication_id}, contents => $publication_txt ) ) {
			$self->{dbh}->endTransaction();
			return 1;
		} else {
			$self->{errmsg} = "Lock release failed(1).\n" . $self->{errmsg};
			$self->{dbh}->endTransaction();
			return 0;
		}
	} else {
		$self->{errmsg} = "Lock release failed(2).\n" . $self->{errmsg};
		$self->{dbh}->endTransaction();
		return 0;
	}
}

sub getPublishedPublicationsByAnalysisId {
	my ( $self, %args ) = @_;
	undef $self->{errmsg};
		
	if ( !$args{analysis_id} || !$args{table} ) {
		return undef;
	}

	my $table = delete $args{table};
	
	my %where = %args;
	$where{'pu.status'} = 3;
	
	my ( $stmnt, @bind ) = $self->{sql}->select( "$table AS p", "p.*", \%where );

	tie my %join, "Tie::IxHash";
	%join = (
		'JOIN publication pu' => { 'pu.id' => 'p.publication_id' },
		'JOIN analysis_publication ap' => { 'ap.publication_id' => 'pu.id' } 
	);
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );
		
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	$self->{errmsg} = $self->{dbh}->{db_error_msg} if ( $self->{dbh}->{db_error_msg} );
	
	my @publications;
	while ( $self->nextObject() ) {
		push @publications, $self->getObject();
	}
	
	return \@publications;
}


=head1 NAME 

Taranis::Publication

=head1 SYNOPSIS

  use Taranis::Publication;

  my $obj = Taranis::Publication->new();
  
  $obj->addPublication( %publication_details );

  $obj->setPublication( %publication_details );
  
  $obj->deletePublication( $id, $publication_type );

  $obj->linkToPublication( %link_data );
  
  $obj->unlinkFromPublication( %link_data );
  
  $obj->getLinkedToPublication( %searchFields );
  
  $obj->getLinkedToPublicationIds( table => 'table_name', select_column => 'select column', publication_id => id, advisory_id => id );

  $obj->loadCollection( table => 'table name', \%search_fields );
  
  $obj->getPublicationDetails( table => 'table name', \%search_fields );
  
  $obj->setPublicationDetails( table => 'table name', where => %search_fields , \%publication_details );
  
  $obj->extractSoftwareHardwareFromCve( $idstring );
  
  $obj->nextObject();

  $obj->getObject();

  $obj->getPublicationTypeId( $publication_type_name );
  
  $obj->getItemLinks( { [ analysis_id => id || publication_id => id ] } );

  $obj->processPreviewTemplatePart( $json_str, $table_name );

  $obj->processPreviewXml( $advisory_id );

  $obj->setCdata( $arguments );
  
  $obj->getPreviousVersions( $publication_id );

  $obj->getRelatedPublications( @cve_ids );
  
  $obj->searchPublishedPublications( $search_string );
  
  $obj->getDistinctPublicationTypes();
  
=head1 METHODS

=head2 B<new>

Constructor of the Taranis::Publication class.

    my $obj = Taranis::Publication->new();

Creates a new database handler which can accessed by:

    $obj->{dbh};

Creates a new SQL::Abstract object which can be accessed by:

    $obj->{sql};
  
Clears error message for the new object. Can be accessed by:
   
    $obj->{errmsg};	  

Returns the blessed object.	

=head2 B<addPublication>

Method for adding a publication.

Takes the publication details as paramater in a single hash. The format is column_name => 'value': 

    $obj->addPublication( { title => 'publication title', type => 1, status => '0', contents => 'content text', created_by => 'user_name' } );
  
The default value for column created_on is set to now() in the implementation model.
  
Returns true if addition is successful. Returns false if addition is unsuccessful and sets the object property $errmsg to Taranis::Database->{db_error_msg}. 
   
=head2 B<setPublication>

Method for saving changes to a publication, but changes only settings stored in table 'publication'.

Takes the publication details as paramater. The format is column_name => 'value'.

For selecting the publication the parameter 'where' or 'id' can be given to the subroutine. The 'where' parameter is a hash that contains key => value pairs. The 'id' parameter contains the value of the id of an publication.
  
    $obj->setPublication( id => 23, contents => $contents_text, status => 2 );
  
or
  
    $obj->setPublication( where => { replacedby_id => 23 }, contents => $contents_text, status => 2 );
  
Returns true if update is successful. Returns false if update is unsuccessful and sets the object property $errmsg to Taranis::Database->{db_error_msg}. 
  
=head2 B<deletePublication>

Method for deleting publications.

Takes the publication details id and the publication type ( 'advisory' or 'eow' ) as arguments:
  
    $obj->deletePublication( 23, 'advisory' );

Returns true if delete is successful. Returns false if delete is unsuccessful and sets the object property $errmsg to Taranis::Database->{db_error_msg}. 

=head2 B<linkToPublication>

Method for linking publication details to publication. 

This can be software/hardware, an analysis or publication specific details (advisory or eow). It is mandatory to specify the table for linking:
  
    $obj->linkToPublication( table => 'product_in_publication', publication_id => 23, softhard_id => 156 ); 

Returns true if linking is successful. Returns false if linking is unsuccessful and sets the object property $errmsg to Taranis::Database->{db_error_msg}. 
  
=head2 B<unlinkFromPublication>

Method for unlinking details from publication.

See sub linkToPublication.
  
=head2 B<getLinkedToPublication>

Method for retrieving linked publication details.

When visualising the table 'publication' as the basis, the surrounding tables that are connected through junction tables can be seen as publication details.
  
This method takes three arguments:

=over

=item 1

join_table_1, contains a hash for specifying the junction tablename (key) and the matching foreign key (value) which points to the primary key of the details table.

=item 2

join_table_2, containt a hash for specifying the details tablename (key) and the primary key (value) of the details table.

=item 3

'pu.id', contains the value of the id of the publication.

=back

Example:

    $obj->getLinkedToPublication( 
				  join_table_1 => { analysis_publication => 'analysis_id' },
				  join_table_2 => { analysis => 'id' },
				  'pu.id'      => $query->param('id')
				 );

Returns the value of DBI->execute(). Sets $errmsg of this object to Taranis::Database->{db_error_msg} if database execution fails.
    
=head2 B<getLinkedToPublicationIds>

Method for retrieving the ID's of details linked to publication or advisory.
  
Method can be used to get ID's of tables that have a direct relation with table 'publication' or 'advisory'.
  
Takes three arguments:

=item 1

table, tablename of the table to extract id's from

=item 2

select_column, column name of the specified table

=item 3

I<a)> publication_id, id of the publication or I<b)> advisory_id, id of the advisory

=back

Example:

    $obj->getLinkedToPublicationIds( 
				     table          => 'product_in_publication', 
				     select_column  => 'softhard_id', 
				     publication_id => $publication_id 
				    );

or

    $obj->getLinkedToPublicationIds( 
				     table         => 'advisory_damage', 
				     select_column => 'damage_id', 
				     advisory_id   => $advisory_id 
				    );

Returns an array with ID's.

=head2 B<loadCollection>

Method for retrieving publications and some details specified in the supplied table.
  
This method takes nine arguments:

=item 1

table, name of the table that holds the publication details

=item 2

status, an array reference of all the desired statuses

=item 3

date_column, name of the column to search with start_date and end_date

=item 4

start_date, starting date to search the column specified with date_column

=item 5

end_date, ending date to search the column specified with date_column

=item 6

hitsperpage, number of maximum amount of results

=item 7

offset, the number of the starting point of the range of the results

=item 8

search, search string used to search the columns specified in the constants which are dependent on the table name (see 1. table )

=item 9

order_by, columns separated by comma's to specify the order of the results

=back

Example:

    $obj->loadCollection(
			 table       => 'publication_advisory',
			 status      => [2,3],
			 start_date  => 20090525,
			 end_date    => 20090527,
			 date_column => 'published_on',
			 hitsperpage => 100,
			 offset      => 0,
			 search      => 'windows',
			 order_by    => 'govcertid, version'
                        );
  
Collects per publication all data from table publication and all data of the table specified as argument. 
  
Returns an array of hashes containting the publications. Sets $errmsg of this object to Taranis::Database->{db_error_msg} if database execution fails.
  
=head2 B<getPublicationDetails>

Method for retrieving the details from the table that belongs to a specific publication like 'publication_advisory' or 'publication_endofweek'.
  
Takes at least two arguments:

=item 1

table, name of the table of the specific publication

=item 2

'tablename.columnname', an unique id of the table set in argument one.

=back

Example:

    $obj->getPublicationDetails(
                        	 table => 'publication_advisory',
                        	 'publication_advisory.id' => 25
                        	);

  
Retrieves all data from table publication and all data of the table specified as argument.

Returns the publication details. Sets $errmsg of this object to Taranis::Database->{db_error_msg} if database execution fails.
  
=head2 B<setPublicationDetails>
  
Method for updating publication details.
  
Takes at least three arguments and as many as the table to update has columns:

=item 1

table, name of the table of the publication details

=item 2

where, contains a hash with the details for selecting the publication to update.

=item 3

'column name', value which needs to be updated.

=back

Example:

    $obj->setPublicationDetails(
                        	 table => 'publication_advisory',
                        	 where => { id => 42 },
                        	 title => 'my new advisory title',
                        	 damage => '2'
                        	);

Returns true if update is successful. Returns false if update is unsuccessful and sets the object property $errmsg to Taranis::Database->{db_error_msg}. 
  
=head2 B<extractSoftwareHardwareFromCve>

Method for getting software/hardware that is linked to a CVE ID
  
Takes an idstring as argument. The ID's have to space separated:
  
    $obj->extractSoftwareHardwareFromCve( 'CVE-2009-0003 CVE-2009-2345 CVE-2009-4567' );
  
Returns a list of software/hardware. The data retrieved is the software/hardware description and all found data from table software_hardware.
  
=head2 B<nextObject> & B<getObject>

Method to retrieve the list that is generated by a method like loadCollection.

This way of retrieval can be used to get data from the database one-by-one. Both methods don't take arguments.

Example:

    $obj->loadCollection( $args );

    while( $obj->nextObject ) {
        push @list, $obj->getObject;
    }
    
=head2 B<getPublicationTypeId>

Method for retrieving the ID that is set in table publication_type for the specified type name.

Takes the type name as argument:
  
    $obj->getPublicationTypeId( 'Advisory (email)' );
  
Returns an ID number. Sets $errmsg of this object to Taranis::Database->{db_error_msg} if database execution fails.
  
=head2 B<getItemLinks>

Method for retrieving the links from item that are linked to an analysis.
  
Takes one argument which can be the analysis id or the publication id:
  
    $obj->getItemLinks( analysis_id => 25 );
  
or
  
    $obj->getItemLinks( publication_id => 76 );
  
Returns a list of links. Sets $errmsg of this object to Taranis::Database->{db_error_msg} if database execution fails.
  
=head2 B<processPreviewTemplatePart>

Method for creating a part of the preview.
  
Takes two arguments:

=item 1

JSON string, which holds the following arrays:

=item I<ids, ID's of the records to retrieve>

=item I<columns, the column names of the desired information>

=item I<destination (single value), destination id on HTML page>

=item 2

table, table name

=back

Example:
  
    $obj->processPreviewTemplatePart( '{"ids":["46533","46561","46550"],"columns":["producer","name","version"],"destination":"platforms_txt"}', 'software_hardware' );
  
Returns the preview part text and the destination.	  
  
=head2 B<processPreviewXml> I<(advisory only)>

Method for creating the XML output of an advisory.
  
Takes the the advisory id as argument:
  
    $obj->processPreviewXml( 34 );
  
Note: the content of the XML is placed between CDATA tags.
  
Returns the XML as a string. 
  
=head2 B<setCdata>

Method for adding CDATA tags to all the value of a complex data structure.
  
Takes a complex data structure with arrays and hashes as argument:
  
    $obj->setCdata( $data_structure );  
  
Returns the data structure where all the values are enclosed by CDATA tags.
  
=head2 B<getPreviousVersions> I<(advisory only)>

Method for retrieving previous versions of an advisory.
  
Takes the publication id as argument:
  
    $obj->getPreviousVersions( 35 );
    
Retrieves the publication_id (as 'pub_id'), replacedby_id, version, update and published_on (as 'date') from version found.

Returns an array reference with the previous version collected.
    
=head2 B<getRelatedPublications> I<(advisory only)>

Method for retrieving related advisories based on a list of CVD ID's.

Searches for published advisories (status = 3) and that the highest version (replacedby_id = NULL).
  
Takes an array of CVE ID's as argument or no argument at all:
  
    $obj->getRelatedPublications( [ 23, 56, 76 ] ); 
  
or
  
    $obj->getRelatedPublications();
  
Retrieves the govcertid, id (as advisory_id), title (as advisory_title), version and publication_id.

Returns an array reference with the related advisories. Sets $errmsg of this object to Taranis::Database->{db_error_msg} if database execution fails.
  
=head2 B<searchPublishedPublications>

Same as 'getRelatedPublications', the difference being it is based on a search string that searches in column 'contents' of table publication.

=head2 B<getDistinctPublicationTypes>

Method for retrieving the publication types.
  
Takes no arguments:
  
    $obj->getDistinctPublicationTypes();
    
Returns an array with the names of the publication types.
    
=head1 AUTHOR

Sebastiaan van Achterbergh

May 27, 2009

=cut

1;
