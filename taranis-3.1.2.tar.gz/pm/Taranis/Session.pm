package Taranis::Session;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;
use Taranis::Database;

use SQL::Abstract;
use CGI::Session qw(-ip_match);
use CGI::Simple;
use CGI::Session::ID::sha512;
use Taranis::Config;
use Taranis::Role;
use Taranis::Category;
use Taranis::Publication;
use Taranis::Config::XMLGeneric;
use Taranis qw(:all);
use Tie::IxHash;
use ModPerl::Util;

use Data::Dumper;
$CGI::Simple::DISABLE_UPLOADS = 0;   # enable uploads, need it for icon image upload.

#TODO: check for unused methods, some seem to be leftovers from dev.

my ( $entitlement, $error );

BEGIN {
  my $cfg      = Taranis::Config->new();
  my $ent_file = $cfg->{entitlements};
	$error = '';
  # beware! changing contents of entitlements file needs Apache restart!
  $entitlement = Taranis::Config->new("$ent_file");
}

sub new {
  my ( $class, $arg ) = @_;
  my $cgi = CGI::Simple->new;
  my $cgisession = CGI::Session->new('id:sha512', $cgi) or logdit( CGI::Session->errstr );  
#TODO: sub  {} ???  
  my $self = {
               errmsg     => undef,
#               cgisession => CGI::Session->load('id:sha512', $cgi),
               cgisession => $cgisession,               
               dbh        => Taranis::Database->new(),
               sql        => SQL::Abstract->new(),
               rwx        => sub { }
  };

  my $is_secure = Taranis::Config->getSetting("session_secure_cookie");
  $is_secure = ( $is_secure && $is_secure =~ /^yes$/i ) ? 1 : 0;

  my $cookie = $self->{cgisession}->cookie( -httponly => 1, -secure => $is_secure );

  $self->{cgisession}->query->header( -cookie => $cookie, -type=>'text/html' );
  $self->{cgisession}->expire( Taranis::Config->getSetting("session_expire") );

  
  bless $self;
  return $self;
}

sub loadSession {
  my ( $class, %arg ) = @_;

  my $cgi = CGI::Simple->new;
  my $goto_url = $arg{redirect};

	##### FOR DEBUGGING #####
	my $cgisession = CGI::Session->load('id:sha512', $cgi) or logdit( CGI::Session->errstr );

  my $self = {
               errmsg     => undef,
               cgisession => $cgisession,
               dbh        => Taranis::Database->new(),
               sql        => SQL::Abstract->new()
  };

  if ( $self->{cgisession}->is_expired() ) {
    $error = 'Your session has expired. Please <a href="">login</a> again.';

    # Look for ajax argument, if true a 403 header is send (no redirect).
    # the calling Ajax javascript should check for error and display in a <div> 
    if ( defined( $arg{ajax} ) && $arg{ajax} ) {
        return 0;
    } else {
      redirectToLogin( $goto_url . "&cause=expired" );
    }
  } elsif ( $self->{cgisession}->is_empty() ) {
    $error = 'You are not logged in. Please <a href="">login</a>..';

    # Look for ajax argument, if true a 403 header is send (no redirect).
    # the calling Ajax javascript should check for error and display in a <div> 
    if ( defined( $arg{ajax} ) && $arg{ajax} ) {
        return 0;
    } else {
      redirectToLogin( $goto_url . "&cause=nosession" );
    }  
  } else {
    bless $self;
    my $q = $self->{cgisession}->query;

	my $program = $q->param('pageName') || 'index';
#    $self->{me} = $program;

    # Get the entitlements belonging to the script
    my @IAMA = $entitlement->{entitlement}->{$program}->{use_entitlement};

    # Get the user rights for this entitlement
    $self->{rights} = $self->getUserRights( 'username'    => $self->{cgisession}->param("userid"),
                                            'entitlement' => \@IAMA );

    # dummy rights record, if this happens the taranis.conf.entitlements.xml has no proper
    # entry for this entitlement
    my %dummy = (
                  'particularization' => '',
                  'read_right'        => '0',
                  'execute_right'     => '0',
                  'write_right'       => '0'
    );
    if ( !$self->{rights} ) { $self->{rights} = { dummy => \%dummy }; }

    # make sure you can only get beyond this if the user role hase read or write right
    my $read_right = 0;
    foreach my $record ( keys %{ $self->{rights} } ) {
      $read_right =
        ( $self->{rights}->{$record}->{read_right} || $self->{rights}->{$record}->{write_right} )
        ? 1
        : $read_right;
    }

    # execute right and particularization has to be figured in the program.

    if ( ( !$self->{rights} || !$read_right ) && ( $program ne 'logout' ) ) {
      $self->{errmsg} = $program;
      $self->logout;
    }

    my $fd = $q->Vars;

    # walk the form data to encode/sanitize the values
    # we have to skip some values because encodeInput would destroy them
    while ( my ( $key, $val ) = ( each %$fd ) ) {
      if ( $key =~ /^particularizations/ ) {

        # TODO: some special sanitation with the values here
        next;
      }

      if ( $key !~ /^\./ ) {
        my @multi_val;
        if ( $val =~ /.*\0.*/ ) {
          @multi_val = split( "\0", $val );
#          $q->param( -name => "$key", -value => encodeInput( \@multi_val ) );
          $q->param( -name => "$key", -value => \@multi_val );
        } else {
#          $q->param( -name => "$key", -value => encodeInput( \$val ) );
			$q->param( -name => "$key", -value => $val );
        }
      }
    }

    # make sure session data is written to session disk file.
    $self->{cgisession}->flush;

    return $self;
  }
}

sub getMenuItems {
  # used by login to get all items for top-level menu
  my ( $self, $username ) = @_;

  my $vars;
  foreach my $program ( keys %{ $entitlement->{entitlement} } ) {
  	
    if ( defined $entitlement->{entitlement}->{$program}->{menuitem} ) {
    	
      my @IAMA = $entitlement->{entitlement}->{$program}->{use_entitlement};
      
      my $rights = $self->getUserRights( username => $username, entitlement => \@IAMA );
      
      foreach my $use_entitlement ( keys %$rights ) {
      
        if ( $rights->{$use_entitlement}->{read_right} ) {
      
          if ( $rights->{$use_entitlement}->{particularization} ne '' ) {
            $vars->{menuitem}->{$program} = $rights->{$use_entitlement}->{particularization};
          } else {
            $vars->{menuitem}->{$program} = $use_entitlement;
          }
        }
      }
    }
  }

  return $vars->{menuitem}; # OK
}

sub getSessionUserSettings {
# returns a  hash with all menuitems, and categories for mod_assess/assess
# this result depends on read_right from role_right.


	my $self = shift;
	my $vars;
	my @analysis_status_options;
	
	foreach my $status ( split( ",", Taranis::Config->getSetting("analyze_status_options") ) ) {
		push @analysis_status_options, trim( $status );
	}

	my $ca = Taranis::Category->new();
	my @assessCategoriesFromDatabase = $ca->getCategory( 'is_enabled' => 1 );
	
#	my @assessCategoryNames;
#	foreach my $assessCategory ( @assessCategoriesFromDatabase ) {
#		push @assessCategoryNames, $assessCategory->{name};
#	}

	my $pu = Taranis::Publication->new();
	my @publication_options = $pu->getDistinctPublicationTypes();

	$vars->{blingbling} = $self->{cgisession}->param('bling');
	$vars->{menuitem} = $self->{cgisession}->param('menuitem');
	
	my @assessCategoriesFromSession;
	my %uniqueCategory;
	if ( ref( $vars->{menuitem}->{assess} ) eq "ARRAY" ) {
		foreach my $category ( sort @{ $vars->{menuitem}->{assess} } ) {
			$category = lc( $category );
			
			if ( !exists( $uniqueCategory{ $category } ) ) {
				$uniqueCategory{ $category} = 1;
				
				my $categoryId = $ca->getCategoryId( $category );
				
				push @assessCategoriesFromSession, { id => $categoryId, name => $category };
			}
		}
	}

	my @all_categories = ( ref( $vars->{menuitem}->{assess} ) ne "ARRAY" ) ?  @assessCategoriesFromDatabase : @assessCategoriesFromSession;
	
	@{ $vars->{assess_categories} } = @all_categories;

	my @status_options = ( ref( $vars->{menuitem}->{analyze} ) ne "ARRAY" ) ? @analysis_status_options : @{ $vars->{menuitem}->{analyze} };
	my %tmp_status_options = map( { lc $_ => 1 } @status_options );
	@{ $vars->{analysis_status_options} } = sort keys %tmp_status_options;

	my @publications = ( ref( $vars->{menuitem}->{publications} ) ne "ARRAY" ) ? @publication_options : @{ $vars->{menuitem}->{publications} };
	my %tmp_publications = map( { lc $_ => 1 } @publications );
	@{ $vars->{publication_options} } = sort keys %tmp_publications;
	
	# get the tools items for tools dropdown menu
	my $tools = Taranis::Config::XMLGeneric->new("toolsconfig", "toolname", "tools");
	my $tools_config = $tools->{elements};
	
	my $menuitems = $vars->{menuitem};

	foreach my $tool ( @$tools_config ) {
		
		if ( $tool->{webscript} =~ /^.*?\/(.*?)\//i ) {			
			my $tool_id = $1;
			if ( exists( $menuitems->{ $tool_id } ) ) {
				push @{ $vars->{toolsconfig} }, $tool;
			}
		}
	}

# get userinfo for display in window
	my $userid = $self->{cgisession}->param("userid");
	my $ro = Taranis::Role->new();
	
	my $roles = $ro->getRolesFromUser( username => $userid);
	
	$vars->{info_username} = $userid;
	if ($roles) {
		foreach my $id ( keys %$roles ) {
			push @{ $vars->{info_user_roles} },  $roles->{$id}->{name};
		}
	}

# get organisation info and advisory prefix
	$vars->{organisation} 	 = Taranis::Config->getSetting("organisation");
	$vars->{advisory_prefix} = Taranis::Config->getSetting("advisory_prefix");
	$vars->{advisory_id_length} = Taranis::Config->getSetting("advisory_id_length");

  return $vars;  
}

sub right {
  my ( $self, $arg ) = @_;

  my $wanted_right;
  if ( $arg =~ /^r/i ) { $wanted_right = 'read_right' }
  if ( $arg =~ /^w/i ) { $wanted_right = 'write_right' }
  if ( $arg =~ /^e/i ) { $wanted_right = 'execute_right' }
  if ( $arg =~ /^p/i ) { $wanted_right = 'particularization' }

  my $return_right = 0;

  foreach my $record ( keys %{ $self->{rights} } ) {
    if ( $wanted_right eq 'particularization' ) {
    	$return_right = $self->{rights}->{$record}->{$wanted_right};
    } else {
    	$return_right = $self->{rights}->{$record}->{$wanted_right} ? 1 : $return_right;	
    }
  }

  return $return_right;

}

sub rightOnParticularization {
	my ( $self, $part_name ) = @_;
	
	my $has_part_rights = 0;

	if ( $self->right("particularization") ) {
		
		foreach my $right ( @{ $self->right("particularization") } )	{
			if ( lc $right eq lc $part_name ) {
				$has_part_rights = 1;
			}
		}
	} else {
		$has_part_rights = 1;
	}
	
	return $has_part_rights;
}

sub getUserRights {
  my ( $self, %args ) = @_;
  undef $self->{errmsg};
  my $username     = $args{username};
  my @entitlements = $args{entitlement};

  tie my %join, "Tie::IxHash";
  my %entitlement;
  my $select =
'ent.name as ent_name, rr.entitlement_id, rr.role_id, rr.read_right, rr.write_right, rr.execute_right, rr.particularization';

  my %where = (
                'ur.username' => $username,
                'ent.name'    => [ \@entitlements ]
  );
  my $from = 'role_right rr';
  my ( $stmnt, @bind ) = $self->{sql}->select( $from, $select, \%where );

  %join = (
            'JOIN user_role AS ur'    => { 'ur.role_id'        => 'rr.role_id' },
            'JOIN entitlement AS ent' => { 'rr.entitlement_id' => 'ent.id' },
            'JOIN role AS r'          => { 'r.id'              => 'ur.role_id' }
  );

  $stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

  $self->{dbh}->prepare($stmnt);
  my $result = $self->{dbh}->executeWithBinds(@bind);

  my @role_right;
  while ( $self->{dbh}->nextRecord ) {
    my $result = $self->{dbh}->getRecord;
    push @role_right, $self->{dbh}->getRecord;
  }
  if ( scalar @role_right < 1 ) {
    $self->{errmsg} = 'no role_rights for this entitlement';
    return 0;
  }

  no warnings;
  foreach my $rr (@role_right) {
    if ( $rr->{particularization} ne '' ) {
    	
	   	$entitlement{ $rr->{ent_name} }->{particularization} .= $rr->{particularization} . ",";
    } else {
    	$entitlement{ $rr->{ent_name} }->{particularization} = "HAS_ALL_RIGHTS";
    }
    
    $entitlement{ $rr->{ent_name} }->{read_right} =
        $entitlement{ $rr->{ent_name} }->{read_right}
      ? $entitlement{ $rr->{ent_name} }->{read_right}
      : $rr->{read_right};

    $entitlement{ $rr->{ent_name} }->{write_right} =
        $entitlement{ $rr->{ent_name} }->{write_right}
      ? $entitlement{ $rr->{ent_name} }->{write_right}
      : $rr->{write_right};

    $entitlement{ $rr->{ent_name} }->{execute_right} =
        $entitlement{ $rr->{ent_name} }->{execute_right}
      ? $entitlement{ $rr->{ent_name} }->{execute_right}
      : $rr->{execute_right};
  }

  for ( my ( $k, $v ) = each(%entitlement) ) {

    if ( $v->{particularization} && $v->{particularization} !~ /.*HAS_ALL_RIGHTS.*/ ) {

      my $particularization = trim( $v->{particularization} );
      $particularization =~ s/,+$//;
      $particularization =~ s/^,+//;
      $particularization =~ s/,+/,/;

      my @tmparr = split( ',', $particularization );
      my %part_keys = map { lc $_ => 1 } @tmparr;
      my @parti = keys %part_keys;

      my @return_particularization;
      if ( @parti && $particularization !~ /^ARRAY\(/ ) {
        for ( my $i = 0 ; $i < scalar @parti ; $i++ ) {
          push @return_particularization, trim( $parti[$i] );
        }
        $entitlement{$k}->{particularization} = [@return_particularization];
      }

    } else {
    	$entitlement{$k}->{particularization} = "";
    }
  }
  return \%entitlement;
}

sub setUserAction {
  my ( $self, %arg ) = @_;
  undef $self->{errmsg};
  my $table = 'user_action';

  my ( $stmnt, @bind ) = $self->{sql}->insert( $table, \%arg );
  my $sth = $self->{dbh}->prepare($stmnt);
  my $res = $self->{dbh}->executeWithBinds(@bind);

  if ( defined( $self->{dbh}->{sth}->errstr ) ) {
    $self->{errmsg} = $self->{dbh}->{sth}->errstr;
    return 0;
  }
  return 1;
}

sub logout {
  my $self = shift;

  my $q = $self->{cgisession}->query;
  my $msg = ( $self->{errmsg} ) ? ( $self->{errmsg} ) : "";
  
  $self->{cgisession}->delete();
  $self->{cgisession}->flush();
}

sub redirectToLogin {
  my ($arg) = shift;
  my $cgi = CGI::Simple->new;

  my $referer = $ENV{'QUERY_STRING'};
  if ( $arg =~ /^\// ) { $referer = '?goto=' . $arg }

  my $redirect = "login/" . $referer;

  print $cgi->redirect($redirect);
  ModPerl::Util::exit();
}

sub sessionError {
	my ( $class ) = @_;
	
	return $error;	
}
1;

=head1 NAME 

Taranis::Session

=head1 SYNOPSIS

use Taranis::Session;
my $ses = Taranis::Session->new('/redirect/path/to/program');


=head1 QUICK START

Use the /redirect/path/to/program for returning to this page if
a session was timed-out and the user must login again 

=head1 METHODS

=head2  B<loadSession(redirect =>> $ENV{REQUEST_URI})

loads Taranis session data

puts return value of getUserRights into $self->{rights}
puts calling program name into $self->{me}

So you can check for rights like so:

my $write_right = $session->{rights}->{$session->{me}}->{write_right};

=head2  B<getUserRights(username =>> $username, entitlement => \@IAMA)

returns a hash with entitlement name as a key and role_rights as hash with values for this users role.
e.g.

$VAR1 = 
  {
    'constituent_individuals' => {
                                   'particularization' => 'CA, CB,',
                                   'read_right' => '1',
                                   'execute_right' => '1',
                                   'write_right' => '0'
                                 },
    'analysis' => {
                    'particularization' => 'AA, BB,',
                    'read_right' => '1',
                    'execute_right' => '0',
                    'write_right' => '1'
                  }
  };
        

every program should register itself and its roles as an entitlement in taranis.conf.entitlements.xml

=head2 B<logout()>

Deletes the session. 

=head2 B<setUserAction()>

Insert a record into user_action table.

$session->userAction(
            username    => $session->{cgisession}->param('userid'),
            entitlement => $session->{me},
            action      => $action,
            comment     => $comment);

=head2 B<getMenuItems()>

Used by mod_loign/login.pl to fill the session object with a hash of all menuitems this 
user has (at least) read acces to.
In a program that has a menubar on top (that has a [% INCLUDE header_menu.tt %] in it's TT source)
enter this line after loading session and declaring $vars; 

$vars->{menuitem} = $session->{cgisession}->param('menuitem');

Return value contains particularization (if any) als a @list, to be used in 
applications that need to know about them.

=head2 B<getSessionUserSettings()>

returns a hash with menuitems.

$vars->{categories} = $session->getSessionUserSettings();

This hash is used by header.tt to build the user menu (drop-down lists etc)


=head2 B<right()>

right([read,right,execute,particularization])

returns boolean for a wanted value.
e.g. $session->right("read")  returns either 0 or 1.

argument must contain at least first charachter of wanted right (r,w,e,p), case insensitive.

return 

 

=head1 AUTHOR

jeroen
Mar 18, 2009

=cut
