package Taranis::Dashboard::Collector;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Database;
use Taranis::Config;
use SQL::Abstract;
use strict;

sub new {
	shift @_;
	
	my $self = {
		errmsg => undef,
		dbh => Taranis::Database->new(),
		sql => SQL::Abstract->new(),
		tpl => 'dashboard_collector.tt',
		tpl_minified => 'dashboard_collector_minified.tt'
	};
	bless $self;
	return $self;	
}

sub collectorStatus {
	my ( $self ) = @_;
	my $cfg = new Taranis::Config();

	my $pidfile = $cfg->{pidfile};
	my $isRunning = 0;
	
	if ( -e $pidfile ) {
		## PID-file exists!
		my $fh1;
		open( $fh1, "<", $pidfile );
		my $pid = <$fh1>;
		$isRunning = kill 0, $pid;
		close( $fh1 );
	}
	
	return $isRunning;
}

sub lastSuccessfulRun {
	my ( $self ) = @_;
	
	my $stmnt = "SELECT to_char( MAX(finished), 'HH24:MI DD-MM-YYYY' ) AS last_successful_run FROM statistics_collector;";
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds();

	return $self->{dbh}->fetchRow()->{last_successful_run};
}

sub graphNumberOfErrorsPerRun {
	my ( $self ) = @_;
	
	my ( @collectorRuns, @graphDataPoints, $previousRunStart );
	
	# the * 1000 is needed because javascript timestamp is in miliseconds 
	my $stmnt = "SELECT EXTRACT(EPOCH FROM started) * 1000  AS started_epoch, started, finished"
		. " FROM statistics_collector"
		. " WHERE started > NOW() - '1 day'::INTERVAL"
		. " ORDER BY started DESC;";
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds();
	
	while ( $self->{dbh}->nextRecord() ) {
		my $run = $self->{dbh}->getRecord();
		
		if ( !$run->{finished} ) {
			$run->{finished} = $previousRunStart;
		}
		
		$previousRunStart = $run->{started};
		push @collectorRuns, $run;
	}

	my %where = ( time_of_error => {-between => ['000000 0000', '000000 0000'] } );
	my ( $preparedStmnt, @bind ) = $self->{sql}->select( 'errors', 'COUNT(*) AS error_count', \%where );
	$self->{dbh}->prepare( $preparedStmnt );

	foreach my $run ( @collectorRuns ) {
		next if ( !$run->{finished} );
		
		my @binds = ( $run->{started}, $run->{finished} );
		$self->{dbh}->executeWithBinds( @binds );
		
		my $count = $self->{dbh}->fetchRow()->{error_count};
		push @graphDataPoints, [ int $run->{started_epoch}, int $count ];
	}
	
	@graphDataPoints = reverse @graphDataPoints;
	
	my %graphSettings = ( 
		type => 'graph', 
		data => { 
			data=> \@graphDataPoints, 
			points => { symbol => 'triangle' },
			color => '#f30c20',
			threshold => {
				below => 1,
				color => '#53e561'
			}
		}, 
		name => 'graphNumberOfErrorsPerRun',
		yaxisname => 'errors', 
		options => {
			xaxis => {
				mode => 'time',
				timezone => 'browser',
				timeformat => '%H:%M'
			},
			series => {
				points => { show => 1 } 
			},
			grid => { hoverable => 1 }
		} 
	);
	return \%graphSettings;
}

sub graphDurationPerRun {
	my ( $self ) = @_;
	
	my ( @collectorRuns, @graphDataPoints );
	
	# the * 1000 is needed because javascript timestamp is in miliseconds 
	my $stmnt = "SELECT TO_CHAR(AGE(finished, started), 'MI') AS run_duration, EXTRACT(EPOCH FROM started) * 1000  AS started_epoch" 
		. " FROM statistics_collector"
		. " WHERE started > NOW() - '1 day'::INTERVAL"
		. " ORDER BY started DESC;";
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds();
	
	while ( $self->{dbh}->nextRecord() ) {
		my $run = $self->{dbh}->getRecord();
		
		if ( !$run->{run_duration} ) {
			$run->{run_duration} = 0;
		}
		
		push @graphDataPoints, [ int $run->{started_epoch}, int $run->{run_duration} ];
	}

	@graphDataPoints = reverse @graphDataPoints;
	
	my %graphSettings = ( 
		type => 'graph', 
		data => { 
			data=> \@graphDataPoints, 
			points => { symbol => 'triangle' },
			color => '#fa7505',
			threshold => [
			{
				below => 1,
				color => "#f30c20"
			}, 
			{
				below => 15,
				color => "#53e561"
			}]
		}, 
		name => 'graphDurationPerRun',
		yaxisname => 'minutes', 
		options => {
			xaxis => {
				mode => 'time',
				timezone => 'browser',
				timeformat => '%H:%M'
			},
			yaxis => { 
				minTickSize => 1,
				tickDecimals => 0 
			},
			series => {
				points => { show => 1 } 
			},
			grid => { hoverable => 1 }
		} 
	);
	return \%graphSettings;	
}

1;
