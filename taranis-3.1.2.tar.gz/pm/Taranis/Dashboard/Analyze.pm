package Taranis::Dashboard::Analyze;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Database;
use SQL::Abstract;
use strict;

sub new {
	shift @_;
	
	my $self = {
		errmsg => undef,
		dbh => Taranis::Database->new(),
		sql => SQL::Abstract->new(),
		tpl => 'dashboard_analyze.tt',
		tpl_minified => 'dashboard_analyze_minified.tt'
	};
	bless $self;
	return $self;	
}

sub numberOfPendingAnalyses {
	my ( $self ) = @_;
	my $stmnt = "SELECT COUNT(*) AS count FROM analysis WHERE status = 'pending';";
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds();

	return $self->{dbh}->fetchRow()->{count};	
}

sub numberOfPendingAnalysesWithoutOwner {
	my ( $self ) = @_;
	my $stmnt = "SELECT COUNT(*) AS count FROM analysis WHERE status = 'pending' AND owned_by IS NULL;";
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds();

	return $self->{dbh}->fetchRow()->{count};
}

sub graphNumberOfPendingAnalysesPerHour {
	my ( $self ) = @_;
	
	my ( @graphDataPoints );
	
	# the * 1000 is needed because javascript timestamp is in miliseconds
	my $stmnt = "SELECT EXTRACT(EPOCH FROM timestamp) * 1000  AS timestamp_epoch, pending_count"
		. " FROM statistics_analyze"
		. " WHERE timestamp > NOW() - '2 days'::INTERVAL"
		. " ORDER BY timestamp DESC;";
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds();
	
	while ( $self->{dbh}->nextRecord() ) {
		my $record = $self->{dbh}->getRecord();
		push @graphDataPoints, [ int $record->{timestamp_epoch}, int $record->{pending_count}];
	}
	
	@graphDataPoints = reverse @graphDataPoints;
	
	my %graphSettings = ( 
		type => 'graph', 
		data => \@graphDataPoints, 
		name => 'graphNumberOfPendingAnalysesPerHour',
		yaxisname => 'pending analysis', 
		options => {
			xaxis => {
				mode => 'time',
				timezone => 'browser',
				timeformat => '%H:%M',
				minTickSize => [1, 'hour']
			},
			yaxis => { 
				minTickSize => 1,
				tickDecimals => 0,
				min => 0
			},
			series => {
				points => { show => 1 }, 
				lines => { show => 1 }
			},
			grid => { hoverable => 1 }
		} 
	);
	return \%graphSettings;	
}

# should always return TRUE or FALSE 
sub countNumberOfPendingAnalysesPerHour {
	my ( $self ) = @_;
	
	my $stmnt = "SELECT MAX(timestamp) AS last_count FROM statistics_analyze WHERE timestamp > NOW() - '1 hour'::INTERVAL;";
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds();

	if ( !$self->{dbh}->fetchRow()->{last_count} ) {
		my $pendingCount = $self->numberOfPendingAnalyses();
		
		my ( $addCountStmnt, @bind ) = $self->{sql}->insert( "statistics_analyze", { pending_count => $pendingCount } );
		$self->{dbh}->prepare( $addCountStmnt );
		
		if ( defined( $self->{dbh}->executeWithBinds( @bind ) ) > 0 ) {
			return 1;
		} else {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			return 0;
		}
	} else {
		return 1;
	}
}


1;
