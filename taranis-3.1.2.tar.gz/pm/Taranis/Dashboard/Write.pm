package Taranis::Dashboard::Write;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Config;
use Taranis::Publication;
use Date::Parse;
use DateTime;
use JSON;
use POSIX;

use strict;

sub new {
	shift @_;
	
	my $self = {
		errmsg => undef,
		dbh => Taranis::Database->new(),
		tpl => 'dashboard_write.tt',
		tpl_minified => 'dashboard_write_minified.tt'
	};
	bless $self;
	return $self;	
}

sub endOfShiftStatus {
	my ( $self ) = @_;

	my $cfg = new Taranis::Config();
	my $orangeTime = $cfg->{publication_eos_orange};
	my $redTime = $cfg->{publication_eos_red};
	my $status = undef;
	my $lastPublication = undef;
	
	if ( $orangeTime =~ /^([01][0-9]|2[0-4])[0-5][0-9]$/ && $redTime =~ /^([01][0-9]|2[0-4])[0-5][0-9]$/ ) {
	
		my $pu = Taranis::Publication->new();
		
		my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{eos}->{email};
		my $typeId = $pu->getPublicationTypeId( $typeName )->{id};
	    
		my $publicationDateTime = $pu->getLatestPublishedPublicationDate( type => $typeId );  	
		my ( $publicationDate, $publicationTime);
	
		if ( $publicationDateTime->{published_on_str} ) {
			( $publicationDate, $publicationTime) = split(' ', $publicationDateTime->{published_on_str});
			my $nowTime = strftime( '%H%M', localtime( time() ) );

			my $nowDateTimeObj = DateTime->today();
			my $publicationDateTimeObj = DateTime->new(
				year => substr( $publicationDate, 0, 4 ),
				month => substr( $publicationDate, 4, 2 ),
				day => substr( $publicationDate, 6, 2 ),
			);
		
			my $offsetInDays = $nowDateTimeObj->delta_days( $publicationDateTimeObj )->in_units('days');
		 
			if ( !$publicationDate || $offsetInDays == 1 ) {
				# there is no published publication or last published publication was yesterday
				if ( $nowTime > $redTime ) {
					$status = 'red';
				} elsif ( $nowTime > $orangeTime ) {
					$status = 'yellow';
				} else {
					$status = 'green';    		
		    	}
		    	
			} elsif ( $offsetInDays > 1 ) {
				# last published publication was more than 1 day ago
				$status = 'red';
			} else {
				# last published publication was of today
				$status = 'green';    	
			}
			
			my $year = substr( $publicationDateTime->{published_on_str}, 0, 4 );
			my $month = substr( $publicationDateTime->{published_on_str}, 4, 2 );
			my $dayOfMonth = substr( $publicationDateTime->{published_on_str}, 6, 2 );
			my $hour = substr( $publicationDateTime->{published_on_str}, 9, 2 );
			my $minute = substr( $publicationDateTime->{published_on_str}, 11, 2 );
			$lastPublication = "$hour:$minute $dayOfMonth-$month-$year";
			
		} else {
			$status = 'red';
		} 
	}
	
	return { status => $status, lastPublication => $lastPublication};
}

sub collectorNotifications {
	my ( $self ) = @_;
	
	my $stmnt = "SELECT error, to_char(time_of_error, 'dy HH24:MI') AS datetime FROM errors WHERE ( error_code = 'C016' OR error_code = 'C015' ) AND time_of_error > NOW() - '1 day'::INTERVAL ORDER BY time_of_error DESC;";
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds();
	
	my @notifications;
	while ( $self->{dbh}->nextRecord() ) {
		push @notifications, $self->{dbh}->getRecord();
	}
	return \@notifications;
}

1;
