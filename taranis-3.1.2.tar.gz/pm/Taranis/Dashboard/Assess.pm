package Taranis::Dashboard::Assess;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Database;
use Taranis::TagCloud;
use Taranis qw(:all);
use Tie::IxHash;
use SQL::Abstract;
use JSON;
use strict;

sub new {
	shift @_;
	
	my $self = {
		errmsg => undef,
		dbh => Taranis::Database->new(),
		sql => SQL::Abstract->new(),
		tpl => 'dashboard_assess.tt',
		tpl_minified => 'dashboard_assess_minified.tt',
		tagCloudCategories => ['news']
	};
	bless $self;
	return $self;	
}

sub numberOfUnreadItems {
	my ( $self ) = @_;
	
	my $stmnt = "SELECT COUNT(*) AS count FROM item WHERE status = 0;";
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds();

	return $self->{dbh}->fetchRow()->{count};	
}

sub assessTagCloud {
	my ( $self ) = @_;
	my $tc = Taranis::TagCloud->new();	
	my $stmnt = "SELECT tag_cloud FROM statistics_assess ORDER BY timestamp DESC LIMIT 1;";
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds();
 
	my $tagCloud = $self->{dbh}->fetchRow();

	if ( $tagCloud ) {
		my $tagList = from_json( $tagCloud->{tag_cloud} );
		
		my $sortedList = $tc->sortList( $tagList );
		my $list = $tc->resizeList( list => $sortedList, maximumUniqWords => 20, level => 20 );

		my %cloudSettings = (
			type => 'tagcloud',
			name => 'assessTagCloud',
			data => $list,
			'link' => 'assess/assess/displayAssess/searchkeywords='  
		);

		return \%cloudSettings;
		
	} else {
		return \'{}';
	}
}

sub createAssessTagCloudList {
	my ( $self ) = @_;

	my $stmnt = "SELECT MAX(timestamp) AS last_count FROM statistics_assess WHERE timestamp > NOW() - '20 minutes'::INTERVAL;";
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds();

	if ( !$self->{dbh}->fetchRow()->{last_count} ) {

		my %where = ( 'i.created' => { '>', \"NOW() - '1 day'::INTERVAL"} );
		$where{'c.name'} = $self->{tagCloudCategories} if ( $self->{tagCloudCategories} );
		
		my ( $stmnt, @bind ) = $self->{sql}->select( 'item i', 'i.title', \%where );
		
		my %join = ( 'JOIN category c' => { 'c.id' => 'i.category' } );
		$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );	
		
		$self->{dbh}->prepare( $stmnt );
		$self->{dbh}->executeWithBinds( @bind );
	
		my $text = '';
		while ( $self->{dbh}->nextRecord() ) {
			$text .= $self->{dbh}->getRecord()->{title} . ' ';
		}
	
		my $tc = Taranis::TagCloud->new();
		my $list = $tc->createTagsListFromText( text => $text );
		
		tie my %resizedList, 'Tie::IxHash';
		foreach my $tag ( keys %$list ) {
			if ( !$tc->isBlacklisted( $tag ) ) {
				$resizedList{ encodeInput(\$tag ) } = $list->{$tag}; 
			}
		}
		
		my ( $addListStmnt, @tagListBind ) = $self->{sql}->insert( "statistics_assess", { tag_cloud => to_json( \%resizedList ) } );
		$self->{dbh}->prepare( $addListStmnt );
		
		if ( defined( $self->{dbh}->executeWithBinds( @tagListBind ) ) > 0 ) {
			return 1;
		} else {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			return 0;
		}
	} else {
		return 1;
	}
}

1;
