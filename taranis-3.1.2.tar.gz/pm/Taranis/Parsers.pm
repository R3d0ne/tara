package Taranis::Parsers;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;
use Taranis qw(:all);
use Taranis::Config;
use Taranis::Database;
use Data::Dumper;
use SQL::Abstract;

sub new {
	shift @_;
	
	my $self = {
		errmsg 	=> undef,
		dbh => Taranis::Database->new(),
		sql => SQL::Abstract->new(),
		config => Taranis::Config->new()
	};
	bless $self;
	return $self;
}

sub getParsers {
	my ( $self, $parsername ) = @_;
	undef $self->{errmsg};

	my %where;
	if ( $parsername ) {
		$where{parsername} = { -ilike => [ '%' . $parsername . '%' ] };
	}

	my ( $stmnt, @bind ) = $self->{sql}->select( 'parsers', '*', \%where, 'parsername' );

	$self->{dbh}->prepare( $stmnt );
	my $result = $self->{dbh}->executeWithBinds( @bind );
	
	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
    }
 	
 	my @parsers;
	while ( $self->nextObject() ) {
		push @parsers, $self->getObject();
	}
	return \@parsers; 
}


*getElement = \&getParser;

sub getParser {
    my ( $self, $arg ) = @_;
    undef $self->{errmsg};

    my %where = ( parsername => $arg );
    my $order = 'parsername';
    
    my ( $stmnt, @bind ) = $self->{sql}->select( 'parsers', "*", \%where, $order );

    $self->{dbh}->prepare($stmnt);

    if ( defined( $self->{dbh}->{db_error_msg} ) ) {
        $self->{errmsg} = $self->{dbh}->{db_error_msg};
        return 0;
    }

    $self->{dbh}->executeWithBinds(@bind);
    
        if ( defined( $self->{dbh}->{db_error_msg} ) ) {
        $self->{errmsg} = $self->{dbh}->{db_error_msg};
        return 0;
    }

    my $hash_ref = $self->{dbh}->{sth}->fetchall_hashref('parsername');
    my $return;
    while ( my ( $uKey, $uVal ) = ( each %$hash_ref ) ) {
        while ( my ( $key, $val ) = ( each %$uVal ) ) {
          if (defined $val) {
            $return->{$key} = $val ;
          } else {
            $return->{$key} = ''; #  emulate XMLGeneric behaviour
          }
        }
    }
              
    return $return;
    
}

sub getParserSimple {
	my ( $self, $parsername ) = @_;
	undef $self->{errmsg};

	my %where = ( parsername => $parsername );

	my ( $stmnt, @bind ) = $self->{sql}->select( 'parsers', "*", \%where, 'parsername' );

	$self->{dbh}->prepare($stmnt);

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}

	$self->{dbh}->executeWithBinds(@bind);

	return $self->{dbh}->fetchRow();
}

sub addParser {
	my ( $self, %inserts ) = @_;
	undef $self->{errmsg};

    if ( !defined( $inserts{parsername} ) ) {
		$self->{errmsg} = "cannot add a parser without a name";
		return 0;
	}

	my ( $stmnt, @bind ) = $self->{sql}->insert( 'parsers', \%inserts );

	$self->{dbh}->prepare($stmnt);

	if ( defined( $self->{dbh}->executeWithBinds( @bind ) ) > 0 ) {
		return 1;
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}
}

sub setParser {
	my ( $self, %update ) = @_;

	undef $self->{errmsg};
	my $parsername;

	if ( !defined( $update{parsername} ) ) {
		$self->{errmsg} = "Invalid input.";
		return 0;
	} else {
		$parsername = $update{parsername};
	}

	delete $update{parsername};

	my %where = ( parsername => $parsername );

	my ( $stmnt, @bind ) = $self->{sql}->update( 'parsers', \%update, \%where );

	$self->{dbh}->prepare($stmnt);

	my $result = $self->{dbh}->executeWithBinds( @bind );
	
	if ( defined($result) && ($result !~ m/(0E0)/i ) ) {		
		if ( $result > 0 ) {
			return 1;
		} elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			return 0;
		} 
	} else {
		$self->{errmsg} = "Update failed, corresponding parser not found in database.";
		return 0;
	}
}

*deleteElement = \&deleteParser;

sub deleteParser {
	my ( $self, %where ) = @_;
	undef $self->{errmsg};

	if ( !defined( $where{parsername} ) ) {
		$self->{errmsg} = "no parsername supplied";
		return 0;
	}

	###################################################################
	# check if there are any sources records connected to this parser #
	###################################################################
	my ( $stmnt, @bind ) = $self->{sql}->select( 'sources', 'count(*) as cnt', { parser => $where{parser} } );

	$self->{dbh}->prepare($stmnt);
	$self->{dbh}->executeWithBinds(@bind);

	my $sourcesCount = $self->{dbh}->fetchRow();

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}
	
	if ( $sourcesCount->{cnt} > 0 ) {
		$self->{errmsg} = 'There are ' . $sourcesCount->{cnt} . ' sources which use to this parser';
		return 0;
	}

	( $stmnt, @bind ) = $self->{dbh}->{sql}->delete( 'parsers', \%where );

    $self->{dbh}->prepare($stmnt);
	my $result = $self->{dbh}->executeWithBinds(@bind);
	if ( defined($result) && ( $result !~ m/(0E0)/i ) ) {
		if ( $result > 0 ) {
			return 1;
		} elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			return 0;
		}
	} else {
		$self->{errmsg} = "Delete failed, corresponding id not found in database.";
		return 0;
	}
}

sub nextObject {
    my ($self) = @_;
    return $self->{dbh}->nextRecord;
}

sub getObject {
    my ($self) = @_;
    return $self->{dbh}->getRecord;
}


1;

=head1 NAME 



=head1 SYNOPSIS Taranis::Parsers

Get, Set, Update and Delete Taranis Parsers.


=head1 QUICK START

use Taranis::Parsers;

my $p = Taranis::Parsers->new();

=head1 METHODS


=head2  B<new()>

create a new Taranis::Parsers object;

=head2  B<addParser()>

Add a new parser to the Database;

$parser = {
          'item_stop' => '&lt;/tr&gt;',
          'link_stop' => '\\&quot;',
          'title_stop' => '&lt;',
          'title_start' => '450px;\\&quot;&gt;',
          'strip1_start' => 'OSVDB\\ News',
          'strip0_start' => 'DOCTYPE',
          'parsername' => 'html:osvdb',
          'strip0_stop' => 'ader\\&amp;quot;&amp;gt;Latest\\ OSVDB\\ Vulnerabilities',
          'item_start' => '&lt;tr&gt;',
          'strip1_stop' => '&amp;lt;\\/html&amp;gt;',
          'link_prefix' => 'http://osvdb.org',
          'link_start' => 'href=\\&quot;'
  };

$p->addParser(\$parser);


=head2 B<getParser()>

Gets a single parser from DB;
returns a hash.

$parser = $p->getParser($parsername);

=head2 B<getParsers()>

Retrieve all parsers from DB, returns an Array of Hashes.

=head2 B<deleteParser(parername => $parsername)>

delete a parser from DB

=head2 B<setParser()>

$p->setParser(link_prefix => undef, parsername => $parsername, link_start => 'blah')

=head1 AUTHOR

jeroen
30-mrt-2009

=cut
