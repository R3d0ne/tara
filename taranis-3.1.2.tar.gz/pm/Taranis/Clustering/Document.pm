package Taranis::Clustering::Document;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###
use strict;
use Taranis::Clustering::Tokenizer;
use Lingua::Identify qw(:language_identification);
use Time::Local;
use HTML::Entities;
use Data::Dumper;

my $DEBUG = 0;

my $FIELD_INDEX = { taranis => [ qw/Digest Category Source Title URL Description Timestamp Status ClusterID Score/ ],
                    ittt => [ qw/ID Timestamp Title Description ClusterID Score/ ],
                    raw  => [ qw/ID Description ClusterID Score/ ]
                  };

my $TOKENIZER = new Taranis::Clustering::Tokenizer();
my $ZERO_PROBABILITY = 0.0001;
my $TWEET_CATEGORY = 6;


## creator
#
sub new{
  my $class  = shift;
  my $fields = shift;
  my $format = shift;
  my $language = shift;
  my $loaded = 0;
  my $self   = {};

  bless $self,$class;

  ## the following input formats are currently supported:
  #  1. taranis: Digest Category Source Title URL Description Timestamp [ClusterID Score]
  #  2. ittt: ID Timestamp Title Description [ClusterID Score]
  #  3. raw:  ID Description [ClusterID Score]
  #
  #  if no format is provided, it assumes the 'raw' format
  #
  if($format){
    if($format eq 'taranis'){
      $loaded = $self->load_taranis_format($fields, $language);
    }
    elsif($format eq 'ittt'){
      $loaded = $self->load_ittt_format($fields);      
    }
  } else{
      $loaded = $self->load_raw_format($fields);
  }

  return undef unless $loaded;
  return $self;
}

sub fieldIndex{
  my $self = shift;
  my $value = shift;
  return $FIELD_INDEX->{$value} if defined $FIELD_INDEX->{$value};
  return [];  
}

sub get{
  my $self = shift;
  my $attr = shift;

  if ( (not defined $self->{$attr}) and $DEBUG ){
    print STDERR "WARNING: $attr not defined in Document object\n";
  }

  return defined($self->{$attr}) ? $self->{$attr} : '';
}

sub set{
  my $self = shift;
  my ($attr,$value) = @_;
  $self->{$attr} = $value;
}

sub load_raw_format{
    my $self = shift;
    my $fields = shift;

    for(my $i=0;$i<@$fields;$i++){
      my $fname = $FIELD_INDEX->{raw}[$i];

      if($fname =~ /ID|Description|ClusterID|Score/){
        $self->{$fname} = $fields->[$i];
      }
    }

    ## this format does not have a timestamp    
    $self->{Epoch} = 1;

    ## tokenize
    my @tokens = $TOKENIZER->tokenize( $self->{Description} );
    $self->{Text} = join(" ", @tokens);

    ## set the language
    $self->{Lang} = langof($self->{Text}) 
      if defined($self->{Text}) and length($self->{Text});
    
    ## create language model
    $self->createLanguageModel();

    return 1;
}

sub load_ittt_format{
    my $self = shift;
    my $fields = shift;
    
    for(my $i=0;$i<@$fields;$i++){
      my $fname = $FIELD_INDEX->{ittt}[$i];

      if(defined $fname and $fname =~ /ID|Title|Description|Timestamp|ClusterID|Score/){
        $self->{$fname} = $fields->[$i];
        $self->{Epoch} = $self->timestampToEpoch($self->{$fname}) if $fname eq 'Timestamp';        
      }
    }
    
    ## tokenize the text
    for('Title','Description'){
      my $t = decode_entities($self->{$_});
      my @tokens = $TOKENIZER->tokenize( $t );
      $self->{Text} .= ' '.join(" ", @tokens);
    }

    ## set the language
    $self->{Lang} = langof($self->{Text}) 
      if defined($self->{Text}) and length($self->{Text});
    
    ## create a language model
    $self->createLanguageModel();

    return 1;
}

sub load_taranis_format{
  my $self   = shift;
  my $fields = shift;
  my $language = shift;
  for(my $i=0;$i<@$fields;$i++){
    my $fname = $FIELD_INDEX->{taranis}[$i];

    if($fname =~ /Digest/){
      $self->{ID} = $fields->[$i];
    }
    elsif($fname =~ /Title|Description/){
      $self->{$fname} = clean($fields->[$i]);
    }
    elsif($fname =~ /Timestamp/){
      $self->{$fname} = $fields->[$i];
      $self->{Epoch} = $self->timestampToEpoch($self->{$fname});
    }
    elsif($fname =~ /Category|Source|URL|Status|ClusterID|Score/){
      $self->{$fname} = $fields->[$i];
    }
  }
 
  ## hack for tweets: ignore the title (which is a copy of the tweet text)
  #
  if($self->{Category} == $TWEET_CATEGORY){
    $self->{Title} = '';
  }

  ## preprocess and tokenize the text
  #
  for('Title','Description'){
    my $t = decode_entities($self->{$_});
    specialTweetTreatment(\$t);
    my @tokens = $TOKENIZER->tokenize( $t );
    $self->{Text} .= ' '.join(" ", @tokens);
  }

  $self->{Text} =~ s/\s{2,}/ /g;

  ## set the language if language param for document has been set, otherwise guess it
  if ( $language ) {
  	$self->{Lang} = $language;  	
  } else {
    $self->{Lang} = langof($self->{Text}) 
      if defined($self->{Text}) and length($self->{Text});
  }

##TODO: remove
    if ( $self->{Lang} !~ /^(en|nl)$/i ) {
    	$self->{keniknie} = 1;
    } else {
    	$self->{keniknie} = 0;
    }

  ## create the language model (i.e. the probability distribution)
  #
  $self->createLanguageModel();
  
  return 1;
}

sub timestampToEpoch{
  my $self = shift;
  my $t = shift;
  
  if(defined $t){
    $t=~s/[\+\.].*$//;
    my @dateFlds = split(/[\s:\-\.\_]/,$t);

    my $epoch = timegm($dateFlds[5],$dateFlds[4],$dateFlds[3],
                       $dateFlds[2],$dateFlds[1]-1,$dateFlds[0]);

    return $epoch;
  }
  return '';
}

sub createLanguageModel{
  my $self   = shift;
  my $total  = 0;

  $self->{Probs} = {};
  $self->{TF} = {};
  $self->{Tokens} = [];
  
  foreach my $t (split(" ",$self->{Text})){
    $self->{TF}{$t}++;
    $total++;
  }

  foreach my $t (keys %{$self->{TF}}){
    $self->{Probs}{$t} = $self->{TF}{$t}/$total;
    push @{$self->{Tokens}},$t;
  }

  $self->{Doclen} = $total;
}

sub getUniqueTokens{
  my $self = shift;
  my @unique = map {$_=>1} @{$self->{Tokens}};

  return @unique;
}

sub getUniqueTitleTokens{
  my $self = shift;
  my @tokens = ();
  if(defined $self->{Title} and $self->{Title} =~ /\S/){
    @tokens = $TOKENIZER->tokenize( $self->{Title} );
  }
  return @tokens;
}

sub getWordFreq{
  my $self = shift;
  my $word = shift;

  return defined($self->{TF}{$word}) ? $self->{TF}{$word} : 0;
}

sub getWordProbability{
  my $self = shift;
  my $word = shift;

  return defined($self->{Probs}{$word}) ? $self->{Probs}{$word} : $ZERO_PROBABILITY;
}

sub clean{
  my $string = shift;
  $string=~s/\#{2,}/ /g;
  $string=~s/\s{2,}/ /g;
  $string=~s/^\s+//;
  $string=~s/\s+$//;
  return $string;
}

sub specialTweetTreatment{
  my $textref = shift;
  $$textref =~ s/\@\w+//g;
  $$textref =~ s/\brt\b//ig;
  $$textref =~ s/\bhttp:[\\\/\.\w+]+\/(\w+)\b/$1/g;
  $$textref =~ s/(?:profile_url|status_id)//ig;
}


1;


__END__

=head1 NAME

Document - A module for storing document information

=head1 SYNOPSIS

use Document;

my $doc = new Document( I< $record, 'taranis' > );

=head1 DESCRIPTION

See the section on "Public Methods" below for details.

=head2 Public Methods


=over

=item I<PACKAGE>->new(I< record, format >):

Returns a newly created PACKAGE object. Accepts a hash reference containing the clustering parameters. Expects two arguments:

   record: an array reference containing the fields of the specified format
   format: the record format (taranis, ittt, raw)

the following input formats are currently supported:

   1. taranis: Digest Category Source Title URL Description Timestamp [ClusterID Score]
   2. ittt: ID Timestamp Title Description [ClusterID Score]
   3. raw:  ID Description [ClusterID Score]

ClusterID and Score are optional, but should be set to the empty list if undefined

=back

=head1 AUTHORS

Martijn Spitters (martijn.spitters@tno.nl)

Copyright (c) 2012-2013, TNO. All rights reserved.

=head1 VERSION

1.0


