package Taranis::Database;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;
use Taranis::Config;
use Taranis qw(:all);
use DBI;
use SQL::Abstract;
use Data::Validate qw(:math);
use Sys::Syslog qw( :DEFAULT setlogsock );
use ModPerl::Util;

use Data::Dumper;

sub new {
	my ($class) = @_;

	my $cfg      = Taranis::Config->new();
	my $user     = $cfg->{'dbuser'};
	my $name     = $cfg->{'dbname'};
	my $pass     = $cfg->{'dbpasswd'};
    my $dbhost   = $cfg->{'dbhost'};
    my $dbi      = $cfg->{'dbi'};
    my $dbdriver = $cfg->{'dbdriver'};
    my $dbport   = $cfg->{'dbport'};
    my $syslog	 = ( $cfg->{'syslog'} =~ /^on$/i ) ? 1 : 0; 
    
	my $dbh = DBI->connect( "$dbi:$dbdriver:dbname=$name;host=$dbhost;port=$dbport",
                            "$user", "$pass", { AutoCommit => 1 } );
                            
    $dbh->{PrintError} = 0;
    
    # RaiseError has to be set to 1 for the start- and endTransaction to work properly
    $dbh->{RaiseError} = 1;
    my $self = {
                 dbh               => $dbh,
                 sth               => undef,
                 record            => undef,
                 db_error_msg      => undef,
                 log_error_enabled => $syslog,
                 sql               => SQL::Abstract->new()
    };
    bless $self, $class;

    return $self;
}

sub execute {
    my ($self) = @_;
    my $query  = $_[1];
    my $dbh    = $self->{dbh};

    if ( index( uc($query), "SELECT" ) > -1 ) {
        my $sth = $dbh->prepare($query);
        $sth->execute();
        $self->{sth} = $sth;
    } else {
        $dbh->do($query);
    }
}

sub do {
  my ($self, $arg) = @_;
  my $dbh    = $self->{dbh};
  my $return_val;
  
  eval { $return_val = $dbh->do($arg) };

    if ( $@ ) {
        $self->logError($@);
    } else {
        $self->{db_error_msg} = undef;
    }
  
  return $return_val;
}

sub nextRecord {
    my ($self) = @_;
    my $sth    = $self->{sth};
    my $eor    = 0;
    my $record;
    
    if ( $record = $sth->fetchrow_hashref ) {
        $eor = 1;
    } else {
        $eor = 0;
    }

    $self->{record} = $record;
    return $eor;
}

sub getRecord {
    my ($self) = @_;
    my $record = $self->{record};

    return $record;
}

sub fetchRow {
    my ($self) = @_;
    my $sth    = $self->{sth};
	
		return $sth->fetchrow_hashref;	
}

sub close {
    my ($self) = @_;

    $self->{dbh}->disconnect();
}

sub startTransaction {
    my ($self) = @_;
    $self->{dbh}->begin_work;
}

sub endTransaction {
    my ($self) = @_;
		if ( $self->{db_error_msg} ) {
			$self->{dbh}->rollback;
		} else {
    	$self->{dbh}->commit;
		}
}

sub prepare {
    my ( $self, $stmnt ) = @_;

    return $self->{sth} = $self->{dbh}->prepare($stmnt);
}

sub executeWithBinds {
    my ( $self, @binds ) = @_;
    my $return_val;
    eval { $return_val = $self->{sth}->execute(@binds); };

    if ( $@ ) {
        $self->logError( $@ . "\n==> STMNT: " . $self->{sth}->{Statement} . "\n==> BINDS: @binds" );
	  } else {
        $self->{db_error_msg} = undef;
    }
    return $return_val;
}

# Logerror also causes $db_error_msg of the Database object to be set
# Changes to the setting of $db_error_msg has consequences for the 'endTransaction' routine in Database.pm
sub logError {
    my ( $self, $error, $prioritySetting ) = @_;
    
    my $logging_ok = 0;
    
###### DO NOT USE LOGDIT IN THIS SUBROUTINE!!!
    
    if ( $self->{log_error_enabled} ) {

    	my $cfg = Taranis::Config->new();
    	
    	my $priority = 	( 
    										exists( $cfg->{syslog_priority} ) 
    										&& $cfg->{syslog_priority} =~ /^(EMERG|ALERT|CRIT|ERR|WARNING|NOTICE|INFO|DEBUG)$/i 
    								 	) 
    									? $cfg->{syslog_priority} 
    									: undef;
			
			$priority = $prioritySetting if ( $prioritySetting =~ /^(EMERG|ALERT|CRIT|ERR|WARNING|NOTICE|INFO|DEBUG)$/i );
			
    	my $facility = ( 
    										exists( $cfg->{syslog_facility} ) 
    										&& $cfg->{syslog_facility} =~ /^local[0-7]$/i 
    									) 
    									? $cfg->{syslog_facility} 
    									: undef;
    									
    	my $pid = ( 
    							exists( $cfg->{syslog_pid}	)
    							&& $cfg->{syslog_pid} =~ /^on$/i
    						)
    						? 'pid'
    						: '';

    	if ( $priority && $facility ) {
    		
        setlogsock('unix');
        openlog( 'TARANIS', $pid, $facility );
        syslog( $priority, $error );
        closelog;
        
        $logging_ok = 1; 
    	}
    }
    
	$self->{db_error_msg} = ( $logging_ok ) 
													? "Database error, please check log for info."
													: "Database error. (Error cannot be logged because logging is turned off or is not configured correctly).";

#	$self->{db_error_msg} = $error;													
													
}

#### data struture $join_columns is { "JOIN table" => { column_id => column_id } }
# (INNER) JOIN: Return rows when there is at least one match in both tables
# LEFT (OUTER) JOIN: Return all rows from the left table, even if there are no matches in the right table
# RIGHT (OUTER) JOIN: Return all rows from the right table, even if there are no matches in the left table
# FULL JOIN: Return rows when there is a match in one of the tables
sub sqlJoin {
    my ( $self, $join_columns, $stmnt ) = @_;
    my ( $str, $table_key);
    my %columns;

    for $table_key ( keys %$join_columns ) {
        $str .= " " . $table_key . " ON ";
        my $columns = $join_columns->{$table_key};
        for my $column_key ( keys %$columns ) {
            $str .= $column_key . " = " . $columns->{$column_key};
        }
    }

    if ( $stmnt =~ m/(WHERE)/ ) {
        $stmnt =~ s/( WHERE \()/$str WHERE \(/;
    } elsif ( $stmnt =~ m/(ORDER BY)/ ) {
        $stmnt =~ s/( ORDER BY )/$str ORDER BY /;
    } else {
        $stmnt .= $str;
    }
    return $stmnt;
}

sub checkIfExists {
    my ( $self, $checkData, $table, $case ) = @_;
    my %where;

    if ( $case  ) {
        for my $key ( keys( %$checkData ) ) {
            if ( is_integer( $checkData->{$key} ) || ( ref( $checkData->{$key} ) eq "HASH" ) )
            {
                $where{$key} = $checkData->{$key};
            } elsif ( $checkData->{$key} ) {
                $where{$key}{-ilike} = $checkData->{$key};
            }
        }
    } else {
        %where = %$checkData;
    }
    my ( $stmnt, @bind ) = $self->{sql}->select( $table, "COUNT(*)", \%where );
		
		$stmnt .= " LIMIT 1";
  
    $self->prepare( $stmnt );
    $self->executeWithBinds( @bind );
    my $cnt = eval {$self->{sth}->fetch;};
    if ( $cnt->[0] && $cnt->[0] > 0 ) {
        return 1;
    } else {
        return 0;
    }
}

sub countRows {
    my ( $self, $checkData, $table, $case, $include_undef ) = @_;
    my %where;

    if ( $case  ) {
        for my $key ( keys( %$checkData ) ) {
            if ( 
		            	is_integer( $checkData->{$key} ) 
		            	|| ( ref( $checkData->{$key} ) =~ /^(HASH|SCALAR|ARRAY)$/ ) 
		            	|| ( $include_undef && !$checkData->{$key} ) 
	             )
            {
                $where{$key} = $checkData->{$key};
            } elsif ( $checkData->{$key} ) {
                $where{$key}{-ilike} = $checkData->{$key};
            }
        }
    } else {
        %where = %$checkData;
    }

	   my ( $stmnt, @bind ) = $self->{sql}->select( $table, "COUNT(*)", \%where );

    $self->prepare( $stmnt );
    $self->executeWithBinds( @bind );
    my $cnt = eval {$self->{sth}->fetch;};
    
    return $cnt->[0]
}

sub getLastInsertedId {
	my ( $self, $table ) = @_;
	my $id;
	eval {
		$id = $self->{dbh}->last_insert_id( undef, undef, $table, undef,	undef );
	};
	
	if ( $@ ) { 
		$self->logError( $@ );
		return 0; 
	} else {
		return $id;
	}
}

sub createWhereFromArgs {
	my ( $self, %args ) = @_;
	my %where;
	
	for my $key ( keys(%args) ) {
		if ( ref( $args{$key} ) eq "ARRAY" ) {
			$where{$key} = \@{ $args{$key} };
		} elsif ( $args{$key} ne "" && $args{$key} =~ /^\d+$/ ) {
      $where{$key} = $args{$key};
    } elsif ( $args{$key} ne "" ) {
      $where{$key}{-ilike} = "%" . trim( $args{$key} ) . "%";
    }
  }	
	
	return %where;
}

sub setResultCount {
	my ( $self, $stmnt, @bind ) = @_;
	
	$stmnt =~ s/SELECT .*? FROM(.*$)/SELECT COUNT\(\*\) AS cnt FROM$1/is;
	$stmnt =~ s/ORDER.*$//i;

	$self->prepare( $stmnt );
	$self->executeWithBinds( @bind );

  my $cnt = $self->fetchRow();

  return $cnt->{cnt};
}

sub setObject {
	my ( $self, $table, $where, $update ) = @_;
	undef $self->{db_error_msg};

	if ( !scalar( %$where ) ) {
		$self->{db_error_msg} = "Cannot perform update, because whereclause is missing.";
		return 0;
	}

	my ( $stmnt, @bind ) = $self->{sql}->update( $table, $update, $where );
	$self->prepare( $stmnt );

	$self->executeWithBinds( @bind );

	if ( defined( $self->{db_error_msg} ) ) {
		return 0;
	} else {
		return 1;
	}
}


=head1 NAME 

Taranis::Database - module for interaction with database

=head1 SYNOPSIS

  use Taranis::Database;

  my $obj = Taranis::Database->new();

  $obj->execute( $sql_query );

  $obj->do( $sql_non_select_query )

  $obj->nextRecord();

  $obj->getRecord();

  $obj->fetchRow();

  $obj->close();

  $obj->startTransaction();

  $obj->endTransaction();

  $obj->prepare( $sql_query );

  $obj->executeWithBinds( @bindings );

  $obj->logError( $error );

  $obj->sqlJoin( \%join_columns, $sql_query );

  $obj->checkIfExists( \%checkData, $table_name, $case_sensitivity );

  $obj->countRows( \%checkData, $table_name, $case_sensitivity );

  $obj->getLastInsertedId( $table_name );

  $obj->createWhereFromArgs( %args );

  $obj->setResultCount( $sql_query, @bindings );

  $obj->setObject( $table, $where, $update );

=head1 DESCRIPTION

Module for setting up a connection to database. All query executions go through this module as well as database error logging (if configured).
Module also has some useful helper method like checkIfexists() and methods to set up a transaction. Most method port to comparable DBI methods.

=head1 METHODS

=head2 new( )

Constructor of the C<Taranis::Database> class.

    my $obj = Taranis::Database->new();

Creates a new database handler which can accessed by:

    $obj->{dbh};

Creates a new C<SQL::Abstract> object which can be accessed by:

    $obj->{sql};

Clears error message for the new object. Can be accessed by:

    $obj->{db_error_msg};

Sets error logging on/off:

    $obj->{log_error_enabled};

The constructor creates a connection with the database using configuration settings from main configuration file taranis.conf.xml.
The connection made using C<DBI>. After creating the C<DBI> object the property C<PrintError> is turned off and the property C<RaiseError> is turned on.

Returns the blessed object.

=head2 execute( $sql_query )

You should use executeWithBinds() instead!!

The method execute() does not handle bindings in SQL.

=head2 do( $sql_non_select_query )

You should use executeWithBinds() instead!!

The method do() takes an SQL non-select query, but does not handle bindings in SQL. 

Returns the return value of C<< DBI->do() >>.

=head2 nextRecord( ) & getRecord( )

Method to retrieve the list that is generated by a method like loadCollection() .

This way of retrieval can be used to get data from the database one-by-one. Both methods don't take arguments.

Example:

    $obj->loadCollection( $args );

    while( $obj->nextRecord() ) {
        push @list, $obj->getRecord();
    }

=head2 fetchRow( )

Port to C<< DBI->fetchrow_hashref() >>. From DBI POD:

I<Fetches the next row of data and returns it as a reference to a hash containing field name and field value pairs. 
Null fields are returned as undef values in the hash.>

=head2 close( )

Method calls C<< DBI->disconnect() >>, which will result in a disconnect from the database.

=head2 startTransaction( ) & endTransaction( ) 

Calls C<< DBI->begin_work() >> and C<< DBI->commit() >> (or C<< DBI->rollback() >>). 
These methods should be used when several non-SELECT statements are performed sequentially.
Method startTransaction() should always be placed before the first non-SELECT SQL statements whereas endTransaction() should be placed after the last non-SELECT statement.

    my $obj = Taranis::SomeModule->new();

    $obj->{dbh}->startTransaction();

    $obj->doSQLInsert();

    $obj->doSQLUpdate();

    $obj->doSQLDelete();

    $obj->{dbh}->endTransaction();

When one of the non-SELECT statements causes an error C<< DBI->rollback() >> will be called, and thereby cancelling all preceding and future non-SELECT statements within the transaction. 

This method is extremely useful when doing updates on different tables.

Note: within the transaction method only you should only use database actions that originate from the same object. 
For instance the following will not work:

    my $obj = Taranis::SomeModule->new();

    my $other_obj = Taranis::SomeOtherModule->new();

    $obj->{dbh}->startTransaction();
    
    $obj->doSQLInsert();

    $other_obj->doSQLUpdate(); # does not use the same database object

    $obj->doSQLDelete();

    $obj->{dbh}->endTransaction();

=head2 prepare( $sql_query )

Method to create a prepared SQL statement.
Takes the SQL query as mandatory argument.

    $obj->prepare( 'SELECT * FROM books WHERE auhtor = ? AND title = ?' );

The statements may have placeholders (is recommended!) which can be fed to executeWithBinds() .

The statements can be created using C<SQL::Abstract> which almost every module has ( << $obj->{sql} >> ).
Creating a statement this way also results in splitsing the bindings and statement:

    my ( $statement, @binds ) = $obj->{sql}->select( 'mytable', 'myselection', \%where );
    
    $obj->prepare( $statement );
    
    $obj->executeWithBinds( @binds ); 

Methods getRecord(), nextRecord() and fetchRow() can be used to retrieve the actual data in case of a SELECT statement. 

=head2 executeWithBinds( @binds )

Method does C<< DBI->execute( @binds ) >> in C<eval>. For an example of usage see prepare() .

If C<< DBI->execute() >> fails an error will be logged to logError() with a copy of the statement as was passed to prepare() as well as the bindings.

If all goes well C<< $obj->{db_error_msg} >> is given value C<undefined>.

In all cases the return value of C<< DBI->execute() >> is returned.

=head2 logError( $error )

Method for logging errors to syslog, but only if C<< $obj->{log_error_enabled} >> has been set.

Syslog settings are pulled from the main configuration file taranis.conf.xml.

If C<< $obj->{log_error_enabled} >> is set the method will set C<< $obj->{db_error_msg} >> to the text I<Database error, please check log for info.>. 
If C<< $obj->{log_error_enabled} >> is not set the text C<< $obj->{db_error_msg} >> for will be I<Database error. (Error cannot be logged because logging is turned off or is not configured correctly).>.

Method does not return any value.

=head2 sqlJoin( \%join_columns, $sql_query )

Method to edit an SQL query with a JOIN part.
It takes two mandatory arguments:

=over

=item 1

HASH reference, that has several parts:

=over

=item *

JOIN part, 'JOIN mytable AS alias'

=item *

ON part, is an HASH with the two joining columns: { 'alias1.id_column' => 'alias2.id_column' }

=back

=item 2

the SQL query to edit the JOIN in

=back

Example:

    $obj->sqlJoin( 
                   {
                     'JOIN item' => { 'item.digest' => 'email_item.digest' },
                     'JOIN category' => { 'item.category' => 'category.id' } 
                   },
                   $sql_query
                 );

Also when creating a JOIN there are several options:

=over

=item *

(INNER) JOIN: Return rows when there is at least one match in both tables

=item *

LEFT (OUTER) JOIN: Return all rows from the left table, even if there are no matches in the right table

=item *

RIGHT (OUTER) JOIN: Return all rows from the right table, even if there are no matches in the left table

=item *

FULL JOIN: Return rows when there is a match in one of the tables

=back

Returns the SQL query with the JOIN inserted.

=head2 checkIfExists( \%checkData, $table_name, $case_sensitivity )

Method for checking if certain data exists in database. 
Takes 3 arguments, first two are mandatory;

=over

=item 1

an HASH reference where the keys are table column names and values are the data to check for.

=item 2

table name

=item 3

case sensitivity, set to true for case insensitive search

=back

Example:

    $obj->checkIfExists( { name => 'news' }, 'category', 'IGNORE_CASE' );

Internally does a COUNT(*) with a LIMIT 1.

Returns TRUE if COUNT(*) is 1, FALSE if it's 0.

=head2 countRows( \%checkData, $table_name, $case_sensitivity )

Does exactly the same as checkIfExists() , but LIMIT 1 is left out and it returns the result of COUNT(*).

=head2 getLastInsertedId( $table_name )

Method to retrieve the id (primary key) of the record that was just insert into the specified table.
Comes in handy when the input of one database action depends on a prior insert. Can also be used in transactions.

    my $obj = Taranis::SomeModule->new();

    $obj->{dbh}->startTransaction();

    $obj->addBook( table => 'book', title => 'holiday fever' );

    my $holiday_fever_id = $obj->getLastInsertedId( 'book' );

    $obj->updateCatalog( book_id => $holiday_fever_id );

    $obj->{dbh}->endTransaction();

Uses C<< DBI->last_insert_id() >> for retrieval of id.

Returns the id if successful. Returns FALSE if unsuccessful, and logs the error using logError() .

=head2 createWhereFromArgs( %args )

Method to create a where HASH suitable for using with C<SQL::Abstract>.
It will turn strings into ILIKE comparison with wildcards (%) at start and end of string. Integers will be set to an = comparison.
ARRAYs will be turned into ARRAY reference ( = \@ ) comparison for C<SQL::Abstract>.

    $obj->createWhereFromArgs( %args );

Returns an HASH.

=head2 setResultCount( $sql_query, @bindings )

This method will change the SELECT part of the SQL query into a COUNT(*) and removes the ORDER BY part and everything after it.
It will execute the query.

    $obj->setResultCount( $sql_query, @bindings );

It will return the result of COUNT(*).

=head2 setObject( $table, $where, $update )

Method to execute an SQL UPDATE. Takes three mandatory arguments:

=over

=item 1

tablename

=item 2

an HASH reference representing the WHERE clause

=item 3

an HASH reference representing the update settings

=back

    $obj->setObject(
                     'software_hardware',
                     { cpe_id => $item->{cpe_id} },																					
                     {
	                     producer => $item->{producer},
                       name => $item->{name},
                       version => $item->{version},
                       type => $item->{type},
                       deleted => $setItemToDeleted
                     }
                   );

Method can be used when using a transaction and the setObject() method is of another module than the transaction is made with.

EXAMPLE:

    my $obj = Taranis::SomeModule->new();

    my $other_obj = Taranis::SomeOtherModule->new();

    $obj->{dbh}->startTransaction();
    
    $obj->odSQLInsert();

		# as $other_obj->doSQLUpdate(); is not permitted you should do

    $obj->{dbh}->setObject()

    $obj->{dbh}->endTransaction();

Returns TRUE if successful.Returns FALSE if a database error occurs.

=head1 DIAGNOSTICS

The following messages can be expected from this module:

=over

=item *

I<Cannot perform update, because whereclause is missing.>

Caused by setObject() when the second argument is undefined or is an empty HASH.

=item *

I<Database error, please check log for info> or I<Database error. (Error cannot be logged because logging is turned off or is not configured correctly)>

Is caused by a database syntax or input error. 

=back

=head1 DEPENDENCIES

CPAN modules required are B<SQL::Abstract>, B<DBI>, B<Data::Validate>, B<Sys::Syslog> and B<ModPerl::Util>.

Taranis modules required are B<Taranis> and B<Taranis::Config>.

=head1 AUTHOR

Sebastiaan van Achterbergh <info@govcert.nl>

November 2010

=cut


1;
