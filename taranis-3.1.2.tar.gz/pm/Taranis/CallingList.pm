package Taranis::CallingList;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Database;
use Taranis qw(:all);
use SQL::Abstract;
use strict;

sub new {
	shift @_;
	
	my $self = {
		errmsg 	=> undef,
		dbh 		=> Taranis::Database->new(),
		sql 		=> SQL::Abstract->new()
	};
	bless $self;
	return $self;	
}

sub addCallingList {
	my ( $self, %inserts ) = @_;
	undef $self->{errmsg};
	
	my ( $stmnt, @bind ) = $self->{sql}->insert( 'calling_list', \%inserts );
	$self->{dbh}->prepare( $stmnt );
	if ( defined( $self->{dbh}->executeWithBinds( @bind ) ) > 0 ) {
		return 1;
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}
}

sub updateCallingList {
	my ( $self, %updates ) = @_;
	undef $self->{errmsg};
	
	my ( $id, $publicationId, $user );
	my %where;
	if ( $id = delete( $updates{id} ) ) {
		%where = ( id => $id );	
	} elsif ( ( $publicationId = delete( $updates{publicationId} ) ) && ( $user = delete( $updates{user} ) ) ) {
		%where = ( locked_by => $user, publication_id => $publicationId );
	} else {
		$self->{errmsg} = "Error: argument missing for update of calling list.";
		return 0;
	}
	
	my ( $stmnt, @bind ) = $self->{sql}->update( 'calling_list', \%updates, \%where );

	$self->{dbh}->prepare( $stmnt );
	if ( defined( $self->{dbh}->executeWithBinds( @bind ) ) > 0 ) {
		return 1;
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}
}

sub getCallingList {
	my ( $self, %where ) = @_;
	undef $self->{errmsg};

	my $time_of_day = ( exists( $where{time_of_day} ) && $where{time_of_day} ) ? delete $where{time_of_day} : undef; 
	
	delete $where{time_of_day} if ( exists( $where{time_of_day} ) );

	$where{'cg.call_hh'} = 1;
	
	tie my %join, 'Tie::IxHash';
	my ( $stmnt, @bind ) = $self->{sql}->select( 'calling_list cl', 'cl.*, cg.name AS groupname, cg.notes AS group_notes, cg.id AS constituent_group_id, u.fullname', \%where, 'groupname' );
	%join = (
						'JOIN constituent_group cg' => { 'cg.id' 			=> 'cl.group_id' },
						'LEFT JOIN users u'				  => { 'u.username' => 'cl.locked_by'}						
					);
	
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	$self->{errmsg} = $self->{dbh}->{db_error_msg};
	
	my ( @groups, @groupsToCall );
	while ( $self->nextObject() ) {
		push @groups, $self->getObject();
	}
	
	my $dsc_search = "%DSC%";
	my $hour = substr( nowstring(1), 0, 2);

	%join = (
						'JOIN membership m' 			 => { 'm.constituent_id' => 'ci.id' 	},
						'JOIN constituent_role cr' => { 'cr.id' 					 => 'ci.role' }
					);

	my $individualSelect = 'ci.firstname, ci.lastname, ci.tel_mobile, ci.tel_regular, cr.role_name';
	foreach my $group ( @groups ) {
		
		my %groupWhere;
		if ( $time_of_day =~ /^day$/ || ( !$time_of_day && $hour >= 9 && $hour < 18 ) ) {
			%groupWhere = ( 'm.group_id' => $group->{constituent_group_id}, 'ci.status' => "0", 'ci.call_hh' => 1, "cr.role_name" => { -ilike => $dsc_search } );
		} else {
			%groupWhere = ( 'm.group_id' => $group->{constituent_group_id}, 'ci.status' => "0", 'ci.call_hh' => 1, "ci.call247" => 1 );
		}
		
		my ( $groupStmnt, @groupBind ) = $self->{sql}->select( 'constituent_individual ci', $individualSelect, \%groupWhere, 'ci.lastname, ci.firstname' );
		
		$groupStmnt = $self->{dbh}->sqlJoin( \%join, $groupStmnt );

		$self->{dbh}->prepare( $groupStmnt );
		$self->{dbh}->executeWithBinds( @groupBind );

		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		
		while ( $self->nextObject() ) {
			my $individual = $self->getObject();
			push @{ $group->{individuals} }, $individual;
		}
		
		if ( exists( $group->{individuals} ) ) {
			push @groupsToCall, $group;
		}		
	}
	
	return \@groupsToCall;
}

sub getPublicationLists {
	my ( $self, %listSettings ) = @_;
	undef $self->{errmsg};
	
	my $publicationId = delete( $listSettings{publicationId} );
	
	my %where = ( 'c.publication_id' => $publicationId );
	my ( $stmnt, @bind ) = $self->{sql}->select( 'calling_list c', 'c.* AS list_id, u.fullname, c.locked_by, c.is_called', \%where );
	
	my %join = ( 'LEFT JOIN users u' => { 'u.username' => 'c.locked_by' } );
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	$self->{errmsg} = $self->{dbh}->{db_error_msg};
	
	my @lists;
	
	while ( $self->nextObject() ) {
		push @lists, $self->getObject();
	}
	
	return \@lists;
}

sub nextObject {
	my ( $self ) = @_;
	return $self->{dbh}->nextRecord;
}

sub getObject {
	my ( $self ) = @_;
	return $self->{dbh}->getRecord;		
}

1;

=head1 NAME

Taranis::CallingList - callinglists in case of a High/High advisory. 

=head1 SYNOPSIS

  use Taranis::CallingList;

  my $obj = Taranis::CallingList->new();

  $obj->addCallingList( \%inserts );

  $obj->updateCallingList( \%updates );

  $obj->getCallingList( publication_id => $publication_id, time_of_day => $time_of_day );

  $obj->getPublicationLists( publicationId => $publicationId );

  $obj->nextObject();

  $obj->getObject();

=head1 DESCRIPTION

In case an advisory has both damage and probability set to high a callinglist is generated when the advisory has been published.
A callingslist is a list of constituents which need to be informed of the High/High advisory.

The callinglist contains phonenumbers of the individuals which meet certain criteria. 
For instance if the person has a role with 'DSC' in it or if he has specified that he wishes to be called 24/7 and if he wishes to be called in case of an High/High advisory.

After publishing the advisory the callinglist can be administrated per constituent group.

=head1 METHODS

=head2 new( )

Constructor of the C<Taranis::CallingList> class.

    my $obj = Taranis::CallingList->new();

Creates a new database handler which can accessed by:

    $obj->{dbh};

Creates a new C<SQL::Abstract> object which can be accessed by:

    $obj->{sql};

Clears error message for the new object. Can be accessed by:

    $obj->{errmsg};

Returns the blessed object.

=head2 addCallingList( publication_id => $publication_id, group_id => $groupId )

Method for adding a calling list. Can take all columns of table C<calling_list> as arguments. It's recomended to at least specify C<publication_id> and C<group_id>.

  $obj->addCallingList( publication_id => 67, group_id => 89 );

Returns TRUE if all goes well, FALSE if not, and will set C<< $obj->{errmsg} >> to C<< Taranis::Database->{db_error_msg} >> in this case.

=head2 updateCallingList( id => $callinglistId, comments => $comments, is_called => $is_called, locked_by => undef )

Method for editing a callinglist entry. This method takes two forms which both have mandatory arguments.

First option is to update a callinglist using callinglist C<id> as mandatory argument. In this case C<id> will be used in the WHERE clause:

    $obj->updateCallingList( id => 76, comments => $comments, is_called => $is_called, locked_by => undef );

Second option is to update a callinglist using the column C<user> and C<publicationId> as mandatory arguments. 
In this case C<user> and C<publication_id> will be used in the WHERE clause: 

    $obj->updateCallingList( user => 'userx', publication_id => 76, locked_by => undef );

If argument C<id> has been given, all other argument will be used as update arguments.

Returns TRUE if update is successful, FALSE in case of database error, which will also set C<< $obj->{errmsg} >> to C<< Taranis::Database->{db_error_msg} >>.

=head2 getCallingList( publication_id => $publication_id, time_of_day => $time_of_day )

To retrieve a callinglist you should use the getCallingList() method. It will retrieve an ARRAY of HASHES consisting of constituent groups. Each group has the following keys:

=over

=item *

individuals, is also an ARRAY of HASES which has the C<firstname>, C<lastname>, C<role_name>, C<tel_regular> and C<tel_mobile> per individual. 

=item *

comments, concerning the call

=item *

group_id and constituent_group_id, internal id of constituent group

=item *

is_called, flag to be set when constituent has been informed

=item *

groupname, name of constituent group

=item *

locked_by, can be set to user. Only existing user id's or NULL/undef are allowed.

=item *

fullname, the descriptive name of the user who has been set at C<locked_by>

=item *

publication_id, internal id of publication

=item *

id, internal id of callinglist

=item *

group_notes, notes which are set for the constituent.

=back

This method can take any column of tables C<calling_list> and C<constituent_group> as argument in a C<< column => value >> format.
Note that columns of table C<calling_list> need to be preceded by 'cl.' and columns of table C<constituent_group> need to be preceded by 'cg.'.

Another optional argument is C<time_of_day> which only takes values C<night> an C<day>. 
When C<day> is set, the list of the individuals will be made by searching for individuals with a role that has the lettes 'DSC' in it. 
When C<night> is set, the list will be made by searching for individuals that have C<call247> set to true.

    $obj->getCallingList( publication_id => 78, time_of_day => 'day' );

It returns an ARRAY reference if retrieval is ok. It will return FALSE if an database error occurs, which will also set C<< $obj->{errmsg} >> to C<< Taranis::Database->{db_error_msg} >>. 

=head2 getPublicationLists( publicationId => $publicationId )

Method for retrieving a callinglist as getCallingList() does, but without the argument C<time_of_day> and with less details per group.
Only C<is_called>, C<group_id>, C<locked_by>, C<fullname>, C<publication_id>, C<id> and C<comments> are retrieved per group.

Only takes publicationId as C<< key => value >> as argument.

    $obj->getPublicationLists( publicationId => 78 );

Returns an ARRAY of HASHES or FALSE in case of database error, which also sets C<< $obj->{errmsg} >> to C<< Taranis::Databas->{db_error_msg} >>.

=head2 nextObject( ) & getObject( )

Method to retrieve the list that is generated by a method  like getPublicationLists().

This way of retrieval can be used to get data from the database one-by-one. Both methods don't take arguments.

Example:

    $obj->loadCollection( $args );

    while( $obj->nextObject ) {
        push @list, $obj->getObject;
    }

=head1 DIAGNOSTICS

The following messages can be expected from this module:

=over

=item *

I<Error: argument missing for update of calling list.>

Is caused by updateCallingList() if one of the mandatory arguments ( C<publicationId> and C<user>, or C<id> ) is undefined.

=item *

I<Database error, please check log for info> or I<Database error. (Error cannot be logged because logging is turned off or is not configured correctly)>

Is caused by a database syntax or input error. 
If syslog has been setup correctly the exact SQL statement and bindings should be visible in the configured syslog.

=back

=head1 DEPENDENCIES

CPAN modules required are B<SQL::Abstract>.

Taranis modules required are B<Taranis> and B<Taranis::Database>.

=head1 AUTHOR

Sebastiaan van Achterbergh <info@govcert.nl>

November 2010

=cut
