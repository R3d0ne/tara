package Taranis::SoftwareHardware;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:util);
use Taranis::Database;
use Taranis::Config;
use SQL::Abstract;
use XML::XPath;
use XML::XPath::XMLParser;
use strict;

sub new {
	shift @_;
	
	my $self = {
		cfg => Taranis::Config->new(),
		dbh => Taranis::Database->new(),
		sql => SQL::Abstract->new(),
		errmsg => '',
	};
	bless $self;
	return $self;
}

sub addObject {
	my ( $self, %inserts ) = @_;
	undef $self->{errmsg};

	$inserts{deleted} 	= 0 if ( !exists( $inserts{deleted} ) );
	$inserts{monitored} = 0 if ( !exists( $inserts{monitored} ) );

	my ( $stmnt, @bind ) = $self->{sql}->insert( 'software_hardware', \%inserts );
	$self->{dbh}->prepare( $stmnt );

	if ( defined( $self->{dbh}->executeWithBinds( @bind ) ) > 0 ) {
		return 1;
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}
}

sub deleteObject {
	my ( $self, %delete ) = @_;
	undef $self->{errmsg};
	
	my $table = ( $delete{table} ) ? delete( $delete{table} ) : 'software_hardware';
	
	my ( $stmnt, @bind ) = $self->{sql}->delete( $table, \%delete );
	
	$self->{dbh}->prepare( $stmnt );
	
	if ( $self->{dbh}->executeWithBinds( @bind) > 0 ) {
		return 1;
	} elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	} else {
		$self->{errmsg} = "Delete failed, corresponding id not found in database.";
		return 0;
	}			
}

sub getDistinctList {

    # returns an array of (distinct) values from hardware_software table;

    my ( $self, @args ) = @_;
    undef $self->{errmsg};

    my %where;
    my $what;
    if ( scalar(@args) <= 1 ) {
        $what = $args[0] || 'producer';    # defaults to producer

    } else {
        $what = 'name';
        %where = ( $args[0] => $args[1] );
    }

    my ( $stmnt, @bind ) =
      $self->{dbh}->{sql}->select( 'software_hardware', "distinct $what", \%where );

    $self->{dbh}->prepare($stmnt);
    $self->{dbh}->executeWithBinds(@bind);

    if ( $self->{dbh}->{sth}->errstr ) { print $self->{dbh}->{sth}->errstr . "\n"; }
    $self->{errmsg} = $self->{dbh}->{sth}->errstr;

    my @return;
    while ( my $array_ref = $self->{dbh}->{sth}->fetchrow_arrayref() ) {
        push @return, @$array_ref;
    }
    return @return;

}

sub getList {
	my ( $self, @args ) = @_;
	undef $self->{errmsg};
	my %where = @args;

	my $offset = delete $where{offset};
	my $limit  = delete $where{limit};

	if ( defined( $where{id} ) ) {
		# get_single_record to return only 1 record.
		$self->{get_single_record} = 1;
		$where{'sh.id'} = delete $where{id};
	}

	if ( $where{producer} eq '' ) {
		delete $where{producer};
	}

	if ( $where{type} eq '' ) {
		delete $where{type};
	}

	# set your $obj->{deleted} attribute to 't' (true) to get a list of deleted items
	$where{'deleted'} = $self->{deleted} ? $self->{deleted} : 'f';

	if ( defined( $where{name} ) && $where{name} ) {
		my $search = delete $where{name};
		$where{"producer || ' ' || name"} = ( { -ilike => [ '%' . $search . '%' ] } );
	} else {
		delete $where{name};
	}

	my $select	 = "sh.producer, sh.name, sh.version, sht.description, sh.id, sh.type, count(shu.soft_hard_id) AS in_use, sh.cpe_id, sh.monitored ";
	my $order_by = " ORDER BY sh.producer, sh.name, sh.version";
	my $group_by = " GROUP BY sh.producer, sh.name, sh.version, sht.description, sh.id, sh.type, sh.cpe_id, sh.monitored";

	my ( $stmnt, @bind ) = $self->{sql}->select( "software_hardware AS sh", $select, \%where );

	my $join = { 
								"JOIN soft_hard_type sht " => { "sh.type" => "sht.base" },
								"LEFT JOIN soft_hard_usage shu" => { "shu.soft_hard_id" => "sh.id" }
						 };
	$stmnt = $self->{dbh}->sqlJoin( $join, $stmnt );

	$stmnt .= $group_by . $order_by; 
		
	$stmnt .= defined( $limit ) ? ' LIMIT ' . $limit : '';
	$stmnt .= ( defined( $offset ) && defined( $limit ) ) ? ' OFFSET ' . $offset  : '';

	$self->{dbh}->prepare( $stmnt );

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = "DB ERROR " . $self->{dbh}->{db_error_msg};
		return 0;
	} else {
		$self->{deleted} = 'f';
		if ( $self->{get_single_record} ) {

			# want just a single_record
			# so process locally and return a hash;
			$self->{dbh}->executeWithBinds( @bind );
			if ( $self->nextObject() ) {
				return $self->getObject();
			}
		}
		return $self->{dbh}->executeWithBinds( @bind );
	}
}

sub getListCount {

    # returns database count number from query
    # usefull to show number of matches on your output page
    # and to generate a list of buttons (1..x)

    my ( $self, @args ) = @_;
    undef $self->{errmsg};
    my %where = @args;

    my $search;

    if ( $where{producer} eq '' ) {
        delete $where{producer};
    } 

    if ( $where{type} eq '' ) {
        my $search = delete $where{type};
    }

    # set your $obj->{deleted} attribute to 't' (true) to get a list of deleted items
    $where{'deleted'} = $self->{deleted} ? $self->{deleted} : 'f';

    # search for something within the name column (like clause)
    if ( defined( $where{name} ) ) {
        my $search = delete $where{name};
        $where{"producer || ' ' || name"} = ( { -ilike => [ '%' . $search . '%' ] } );
    } else {
    	delete $where{name};
    } 

    my $select = "count(*)";

    my ( $stmnt, @bind ) = $self->{dbh}->{sql}->select( 'software_hardware', $select, \%where );
    $self->{dbh}->prepare($stmnt);

    if ( defined( $self->{dbh}->{sth}->errstr ) ) {
        $self->{errmsg} = "DB ERROR " . $self->{dbh}->{sth}->errstr;
        return 0;
    } else {
        $self->{deleted} = 'f';
        $self->{dbh}->executeWithBinds(@bind);
        if ( $self->nextObject() ) {
            my $res = $self->getObject();
            return $res->{count};
        }
    }

}

sub nextObject {
    my ($self) = @_;
    return $self->{dbh}->nextRecord;
}

sub getObject {
    my ($self) = @_;
    return $self->{dbh}->getRecord;
}

sub setObject {
	my ( $self, %update ) = @_;
	undef $self->{errmsg};

	my %where;

	if ( $update{id} ) {
		$where{id} = delete $update{id};
	} elsif ( $update{cpe_id} ) {
		$where{cpe_id} = delete $update{cpe_id};
	} else {
		$self->{errmsg} = "No unique id given to identify record.";
		return 0;
	}

	my ( $stmnt, @bind ) = $self->{sql}->update( 'software_hardware', \%update, \%where );
	$self->{dbh}->prepare( $stmnt );

	$self->{dbh}->executeWithBinds( @bind );

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	} else {
		return 1;
	}
}

sub getBaseTypes {
	my ( $self, @args ) = @_;
	undef $self->{errmsg};

	my $sql = 'SELECT description AS base_description, base AS  base_char FROM soft_hard_type';

	$self->{dbh}->prepare( $sql );
	$self->{dbh}->executeWithBinds();

	$self->{errmsg} = $self->{dbh}->{db_error_msg} if ( $self->{dbh}->{db_error_msg} );

	my $ret_hash;

	while ( $self->nextObject() ) {
		my $result = $self->getObject();
		$ret_hash->{ $result->{base_char} } = $result->{base_description};
	}
	
	return $ret_hash;
}

sub getShType {
    my ( $self, @args ) = @_;
    undef $self->{errmsg};

    my %argumenten = @args;
    my %where;    # = {};
    my $return_hash;
    if ( defined( $argumenten{base} ) ) {
        $where{base} = delete $argumenten{base};
        $return_hash = 1;

    }

    # let's do the query
    my $order = 'substr(sub_type,0,1) desc, description';
    my ( $stmnt, @bind ) = $self->{dbh}->{sql}->select( 'soft_hard_type', "*", \%where, $order );

    my $sth = $self->{dbh}->prepare($stmnt);

    $self->{dbh}->executeWithBinds(@bind);

    if ( defined( $self->{dbh}->{sth}->errstr ) ) {
        $self->{errmsg} = 'DB error' . $self->{dbh}->{db_error_msg};
        return 0;
    } else {
        if ($return_hash) {
            while ( $self->nextObject() ) {
                return $self->getObject();
            }
        }
        return 1;
    }

}

sub getSuperTypeDescription {
	my ( $self, $base ) = @_;
	undef $self->{errmsg};

	my $where = { 'sub.base' => $base };
	my ( $stmnt, @bind ) = $self->{sql}->select( 'soft_hard_type sub', 'super.description', $where );
	
	my %join = ( 'JOIN soft_hard_type super' => { 'super.base' => 'sub.sub_type' } );
	
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
		
	$self->{errmsg} = $self->{dbh}->{db_error_msg};

	return $self->{dbh}->fetchRow();
}

sub setShType {

    # update soft_hard_type
    my ( $self, @args ) = @_;
    undef $self->{errmsg};

    my %argumenten = @args;
    my %where;
    $where{base} = delete $argumenten{base};

    my %check = (

        description => $argumenten{description},
        sub_type    => $argumenten{sub_type},
    );

    if ( !$argumenten{description} ) {
        $self->{errmsg} = 'description argument mandatory';
        return 0;
    }

    if ( $self->{dbh}->checkIfExists( \%check, 'soft_hard_type' ) ) {
        $self->{errmsg} = 'entry exists';
        return 0;
    }

    # let's do the update

    my ( $stmnt, @bind ) = $self->{dbh}->{sql}->update( 'soft_hard_type', \%argumenten, \%where );
    my $sth = $self->{dbh}->prepare($stmnt);

    $self->{dbh}->executeWithBinds(@bind);

    if ( defined( $self->{dbh}->{sth}->errstr ) ) {
        $self->{errmsg} = 'DB update error' . $self->{dbh}->{sth}->errstr;
        return 0;
    } else {
        return 1;
    }
}

sub addShType {

    # add soft_hard_type
    my ( $self, @args ) = @_;
    undef $self->{errmsg};
    $self->{dbh}->{PrintError} = 1;
    $self->{dbh}->{RaiseError} = 1;

    my %argumenten = @args;
    my %where;    # = {};
    $where{base} = delete $argumenten{base};

    my %check = (

        description => $argumenten{description},
        sub_type    => $argumenten{sub_type}
    );

    if ( !$argumenten{description} || !$argumenten{sub_type} ) {
        $self->{errmsg} = 'description and sub_type arguments mandatory';
        return 0;
    }

    if ( $self->{dbh}->checkIfExists( \%check, 'soft_hard_type' ) ) {
        $self->{errmsg} = 'entry exists';
        return 0;
    }

    my $sql =
'SELECT substr(max(base),1,1) as firstchar, substr(max(base),2,1) as lastchar FROM soft_hard_type where character_length(base) >1';
    $self->{dbh}->prepare($sql);
    if ( $self->{dbh}->{sth}->errstr ) { $self->{errmsg} = $self->{dbh}->{sth}->errstr; }
    $self->{dbh}->executeWithBinds();

    my $newchar = 0;

    if ( $self->{dbh}->nextRecord() ) {
        my $result = $self->{dbh}->getRecord();
        if ( defined( $result->{firstchar} ) ) {
            $newchar = &_getNewChar( $result->{firstchar}, $result->{lastchar} );
            if ( $newchar =~ /zz/ ) {
                $self->{errmsg} =
                  "you've reached the maxium possible type descriptions (aa-zz)";
                return 0;
            }
        } else {
            $newchar = 'aa';
        }
    }

    my %add = (
                base        => $newchar,
                description => $argumenten{description},
                sub_type    => $argumenten{sub_type}
    );

    my ( $stmnt, @bind ) = $self->{dbh}->{sql}->insert( 'soft_hard_type', \%add );
    my $sth = $self->{dbh}->prepare($stmnt);
    if ( $self->{dbh}->executeWithBinds(@bind) ) {
        my $err = $self->{dbh}->{sth}->errstr;
        return $newchar;
    } else {
        $self->{errmsg} = $self->{dbh}->{sth}->errstr;
        return 0;
    }

}

sub delShType {

    # DEL soft_hard_type
    my ( $self, @args ) = @_;
    undef $self->{errmsg};

    $self->{log_error_enabled} = 1;

    my %argumenten = @args;
    if ( !$argumenten{base} ) {    # || !$argumenten{sub_type}
        $self->{errmsg} = 'base argument mandatory';
        return 0;
    }

    my %where;                     # = {};
    $where{base} = delete $argumenten{base};

    # let's delete
    my ( $stmnt, @bind ) = $self->{dbh}->{sql}->delete( 'soft_hard_type', \%where );
    my $sth = $self->{dbh}->prepare($stmnt);

    $self->{dbh}->executeWithBinds(@bind);

    if ( defined( $self->{dbh}->{sth}->errstr ) ) {
         $self->{errmsg} =  $self->{dbh}->{db_error_msg};
        return 0;
    } else {
        return 1;
    }
}

sub _getNewChar($$) {

    # generate a base_type character.
    # values range from aa to zz
    # given firstchar b and lastchar y, return value would be 'bz'
    # 676 max available combinations

    my $firstchar = $_[0];
    my $lastchar  = $_[1];
		my ( $location_first, $location_last, $newchar );
		
    my @alpha = ( "a" .. "z" );
    my $alfa  = "@alpha";
    $alfa =~ s/ //g;
    my $num = scalar(@alpha);

    while ( $alfa =~ m/$firstchar/g ) {
        $location_first = pos($alfa) - 1;
    }
    while ( $alfa =~ m/$lastchar/g ) {
        $location_last = pos($alfa) - 1;
    }

    if ( $location_last < $num - 1 ) {
        my $nextchar = $alpha[ $location_last + 1 ];
        $newchar  = $firstchar . $nextchar;
    } elsif ( $location_last == $num - 1 ) {
        $newchar = $alpha[ $location_first + 1 ] . 'a';
    } else {
        return 0;    #$newchar = 'OUT OF COMBINATIONS';
    }
    return $newchar;

}

# key options for %args input variable are:
# search, which is used to search name and producer column of table software_hardware;
# types, which is an array types. It searches column 'sub_type' and 'base' of table soft_hard_type;
# not_type, holds one type which is excluded in the search. It searches column 'sub_type' and 'base' 
# of table soft_hard_type and includes records that have a NULL value in column soft_hard_type.sub_type;
sub searchSH {
	my ( $self, %args ) = @_;
	undef $self->{errmsg};
	my @nests;
			
	my $search = delete $args{search};
	my %where = (	
								"producer || ' ' || name" => { -ilike => "%$search%" },
								deleted => 'f'
							);

	if ( exists( $args{types} ) ) {
		push @nests, [ 
										"sht.sub_type" => \@{ $args{types} },
										"sht.base"		 => \@{ $args{types} }
									];
	}
	
	if ( exists( $args{not_type} ) ) {
		my $is_null = "IS NULL";
		
		foreach my $not_type ( @{ $args{not_type} } ) {

			push @nests, [
										 "sht.sub_type" => { "!=" => $not_type },
										 "sht.sub_type" => \$is_null
									 ],
									 { "sht.base" => { "!="  => $not_type } };
		}
	}

	$where{-and} = \@nests if ( @nests );

	my $select = "sh.*, sht.*, count(shu.soft_hard_id) AS in_use";
	my $order_by = " ORDER BY sh.producer, sh.name, sh.version";
	my $group_by = " GROUP BY sh.producer, sh.name, sh.version, sh.deleted, sh.monitored, sh.id, sh.type, sh.cpe_id, sht.description, sht.base, sht.sub_type";
	
	my ( $stmnt, @bind ) = $self->{sql}->select( "software_hardware AS sh", $select, \%where );	
	my %join = ( 
								"JOIN soft_hard_type AS sht" => { "sh.type" => "sht.base" },
								"LEFT JOIN soft_hard_usage shu" => { "shu.soft_hard_id" => "sh.id" }
						);
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$stmnt .= $group_by . $order_by;

	$self->{dbh}->prepare( $stmnt );
	
	my $result = $self->{dbh}->executeWithBinds( @bind );

  $self->{errmsg} = $self->{dbh}->{db_error_msg};
  return $result;	
}

sub getConstituentUsage {
	my ( $self, $sh_id ) = @_;
	undef $self->{errmsg};
	
	my %where = ( "cg.status" => { "!=" => 1 }, soft_hard_id => $sh_id );
	my @cg_data;
	
	my ( $stmnt, @binds ) = $self->{sql}->select( "constituent_group AS cg", "cg.*, ct.type_description", \%where, "cg.name" );
	
	my %join = ( 
							 "JOIN soft_hard_usage AS shu" => { "shu.group_id" => "cg.id"	},
							 "JOIN constituent_type AS ct" => { "ct.id" => "cg.constituent_type" }
						 );
						 
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @binds );

	while ( $self->nextObject ) {
		push( @cg_data, $self->getObject );
	}
		
	$self->{errmsg} = $self->{dbh}->{db_error_msg};

	return \@cg_data;
}

sub countUsage {
	my ( $self, %where ) = @_;
	
	my ( $stmnt, @bind ) = $self->{sql}->select( 'soft_hard_usage shu', 'COUNT(shu.*) as cnt', \%where );
	my %join = ( 'JOIN software_hardware sh' => { 'shu.soft_hard_id' => 'sh.id' } );	

	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	$self->{errmsg} = $self->{dbh}->{db_error_msg};

	my $count = $self->{dbh}->fetchRow()->{cnt};
	return $count;	
}

sub loadCollection {
	my ( $self, %where ) = @_;
	
	my ( $stmnt, @bind ) = $self->{sql}->select( 'software_hardware', '*', \%where, 'producer, name, version' );
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	my @softwareHardware;
	while ( $self->nextObject() ) {
		push @softwareHardware, $self->getObject();
	}
	
	return \@softwareHardware;
}

1;


=head1 NAME 

    Taranis::SoftwareHardware

=head1 SYNOPSIS

    use Taranis::SoftwareHardware;
    
    my $obj = Taranis::SoftwareHardware->new();


=head1 QUICK START

    use Taranis::SoftwareHardware;
    my $obj = Taranis::SoftwareHardware->new();
    my @vendors = $obj->getDistinctList('producer') ;
    my @product_names = $obj->getDistinctList('name');
    my list = $obj->getList(producer => 'Sun');
    
    $obj->setObject(
            id => $obj_id, 
            monitored => 't',
            producer => 'New Producer Name', 
            name => 'New Product Name');

=head1 METHODS

=head2 B<cpeImport()>

    imports the cpe list into the database.
    my $import = $obj->cpeImport('/path/to/cpe-import-vXXX.xml');
    print    "$import{inserts}, 
              $import{last_error_message}, 
              $import{not_inserted}, 
              $import{skipped}"; 

    Import defaults to $self->{cfg}->{cpefile};
    So you can also put the location in the main Taranis Config file 
    as the value to element <cpefile>.

=head2 B<getBaseTypes()>

    returns a hash with base types with descriptions
    
    my $basetypes = $obj->getBaseTypes();
    e.g.
    $basetype = {a => 'Application',
                 h => 'Hardware',
                 o => 'Operating Systems'}
     
=head2 B<getDistinctList()>

    returns a list of values from DB table.
    
    my @vendors = $obj->getDistinctList('producer');
    Returns all vendor/producer names (Default), 
    or
    my @product_names = $obj->getDistinctList('name');
    All product names
    or
    $all_3com_devices = $obj->getDistinctList(producer => '3com');
    Gives the names of all items for producer 3com.

 
=head2 B<getList()>

    my $vendor = $object->getList(id => '1234')
    returns a hash record of a certain DB id.
    
    Only returns undeleted records (meaning records that have the 
    'deleted' column set to false),
    If you want to receive the deleted records set 
        $obj->{deleted} = 'f';
    
    my $stuff = $obj->getList(id => $dbid);
    Returns all data for DB $dbid. 
    or

    $obj->getList(producer => $vendor_name, type => $type, name => $name);
     if ($obj->{errmsg})  {
         print "err: " . $obj->{errmsg} . "\n";
     } else {}
     while ($obj->nextObject()) {
         my $record = $obj->getObject();
         # ... do something with $record
     }
    }
    Adding 'name => $whatever' will cause a 'name LIKE %$whatever%' clause added to the DB query. 

    Returns all data for product names for producer $vendor_name with $type.

=head2 B<getFirstList()> {
    
    $obj->getFirstList();    
    while ( $obj->nextObject() ) {
        my $record = $obj->getObject();
        ... do something with $record ,like push it into an @array
    }
    
     Only to show some output on the first page 
     this method returns the results from 'select * from'
     limits to 100 rows (default.)

=head2 B<getListCount()>


    $obj->getListCount( producer => $producer,
                        type     => $type,
                        name     => $name
                       );
                       
    Returns database count number from query.
    Usefull to show number of matches on your output page
    and to generate a list of buttons (1..x) 
    

=head2 B<setObject()>

    Change stuff in DB.
    $obj->setObject(
            id => $db_id, 
            monitored => 't',
            producer => 'New Producer Name', 
            name => 'New Product Name');
    
    See DB table for column names;
    
    Deleting a record is done by changing the deleted column to a true value.

=head2 B<nextObject()>

    While traversing a resultset, see if there's an other object.

=head2 B<getObject()>

    Get object from a resultset.
    
    while ($obj->nextObject()) {
        my $record = $obj->getObject();
    }

=head2 B<getShType()>

    Return all objects
    $obj->getShType();
    
    Return a single object  
    $obj->getShType(base => 'ad');
    
    
=head2 B<addShType()>

    Add description and base type for a soft_hard_type.
    
    $obj->addShType(description => 'Nice Hardware', sub_type => 'h') 
    
    Subtype must be one of; 
    B<a> (application), 
    B<h> (hardware) or 
    B<o> (Operating System).

    B<The sub_types are derived from cpe import>.
    
    If a new subtype is created a manual DB insert has to
    be executed:
    insert into soft_hard_type (description , base) values ('New Type', 'x')

=head2 B<setShType()>

    Change decscription and/or sub_type for a soft_hard_type.
    $obj->setShType(description => 'Very Nice Hardware', base => 'be')

=head2 B<delShType()>
    
    Deletes an soft_hard_type entry from the database;
    $obj->delShType(base => 'xx')
    

=head1 DB

            my $software_hardware = 
            (
                          deleted   => 0,
                          monitored => 0,
                          name      => $title,
                          producer  => $vendor,
                          type_id   => $type_id_FK,
                          version   => $version,
                          
            );
    The type_id is a foreign key pointing at the soft_hard_type.base column.
    
            my $soft_hard_type = 
            (
                          base          => $base,
                          sub_type      => $sub_type,
                          description   => $description
                          
            );        

    The 'base' column is the primary key and are generated when inserting a new record.
    Ranges from aa to zz, maximimum 675 combinations.
     
=head1 AUTHOR

    jeroen
    Oct 6, 2008

=cut

__END__
