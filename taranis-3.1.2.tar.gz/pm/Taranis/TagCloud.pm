package Taranis::TagCloud;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Config;
use Taranis qw(:all);
use Tie::IxHash;
use strict;

sub new {
	shift @_;
	
	my $self = {
		blacklist => Taranis::Config->getSetting('tagcloud_blacklist'),
		minimumTagLength => 4
	};
	bless $self;
	return $self;	
}

sub createTagsListFromText {
	my ( $self, %args ) = @_;
	my ( @tags );
	tie my %list, "Tie::IxHash";
	my $text = decodeInput( \$args{text} );

	foreach my $tag ( split /\s/, $text ) {

		$tag=~ tr/*//d;               
		$tag=~ tr/(//d;               
		$tag=~ tr/)//d;               
		$tag=~ tr/""//d;              
		$tag=~ tr/''//d;             
		$tag=~ tr/?//d;               
		$tag=~ tr/,//d;                
		$tag=~ tr/. //d;                  
		$tag=~ tr/-//d;               
		$tag=~ tr/"//d;               
		$tag=~ tr/'//d;
		$tag=~ tr/‘//d;
		$tag=~ tr/!//d;               
		$tag=~ tr/;//d;                
		$tag= lc( $tag );                
		$tag=~ s/\[//gi;                
		$tag=~ s/\]//gi;                
		$tag=~ s/://gi;                
		$tag=~ s/#//gi;                
		$tag=~ s/\&rsquos//gi;     

		$tag= '' unless defined $tag;


		if ( trim $tag ) {
			push @tags, trim $tag;
		}
	}

	my %seen = ();
	my @uniq = ();
	foreach my $uniqTag( @tags )	{
		unless ( $seen{ $uniqTag } ) {
			# if we get here, we have not seen it before
			$seen{ $uniqTag } = 1;
			push @uniq, $uniqTag;
		}
	}

	my %count;
	$count{$_}++ for @tags; # Here are the counts
	
	$list{$_} = $count{$_}  for (sort { $count{$b} <=> $count{$a} } keys %count);
	
	return \%list;
}

sub isBlacklisted {
	my ( $self, $tag ) = @_;

	# tag is too short
	if ( length( $tag ) <= $self->{minimumTagLength} ) {
		return 1;
	}

	my $grep = `grep -w '$tag' $self->{blacklist} | wc -l`;
	$grep =~ s/\n//gi;
	
	# tag is in blacklist file
	if ( $grep ne "0" ) { 
		return 1;
	}

	# tag is url
	if ( substr ($tag, 0, 4) eq "http" ) {
		return 1;
	}

	# tag starts with @
	if (substr ($tag, 0, 1) eq "@") {
		return 1;
	}

	# tag contains &
	if (index ($tag, "&") > -1) {
		return 1;
	}

	return 0;
}

sub resizeList {
	my ( $self, %args) = @_;

	my $level = $args{level} || undef;
	my $maximumUniqWords = $args{maximumUniqWords} || undef;
	my $list = $args{list};

	my %levels;
		
	foreach my $tag ( keys %$list ) {
		
		if ( defined $maximumUniqWords && $maximumUniqWords == 0 ) {
			delete $list->{$tag};
		} else {
			$maximumUniqWords--;
		}
		
		if ( exists( $list->{$tag} ) ) {
			if ( defined $level && $level == 0 ) {
				delete $list->{$tag};
			} else {
				if ( !exists( $levels{ $list->{$tag} } ) ) {
					$levels{ $list->{$tag} } = 1;
					$level--;
				}
			}
		}
	}
	
	return $list;
}

sub sortList {
	my ( $self, $list ) = @_;
	tie my %sortedList, 'Tie::IxHash';
	$sortedList{$_} = $list->{$_}  for ( reverse sort { $list->{$a} <=> $list->{$b} } keys %$list);
	return  \%sortedList;
}

1;
