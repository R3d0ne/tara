package Taranis::Users;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

our $VERSION = '0.01';

use strict;

use Taranis qw(:all);
use Taranis::Config;
use Taranis::Database;
use Data::Dumper;
use SQL::Abstract;

use Digest::MD5 qw(md5 md5_hex md5_base64);

sub new {

    my ( $self, $arg ) = @_;

    $self = bless {}, $self;

    my $init = $self->_init(@_);

    bless $init;
    return $init;
}

sub _init {

    my ( $self, $class ) = @_;

    my $obj = {
        dbh         => Taranis::Database->new(),
        sql         => SQL::Abstract->new(),
        user_role   => {},
        role        => {},
        role_right  => {},
        entitlement => {},
        dbtable     => 'users',
        username    => '',
        password    => ''

    };
    return $obj;
}

*checkPassword = \&login;

sub login {
    my ( $self, @arg ) = @_;
    undef $self->{errmsg};
    my %args = @arg;
    my %where =
      ( password => md5_base64( $args{password} ), username => $args{username}, disabled => 0 );

    my $table  = $self->{dbtable};
    my $select = 'COUNT(*)';

    my ( $stmnt, @bind ) = $self->{sql}->select( $table, $select, \%where );

    $self->{dbh}->prepare($stmnt);
    $self->{dbh}->executeWithBinds(@bind);
    my $cnt = $self->{dbh}->{sth}->fetch;

    if ( $cnt->[0] > 0 ) {
        return 1;
    } else {
        return 0;
    }
}

sub getUser {
    my ( $self, $username, $noDisabledInWhere ) = @_;
    undef $self->{errmsg};
    
    my %where = ( username => $username );
    $where{disabled} = 'f' if ( !$noDisabledInWhere );
    
    my $select = "username, password, uriw, search, anasearch, anastatus, c.name AS category, c.id AS categoryid, "
					  			. "mailfrom_sender, mailfrom_email, lmh, statstype, hitsperpage, fullname, " 
					  			. "disabled, to_char(datestart, 'DD-MM-YYYY') AS date_start, "
					  			. "to_char(datestop, 'DD-MM-YYYY') AS date_stop, assess_orderby, source, assess_autorefresh";

    my ( $stmnt, @bind ) = $self->{sql}->select( "users", $select, \%where );

    my %join = ( 'LEFT JOIN category c' => { 'c.id' => 'category' } );
    $stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

    $self->{dbh}->prepare( $stmnt );
    $self->{dbh}->executeWithBinds( @bind );

    $self->{errmsg} = $self->{dbh}->{db_error_msg};

    if ( $self->nextObject() ) {
        return $self->getObject();
    } else {
        $self->{errmsg} = "User doesn't exist.";
        return 0;
    }
}

sub getUserAction {
    my ( $self, %where ) = @_;
    undef $self->{errmsg};

    my $select = 'date, action, comment';
    my $table  = 'user_action';
    my $order  = 'date desc';
    my ( $stmnt, @bind ) = $self->{sql}->select( $table, $select, \%where, $order );
    my $sth = $self->{dbh}->prepare($stmnt);
    $self->{dbh}->executeWithBinds(@bind);

    if ( defined( $self->{dbh}->{db_error_msg} ) ) {
        $self->{errmsg} = $self->{dbh}->{db_error_msg};
        return 0;
    }
    return 1;

}

sub setUser {
	my ( $self, %args ) = @_;
	undef $self->{errmsg};
	
	my %where = ( username => delete $args{username} );

	my ( $stmnt, @bind ) = $self->{sql}->update( 'users', \%args, \%where );
	
	my $sth = $self->{dbh}->prepare($stmnt);
	$self->{dbh}->executeWithBinds(@bind);

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}
	return 1;
}

sub getUsersList {
    my ( $self, @arg ) = @_;
    undef $self->{errmsg};
    my %waar = @arg;

    # sanatize
    while ( my ( $key, $val ) = ( each %waar ) ) {
        $waar{$key} = sanitizeParameter($val);
    }

    my $search = $waar{username};

    my @where = ( { disabled => 'f' } );

    my $select = 'username, fullname';
    my $order  = 'username';
    my $table  = $self->{dbtable};
    my ( $stmnt, @bind ) = $self->{sql}->select( $table, "$select", \@where, $order );
    $self->{dbh}->prepare($stmnt);

    if ( defined( $self->{dbh}->{sth}->errstr ) ) {
        $self->{errmsg} = $self->{dbh}->{sth}->errstr;
        return 0;
    }

    $self->{dbh}->executeWithBinds(@bind);
    return 1;

}



sub addUser {
	my ( $self, %insert ) = @_;
	undef $self->{errmsg};

	$insert{disabled} = 0;

	my %checkdata = ( username => $insert{username} );

	my $table = $self->{dbtable};

	if ( $self->{dbh}->checkIfExists( \%checkdata, $table ) ) {
		$self->{errmsg} = "username exists, perhaps the previous $insert{username} is disabled?";
		return 0;
	}

	my ( $stmnt, @bind ) = $self->{sql}->insert( $table, \%insert );

	$self->{dbh}->prepare($stmnt);
	$self->{dbh}->executeWithBinds(@bind);

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}

	return 1;
}

sub setRoleToUser {
	my ( $self, %insert ) = @_;
	undef $self->{errmsg};

	if ( $insert{username} && $insert{role_id} ) {
		my ( $stmnt, @bind ) = $self->{sql}->insert( 'user_role', { username => $insert{username}, role_id => $insert{role_id} } );
	
		$self->{dbh}->prepare( $stmnt );
		$self->{dbh}->executeWithBinds( @bind );
	
		if ( defined( $self->{dbh}->{db_error_msg} ) ) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			return 0;
		}
	} else {
		$self->{errmsg} = 'Invalid input';
		return 0;
	}
	return 1;
}

sub delUserFromRole {
	my ( $self, %args ) = @_;
	undef $self->{errmsg};
	
	my %where;

	$where{username} = ( exists( $args{username} ) && $args{username} ) ? $args{username} : undef;
	if ( exists( $args{username} ) && $args{username} ) {
		$where{username} = $args{username};	
	}

	if ( exists( $args{role_id} ) && $args{role_id} ) {
		$where{role_id} = $args{role_id};	
	}
    
	if ( exists( $where{role_id} ) || exists( $where{username} ) ) {
		my ( $stmnt, @bind ) = $self->{sql}->delete( 'user_role', \%where );
		
		$self->{dbh}->prepare( $stmnt );
		$self->{dbh}->executeWithBinds( @bind );
	} else {
		$self->{errmsg} = 'missing input';
		return 0;
	}

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}

	return 1;
}

sub nextObject {
    my ($self) = @_;
    return $self->{dbh}->nextRecord;
}

sub getObject {
    my ($self) = @_;
    return $self->{dbh}->getRecord;
}

1;

=head1 NAME Taranis::Users

Taranis user management

=head1 SYNOPSIS

use Taranis::Users;

=head1 QUICK START

my $usr = Taranis::Users->new();

=head1 METHODS

=head2  B<addUser()>

Add a new user, will fail if username already exiss 
(users are never deleted, instead disabled column wil be set to true)

$usr->addUser(username => 'john', 
              fullname => 'John Doe', 
              disabled => 'f', 
              mailfrom_email => 'johndoen@org.org', 
              mailfrom_sender =>  'John Doe');
              
=head2  B<login()>

login a user.

if ($usr->login( username => $username, password => $passwd )) {
    # user is logged in.       
   } 

=head2 B<setUser()>

Set user attributes. Use DB columns for argument keywords.

$usr->setUser( username  => $query->param("username"),
                datestart => nowstring(9),
                datestop  => nowstring(9));

=head2 B<getUserAction()>

retrieves a list of user actions.

$usr->getUserAction(username => $username);

=head2 B<setRoleToUser()>

Grant a role to a user.

$usr->setRoleToUser(username => $username, role_id  => $role_id)

=head2 B<delUserFromRole()>

Remove a role from a user.

$usr->delUserFromRole(username => $username, role_id  => $role_id)

=head2 B<getRolesFromUser()>

DEPRECATED 
getRolesFromUser now is in Roles.pm
 
retrieve a list of roles this user has.

$userrole->getRolesFromUser( username => $username );

=head2 B<getUsersList()>

Returns a DB handle to the users list.

$usr->getUsersList();

while ( $usr->nextObject() ) {
        my $record = $usr->getObject();
        push @users, $record;
    }
    
etc.


=head1 AUTHOR

jeroen
Dec 29, 2008

=cut
