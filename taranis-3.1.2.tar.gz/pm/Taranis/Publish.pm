package Taranis::Publish;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:all);
use Taranis::Database;
use Taranis::Config;
use Taranis::Publication;
use Mail::Sender;
use strict;
use SQL::Abstract;
use Tie::IxHash;
use HTML::Entities;
use Encode; 

use Data::Dumper;

sub new {
	shift @_;
	
	my $self = {
		errmsg 	=> undef,
		dbh 		=> Taranis::Database->new(),
		sql 		=> SQL::Abstract->new()
	};
	bless $self;
	return $self;	
}

sub getNextAdvisoryId {
	my ( $self ) = @_;
	
	my $advisoryPrefix = Taranis::Config->getSetting("advisory_prefix");
	my $advisoryIdLength = Taranis::Config->getSetting("advisory_id_length");
	
	$advisoryPrefix = "ADVISORY" if ( !$advisoryPrefix );
	
	my $zeros = "";
	for ( my $i = 1; $i <= $advisoryIdLength; $i++ ) {
		$zeros .= "0";
	}
	
	my $currentYear = nowstring(6);
	
  my $select = "MAX( CAST( SUBSTRING( govcertid FROM '%-#\"%#\"%' FOR '#' ) AS INTEGER ) ) AS maxint, govcertid AS maxid";
  my $stmnt = "SELECT $select FROM publication_advisory WHERE govcertid NOT ILIKE ? AND govcertid ILIKE ? GROUP BY maxid ORDER BY maxint DESC LIMIT 1;";	
	
  my $not_ilike = $advisoryPrefix . "-" . $currentYear . "-X%";
  my $ilike     = $advisoryPrefix . "-" . $currentYear . "%";

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( $not_ilike, $ilike );
	
	my $result = $self->{dbh}->{sth}->fetchrow_hashref();
	my $maxid = $result->{maxid} if ( exists( $result->{maxid} ) );
	
	my ( $prefix, $year, $sequence ) = $maxid =~ /^(.*?)-(\d{4})-(\d+)$/ if $maxid;
	
  if ( !$maxid || $year ne $currentYear ) {
    ## Year of current max ID doesn't correspond with current year, thus it's a new year

    $prefix   = $advisoryPrefix;
    $year     = $currentYear;
    $sequence = $zeros;
  }
  
  ## in case the maximum ID ends with XXX, this may occur when the advisory prefix has been changed
  $sequence = $zeros if ( $sequence !~ /^\d+$/ );
  
  ## if setting 'advisory_id_length' has changed, make the advisory ID wider/shorter
  if ( length($sequence) != $advisoryIdLength ) {
    
  	if ( length($sequence) < $advisoryIdLength ) { # make the advisory ID wider by adding zero's 
  		
  		for ( my $j = 0; $j < ( $advisoryIdLength - length($sequence ) ); $j++ ) {
  			$sequence = "0" . $sequence;
  		}
  	} else { # shorten the advisory ID

  		my $idShortening =  length( $sequence ) - $advisoryIdLength;
  		
  		if ( $sequence =~ /^0{$idShortening,}[1-9]+$/ ) {
  			$sequence = substr( $sequence, $idShortening );
  			
  		} # else ignore the shortening of the advisory ID
  	}
  } 
  
  ## Add one to the maximum ID
  $sequence++;
  
  $maxid = $prefix."-".$year."-".$sequence;

	return $maxid;	
}

sub getPreviousAdvisoryId {
  my ( $self, $advisory_id ) = @_;
  
  my $advisoryPrefix = Taranis::Config->getSetting("advisory_prefix");
  my $advisoryIdLength = Taranis::Config->getSetting("advisory_id_length");
  
  $advisoryPrefix = "ADVISORY" if ( !$advisoryPrefix );
  
  my $firstOfTheYearSequence = "";
  for ( my $i = 1; $i <= $advisoryIdLength - 1; $i++ ) {
    $firstOfTheYearSequence .= "0";
  }
  $firstOfTheYearSequence .= "1";
  
  my $currentYear = nowstring(6);
  
  $advisory_id =~ /^$advisoryPrefix-(.*?)-(.*?)$/;

  my $year = $1;
  my $sequence_number = $2;
  my $year_sequence_number = $1 . $2;
  
  my $previous_advisory_id;
  
  if ( $year_sequence_number =~ /^\d\d\d\d$firstOfTheYearSequence$/ ) {
    # get last advisory id from last year
    my $last_year = $year - 1;
    
	  my $select = "MAX( CAST( SUBSTRING( govcertid FROM '%-#\"%#\"%' FOR '#' ) AS INTEGER ) ) AS maxint, govcertid AS previous_id";
	  my $stmnt = "SELECT $select FROM publication_advisory WHERE govcertid NOT ILIKE ? AND govcertid ILIKE ? GROUP BY previous_id ORDER BY maxint DESC LIMIT 1;";  
	  
	  my $not_ilike = $advisoryPrefix . "-" . $last_year . "-X%";
	  my $ilike     = $advisoryPrefix . "-" . $last_year . "%";    
    
    $self->{dbh}->prepare( $stmnt );
    $self->{dbh}->executeWithBinds( $not_ilike, $ilike );

    my $row = $self->{dbh}->fetchRow();

    $previous_advisory_id = $row->{previous_id};

  } else {
  	
  	my $prev_seq_nr = $sequence_number - 1;
    my $advisory_id_sql_regex = $advisoryPrefix . '-' . $year . '-0*' . $prev_seq_nr;
    
    my $stmnt = "SELECT govcertid FROM publication_advisory WHERE govcertid ~ ? LIMIT 1;";

    $self->{dbh}->prepare( $stmnt );
    $self->{dbh}->executeWithBinds( $advisory_id_sql_regex );

    my $row = $self->{dbh}->fetchRow();

    $previous_advisory_id = $row->{govcertid};
  } 
  
  return $previous_advisory_id;
}


sub nextObject {
	my ( $self ) = @_;
	return $self->{dbh}->nextRecord;
}

sub getObject {
	my ( $self ) = @_;
	return $self->{dbh}->getRecord;		
}

sub getConstituentGroupIdsForPublication {
	my ( $self, $publication_id, @sh_list ) = @_;
	undef $self->{errmsg};
	my ( @group_ids, @binds );
	tie my %join, "Tie::IxHash";
	my %sh_ids;
	
	my $stmnt = "SELECT id from constituent_group
		 				 	 WHERE use_sh = 'false' 
		 					 AND status = '0'";

	my ( $linked_to_pub_stmnt, @linked_to_pub_bind ) = $self->{sql}->select( "software_hardware", "*", { id => \@sh_list} );

	$self->{dbh}->prepare( $linked_to_pub_stmnt );
	$self->{dbh}->executeWithBinds( @linked_to_pub_bind );

	while ( $self->nextObject() ) {
		my $record =  $self->getObject();
		$sh_ids{ $record->{id} } = $record; 
	}

	my ( @no_version_where, @with_version_where, @no_version_bind, @with_version_bind);
	my ( $no_version_stmnt, $with_version_stmnt, $sh_stmnt );

# check if the Software/Hardware has a version or not and create two lists (with and without version)
	if ( scalar( %sh_ids ) ) {
		foreach my $id ( keys %sh_ids ) {
			if ( !$sh_ids{$id}->{version} ) {
				push @no_version_where, { name => $sh_ids{$id}->{name}, producer => $sh_ids{$id}->{producer} };
			} else {
				push @with_version_where, { name => $sh_ids{$id}->{name}, version => [ undef, "" ], producer => $sh_ids{$id}->{producer} };
			}
		}
	
#	get all Software/Hardware from the created list that have the same name (create the SQL statement only)
		if ( @no_version_where ) {
			( $no_version_stmnt, @no_version_bind ) = $self->{sql}->select( "software_hardware", "*", \@no_version_where );
		
			$sh_stmnt = $no_version_stmnt;
		}
	
#	get all Software/Hardware from the created list that have the same name but without a version
		if ( @with_version_where ) {
			( $with_version_stmnt, @with_version_bind ) = $self->{sql}->select( "software_hardware", "*", \@with_version_where );
			
			$sh_stmnt .= ( $sh_stmnt ) ? " UNION " . $with_version_stmnt : $with_version_stmnt;
		}
	
		push @no_version_bind, @with_version_bind; 
	
		if ( $sh_stmnt ) {
			$self->{dbh}->prepare( $sh_stmnt );
			$self->{dbh}->executeWithBinds( @no_version_bind );
		
			while ( $self->nextObject() ) {
				my $record =  $self->getObject();
				$sh_ids{ $record->{id} } = $record; 
			}		
		}

# get all Software/Hardware that start with the same name of the S/H already selected (and have matching producer) 		
		my @same_name_where;
		foreach my $id ( keys %sh_ids ) {
			push @same_name_where, { name => { -ilike => $sh_ids{$id}->{name} . '%' }, producer => $sh_ids{$id}->{producer} };
		}
		my ( $same_name_stmnt, @same_name_bind ) = $self->{sql}->select( "software_hardware", "id", \@same_name_where );

		$self->{dbh}->prepare( $same_name_stmnt );
		$self->{dbh}->executeWithBinds( @same_name_bind );
		
		while ( $self->nextObject() ) {
			my $record =  $self->getObject();
			$sh_ids{ $record->{id} } = $record; 
		}
		
# get all the constituent groups that have the software/hardware in use
# and all the groups which have not supplied a software/hardware list
# and all the groups which have the 'enabled' status 
		
		my @where = ( "shu.soft_hard_id" => [ keys( %sh_ids ) ] );
		my ( $stmnt_sh_list, @bind ) = $self->{sql}->select( "constituent_group cg", "cg.id", \@where );
		
		%join = ( "JOIN soft_hard_usage shu" => { "shu.group_id" => "cg.id" } );
		$stmnt_sh_list = $self->{dbh}->sqlJoin( \%join, $stmnt_sh_list );
		
		$stmnt .= " UNION " . $stmnt_sh_list;
		@binds = @bind;
	} 	

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @binds );
	
	while ( $self->nextObject() ) {
		push @group_ids, $self->getObject()->{id};
	}

	$self->{errmsg} = $self->{dbh}->{db_error_msg};
	return \@group_ids;
}

sub getConstituentGroupIdsForPublicationAndSelection {
	my ( $self, $publication_id, $selectionIds ) = @_;
	
	# get all software/hardware per combo
	# check if SH has a version and get SH ID's depending on having version or not
	# get all constituents that have one of the combinations of SH.
	
	my @selections;
	
	SELECTIONIDS:
	foreach my $selection ( @$selectionIds ) {

		if ( $selection->[0] =~ /^x$/i && $selection->[1] =~ /^x$/i ) {
			next SELECTIONIDS;

		} elsif ( $selection->[0] =~ /^x$/i ) { 
			$selection->[0] = "";
			@$selection = sort @$selection;
			shift @$selection;

		} elsif ( $selection->[1] =~ /^x$/i ) {
			delete $selection->[1];
		}

		my ( $sh_selection_stmnt, @sh_selection_bind ) = $self->{sql}->select( "software_hardware", "*", { id => $selection } );

		$self->{dbh}->prepare( $sh_selection_stmnt );
		$self->{dbh}->executeWithBinds( @sh_selection_bind );

		my @selectionRecord;
		while ( $self->nextObject() ) {
			my $record =  $self->getObject();
			push @selectionRecord, $record;
		}
		push @selections, \@selectionRecord;
	}

	my @extendedSelections;
	
	SELECTION:
	foreach my $selection ( @selections ) {
		
		my ( @platform, @product );
		
		my $where = { name => { -ilike => $selection->[0]->{name} . "%" }, producer => $selection->[0]->{producer}, deleted => 0 };
		
		$where->{version} = [ undef, "" ]	if ( $selection->[0]->{version} );

		my ( $stmnt, @bind ) = $self->{sql}->select( "software_hardware", "*", $where );
		
		$self->{dbh}->prepare( $stmnt );
		$self->{dbh}->executeWithBinds( @bind );
		
		while ( $self->nextObject() ) {
			my $record = $self->getObject();
			push @platform, $record;
		}

		$where = { name => { -ilike => $selection->[1]->{name} . "%" }, producer => $selection->[1]->{producer}, deleted => 0 };
		
		$where->{version} = [ undef, "" ]	if ( $selection->[1]->{version} );

		( $stmnt, @bind ) = $self->{sql}->select( "software_hardware", "*", $where );
		
		$self->{dbh}->prepare( $stmnt );
		$self->{dbh}->executeWithBinds( @bind );
		
		while ( $self->nextObject() ) {
			my $record = $self->getObject();
			push @product, $record;
		}		
		
		push @extendedSelections, [ \@platform, \@product ];
	}

	my %group_ids;

	my $stmnt = "SELECT id from constituent_group
		 				 	 WHERE use_sh = 'false' 
		 					 AND status = '0'";
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( );
	my @group_ids;

	while ( $self->nextObject() ) {
		my $record = $self->getObject();
		
		$group_ids{ $record->{id} } = 1;
	}		
	
	foreach my $selection ( @extendedSelections ) {

		if ( !@{ $selection->[0] } || !@{ $selection->[1] } ) {

			my $softwareHardware = ( $selection->[0] ) ? $selection->[0] : $selection->[1];
			
			foreach my $sh ( @$softwareHardware ) {

				$stmnt =	
"select shu.group_id from soft_hard_usage shu
join constituent_group cg on cg.id = shu.group_id
where cg.status = 0
and shu.soft_hard_id = $sh->{id}";			

				$self->{dbh}->prepare( $stmnt );
				$self->{dbh}->executeWithBinds();
				my @group_ids;
			
				while ( $self->nextObject() ) {
					my $record = $self->getObject();
					
					$group_ids{ $record->{group_id} } = 1;
				}
			}
		} else {

			for ( my $i = 0; $i < @{ $selection->[0] }; $i++ ) {
				for ( my $j = 0; $j < @{ $selection->[1] }; $j++ ) {
	
					$stmnt =	
"select shu.group_id from soft_hard_usage shu
join constituent_group cg on cg.id = shu.group_id
where cg.status = 0
and shu.soft_hard_id = $selection->[0]->[$i]->{id}
and shu.group_id in (
											select shu2.group_id from soft_hard_usage shu2
											where shu2.soft_hard_id = $selection->[1]->[$j]->{id}
		    						) GROUP BY shu.group_id";
	
					$self->{dbh}->prepare( $stmnt );
					$self->{dbh}->executeWithBinds();
					my @group_ids;
				
					while ( $self->nextObject() ) {
						my $record = $self->getObject();
						
						$group_ids{ $record->{group_id} } = 1;
					}
				}	
			}
		}
	}
	
	my @ids = keys %group_ids;

	return \@ids;
}

sub getConstituentGroupsForPublication {
	my ( $self, $publication_type_id ) = @_;
	my @groups;
	
	my %where = ( "tpc.publication_type_id" => $publication_type_id, "cg.status" => 0 );
	my ( $stmnt, @bind ) = $self->{sql}->select( "constituent_group cg", "cg.*", \%where, "cg.name" );
	
	my %join = ( "JOIN type_publication_constituent tpc" => { "tpc.constituent_type_id" => "cg.constituent_type" } );
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	my $result = $self->{dbh}->executeWithBinds( @bind );

	while ( $self->nextObject() ) {
		push @groups, $self->getObject();
	}

	$self->{errmsg} = $self->{dbh}->{db_error_msg};
	return \@groups;
}

sub getIndividualsForSending {
	my ( $self, $publication_type_id, @groups ) = @_;
	my @individuals;

	my %where = ( 
								"ci.status" 			=> 0,
								"cp.type_id" 			=> $publication_type_id,
								"m.group_id" 			=> \@groups,
								"ci.emailaddress" => { "!=", ""}
							);
	
	my ( $stmnt, @bind ) = $self->{sql}->select( "constituent_individual ci", "DISTINCT ci.*", \%where, "ci.lastname");
	
	my %join = ( 
							 "JOIN constituent_publication cp" => { "cp.constituent_id" => "ci.id"},
							 "JOIN membership m" 							 => { "m.constituent_id" => "ci.id" }
						 ); 
	
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );

	$self->{errmsg} = $self->{dbh}->{db_error_msg};
	
	while ( $self->nextObject() ) {
		push @individuals, $self->getObject();
	}
	
	return \@individuals;	
}

sub sendPublication {
	my ( $self, %args ) = @_;

	my ( $from, $to );
	my $cfg =  Taranis::Config->new();
	
	for ( $args{pub_type} ) {
		if (/^eow$/) {
			$from = '"' . $args{from_name} .'" <' . $cfg->{publish_eow_from} . '>';
			$from = encode( "MIME-Header", HTML::Entities::decode( $from ) );
			$to 	= ( $cfg->{testmode} eq 'off' ) ? $cfg->{publish_eow_to} : $cfg->{publish_testing_to};
		} elsif (/^eos$/) {
      $from = '"' . $args{from_name} .'" <' . $cfg->{publish_eos_from} . '>';
      $from = encode( "MIME-Header", HTML::Entities::decode( $from ) );      
      $to   = ( $cfg->{testmode} eq 'off' ) ? $cfg->{publish_eos_to} : $cfg->{publish_testing_to};
		} elsif (/^eos_public$/) {
      $from = '"' . $args{from_name} .'" <' . $cfg->{publish_eos_from} . '>';
      $from = encode( "MIME-Header", HTML::Entities::decode( $from ) );      
      $to   = ( $cfg->{testmode} eq 'off' ) ? $cfg->{publish_eos_to_public} : $cfg->{publish_testing_to};
		} elsif (/^advisory$/) {
			$from = '"' . $cfg->{publish_advisory_from_name} . '"<' . $cfg->{publish_advisory_from_address} . '>';
			my $production_to = ( $args{attach_xml} ) ? $cfg->{publish_xml_advisory_to} : $cfg->{publish_advisory_to};
			$to = ( $cfg->{testmode} eq 'off' ) ? $production_to : $cfg->{publish_testing_to};
		}
	}
	
	if ( !$to || !$from ) {
		my $missing_input = ( !$to ) ? "TO" : "FROM";
 		return "Missing email setting '$missing_input' for sending. Please check Taranis configuration.";
	} else {
		my $sender = new Mail::Sender {
				smtp => $cfg->{smtpserver},
				user => $cfg->{smtpuser},
				pass => $cfg->{smtppass},
				port => $cfg->{smtpport}, 
				from => $from
		};

    my $addresses = ( exists( $args{addresses} ) ) ? $args{addresses} : undef;
    	
		if ( ref( $sender ) ) {
			$sender->OpenMultipart( { 
															 to 		 => $to,
															 bcc 		 => $addresses,
			                         subject => $args{subject} 
			} );
			 
			$sender->Body( { 
											charset 	=> 'UTF-8',
											ctype 		=> 'text/plain',
											msg 			=> $args{msg}
										 } );
			
			if ( $args{attach_xml} ) {
				$sender->Part( {
					description => $args{xml_description},
				  ctype 			=> 'text/xml',
				  encoding		=> 'Base64',
				  disposition => 'attachment; filename="' . $args{xml_filename} . '.xml"; type="XML"',
				  msg 				=> $args{xml_content}
				} );
			}
			
			$sender->Close;
			if ( !$sender->{error} ) {
				return "OK";
			}	else {
				return $Mail::Sender::Error;
			}
		} else {
			return $Mail::Sender::Error;
		}
	}
}

sub setSendingResult {
	my ( $self, %inserts ) = @_;
	undef $self->{errmsg};
	my ( $stmnt, @bind ) = $self->{sql}->insert( "publication2constituent", \%inserts );
	
	$self->{dbh}->prepare( $stmnt );
	if ( defined( $self->{dbh}->executeWithBinds( @bind ) ) > 0 ) {
		return 1;
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}
}

sub generateCallingList {
	my ( $self, $time_of_day, @groups ) = @_;
	
	my %calling_list;
	tie my %join, "Tie::IxHash";
	my %where;
	my $dsc_search = "%DSC%";
	
	my $hour = substr( nowstring(1), 0, 2);
	
	my $time_setting;
	
	if ( $time_of_day ) {
		$time_setting = $time_of_day;
	} else {
		$time_setting = ( $hour >= 9 && $hour < 18 ) ? 'day' : 'night';
	}

	if ( $time_setting eq 'day' ) {
		%where = ( "cg.call_hh" => 1, "cg.id" => \@groups, "cr.role_name" => { -ilike => $dsc_search } );
	} else {
		%where = ( "cg.call_hh" => 1, "cg.id" => \@groups, "ci.call247" => 1 );
	}
	
	my $select = "ci.firstname, ci.lastname, ci.tel_mobile, tel_regular, cr.role_name, cg.name AS groupname, cg.notes";
	my ( $stmnt, @bind ) = $self->{sql}->select( "constituent_individual ci", $select, \%where, "cg.name" );
	%join = ( 
						"JOIN constituent_role cr" 	=> { "cr.id" => "ci.role" 				 	},
						"JOIN membership m" 			 	=> { "m.constituent_id" => "ci.id" 	},
						"JOIN constituent_group cg" => { "cg.id" => "m.group_id" 				}	 
	 			  );

	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );
	$self->{dbh}->prepare( $stmnt );

	$self->{dbh}->executeWithBinds( @bind );

	my $count = 0;
	while ( $self->nextObject() ) {
		my $person = $self->getObject();
		my $group_name = '';
		
		if ( $group_name ne $person->{groupname} || $count == 0 ) {
			$group_name = $person->{groupname};
			push @{ $calling_list{ $group_name} }, $person;
		} else {
			push @{ $calling_list{ $group_name} }, $person;
		}
	}

	return \%calling_list;
}

sub getPublishDetails {
	my ( $self, $publication_id, $publication_type ) = @_;
	undef $self->{errmsg};
	tie my %join, "Tie::IxHash";
	tie my %join2, "Tie::IxHash";
	my %where = ( publication_id => $publication_id, channel => 1 );
	my %details;
	
	my $select = "cg.name AS groupname, ci.id AS ci_id, ci.firstname, ci.lastname, ci.emailaddress, to_char(p.timestamp, 'DD-MM-YYYY HH24:MI:SS') AS timestamp_str"; 
	my $order = "lastname, firstname, groupname";
	my ( $stmnt, @bind ) = $self->{sql}->select( "publication2constituent p", $select , \%where, $order );
	%join = (
						"JOIN constituent_individual ci" => { "ci.id" => "p.constituent_id"},
						"JOIN membership m"							 => { "m.constituent_id" => "ci.id"},
						"JOIN constituent_group cg"			 => { "cg.id" => "m.group_id"}
					);	
	
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	my %ids;
	my $count = 0;
	while ( $self->nextObject() ) {
		my $record = $self->getObject();
		
		if ( !exists( $ids{ $record->{ci_id} } ) ) {
			$ids{ $record->{ci_id} } = $count;
			push @{ $details{receivers_list} }, $record;
			$count++;
		} else {
			$details{receivers_list}->[ $ids{ $record->{ci_id} } ]->{groupname} .= ", " . $record->{groupname};
		}
	}
	
	my $select2 = "pu.approved_by, to_char(pu.approved_on, 'DD-MM-YYYY HH24:MI:SS') AS approved_on_str, to_char(pu.published_on, 'DD-MM-YYYY HH24:MI:SS') AS published_on_str, pu.published_by, ";

	if ( $publication_type =~ /^advisory$/i ) {
		%join2 = ( "JOIN publication_advisory pa" => { "pa.publication_id" => "pu.id" } );
		$select2 .= "pa.title AS pub_title, pa.damage, pa.probability"	
	} else {
		$select2 .= "pu.title AS pub_title";
	}

	my ( $stmnt2, @bind2 ) = $self->{sql}->select( "publication pu", $select2, { "pu.id" => $publication_id } );

	$stmnt2 = $self->{dbh}->sqlJoin( \%join2, $stmnt2 ) if ( lc $publication_type eq "advisory" );	
	
	$self->{dbh}->prepare( $stmnt2 );
	$self->{dbh}->executeWithBinds( @bind2 );
	
	$details{publication} = $self->{dbh}->fetchRow();
	
	return \%details;
}

sub setAnalysisToDoneStatus {
	my ( $self, $publicationId, $namedPublicationId ) = @_;
	undef $self->{errmsg};
	
	my $error = '';
	my $openDoneStatusSettings = Taranis::Config->getSetting( "analyze_published_status" );

	my $openDoneStatusSettingsCopy = $openDoneStatusSettings;
	
	$openDoneStatusSettingsCopy =~ s/\s//g;
	
	if ( $openDoneStatusSettingsCopy !~ /^([^:,]+:[^:,]+,)*[^:,]+:[^:,]+$/ || !$openDoneStatusSettingsCopy ) {	
		$self->{errmsg} = "Incorrect setting found. Cannot change the status of linked analysis. Please check the setting analyze_published_status in the main configuration.";
		return 0;
	} 
	
	my @openDoneStatusPairs = split( /,/, $openDoneStatusSettings ); 
	
	my %openDoneRegister;
	foreach my $pair ( @openDoneStatusPairs ) {
		$pair = trim $pair;
		$pair =~ /(.*?):(.*?)$/;

		my $openStatus = $1;
		my $doneStatus = $2;

		$openDoneRegister{ trim( lc( $openStatus ) ) } = trim( lc( $doneStatus ) );
	}

	my %analyzeWhere = ( 'ap.publication_id' => $publicationId );

	my ( $analyzeStmnt, @analyzeBind ) = $self->{sql}->select( 'analysis a', 'a.id, a.status', \%analyzeWhere );
	my %join = ( 'JOIN analysis_publication ap' => { 'ap.analysis_id' => 'a.id'} );
	
	$analyzeStmnt = $self->{dbh}->sqlJoin( \%join, $analyzeStmnt );

	$self->{dbh}->prepare( $analyzeStmnt );
	$self->{dbh}->executeWithBinds( @analyzeBind );
	
	my @analysis;
	while ( $self->nextObject() ) {
		push @analysis, $self->getObject();
	}
	
	my @doneStatuses = values( %openDoneRegister );

	my $analysisCount = 0;
	
	ANALYSIS:
	foreach my $analyze ( @analysis ) {
		
		next ANALYSIS if ( grep( /^$analyze->{status}$/i, @doneStatuses ) ); 
		
#		my $doneStatus = ( exists( $openDoneRegister{ lc( $analyze->{status} ) } ) ) ? $openDoneRegister{ lc( $analyze->{status} ) } : 'done';

		my %where = ( id => $analyze->{id}, 'upper(status)' => uc( $analyze->{status} ) );

		my $dateTime = nowstring(7);
#		my $appendComments = "comments || '\n\n[== Taranis ( $dateTime CET) ==]\n Set to status Done, publication $namedPublicationId has been published.'";
    my $appendComments = "comments || '\n\n[== Taranis ( $dateTime CET) ==]\n Publication $namedPublicationId has been published.'";

# it was requested to disable the done status, but keep the comment field.
#		my ( $updateStmnt, @updateBind ) = $self->{sql}->update( 'analysis', { status => $doneStatus, comments => \$appendComments }, \%where );
    my ( $updateStmnt, @updateBind ) = $self->{sql}->update( 'analysis', { comments => \$appendComments }, \%where );		
		
		$self->{dbh}->prepare( $updateStmnt );
	
		if ( defined( $self->{dbh}->executeWithBinds( @updateBind ) ) < 1 ) {
			$error = $self->{dbh}->{db_error_msg} . "\n";
		} else {
			$analysisCount++;
		}
	}

	if ( $error ) {
		$self->{errmsg} = $error;
		return 0;
	} else {
		return $analysisCount;
	}
}


=head1 NAME 

Taranis::Publish

=head1 SYNOPSIS

  use Taranis::Publish;

  my $obj = Taranis::Publish->new();

  $obj->getNextAdvisoryId();
  
  $obj->nextObject();
  
  $obj->getObject();
  
  $obj->getConstituentGroupIdsForPublication( $publication_id, \@software_hardware_list );
  
  $obj->getConstituentGroupsForPublication( $publication_type_id );
  
  $obj->getIndividualsForSending( $publication_type_id, \@constituent_group_ids );
  
  $obj->sendPublication( 
  			 addresses       => \@email_addresses, 
  			 subject         => $email_subject, 
  			 msg             => $email_message_text,
  			 pub_type        => $publication_type,
  			 attach_xml      => $attach_xml,  			 
  			[xml_description => $xml_description,
  			 xml_filename    => $xml_filename ,
  			 xml_content     => $xml_txt,
  			 from_name       => $sender_name
  			 from_address    => $sender_email_address]
  			);
  
  $obj->setSendingResult( channel => $channel_nr, constituent_id => $id, publication_id => $publication_id, result => $result );
  
  $obj->generateCallingList( @constituent_group_ids );
  
  $obj->getPublishDetails( $publication_id, $publication_type );
  
=head1 METHODS

=head2 B<new>
  
Constructor of the Taranis::Publish class.

    my $obj = Taranis::Publish->new():

Creates a new database handler which can accessed by:

    $obj->{dbh};

Creates a new SQL::Abstract object which can be accessed by:

    $obj->{sql};
	  
Clears error message for the new object. Can be accessed by:
   
    $obj->{errmsg};	  

Returns the blessed object.	

=head2 B<getNextAdvisoryId>

Method for retrieving a new advisory ID.
  
Takes no arguments.

Example:
  
    $obj->getNextAdvisoryId();
  
Will create a advisory ID that is not used and directly follows the former advisory ID. Format of ID is for instance 'GOVCERT.NL-2009-004'. 
  
Note: The first time this method is called in a new year the ID will change the year and the sub number to 'GOVCERT.NL-2010-001'.
  
Returns a new advisory ID.

=head2 B<nextObject> & B<getObject>

Method to retrieve the list that is generated by a method like loadCollection.

This way of retrieval can be used to get data from the database one-by-one. Both methods don't take arguments.

Example:

    $obj->loadCollection( $args );

    while( $obj->nextObject ) {
        push @list, $obj->getObject;
    }

=head2 B<getConstituentGroupIdsForPublication> 

Method for extracting the ID's of constituent groups which should receive a publication based on the software/hardware that is linked to the publication.

Other factors that mather for group selection are:

=over

=item has the group got the option software/hardware list (sh list) disabled;

=item has the group got the status of enabled (status 0). 

=back

Takes two arguments:

=over

=item 1

publication id

=item 2

list of software/hardware ID's where further selection of constituent groups is based upon

=back

Example:

    $obj->getConstituentGroupIdsForPublication( 56, [ 25, 67, 89, 234 ] );
  
Returns a list of ID's of constituent groups. Sets $errmsg of this object to Taranis::Database->{db_error_msg} if database execution fails.

=head2 B<getConstituentGroupsForPublication>

Method for for retrieving all enabled groups for a specific publication type.
  
Takes the publication type id as argument:
  
    $obj->getConstituentGroupsForPublication( 4 ); 

Returns a list of constituent groups. Sets $errmsg of this object to Taranis::Database->{db_error_msg} if database execution fails.
  
=head2 B<getIndividualsForSending>

Method for retrieving sending details of constituent individuals which are member of the supplied groups and want to receive publications of the supplied publication type.

Takes two arguments:

=over

=item 1

publication type id

=item 2

list of constituent group id's

=back

Example:
  
    $obj->getIndividualsForSending( 23, [ 45, 78, 88, 89, 94 ] );
  
Returns a list of constituent individuals. Sets $errmsg of this object to Taranis::Database->{db_error_msg} if database execution fails.

=head2 B<sendPublication>

Method for sending publications through email.
  
Takes five mandatory and five optional arguments:

=over

=item 1

addresses, list of email addresses

=item 2

subject, subject of the email message

=item 3

msg, the text of email message

=item 4

pub_type, publication type ('advisory' or 'eow')

=item 5

attach_xml, boolean for specifying if an XML attachment should be send as an attachment to the email

=item 6

xml_description, description of the XML attachment (should be set if attach_xml is set to true)

=item 7

xml_filename, filename of the XML attachment (should be set if attach_xml is set to true)

=item 8

xml_content, the contents of the XML file as a string (should be set if attach_xml is set to true)

=item 9

from_name, name of the sender of the email (should be set if pub_type is 'eow')

=item 10

from_address, email address of the sender of the email (should be set if pub_type is 'eow')

=back

Example:
  
    $obj->sendPublication(
    			  addresses  => [ 'john.doe@domain.com', 'jane.doe@domain.com' ],
    			  subject    => 'subject of email message',
    			  msg        => 'email message',
    			  pub_type   => 'advisory',
    			  attach_xml => 0
    			 );

or

    $obj->sendPublication(
    			  addresses       => [ 'john.doe@domain.com', 'jane.doe@domain.com' ],
    			  subject         => 'subject of email message',
    			  msg             => 'email message',
    			  pub_type        => 'advisory',
    			  attach_xml      => 1,
    			  xml_description => 'my xml file description',
    			  xml_filename    => 'my_advisory.xml',
    			  xml_content     => $xml_content_string
    			 );
    			 
or

    $obj->sendPublication(
    			  addresses    => [ 'john.doe@domain.com', 'jane.doe@domain.com' ],
    			  subject      => 'subject of email message',
    			  msg          => 'email message',
    			  pub_type     => 'eow',
    			  attach_xml   => 0,
    			  from_name,   => 'James Doe',
    			  from_address => 'james.doe@domain.com'
    			 );
  
Note: All addresses will be put in the BCC field of the email.

Returns 'OK' if sending was successful. Returns Mail::Sender::Error if the SMTP server rejected the email.

=head2 B<setSendingResult>

Method for setting the sending result in table publication2constituent.

Takes four arguments:

=item 1

channel, channel number ( 1 = email, 2 = SMS, 3 = website publication, 4 = phone, 5 = XML )

=item 2

constituent_id, the ID of the constituent individual

=item 3

publication_id, the ID of the publcation

=item 4

result, result text

=back

Example:
  
    $obj->setSendingResult(
    			   channel        => 1,
    			   constituent_id => 34,
    			   publication_id => 789,
    			   result         => 'OK'
    			  );
   
Returns true if database execution is successful. Returns false if database execution is unsuccessful and sets $errmsg of this object to Taranis::Database->{db_error_msg}.  

=head2 B<generateCallingList>

Method for generating a calling list based on the supplied ID's of constituent groups.

Takes a list of ID's of constituent groups as argument:
  
    $obj->generateCallingList( [ 24, 34, 56, 89 ] ); 

Does a selection based on the hour of the day, counstituent group settings and constituent individual settings:

B<during working hours> (between 9h and 18h ) it searches the supplied constituent groups

=item which have set call for high/high incident to true

=item which have members who have 'DSC' in their role name.

=back

B<after working hours> (between 18h and 9h) it searches the supplied constituent groups

=item which have set call for high/high incident to true

=item which have member who have set call 24/7 to true

=back  
  
Returns an hash which holds the callinglist. 

=head2 B<getPublishDetails>

Method for retrieving the results of a published publication.
  
Takes two arguments:

=item 1

publication_id, the ID of the publication

=item 2

publication_type, type of publication ('advisory' or anything else)

=back

Example:

    $obj->getPublishDetails( 34, 'advisory' );

or

    $obj->getPublishDetails( 35, 'eow' );
    
Return the details of the published publication.  

=head1 AUTHOR

Sebastiaan van Achterbergh

May 29, 2009

=cut
1;
