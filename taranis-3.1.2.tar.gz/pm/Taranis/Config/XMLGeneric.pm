package Taranis::Config::XMLGeneric;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;
use XML::Simple;
use Data::Dumper;
use Taranis::Config;
use Data::Dumper;
use Taranis qw(:all);

my ($xs, $cdatastart, $cdataclose);

BEGIN {
    $xs = new XML::Simple( NormaliseSpace => 2, SuppressEmpty => '' );
    $cdatastart = '<![CDATA[';
    $cdataclose = ']]>';
}

sub new {
    my ( $class, $config_setting, $primary_key, $root_name, $normaliseSpace ) = @_;

    my $self = bless { config => Taranis::Config->new() }, $class;
		
		$self->{primary_key} 		= $primary_key;
		$self->{config_setting} = $config_setting;
		$self->{root_name} 			= $root_name;  
		
		$normaliseSpace = ( $normaliseSpace =~ /(0|1|2)/) ? $normaliseSpace : "";
		
    my $init = $self->init( $normaliseSpace );

    bless $self;
    return $self;
}

sub init {
    my ( $self, $normaliseSpace, $class ) = @_;

    my $configfile = $self->{config}->{ $self->{config_setting} };
		$self->{errmsg} = '';
		
		$normaliseSpace = ( $normaliseSpace eq '0' ) ? $normaliseSpace : 2;
		
    my $xml = eval { $xs->XMLin($configfile, ForceArray => qr/anon/ , NormaliseSpace => $normaliseSpace) };    # catch error in XML
    if ($@) { $self->{errmsg} = "error in XML $! $@\n"; }
		
		$self->{elements} = $xml;
    
    return $self;
}

sub loadCollection {
    my ( $self, $arg ) = @_;
    my $coll;
    if ( $arg && $self->{elements} ) {
    		my @elements = eval {@{ $self->{elements} }};
    		if ($@) { 
    		  $self->{errmsg} = "error in XML $! $@\n"; 
    		  return 0;
    		}
    		$arg =~ s/\+/\\\+/g; 
	    	foreach my $element (@elements) {
		        if ( $element->{$self->{primary_key}} =~ /.*$arg.*/i ) {
		        	push ( @$coll, $element );
		        }
	    	}    	
    } else {
    	$coll = $self->{elements};
    }
    return $coll;
}

sub loadCollectionBySearchField {
    my $self = shift;
    
    my $search_field = $_[0];
    my $search_value = $_[1];
    my $match_type 	 = $_[2]; 
    
    my $coll;
		my $search;
 		
 		my @elements = eval {@{ $self->{elements} }};
    if ($@) { 
    	  $self->{errmsg} = "error in XML $! $@\n"; 
    	  return 0;
    }
 		
 		$search = ( $match_type eq "EXACT_MATCH" ) ? "^$search_value\$" : ".*$search_value.*";

   	foreach my $element (@elements) {
		    if ( $element->{ $search_field } =~ /$search/i ) {
				   	push ( @$coll, $element );
		    }
	  }    	
    return $coll;	
}

sub getElement {
    my ( $self, $arg ) = @_;
    
 		my @elements = eval {@{ $self->{elements} }};
    if ($@) { 
    	  $self->{errmsg} = "error in XML $! $@\n"; 
    	  return 0;
    }
    
    # escape + sign with \+ for regex in foreach below 
    $arg =~ s/\+/\\\+/g; 
    
    foreach my $element (@elements) {
        if ( $element->{$self->{primary_key}} =~ /^$arg$/i ) {
            return $element;
        }
    }
	  return;
}

sub _writeXML {
	my ( $self ) = @_;

	my $out =  $self->{elements};
	my $outfile = $self->{config}->{ $self->{config_setting} };
    
	my $fh;
	eval{
		open $fh, ">", $outfile #or logErrorToSyslog("open($outfile): $!");
	};
  if ( $@ ) { 
  	$self->{errmsg} = $@;
  	return 0;
  }
    
  eval{
  	XMLout( $out, NoAttr => 1, RootName => $self->{root_name}, NoEscape => 1, OutputFile => $fh, SuppressEmpty => '' , XMLDecl => 1);
  };
  if ( $@ ) { 
  	$self->{errmsg} = $@;
  	return 0;
  }
    
  eval{
  	close $fh;
  };
  if ( $@ ) { 
  	$self->{errmsg} = $@;
  	return 0;
  }

  return 1;
}

sub addElement {
    my ( $self, @arg ) = @_;
    
    if ( @arg % 2 ) {
        $self->{errmsg} = "Default options must be name=>value pairs (odd number supplied)";
    }
    
    my %new_element = @arg;

		my $index;
		if ( $self->{elements} ) {
    	$index = @{ $self->{elements} };
		} else {
			$index = 0;
			$self->{elements} = [];
		}
   
   	foreach my $key ( keys %new_element ) {
			if ( q($new_element{$key}) ) {
   			$self->{elements}->[$index]->{$key} = $cdatastart . $new_element{$key} . $cdataclose;
			} else {
				$self->{elements}->[$index]->{$key} = "";
			}
   	}
   
		for ( my $i = 0 ; $i < $index ; $i++ ) {
		my $element = $self->{elements}->[$i];
			foreach my $key ( keys %$element ) {
				$self->{elements}->[$i]->{$key} = $cdatastart . $self->{elements}->[$i]->{$key} . $cdataclose if ( q($self->{elements}->[$i]->{$key}) );
			} 
    }

	return $self->_writeXML();   	
}

sub setElement {
    my ( $self, @arg ) = @_;

    if ( @arg % 2 ) {
    	$self->{errmsg} = "Default options must be name=>value pairs (odd number supplied)";
    }

    my %element = @arg;
    my $index = @{ $self->{elements} };

    for ( my $i = 0 ; $i < $index ; $i++ ) {
			my $orig_name = "orig_".$self->{primary_key};
    	if ( $self->{elements}->[$i]->{ $self->{primary_key} } eq $element{$orig_name} ) {
		   	delete $element{$orig_name};
		   	foreach my $key ( keys %element ) {
					if ( q($element{$key}) ) {
		   			$self->{elements}->[$i]->{$key} = $cdatastart . $element{$key} . $cdataclose;
					} else {
						$self->{elements}->[$i]->{$key} = "";
					}
		   	}
		  next;
      } 

			my $element = $self->{elements}->[$i];
			foreach my $key ( keys %$element ) {
				$self->{elements}->[$i]->{$key} = $cdatastart . $self->{elements}->[$i]->{$key} . $cdataclose if ( q($self->{elements}->[$i]->{$key}) );
			} 
    }
		return $self->_writeXML();  
}

sub deleteElement {
		my ( $self, $elementname ) = @_;

# TODO misschien moet deze hier ook komen
#    $elementname =~ s/\+/\\\+/g;
    
    my $index = @{ $self->{elements} };
    	
    for ( my $i = 0 ; $i < $index; $i++ ) {
    	if ( $self->{elements}->[$i]->{ $self->{primary_key} } eq $elementname ) {
      	splice (@{$self->{elements}}, $i, 1);
      	last;
      }
    }

		$index = @{ $self->{elements} };
		
		for ( my $i = 0 ; $i < $index ; $i++ ) {
			my $element = $self->{elements}->[$i];
			foreach my $key ( keys %$element ) {
				$self->{elements}->[$i]->{$key} = $cdatastart . $self->{elements}->[$i]->{$key} . $cdataclose if ( $self->{elements}->[$i]->{$key} );
			} 
	  }
    
		return $self->_writeXML();  
}

sub checkIfExists {
	my ( $self, $elementname ) = @_;
	
	# escape + sign with \+ for regex below
	
	$elementname =~ s/\+/\\\+/g;
	my $count = 0;
	if ( $self->{elements} ) {
		my @elements = @{ $self->{elements} };	
		
		foreach my $element (@elements) {
	  	if ( $element->{ $self->{primary_key} } =~ /^$elementname$/i ) {
	    	$count++;
	    }
	  }
	}	
	return $count;	
}

1;

=head1 NAME 

Taranis::Config::XMLGeneric

=head1 SYNOPSIS

  use Taranis::Config::XMLGeneric;
  
  my $obj = Taranis::Config::XMLGeneric->new( $config_setting, $primary_key, $root_name );
  
  $obj->init();
  
  $obj->loadCollection( [ $search_string ] );
  
  $obj->loadCollectionBySearchField( $search_field, $search_value, $match_type );
  
  $obj->getElement( $id );
  
  $obj->_writeXML();
  
  $obj->addElement( $key => $value );
  
  $obj->setElement( orig_name => $orginal_value_of_primary_key_field [ , $key => $value ]);
  
  $obj->deleteElement( $value_of_primary_key_field );
  
  $obj->checkIfExists( $value_of_primary_key_field );

=head1 METHODS

=head2 B<new>

  Constructor of the Taranis::Config::XMLGeneric class. Calling new will create a new blessed object.
  
  First argument is the fieldname of the desired config file. This fieldname is set in taranis.conf.xml.
  Second argument is the 'primary key'. This means values of these field should always be unique. 
  Third argument is the root name of the XML config file concerned.
  
    $obj = Taranis::Config::XMLGeneric->new( "parsersconfig", "parsername", "parsers" );

  This method calls init to load all data into the object.
  
  Returns the blessed object.
  
=head2 B<init>

  Loads the data from the XML file into the object.
  Method takes no arguments.
  
  Returns the object.
  
=head2 B<loadCollection>

  Method for retrieving data that's stored in the object.
  Takes one optional argument which is used to search the primary key field:
  
    $obj->loadCollection( 'govcert' );
  
  To retrieve all data from the object, call method without any arguments:
  
    $obj->loadCollection();
    
  Returns all found data.
  
=head2 B<loadCollectionBySearchField>

  Method for searching specific data.
  First argument holds the name of the field to search in.
  Second argument is the searchstring. 
  Third argument is the type of search that needs to be done. There are two options, namely exact matching (specify 'EXACT_MATCH'), and non exact matching (any string will do).
  
    $obj->loadCollectionBySearchField( 'host', 'www.waarschuwingsdienst.nl', 'EXACT_MATCH' );
  
  Returns all found data.
  
=head2 B<getElement>

  Method for retrieving one specific element (record).
  Takes one mandatory argument which is a string.
  
    $obj->getElement( 'quickndirty' );
    
  It does an exact match search.
  
  Returns the found element data.
  
=head2 B<_writeXML>

  Private method for writing the data stored in the $obj->{elements} to an XML file.
  
    $obj->_writeXML();
  
  Returns true if writing of XML file to disk is successful.
  Returns false if writing of XML file to disk is unsuccessful and sets $obj->{errmsg} to the corresponding error.

=head2 B<addElement>

  Method for adding elements (records) to the XML file.
  Arguments are not restricted but should be supplied in key => value pairs. Where key is the field name and value the data.
  
    $obj->addElement( idname => $idname, pattern => $pattern,	substitute => $substitute	);
    
  Returns _writeXML. 

=head2 B<setElement>

  Method for editing an element.
  Takes one mandatory argument, namely orig_name. Which corresponds with the original value of the primary key of the element that will be changed.
  Other arguments should be supplied in key => value pairs, where key is the field name and value the data.
  
    $obj->setElement( orig_name => 'quickndirty', link_prefix => 'test' );
  
  Returns _writeXML.

=head2 B<deleteElement>
  
  Method for deleting an element from the XML file.
  Takes the value of the primary key of the element that needs to be removed as argument. This is mandatory.
   
    $obj->deleteObject( 'quickndirty' );
    
  Returns _writeXML.

=head2 B<checkIfExists>

  Method for checking if a element with the supplied value exists.
  Takes the value of a primary key of an element. This is mandatory.
  
    $obj->checkIfExists( 'quickndirty' );
    
  Returns the number of elements that have the primary key value.
  (This should however always return 1 or 0);
  
=head1 AUTHOR

Sebastiaan van Achterbergh
Dec 24, 2008

=cut   
