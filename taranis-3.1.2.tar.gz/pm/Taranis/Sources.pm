package Taranis::Sources;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

our $VERSION = '0.1';

use strict;
use Taranis qw(:all);
use Taranis::Config;
use Taranis::Database;
use Data::Dumper;
use SQL::Abstract;
use GD::Simple;

sub new {

    my ( $self, $arg ) = @_;

    $self = bless {}, $self;

    my $init = $self->_init(@_);
    bless $init;
    return $init;
}


sub _init {

    my ( $self, $class ) = @_;
    my $obj = {
                config       => Taranis::Config->new(),
                dbh          => Taranis::Database->new(),
                sql          => SQL::Abstract->new(),
                dbtable      => 'sources',
                dbkey        => 'id',
                errmsg       => ''
    };

    return $obj;
}

*addElement = \&addSource;

sub addSource {
    my ( $self, %args ) = @_;
    undef $self->{errmsg};

    my $fullurl = $args{protocol} . $args{host} . ':' . $args{url};

    my ( $stmnt, @bind ) = $self->{sql}->insert( 'sources', \%args );

    $self->{dbh}->prepare($stmnt);
    $self->{dbh}->executeWithBinds(@bind);

    if ( defined( $self->{dbh}->{db_error_msg} ) ) {
        $self->{errmsg} = $self->{dbh}->{db_error_msg};
        return 0;
    }

    return 1;
}


*loadCollection = \&getSources;

sub getSources {
	my ( $self, %where ) = @_;
	undef $self->{errmsg};

	my $offset = delete $where{offset};
	my $limit  = delete $where{limit};
    
    $where{deleted} = 0;
    
	my $select = "s.id, s.digest, s.fullurl, s.host, s.mailbox, s.mtbc, s.parser, s.username, "
		. "s.password, s.protocol, s.port, s.sourcename, s.status, s.url, s.checkid, "
		. "s.enabled, s.archive_mailbox, s.delete_mail, s.category AS categoryId, " 
		. "c.name AS category, s.language, s.clustering_enabled, s.contains_advisory, s.create_advisory, s.advisory_handler";

	my ( $stmnt, @bind ) = $self->{sql}->select( 'sources s', $select, \%where, 's.sourcename' );

	my %join = ( 'JOIN category c' => { 'c.id' => 's.category' } );
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$stmnt .= defined( $limit ) ? ' LIMIT ' . $limit : '';
	$stmnt .= ( defined( $offset ) && defined( $limit ) ) ? ' OFFSET ' . $offset  : '';

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
    
	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
    }

	my @sources;
	
	while ( $self->nextObject() ) {
		push @sources, $self->getObject();
	}
		
	return \@sources;
}

sub getSourcesCount {
	my ( $self, %where ) = @_;
	undef $self->{errmsg};

	my $select = "COUNT(*) AS sources_count";

	my ( $stmnt, @bind ) = $self->{sql}->select( 'sources s', $select, \%where );
	$where{deleted} = 0;
	
	my %join = ( 'JOIN category c' => { 'c.id' => 's.category' } );
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
    
	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
    }

	my $countRecord = $self->{dbh}->fetchRow();

	return $countRecord->{sources_count};
}

sub getSource {
	my ( $self, $id ) = @_;
	undef $self->{errmsg};
	my %where = ( 's.id' => $id );
	
	my $select = "s.id, s.digest, s.fullurl, s.host, s.mailbox, s.mtbc, s.parser, s.username, "
		. "s.password, s.protocol, s.port, s.sourcename, s.status, s.url, s.checkid, "
		. "s.enabled, s.archive_mailbox, s.delete_mail, s.category AS categoryId, " 
		. "c.name AS category, s.language, s.clustering_enabled, s.contains_advisory, s.advisory_handler, s.create_advisory";  
  
	my ( $stmnt, @bind ) = $self->{sql}->select( 'sources s', $select, \%where, 'sourcename' );
	
	my %join = ( 'JOIN category c' => { 'c.id' => 's.category' } );
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
    
	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}

	my $hash_ref = $self->{dbh}->{sth}->fetchall_hashref( 'id' );
	my $source;
	while ( my ( $uKey, $uVal ) = ( each %$hash_ref ) ) {
		while ( my ( $key, $val ) = ( each %$uVal ) ) {
			if ( defined $val ) {
				$source->{$key} = $val ;
			} else {
				$source->{$key} = ''; #  emulate XMLGeneric behaviour
			}
		}
	}
              
	return $source;
}

sub getSourceByName {
    my ( $self, $arg ) = @_;
    undef $self->{errmsg};
    my %where = ( sourcename => $arg );
    
    if ( !defined( $where{sourcename} ) ) {
        $self->{errmsg} = "no sourcename supplied";
        return 0;
    }
    
    my $order = 'sourcename';
    my $dbkey = $self->{dbkey};
    
    my ( $stmnt, @bind ) = $self->{sql}->select( $self->{dbtable}, "*", \%where, $order );

    $self->{dbh}->prepare($stmnt);

    if ( defined( $self->{dbh}->{db_error_msg} ) ) {
        $self->{errmsg} = $self->{dbh}->{db_error_msg};
        return 0;
    }

    $self->{dbh}->executeWithBinds(@bind);
    
        if ( defined( $self->{dbh}->{db_error_msg} ) ) {
        $self->{errmsg} = $self->{dbh}->{db_error_msg};
        return 0;
    }

    my $hash_ref = $self->{dbh}->{sth}->fetchall_hashref($dbkey);
    my $return;
    while ( my ( $uKey, $uVal ) = ( each %$hash_ref ) ) {
        while ( my ( $key, $val ) = ( each %$uVal ) ) {
          if (defined $val) {
            $return->{$key} = $val ;
          } else {
            $return->{$key} = ''; #  emulate XMLGeneric behaviour
          }
        }
    }
              
    return $return;
    
}

sub getDistinctSources {
	my $self = shift;
	my @sources;
		
	my $stmnt = "SELECT DISTINCT sourcename FROM sources WHERE deleted = FALSE ORDER BY sourcename ASC;";
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds();
	
	while ( $self->nextObject() ) {
		push ( @sources, $self->getObject()->{sourcename} );
	}
	return \@sources;
}

sub deleteSource {
    my ( $self, $id ) = @_;
    undef $self->{errmsg};

    if ( !$id && $id !~ /^\d+$/ ) {
        $self->{errmsg} = "invalid input supplied";
        return 0;
    }

	my ( $stmnt, @bind );

	if ( $self->{dbh}->checkIfExists( { source_id => $id }, "item" ) ) {
		( $stmnt, @bind ) = $self->{dbh}->{sql}->update( 'sources', { deleted => 1 }, { id => $id } );
	} else {
		( $stmnt, @bind ) = $self->{dbh}->{sql}->delete( 'sources', { id => $id } );
	}
 
	$self->{dbh}->prepare($stmnt);
	my $result = $self->{dbh}->executeWithBinds(@bind);
	if ( defined($result) && ( $result !~ m/(0E0)/i ) ) {
		if ( $result > 0 ) {
			return 1;
		} elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			return 0;
		}
	} else {
		$self->{errmsg} = "Delete failed, corresponding id not found in database.";
		return 0;
	}
}

sub setSource {
	my ( $self, %update ) = @_;
	undef $self->{errmsg};

	if ( !defined( $update{id} ) ) {
		$self->{errmsg} = "invalid input";
		return 0;
	}

	my %where = ( id => $update{id} );
	delete $update{id};

	my ( $stmnt, @bind ) = $self->{sql}->update( 'sources', \%update, \%where );

	$self->{dbh}->prepare($stmnt);
	$self->{dbh}->executeWithBinds(@bind);

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}

	return 1;
}

sub createSourceIcon {
    my ( $self, $sourceName ) = @_;
    my ( $fontSize, $x_offset, $y_offset );
	 
    # determine fontsize for icon image
    for ( length($sourceName) ) {
      if (/^(2)$/) {
        $fontSize = 21;
        $x_offset = 20;
        $y_offset = 25;
      } elsif (/^3$/) {
        $fontSize = 21;
        $x_offset = 12;
        $y_offset = 25;        
      } elsif (/^4$/) {
        $fontSize = 20;
        $x_offset = 4;
        $y_offset = 25;       
      } elsif (/^5$/) {
        $fontSize = 16;
        $x_offset = 4;
        $y_offset = 22;       
      } elsif (/^6$/) {
        $fontSize = 13;
        $x_offset = 4;
        $y_offset = 22;
      } else {
        $fontSize = 12;
        $x_offset = 4;
        $y_offset = 22;               
      }
    }   
   
    # create source icon image
    my $img = GD::Simple->new(72,30);
    $img->bgcolor('white');
    $img->fgcolor('black');
    $img->rectangle(0,0,71,29);
    $img->fontsize($fontSize);
    $img->font('courier:bold');
    $img->moveTo($x_offset,$y_offset);
  
    my $sourceNameForIcon = $sourceName;
    
    if ( length( $sourceNameForIcon ) > 7 ) {
      $sourceNameForIcon = substr( $sourceNameForIcon, 0, 6 ) . "."; 
    }
    
    $img->string( $sourceNameForIcon );
	 
	  return $img->gif;
}

sub nextObject {
    my ($self) = @_;
    return $self->{dbh}->nextRecord;
}

sub getObject {
    my ($self) = @_;
    return $self->{dbh}->getRecord;
}

1;

=head1 NAME 



=head1 SYNOPSIS Taranis::Sources


=head1 QUICK START

use Taranis::Sources;
my $s = Taranis::Sources->new();

=head2  B<getSources()>

get all sources, return an Array of Hashes

=head2  B<addSource()>

Add a source record to DB.
$s->addSource(
          'mtbc' => '60',
          'protocol' => 'http://',
          'status' => '',
          'parser' => 'xml',
          'password' => '',
          'url' => '/feed?format=xml',
          'category' => 'news',
          'sourcename' => 'DAG',
          'fullurl' => 'http://feeds.dag.nl:80/DAGnieuwsfeed?format=xml',
          'checkid' => '0',
          'port' => '80',
          'host' => 'feeds.dag.nl',
          'username' => '',
          'mailbox' => '',
          'digest' => '6bjRkkdeSfh4d8xVML5ObA'
);


=head1 METHODS

=head2  B<$s->getSources()>

my $sources = $s->getSources();
returns an array of hashes.

foreach my $source (@$sources) {
  # do something with every source
  ...
}

=head2 B<getSourceByName()>

my $source = $s->getSourceByName('sourcename');

returns a hash with source data

=head2 B<getSource($id)>

retrieve a source by Database ID.
my $source = $s->getSource($id);

returns a hash with source data

=head2 B<deleteSource($id)>

delete a given source.


=head1 AUTHOR

jeroen
31-mrt-2009

=cut
