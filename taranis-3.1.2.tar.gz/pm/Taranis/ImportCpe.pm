package Taranis::ImportCpe;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:all);
use Taranis::Database;
use Taranis::SoftwareHardware;
use Tie::IxHash;
use SQL::Abstract;
use strict;

sub new {
	shift @_;
	
	my $self = {
		errmsg 	=> undef,
		dbh 		=> Taranis::Database->new(),
		sql 		=> SQL::Abstract->new()
	};
	bless $self;
	return $self;	
}

sub addCpeImportEntry {
	my ( $self, %inserts ) = @_;
	undef $self->{errmsg};  
	
	my ( $stmnt, @bind ) = $self->{sql}->insert( "software_hardware_cpe_import", \%inserts );
	$self->{dbh}->prepare( $stmnt );
	
	if ( defined( $self->{dbh}->executeWithBinds( @bind ) ) > 0 ) {
		return 1;
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}
}

sub isLinked {
	my ( $self, $cpe_id ) = @_;
	undef $self->{errmsg};
	my $stmnt = "SELECT 
	( 
		SELECT COUNT(*) FROM platform_in_publication pl
		JOIN software_hardware sh ON sh.id = pl.softhard_id
		WHERE sh.cpe_id = ? 
	) 
	+
	( 
		SELECT COUNT(*) FROM product_in_publication pr 
		JOIN software_hardware sh ON sh.id = pr.softhard_id
		WHERE sh.cpe_id = ?
	) 
	+
	( 
		SELECT COUNT(*) FROM soft_hard_usage shu
		JOIN software_hardware sh ON sh.id = shu.soft_hard_id
		WHERE sh.cpe_id = ?
	) 
	AS cnt";
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( $cpe_id, $cpe_id, $cpe_id );
	
	my $count = $self->{dbh}->fetchRow();
	
	return ( $count ) ? 1 : 0;
}

sub loadCollection {
	my ( $self, %settings ) = @_;
	
	my $limit = delete( $settings{limit} ) if ( exists( $settings{limit} ) );
	
	my ( $stmnt, @bind ) = $self->{sql}->select( 'software_hardware_cpe_import', '*', \%settings, 'producer, name, version' );
	
	$stmnt .= " LIMIT " . $limit if ( $limit );
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	my @softwareHardware;
	while ( $self->nextObject() ) {
		push @softwareHardware, $self->getObject();
	}
	
	return \@softwareHardware;
}

sub importCpeEntry {
	my ( $self, %import ) = @_;
	
	$import{monitored} = 'f';
	
	my ( $stmnt, @bind ) = $self->{sql}->insert( 'software_hardware', \%import );
	
	$self->{dbh}->prepare( $stmnt );
	
	if ( defined( $self->{dbh}->executeWithBinds( @bind ) ) > 0 ) {
		return 1;
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}	
}

sub getUniqueProducts {
	my ( $self ) = @_;
	
	my $stmnt = 
"SELECT producer, name, type FROM software_hardware_cpe_import
GROUP BY producer, name, type 
ORDER BY producer, name, type";	

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds();
	
	my @products;
	
	while ( $self->nextObject() ) {
		push @products, $self->getObject();
	}
	
	return \@products;
}

sub deleteImportEntry {
	my ( $self, %delete ) = @_;
	undef $self->{errmsg};
	
	my $table = ( $delete{table} ) ? delete( $delete{table} ) : 'software_hardware_cpe_import';
	
	my ( $stmnt, @bind ) = $self->{sql}->delete( $table, \%delete );
	
	$self->{dbh}->prepare( $stmnt );
	
	if ( $self->{dbh}->executeWithBinds( @bind) > 0 ) {
		return 1;
	} elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	} else {
		$self->{errmsg} = "Delete failed, corresponding id not found in database.";
		return 0;
	}			
}

sub deleteAllImportEntries {
	my ( $self ) = @_;
	
	my $stmnt = "DELETE FROM software_hardware_cpe_import";
	
	$self->{dbh}->prepare( $stmnt );
	
	if ( $self->{dbh}->executeWithBinds() > 0 ) {
		return 1;
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	} 	
}

sub nextObject {
    my ($self) = @_;
    return $self->{dbh}->nextRecord;
}

sub getObject {
    my ($self) = @_;
    return $self->{dbh}->getRecord;
}

1;
