package Taranis::Cluster;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Database;
use Taranis qw(:all);
use SQL::Abstract;
use strict;

sub new {
	my $class = shift;
    
	my $self = {
		errmsg => undef,
		dbh => Taranis::Database->new(),
		sql => SQL::Abstract->new()
	};
	bless $self;
	return $self;
}

sub nextObject {
	my ( $self ) = @_;
	return $self->{dbh}->nextRecord();
}

sub getObject {
	my ( $self ) = @_;
	return $self->{dbh}->getRecord();		
}

sub getCluster {
	my ( $self, %where ) = @_;
	undef $self->{errmsg};
	my @clusters; 
	
	my ( $stmnt, @bind ) = $self->{sql}->select( "cluster cl", "cl.*, ca.name", \%where, "ca.name, cl.language" );
	
	my %join = ( 'JOIN category ca' => { 'ca.id' => 'cl.category_id ' } );
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		 $self->{errmsg} = $self->{dbh}->{db_error_msg};
		 return 0;
	} else {
		while ( $self->nextObject ) {
			push ( @clusters, $self->getObject );
		}	
		
		if ( scalar @clusters > 1 ) {
			return @clusters;
		} else {
			return $clusters[0];
		}		
	}
}

sub setCluster {
  my ( $self, %updates ) = @_;
	undef $self->{errmsg};
  
  my %where = ( id => $updates{id} ); 
  delete $updates{id};
  
	my ( $stmnt, @bind ) = $self->{sql}->update( "cluster", \%updates, \%where );
	$self->{dbh}->prepare( $stmnt );
	
	my $result = $self->{dbh}->executeWithBinds( @bind );
	
	if ( defined( $result ) && ( $result !~ m/(0E0)/i ) ) {		
		if ( $result > 0 ) {
			return 1;
		} elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			return 0;
		} 
	} else {
		$self->{errmsg} = "Update failed, corresponding id not found in database.";
		return 0;
	}
}

sub addCluster {
  my ( $self, %inserts ) = @_;
	undef $self->{errmsg};  
	
	my ( $stmnt, @bind ) = $self->{sql}->insert( "cluster", \%inserts );
	$self->{dbh}->prepare( $stmnt );
	
	if ( defined( $self->{dbh}->executeWithBinds( @bind ) ) > 0 ) {
		return 1;
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}
}

sub deleteCluster {
	my ( $self, $id ) = @_;
	undef $self->{errmsg};
	
	my ( $stmnt, @bind ) = $self->{sql}->delete( 'cluster', { id => $id } );
	$self->{dbh}->prepare( $stmnt );
	
	if ( $self->{dbh}->executeWithBinds( @bind) > 0 ) {
		return 1;
	} elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	} else {
		$self->{errmsg} = "Delete failed, corresponding id not found in database.";
		return 0;
	}		
}
1;