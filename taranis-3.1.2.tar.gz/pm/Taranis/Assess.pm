package Taranis::Assess;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Database;
use Taranis::Category;
use strict;
use SQL::Abstract;
use Data::Validate qw(:math);
use Taranis qw(:all);
use Tie::IxHash;

my %statusDictionary = ( 
	0 => 'unread',
	1 => 'read',
	2 => 'important',
	3 => 'waitingroom'
);

sub new {
	shift @_;
	
	my $self = {
		result_count 	=> undef,
		errmsg 				=> undef,
		dbh 					=> Taranis::Database->new(),
		sql 					=> SQL::Abstract->new()
	};
	bless $self;
	return $self;	
}

sub loadAssessCollection {
	my ( $self, %searchFields ) = @_;
	undef $self->{errmsg};

	my $limit  = ( $searchFields{limit} ) ? sanitizeInput( "only_numbers", delete ( $searchFields{limit}  ) ) : undef;
	my $offset = ( $searchFields{offset} ) ? sanitizeInput( "only_numbers", delete ( $searchFields{offset} ) ) : undef;
	
	$offset = ( $offset - 1 ) * $limit;
	
############################################ part 1 of sql statement #############################################
	my %nests;

	my %where;
	if ( $searchFields{startdate} && $searchFields{enddate} ) {
		$searchFields{startdate} = formatDateTimeString( $searchFields{startdate} );
		$searchFields{enddate} = formatDateTimeString( $searchFields{enddate} );
		$where{'i1.created'} = {-between => [$searchFields{startdate}." 000000", $searchFields{enddate}." 235959"] };	
	}	
	
	if ( exists( $searchFields{status} ) && scalar( @{ $searchFields{status} } ) != 4  ) {
		my @status;
		foreach (  @{ $searchFields{status} } ) {
			push @status, 'i1.status' => $_;
		}
		$nests{status} = \@status;
	}

	$nests{title_description} = [
																		'i1.title' => { ilike => "%".$searchFields{search}."%"},
																		'i1.description' => { ilike => "%".$searchFields{search}."%"}	
														 	] if ( $searchFields{search} );
	
	if ( exists( $searchFields{category} ) &&  @{ $searchFields{category} } ) {
		
		my $ca = Taranis::Category->new();
		
		my @allCategories = $ca->getCategory( is_enabled => 1  );

		if ( scalar( @allCategories ) != scalar( @{ $searchFields{category} } ) ) {
	  	my @category;
	  	foreach (  @{ $searchFields{category} } ) {
	  		push @category, 'i1.category' => $_;
	  	}
			$nests{category} = \@category;
		}
  }

	if ( $searchFields{source} && @{ $searchFields{source} } > 0 ) {
  	my @sources;
  	foreach (  @{ $searchFields{source} } ) {
  		push @sources, 'i1.source' => { ilike => $_ };
  	}
		$nests{sources} = \@sources;
  }

	foreach my $nest ( values %nests ) {
		push @{ $where{-and} }, -nest => $nest; 
	}

	my $select = "i1.digest, to_char(created, 'DD-MM-YYYY HH24:MI:SS') AS item_date, i1.source, i1.title, i1.link, "
				. "i1.is_mail, i1.description, i1.status, i1.created, c1.name AS category, "
				. "ROUND(i1.cluster_score, 1) AS cluster_score, i1.cluster_id, i1.cluster_enabled, EXTRACT( EPOCH FROM date_trunc('seconds', i1.created) ) AS created_epoch";

	my ( $stmnt_part1, @bind ) = $self->{sql}->select( "item i1", $select, \%where );
	
	my $join1 = { "JOIN category c1" => { "c1.id" => "i1.category" } };
	
	$stmnt_part1 = $self->{dbh}->sqlJoin( $join1, $stmnt_part1 );

#################################### end of part 1 of sql statement ##############################################	

########################################### part 2 of sql statement ##############################################	

	delete $where{-and};
	delete $nests{title_description};
	
	foreach my $key ( keys %where ){
		my $newKey = $key;
		$newKey =~ s/i1/i2/i;
		$where{ $newKey } = $where{ $key };
		delete $where{ $key };
	}

	foreach my $nest ( keys %nests ) {
		if ( $nest =~ /^status$/ ) {
			for ( my $i = 0; $i < @{ $nests{ $nest } }; $i++ ) {
				$nests{ $nest }[ $i ] = "i2.status" if ( $nests{ $nest }[ $i ] eq "i1.status");
			} 
		} elsif ( $nest =~ /^category$/ ) {
			for ( my $i = 0; $i < @{ $nests{ $nest } }; $i++ ) {
				$nests{ $nest }[ $i ] = "i2.category" if ( $nests{ $nest }[ $i ] eq "i1.category");
			} 
		} elsif ( $nest =~ /^sources/ ) {
			for ( my $i = 0; $i < @{ $nests{ $nest } }; $i++ ) {
				$nests{ $nest }[ $i ] = "i2.source" if ( $nests{ $nest }[ $i ] eq "i1.source");
			} 
		} 
	}

	foreach my $nest ( values %nests ) {
		push @{ $where{-and} }, -nest => $nest; 
	}

	$where{"identifier.identifier"} = { ilike => "%".$searchFields{search}."%"} if ( $searchFields{search} );			

	$select =~ s/i1/i2/g;
	$select =~ s/c1/c2/g;
	
	my ( $stmnt_part2, @bind_part2 ) = $self->{sql}->select( "item i2", $select, \%where );
	my $join2 = { 
								"JOIN identifier" => { "identifier.digest" => "i2.digest" },
								"JOIN category c2" => { "c2.id" => "i2.category" }
							};
	$stmnt_part2 = $self->{dbh}->sqlJoin( $join2, $stmnt_part2 );
		
#################################### end of part 2 of sql statement ##############################################
	
	my $orderBy;
	
	if ( exists( $searchFields{sorting} ) && $searchFields{sorting} ) {
		my @sort = split( '_', $searchFields{sorting} );
		
		$orderBy = ( 
									scalar( @sort ) == 2 && 
									$sort[0] =~ /^(created|source|title)$/ && 
									$sort[1] =~ /^(asc|desc)$/ 
								)
									? "ORDER BY " . $sort[0] . " " . uc( $sort[1] )
									: ""; 
	}	else {
		$orderBy = "ORDER BY created DESC";
	}
	
#	my $stmnt = "SELECT * FROM (($stmnt_part1) UNION ($stmnt_part2)) AS item $orderBy LIMIT $limit OFFSET $offset;";
	my $stmnt = "SELECT * FROM (($stmnt_part1) UNION ($stmnt_part2)) AS item $orderBy";
	$stmnt .= " LIMIT $limit OFFSET $offset;" if ( $limit =~ /^\d+$/ && $offset =~ /^\d+$/ );
	
	push @bind, @bind_part2;

#	$self->{result_count} = $self->{dbh}->setResultCount( $stmnt, @bind );
	$self->{dbh}->prepare( $stmnt );
	my $result = $self->{dbh}->executeWithBinds( @bind );

	$self->{errmsg} = $self->{dbh}->{db_error_msg};

	return $result;
}

sub getDistinctSources {
	my ( $self, @assessCategories ) = @_;
	my @sources;
	
	my @where = ( category => @assessCategories );
	
	my ( $stmnt, @bind ) = $self->{sql}->select( 'sources', 'DISTINCT( sourcename )', \@where, 'sourcename ASC' );
		
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	while ( $self->nextObject() ) {
		push ( @sources, $self->getObject()->{sourcename} );
	}
	return @sources;
}

sub setItemStatus {
	my ( $self, %args ) = @_;
	undef $self->{errmsg};
	
	my %where = ( digest => $args{digest}, status => { "!=", 3 } );
	
	my %fieldvals = ( status => $args{status} );

	my ( $stmnt, @bind ) = $self->{sql}->update( "item", \%fieldvals, \%where );

	$self->{dbh}->prepare( $stmnt );
	
	my $result = $self->{dbh}->executeWithBinds( @bind );

	if ( defined( $result ) && ( $result !~ m/(0E0)/i ) ) {
		if ( $result > 0 ) {
			return 1;
		} elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			$self->{errorIsSet} = 1;
			return 0;
		}
	} elsif ( $result =~ /^0E0$/ ) {
		$self->{errmsg} = "No items have been changed. Perhaps you tried to change items with status 'waitingroom'.";
		return 0;				
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		$self->{errorIsSet} = 1;
		return 0;		
	}	
}

sub getItem {
	my ( $self, $digest, $searchArchive ) = @_;
	
	my %where = ( 'i.digest' => $digest );
	
	my $table = ( $searchArchive ) ? 'item_archive' : 'item';
	
	my $select = "i.digest, i.id, i.date, i.time, i.source, i.title, i.link, "
								. "i.description, i.status, i.created, i.is_mail, i.is_mailed, "
								. "c.name AS category, to_char(created, 'DD-MM-YYYY HH24:MI:SS') as item_date";
	
	my ( $stmnt, @bind ) = $self->{sql}->select( "$table i", $select, \%where );

	my %join = ( 'JOIN category c' => { 'c.id' => 'i.category' } );
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	$self->{errmsg} = $self->{dbh}->{db_error_msg};
	
	my $item = $self->{dbh}->fetchRow(); 
	
	if ( $item ) {
		$item->{isArchived} = ( $searchArchive ) ? 1 : 0;
	}
	
	return $item; 	
}

sub getMailItem {
	my ( $self, $id ) = @_;
	
	undef $self->{errmsg};
	
	my %where = ( 'email_item.id' => $id );
	
	my ( $stmnt, @bind ) = $self->{sql}->select( 'email_item', "email_item.*, item.title, category.name AS category", \%where );
	
	tie my %join, "Tie::IxHash";
	%join = ( 
						'JOIN item' => { 'item.digest' => 'email_item.digest' },
						'JOIN category' => { 'item.category' => 'category.id' } 
					);
	
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}

	return $self->{dbh}->fetchRow();
}

sub getRelatedIdDescription {
  my ( $self, $id ) = @_;
  my $table = 'identifier_description';
  
  #select description from identifier_description where identifier=
  my %where = (identifier => uc( $id ) );
  my ( $stmnt, @bind ) = $self->{sql}->select( $table, "*", \%where,  );
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );	
	
	my $return;
	
    if ( $self->nextObject() ) {      
        $return =  $self->getObject();
        
    } else {
        $self->{errmsg} = "No description available.";
        return 0;          
    }
    
  $table = 'publication_advisory pa';
  my $select = 'max(pa.id) AS id, govcertid';
  %where = ( ids => { -ilike => '%'. $id .'%' }, status => 3 );
  
  ( $stmnt, @bind ) = $self->{sql}->select( $table, $select, \%where);

  my %join = ( "JOIN publication p" => { "pa.publication_id" => "p.id" } );

	$stmnt = $self->{dbh}->sqlJoin( \%join , $stmnt );

	$stmnt .= ' GROUP BY govcertid';

  $self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	my @ids;	
	while ( $self->nextObject ) {
		push @ids, $self->getObject();
	}
	
	 $return->{ids} = \@ids;	 	 
   return $return;
	
}

sub getRelatedIds {
	my ( $self, $digest ) = @_;
	my @ids;
	
	my %where = ( digest => $digest );
	my ( $stmnt, @bind ) = $self->{sql}->select( "identifier", "identifier", \%where, "identifier" );
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	while ( $self->nextObject ) {
		push @ids, $self->getObject->{identifier};
	}
	return \@ids;
}

sub getRelatedIdsBulk {
	my ( $self, %where ) = @_;
	
	my ( $stmnt, @bind ) = $self->{sql}->select( "identifier", "identifier, digest", \%where, "identifier" );
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	my %ids;
	while ( $self->nextObject ) {
		my $record = $self->getObject();
		if ( exists( $ids{$record->{digest} } ) ) {
			push @{ $ids{ $record->{digest} } }, $record->{identifier};
		} else {
			$ids{ $record->{digest} } = [ $record->{identifier} ];
		}
	}
	return \%ids;
}

sub getRelatedItemsIdMatch {
	my ( $self, $digest ) = @_; 

	my %where = ( digest => $digest );
	
	my ( $sub_select, @bind ) = $self->{sql}->select( "identifier", "identifier", \%where );  
	
	$sub_select = "($sub_select)";

	%where = ( "identifier.digest" => {"!=", $digest }, 
						 "identifier.identifier IN" => \$sub_select
						);
	
	my ( $sub_select2, @bind_part2 ) = $self->{sql}->select( "identifier", "distinct(identifier.digest)", \%where );
	my $join = { "JOIN item" => {"identifier.digest" => "item.digest"} };

	$sub_select2 = $self->{dbh}->sqlJoin( $join, $sub_select2 );
	$sub_select2 = "($sub_select2)";	
	
	push @bind, @bind_part2;

	%where = ( "digest IN" => \$sub_select2 ); 

	my ( $stmnt, @bind_part3 ) = $self->{sql}->select( "item", "item.*, to_char(created, 'DD-MM-YYYY HH24:MI:SS') as item_date, is_mail", \%where,	"created DESC");
	
	push @bind, @bind_part3;

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	$self->{errmsg} = $self->{dbh}->{db_error_msg};
	
	my @items;
	while ( $self->nextObject ) {
		my $record = $self->getObject();
		$record->{status_description} = $statusDictionary{ $record->{status} };
		push @items, $self->getObject;
	}

	return \@items;
}

sub getRelatedItemsKeywordMatch {
	my ( $self, $digest, @keywords ) = @_;

	my %temp;
	my ( @nest, @where );
	
	if ( scalar @keywords > 1 ) {
	  for ( my $i = 0; $i < @keywords; $i++ ) {
	    for ( my $j = 0; $j < @keywords; $j++ ) {
	      if ( $i != $j && ( $j > $i ) ) {
	      	%temp = ( "-and" => 
	      								[ 
	      									title => { -ilike, "%".$keywords[$i]."%"  }, 
	      									title => {-ilike, "%".$keywords[$j]."%" } 
	      								] 
	      					);
					push @nest, %temp;
	      }
		  }
	  }
	
		@where = (
							-and => [ 
									digest => { '!=', $digest  }, 
									-nest => [ \@nest ]
								] );
	} else {
		@where = ( 		
							-and => [ 
									digest => { '!=', $digest  }, 
									title => { -ilike => '%' . $keywords[0] . '%' }
								] );
	}
	
	my ( $stmnt, @bind ) = $self->{sql}->select( "item", "source, title, link, description, status, to_char(created, 'DD-MM-YYYY HH24:MI:SS') AS item_date, is_mail", \@where, "created DESC" );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	$self->{errmsg} = $self->{dbh}->{db_error_msg};
	
	my @items;
	while ( $self->nextObject ) {
		my $record = $self->getObject();
		$record->{status_description} = $statusDictionary{ $record->{status} };
		push @items, $self->getObject;
	}

	return \@items;
}

sub nextObject {
	my ( $self ) = @_;
	return $self->{dbh}->nextRecord;
}

sub getObject {
	my ( $self ) = @_;
	return $self->{dbh}->getRecord;		
}

sub setIsMailedFlag {
	my ( $self, $digest ) = @_;
	
	if ( !$digest ) {
		$self->{errmsg} = 'Item id missing.';
		return 0;
	}
	
	my ( $stmnt, @bind ) = $self->{sql}->update( 'item', { 'is_mailed' => 1 }, { digest => $digest } );
	
	$self->{dbh}->prepare( $stmnt );
	
	my $result = $self->{dbh}->executeWithBinds( @bind );

	if ( defined($result) && ($result !~ m/(0E0)/i) ) {
		if ( $result > 0 ) {
			return 1;
		} elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			return 0;
		}
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;		
	}		
}

#TODO: replace other item-update subs with setItem
sub setAssessItem {
	my ( $self, %update ) = @_;
	
	if ( !exists( $update{digest} ) ) {
		$self->{errmsg} = 'Item id missing.';
		return 0;
	}
	
	my $itemDigest = delete $update{digest};
	
	my ( $stmnt, @bind ) = $self->{sql}->update( 'item', \%update, { digest => $itemDigest } );
	
	$self->{dbh}->prepare( $stmnt );
	
	my $result = $self->{dbh}->executeWithBinds( @bind );

	if ( defined($result) && ($result !~ m/(0E0)/i) ) {
		if ( $result > 0 ) {
			return 1;
		} elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			return 0;
		}
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;		
	}	
}

sub getAttachmentInfo {
	my ( $self, $entity, $info ) = @_;
	
	if ( $entity->parts() ) {
		foreach my $part ( $entity->parts() ) {
			if ( my $localInfo = $self->getAttachmentInfo( $part, $info ) ) {
				$info = $localInfo;
			}
		}
	} else {
		
		my $head 							 = $entity->head();
		my $contentType 			 = $head->mime_type();
		my $contentDisposition = $head->mime_attr( 'content-disposition' );
		
		$contentDisposition = "" if ( !$contentDisposition );
		
		my $fileName = $head->recommended_filename;
		$fileName = "noname" if ( !$fileName );
		
		my $fileType = "";
		
		return 0 if( 
									( $contentType !~ /^application/ && $contentDisposition !~ /^attachment/i )
									&& $contentType !~ /^(image|audio|video)/i 
								);
			
		( $fileType ) = $contentType =~ /.*?\/(.*)/i;
		
		my $attachment;

		$attachment->{filename} = $fileName if ( $fileName );
		$attachment->{filetype} = $fileType if ( $fileType );

		$info->{ $fileName } = $attachment if ( $attachment );
	}

	return $info;
}

sub getAttachment {
	my ( $self, $entity, $name ) = @_;
	
	my $attachment;
	
	if ( $entity->parts() ) {
		foreach my $part ( $entity->parts() ) {
			if ( my $attachmentText = $self->getAttachment( $part, $name ) ) {
				$attachment = $attachmentText;
			}
		}
	} else {
		
		my $head = $entity->head();
		my $rawText = $entity->stringify();
		my $contentType = $head->mime_type();
		my $contentDisposition = $head->mime_attr( 'content-disposition' );
		
		$contentDisposition = "" if ( !$contentDisposition );
		
		my $fileName = $head->recommended_filename;
		$fileName = "noname" if ( !$fileName );
		
		return 0 if ( 
									( $contentType !~ /^application/ && $contentDisposition !~ /^attachment/i )
									&& $contentType !~ /^(image|audio|video)/i  
								);
			
		return 0 if ( $fileName !~ /$name/i);

		$attachment = $rawText;
	}

	return $attachment;
}

sub getAddedToPublicationBulk {
	my ( $self, %where ) = @_;
	my @publications;
	
	my ( $stmnt, @bind ) = $self->{sql}->select( "item_publication_type", "*", \%where );
  
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
  
	my %publications;
	while ( $self->nextObject ) {
		my $record = $self->getObject();
		if ( exists( $publications{$record->{item_digest} } ) ) {
			push @{ $publications{ $record->{item_digest} } }, $record;
		} else {
			$publications{ $record->{item_digest} } = [ $record ];
		}
	}

	return \%publications; 
}

sub getItemsAddedToPublication {
  my ( $self, $timeframe_start, $timeframe_end, $publication_type, $publication_specifics ) = @_;
  
  my %where;
  $where{"i.created"} = {-between => [$timeframe_start, $timeframe_end] };
  $where{"ipt.publication_type"} = $publication_type;
  $where{"ipt.publication_specifics"} = $publication_specifics;
  
  my ( $stmnt, @bind ) = $self->{sql}->select( "item i", "i.title, i.description, i.link", \%where, "i.created" );
  my $join = { "JOIN item_publication_type ipt" => { "ipt.item_digest" => "i.digest" } };
  $stmnt = $self->{dbh}->sqlJoin( $join, $stmnt );
  
  $self->{dbh}->prepare( $stmnt );
  $self->{dbh}->executeWithBinds( @bind );  
  
  my @items;
  while ( $self->nextObject ) {
    push @items, $self->getObject();
  }  
  
  return \@items;
}

sub addToPublication {
	my ( $self, $digest, $publicationTypeId, $publicationSpecifics ) = @_;
  undef $self->{errmsg};  
  
  my ( $stmnt, @bind ) = $self->{sql}->insert( "item_publication_type", 
                                               {item_digest => $digest, 
                                              	publication_type => $publicationTypeId,
                                              	publication_specifics => $publicationSpecifics} 
  );
  
  $self->{dbh}->prepare( $stmnt );
  
  if ( defined( $self->{dbh}->executeWithBinds( @bind ) ) > 0 ) {
    return 1;
  } else {
    $self->{errmsg} = $self->{dbh}->{db_error_msg};
    return 0;
  }
}

sub removeFromPublication {
  my ( $self, $itemDigest, $publicationTypeId, $publicationSpecifics ) = @_;
  undef $self->{errmsg};  
  
  my ( $stmnt, @bind ) = $self->{sql}->delete( "item_publication_type", 
                                               {item_digest => $itemDigest, 
                                                publication_type => $publicationTypeId,
                                                publication_specifics => $publicationSpecifics} 
  );
  
  $self->{dbh}->prepare( $stmnt );
  
  if ( defined( $self->{dbh}->executeWithBinds( @bind ) ) > 0 ) {
    return 1;
  } else {
    $self->{errmsg} = $self->{dbh}->{db_error_msg};
    return 0;
  }
}

1;


=head1 NAME

Taranis::Assess - functionality for Assess

=head1 SYNOPSIS

  use Taranis::Assess;

  my $obj = Taranis::Assess->new();

  $obj->loadCollection( startdate => $start_date, enddate => $end_date, 
                        search => $search_string, status => \@statuses, 
                        category => \@categories, limit => $limit, offset => $offset,
                        source => \@sources );

  $obj->getDistinctSources( \@assessCategories );

  $obj->setItemStatus( status => $status, digest => $digest );

  $obj->getItem( $digest, $searchArchive );

  $obj->getMailItem( $id );

  $obj->getRelatedIdDescription( $id );

  $obj->getRelatedIds( $digest );

  $obj->getRelatedItemsIdMatch( $digest );

  $obj->getRelatedItemsKeywordMatch( $digest, @keywords );

  $obj->nextObject();

  $obj->getObject();  

  $obj->setIsMailedFlag( $digest );

  $obj->getAttachmentInfo( $entity, $info );

  $obj->getAttachment( $entity, $name );

=head1 DESCRIPTION

=head1 METHODS

=head2 new( )

Constructor of the C<Taranis::Assess> class.

    my $obj = Taranis::Assess->new();

Creates a new database handler which can accessed by:

    $obj->{dbh};

Creates a new C<SQL::Abstract> object which can be accessed by:

    $obj->{sql};

Clears error message for the new object. Can be accessed by;

    $obj->{errmsg};

Clears the counted results set by private method _setResultCount() . Can be accessed by:

    $obj->{result_count};

Returns the blessed object.  

=head2 loadCollection( startdate => $start_date, enddate => $end_date, search => $search_string, ... )

Retrieves all items that are collected by the collector. 

Arguments determine which items are retrieved. Possible arguments are:

=over

=item *

startdate & enddate, searches in column C<created> between supplied startdate and enddate. Both dates come with a time part, for startdate the time is 000000, for enddate the time is 235959.   

=item *

search, string which searches columns C<title> and C<description> from table C<item> and column C<identifier> from table C<identifier>

=item *

status, searches column C<status> for matching status. Value is an ARRAY reference. Possible statuses are: 

=over

=item *

0 (unread)

=item *

1 (read)

=item *

2 (important)

=item *

3 (deleted)

=back

=item *

category, searches column C<category> for matching categories. Value is an ARRAY reference.

=item *

source searches column C<source> for matching sources. Value is an ARRAY reference.

=item *

limit, setting for the maximum items per page

=item *

offset, setting depending on the current page

=item *

sorting, setting to set the ORDER BY of the SQL statement. Possible values are:

=over

=item *

created_desc, translates to 'ORDER BY created DESC'

=item *

created_asc, translates to 'ORDER BY created ASC'

=item *

source_asc, translates to 'ORDER BY source ASC'

=item *

source_desc, translates to 'ORDER BY source DESC'

=item *

title_asc, translates to 'ORDER BY title ASC'

=item *

title_desc, translates to 'ORDER BY title DESC'

=back

=back

Example:

    $obj->loadCollection( startdate => '21-12-2008', enddate => '23-12-2008', 
                          search => 'microsoft update for office 2007', status => \[ 1, 3 ],
                          source => \[ 'source_x', 'source_y' ], category => \[ 2, 4 ] );

Also before database execution the private method _setResultCount() is called.

The query being build in this method consists of two queries which are combined with a UNION. 
The difference between the two queries can be found in the JOIN of table identifier in one of the queries. 

Returns the return value of DBI->execute(). Sets C<< $obj->{errmsg} >> of this object to C<< Taranis::Database->{db_error_msg} >> if database execution fails.

=head2 getDistinctSources( \@assessCategories )

Retrieves a list of all unique source names depending on the supplied Assess statuses.

Method expects an ARRAY reference as argument containing assess statuses.

    $obj->getDistinctSources( \[ 1, 4, 5 ] );

Returns an ARRAY containing only sourcenames in alphabetical order.

=head2 setItemStatus( status => $status, digest => $digest )

Method for changing the status of an item.

Takes two arguments as key value pairs, both are mandatory:

    $obj->setItemStatus( status => 2, digest => 'YCpWzDJgrxy+aWdXzaf2lw' );

Returns TRUE if database update is successful or returns FALSE if update is unsuccessful and sets C<< $obj->{errmsg} >> of this object to C<< Taranis::Database->{db_error_msg} >>.

=head2 getItem( $digest, $searchArchive )

Retrieves one item and returns it.

Takes the item digest as argument. The second argument is optional, which specifies whether to search archived items or non-archived items. 
Setting value to 1 (or 'true') does a search in archived items, value 0 (default), does a search in non-archived items.

    $obj->getItem( 'YCpWzDJgrxy+aWdXzaf2lw', 1 );

Returns the item. Sets C<< $obj->{errmsg} >> of this object to C<< Taranis::Database->{db_error_msg} >> if there's a database failure.

=head2 getMailItem( $id )

Retrieves one email item.

Takes the item digest as argument:

    $obj->getMailItem( 'YCpWzDJgrxy+aWdXzaf2lw' );

Returns the item. Sets C<< $obj->{errmsg} >> of this object to C<< Taranis::Database->{db_error_msg} >> if there's database failure.

=head2 getRelatedIdDescription( $id )

Retrieves description from identifiers like CVE id's.

Takes the identifier as argument.

    $obj->getRelatedIdDescription( 'CVE-2010-0001' );

If found, it will also collect all related Advisory ids. Note that it will only collect the last published advisories.

Returns an HASH reference containing all columns of table identifier_description and, if found, related advisory id's with key name C<ids>.

=head2 getRelatedIds( $digest )  

Retrieves identifiers that are related with the item.

Takes the item digest as argument:

    $obj->getRelatedIds( 'YCpWzDJgrxy+aWdXzaf2lw' );

The method searches the table identifier for the supplied digest.

Returns an ARRAY of all the identifiers found. Sets C<< $obj->{errmsg} >> of this object to C<< Taranis::Database->{db_error_msg} >> if there's database failure.

=head2 getRelatedItemsIdMatch( $digest )

Retrieves all items that having matching identifiers.

Takes the item digest as argument:

    $obj->getRelatedItemsIdMatch( 'YCpWzDJgrxy+aWdXzaf2lw' );

Note: the column C<created> is converted to string and is formatted to 'DD-MM-YYYY HH24:MI:SS' (example: '23-12-2008 14:23:55') and renamed to C<item_date>.

Also: the resulting items are ordered by date (column C<created>) descending. So newest items first.

Returns all the items found in an ARRAY. Sets C<< $obj->{errmsg} >> of this object to C<< Taranis::Database->{db_error_msg} >> if there's database failure.

=head2 getRelatedItemsKeywordMatch( $digest, \@keywords )

Retrieves all the items where the title matches combinations of the supplied keywords.

Takes two arguments, both mandatory. Argument one is the item digest, second is an ARRAY of keywords:

    $obj->getRelatedItemsKeywordMatch( 'YCpWzDJgrxy+aWdXzaf2lw', [ 'keyword1', 'keyword2' ] );

The search is done by combining two keywords:

    ...( ( title ILIKE 'keyword_1' ) AND ( title ILIKE 'keyword_2' ) ) OR ( ( title ILIKE 'keyword_1 ) AND ( title ILIKE 'keyword_3' ) )...
 
The method creates all combinations of keywords.

Returns all the items found. Sets C<< $obj->{errmsg} >> of this object to C<< Taranis::Database->{db_error_msg} >> if there's database failure.

=head2 nextObject( ) & getObject( )

Method to retrieve the list that is generated by a method like loadCollection().

This way of retrieval can be used to get data from the database one-by-one.

Both methods don't take arguments.

    $obj->loadCollection( $args );

    while( $obj->nextObject ) {
        push @list, $obj->getObject;
    }

=head2 setIsMailedFlag( $digest )

This method is used to set the is_mailed flag of an item when a user uses the 'E-mail the item' option in Assess.

It takes the item digest as argument.

    $obj->setIsMailedFlag( 'YCpWzDJgrxy+aWdXzaf2lw' );

Returns TRUE if it's successful, FALSE on database failure. Also sets C<< $obj->{errmsg} >> to C<< Taranis::Database->{db_error_msg} >> on failure.

=head2 getAttachmentInfo( $entity, $info )

Retrieves information on possible attachments in an email item.

First argument is an MIME::Entity object which can be created by using MIME::Parser as follows:

    my $parser = MIME::Parser->new();
    my $entity = $parser->parse_data( $email_body_text );

The second argument should be supplied with value C<undef>. The method uses this argument only when in recursion.

Returns an HASH reference containing the filename and filetype of the attachments.

Returns FALSE if the contenttype is not C<application>, C<image>, C<audio> or C<video>. 
Also returns FALSE in case contenttype is C<application> but content disposition is not attachment. 

=head2 getAttachment( $entity, $name )

Retrieves the complete attachment as raw text.
Takes a MIME::Entity object as first argument (see getAttachmentInfo() ). 
Second argument is the name of the attachment which can retrieved by getAttachmentInfo().

    my $parser = MIME::Parser->new();
    my $entity = $parser->parse_data( $email_body_text );
    $obj->getAttachment( $messageEntity, 'my_attachment.pdf' );

Returns the attachment as raw text.

=head1 DIAGNOSTICS

The following messages can be expected from this module:

=over

=item *

I<No items have been changed. Perhaps you tried to change items with status 'waitingroom'.>

Message is caused by trying to change the status of items that have status 'waitingroom' (value 3). This is not allowed in Taranis.
The message originates from method setItemStatus().

=item *

I<No description available.>

Message is caused by method getRelatedIdDescription() when there is no description in the database for specified identifier. 
If there's a description available online, running admin script cve_descriptions.pl will solve this issue.

=item * 

I<Item id missing.>

Message is caused by setIsMailedFlag() when the item digest is missing.

=item *

I<Database error, please check log for info> or I<Database error. (Error cannot be logged because logging is turned off or is not configured correctly)>

Is caused by a database syntax or input error. 
If syslog has been setup correctly the exact SQL statement and bindings should be visible in the configured syslog.

=back

=head1 DEPENDENCIES

CPAN modules required are B<SQL::Abstract>, B<Data::Validate> and B<Tie::IxHash>.

Taranis modules required are B<Taranis>, B<Taranis::Database> and B<Taranis::Category>.

=head1 AUTHOR

Sebastiaan van Achterbergh <info@govcert.nl>

November 2010

=cut
