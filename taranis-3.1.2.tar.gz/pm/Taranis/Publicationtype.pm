package Taranis::Publicationtype;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Database;
use Data::Validate qw(:math);
use SQL::Abstract;
use Tie::IxHash;
use strict;

use Taranis qw(:all);

our $VERSION = '0.1';

sub new {
	shift @_;
	
	my $self = {
		errmsg 	=> undef,
		dbh 		=> Taranis::Database->new(),
		sql 		=> SQL::Abstract->new()
	};
	bless $self;
	return $self;	
}

sub getPublicationTypeIds {
	my ( $self, $id ) = @_;
	undef $self->{errmsg};
	my @type_ids;
		
	if ( !defined( $id ) || !is_integer( $id ) ) {
		$self->{errmsg} = "No valid id given for routine.";		
		return 0;
	}

	my %where = ( "ci.id" => $id );
	
	tie my %join, "Tie::IxHash";
	my ( $stmnt, @bind ) = $self->{sql}->select("publication_type AS pt", "pt.id", \%where );
	%join = ( 
						"JOIN constituent_publication AS cp" => { "cp.type_id" => "pt.id" 						}, 
						"JOIN constituent_individual AS ci"  => { "ci.id" 		 => "cp.constituent_id" } 
					);

	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	if ( defined( $self->{dbh}->{db_error_msg} )) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	} else {
		while ( $self->nextObject ) {
			push( @type_ids, $self->getObject->{id} );
		}
		return @type_ids;
	}	
}

sub getPublicationTypes {
  my ( $self, %searchFields ) = @_;
	undef $self->{errmsg};
	my %where;
	
	tie my %join, "Tie::IxHash";
		
	for my $key ( keys ( %searchFields ) ) {
		if ( $key eq "cg.id" || ref( $searchFields{$key} ) =~ /^ARRAY$/ ) {
			$where{$key} = \@{ $searchFields{$key} };
		} elsif ( defined( is_integer( $searchFields{$key} ) ) ) {
			$where{$key} = $searchFields{$key};				
		} elsif ( $searchFields{$key} ne "" ) {
			$where{$key}{-ilike} = "%".$searchFields{$key}."%";
		}
	}	

  my $select = "pt.*";
  $select .= ", min(cg.status) as group_status" if ( exists( $searchFields{"ci.id"} ) || exists( $searchFields{"cg.id"} ) );
  
	my ( $stmnt, @bind ) = $self->{sql}->select( "publication_type AS pt", $select, \%where, "pt.title"); 

	if ( exists( $searchFields{"ci.id"} ) ) {	
		%join = ( 
							"JOIN type_publication_constituent AS tpc" => { "tpc.publication_type_id" => "pt.id"									 },
							"JOIN constituent_group AS cg" 						 => { "cg.constituent_type" 		=> "tpc.constituent_type_id" }, 
							"JOIN membership AS m" 										 => { "m.group_id" 						 	=> "cg.id" 									 }, 
							"JOIN constituent_individual AS ci" 			 => { "ci.id" 									=> "m.constituent_id" 			 } 
						);
	} elsif ( exists( $searchFields{"cg.id"} ) ) {
		%join = ( 
							"JOIN type_publication_constituent AS tpc" => { "tpc.publication_type_id" => "pt.id"									 },
							"JOIN constituent_group AS cg" 						 => { "cg.constituent_type" 		=> "tpc.constituent_type_id" } 
						);						
	} elsif ( exists( $where{"ct.id"} ) || exists( $where{"ct.type_description"} ) ) {
		%join = ( 
							"JOIN type_publication_constituent AS tpc" => { "tpc.publication_type_id" => "pt.id" 									 },
							"JOIN constituent_type AS ct" 						 => { "ct.id" 									=> "tpc.constituent_type_id" } 
						);
	}
	
	if ( scalar %join ) {
		$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );
		$stmnt =~ s/(ORDER.*)/ GROUP BY pt.id, pt.title, pt.description $1/i;
	}

	$self->{dbh}->prepare( $stmnt );
	my $result = $self->{dbh}->executeWithBinds( @bind );

	$self->{errmsg} .= $self->{dbh}->{db_error_msg} if ( $self->{dbh}->{db_error_msg} );
	return $result;		
	
}

sub nextObject {
	my ( $self ) = @_;
	return $self->{dbh}->nextRecord;
}

sub getObject {
	my ( $self ) = @_;
	return $self->{dbh}->getRecord;		
}

1;
=head1 NAME 

Taranis::Publicationtype - module for retrieval of pubication types and retrieval of list of constituent individuals for a specific publication type

=head1 SYNOPSIS

  use Taranis::Publicationtype;

  my $obj = Taranis::Publicationtype->new();
  
  $obj->getPublicationTypeIds( $constituent_individual_id );
  
  $obj->getPublicationtypes( [ 'pt.id' => $publication_type_id, 'ci.id' => $constituent_individual_id, etc... ] );

  $obj->nextObject();

  $obj->getObject();  

=head1 METHODS

=head2 B<new>

Constructor for the Taranis::Publicationtype class:

    my $obj = Taranis::Publicationtype->new();

Creates a new database handler which can accessed by:

    $obj->{dbh};

Creates a new SQL::Abstract object which can be accessed by:

    $obj->{sql};
	  
Clears error message for the new object. Can be accessed by:
   
    $obj->{errmsg};	 	  
	
Returns the blessed object.	

=head2 B<getPublicationTypeIds>

Method for retrieving the id's of publication types.

Takes the constituent individual id as argument:
  
    $obj->getPublicationTypeIds( 24 );
  
Returns an array with all the publication type id's. Sets $errmsg of this object to Taranis::Database->{db_error_msg} if database exectution fails.
  
=head2 B<getPublicationtypes>

Method for retrieving publication types.

Takes arguments that correspond with table columns of different tables. A column name is preceeded by a table alias:

=over

=item ci. for constituent_individual

=item cg. for consitituen_group

=item ct. for constituent_type

=item pt. for publication_type

=back
  
For instance 'ci.id' corresponds with the column id of table constituent_individual:

    $obj->getPublicationTypes( 'ci.id' => 23 );  

To retrieve all publication types:

    $obj->getPublicationtype();	

Note: for argument 'cg.id' a list of id's is expected:
  
    $obj->getPublicationTypes( 'cg.id' => \@group_ids );
    
Also: it is not possible to combine one of the following: 'ci.id', 'cg.id' and  'ct.id'.
  
Returns the return value of DBI->execute(). Sets $errmsg of this object to Taranis::Database->{db_error_msg} if database execution fails.
  
=head2 B<nextObject> & B<getObject>

Method to retreive the list that is generated by method loadCollection. 

This way of retrieval can be used to get data from the database one-by-one. Both methods do not take arguments.

Example:

    $obj->loadCollection( $args );

    while( $obj->nextObject ) {
  	  myFunction( $obj->getObject );
    }

=head1 AUTHOR

Sebastiaan van Achterbergh

Dec 24, 2008

=cut

