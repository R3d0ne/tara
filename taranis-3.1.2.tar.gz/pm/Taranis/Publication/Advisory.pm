package Taranis::Publication::Advisory;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:all);
use Taranis::Config;
use Taranis::Damagedescription;
use Taranis::Database;
use Taranis::Publication;
use Taranis::Tagging;
use Taranis::SoftwareHardware;
use SQL::Abstract;
use Encode;
use strict;

sub new {
	my ( $class, %args ) = @_;

	my $dbh = ( !$args{no_db} ) ? Taranis::Database->new(): undef;

	my $self = {
		errmsg => undef,
		dbh => $dbh,
		sql => SQL::Abstract->new(),
		scale => { high => 1, medium => 2, low => 3 }
	};
	bless $self;
	return $self;
}

sub isBasedOn {
	my ( $self, %where ) = @_;
	
	$where{deleted} = 0;
	my ( $stmnt, @bind ) = $self->{sql}->select( "publication_advisory", "based_on, id AS advisory_id, publication_id, govcertid, version", \%where );
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	my @basedOnList;
	while ( $self->{dbh}->nextRecord() ) {
		my $basedOn = $self->{dbh}->getRecord();
		$basedOn->{based_on_id} = ( $basedOn->{based_on} =~ /(.*?) \d\.\d\d$/ )[0];
		$basedOn->{based_on_version} = ( $basedOn->{based_on} =~ /.*? (\d\.\d\d)$/ )[0];
		
		push @basedOnList, $basedOn;
	}
	
	return \@basedOnList;
}

sub getLinksFromXMLAdvisory {
	my ( $self, $xmlAdvisory ) = @_;
	my $advisoryLinks = "";
	if ( ref ( $xmlAdvisory->{content}->{additional_resources}->{resource} ) =~ /^ARRAY$/ ) {
		foreach my $advisoryLink ( @{ $xmlAdvisory->{content}->{additional_resources}->{resource} } ) {
			$advisoryLinks .= $advisoryLink . "\n"; 
		}
		$advisoryLinks =~ s/\n$//;
	} else {
		$advisoryLinks = $xmlAdvisory->{content}->{additional_resources}->{resource};
	}
	return $advisoryLinks;	
}

sub getTitleFromXMLAdvisory {
	my ( $self, $xmlAdvisory ) = @_;
	my $title = encodeInput( \encode( 'UTF-8', $xmlAdvisory->{meta_info}->{title} ) );
	$title =~ s/.*\[v\d\.\d\d\] \[(?:L|M|H)\/(?:L|M|H)\] (.*?)$/$1/;
	return $title;
}

sub getAdvisoryIDDetailsFromXMLAdvisory {
	my ( $self, $xmlAdvisory ) = @_;
	my %advisoryDetails = ( newAdvisoryVersion => '1.00' );
	
	my $basedOn = $self->isBasedOn( based_on => { ilike => $xmlAdvisory->{meta_info}->{reference_number} . ' %' } );	
	
	if ( @$basedOn > 0 ) {
		$advisoryDetails{newAdvisoryDetailsId} = $basedOn->[0]->{govcertid};
		
		foreach my $basedOnAdvisory ( @$basedOn ) {
			if ( $basedOnAdvisory->{version} >= $advisoryDetails{newAdvisoryVersion} ) {
				$advisoryDetails{newAdvisoryVersion} = $basedOnAdvisory->{version} + 0.01;
				$advisoryDetails{publicationPreviousVersionId} = $basedOnAdvisory->{publication_id};
			}
		}
	} else {
		# this is a first version advisory
		my $advisoryIdLength = $self->{cfg}->{advisory_id_length};
		$advisoryIdLength = 3 if ( !$advisoryIdLength || $advisoryIdLength !~ /^\d+$/ );
		my $advisoryX = '';
		for ( my $i = 1; $i <= $advisoryIdLength; $i++ ) { $advisoryX .= 'X'; }
		
		$advisoryDetails{newAdvisoryDetailsId} = Taranis::Config->getSetting("advisory_prefix") . '-' . nowstring(6) . '-' . $advisoryX;
	}	

	return \%advisoryDetails;
}

sub getSoftwareHardwareFromXMLAdvisory {
	my ( $self, $xmlAdvisory ) = @_;
	
	my $sh = Taranis::SoftwareHardware->new();
	my %softwareHardwareDetails = (
		products => [],
		platforms => [],
		importProblems => []
	);
	
	foreach my $shType ( 'product', 'platform' ) {
		my @xmlAdvisorySoftwareHardware = ( ref ( $xmlAdvisory->{meta_info}->{system_information}->{systemdetail}->{'affected_' . $shType}->{$shType} ) =~ /^ARRAY$/  ) 
			? @{ $xmlAdvisory->{meta_info}->{system_information}->{systemdetail}->{'affected_' . $shType}->{$shType} }
			: $xmlAdvisory->{meta_info}->{system_information}->{systemdetail}->{'affected_' . $shType}->{$shType};

		foreach my $softwareHardware ( @xmlAdvisorySoftwareHardware ) {
			next if ( !$softwareHardware->{cpe_id} && !$softwareHardware->{producer} && !$softwareHardware->{name} );
			
			my %where = ( $softwareHardware->{cpe_id} ) 
				? ( cpe_id => $softwareHardware->{cpe_id} ) 
				: ( 
					producer => { -ilike => encodeInput( \encode( 'UTF-8', $softwareHardware->{producer} ) ) },
					name => { -ilike => encodeInput( \encode( 'UTF-8', $softwareHardware->{name} ) ) }
				);
				
			if ( exists( $where{producer} ) && $softwareHardware->{version} ) {
				$where{version} = { -ilike => encodeInput( \encode( 'UTF-8', $softwareHardware->{version} ) ) };
			}

			if ( my $foundSoftwareHardware = $sh->loadCollection( %where ) ) {
				if ( @$foundSoftwareHardware == 1 ) {
						
					if ( $shType =~ /^product$/) {
						push @{ $softwareHardwareDetails{products} }, $foundSoftwareHardware->[0];
					} else {
						push @{ $softwareHardwareDetails{platforms} }, $foundSoftwareHardware->[0];
					}
				} else {
					my $productDescription = "$softwareHardware->{producer} $softwareHardware->{name}";
					$productDescription .=  " $softwareHardware->{version}" if ( $softwareHardware->{version} );
					$productDescription .= " ($softwareHardware->{cpe_id})" if ( $softwareHardware->{cpe_id} );
					
					if ( @$foundSoftwareHardware > 1 ) {
						push @{ $softwareHardwareDetails{importProblems} }, encode( 'UTF-8', "Found several matches for '$productDescription' during advisory import. Did not link product to advisory. Please check 'Products text', 'Versions text' and 'Platforms text' for references to missing product." );
					} else {
						push @{ $softwareHardwareDetails{importProblems} }, encode( 'UTF-8', "Could not find '$productDescription' during advisory import. Did not link product to advisory. Please check 'Products text', 'Versions text' and 'Platforms text' for references to missing product." );
					}
				}
			}
		}
	}
	
	return \%softwareHardwareDetails;
}

sub getDamageDescriptionsFromXMLAdvisory {
	my ( $self, $xmlAdvisory ) = @_;
	my %damageDescriptions = ( newDamageDescriptions => [], damageDescriptionIds => [] );
	
	my $dd = Taranis::Damagedescription->new();
	
	my @xmlDamageDescriptions = ( ref ( $xmlAdvisory->{meta_info}->{vulnerability_effect}->{effect} ) =~ /^ARRAY$/  ) 
		? @{ $xmlAdvisory->{meta_info}->{vulnerability_effect}->{effect} }
		: $xmlAdvisory->{meta_info}->{vulnerability_effect}->{effect};
	
	# check whether damage descriptions from XML exist in database,
	foreach my $xmlDamageDescription ( @xmlDamageDescriptions ) {
		my $unencodedXMLDamageDescription = encode( 'UTF-8', $xmlDamageDescription );
		$xmlDamageDescription = encodeInput( \encode( 'UTF-8', $xmlDamageDescription ) );
			
		if ( $xmlDamageDescription ) {
			if ( my $damageDescription = $dd->getDamageDescription( description => { ilike => $xmlDamageDescription } ) ) {
				push @{ $damageDescriptions{damageDescriptionIds} }, $damageDescription->{id};
			} else {
				push @{ $damageDescriptions{newDamageDescriptions} }, $xmlDamageDescription;
			}
		}
	}
	
	return \%damageDescriptions;	
}

1;
