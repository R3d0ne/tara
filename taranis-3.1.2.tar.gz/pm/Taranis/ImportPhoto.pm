package Taranis::ImportPhoto;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:all);
use Taranis::Database;
use Taranis::SoftwareHardware;
use Tie::IxHash;
use SQL::Abstract;
use strict;

sub new {
	shift @_;
	
	my $self = {
		errmsg 	=> undef,
		dbh 		=> Taranis::Database->new(),
		sql 		=> SQL::Abstract->new()
	};
	bless $self;
	return $self;	
}

sub addImportPhotoEntry {
	my ( $self, %inserts ) = @_;
	undef $self->{errmsg};  
	return $self->addToImport( "import_photo_software_hardware", \%inserts );
}

sub addImportPhoto {
	my ( $self, %inserts ) = @_;
	undef $self->{errmsg};  
	return $self->addToImport( "import_photo", \%inserts );
}

sub addImportSoftwareHardware {
	my ( $self, %inserts ) = @_;
	undef $self->{errmsg};  
	return $self->addToImport( "import_software_hardware", \%inserts );
}

sub addToImport {
	my ( $self, $table ,$inserts ) = @_;
	undef $self->{errmsg};  

	my ( $stmnt, @bind ) = $self->{sql}->insert( $table, $inserts );
	$self->{dbh}->prepare( $stmnt );
	
	if ( defined( $self->{dbh}->executeWithBinds( @bind ) ) > 0 ) {
		return 1;
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}	
}

sub getPhotoDetails {
	my ( $self, $photoId ) = @_;
	
	my $select = "ip.*, to_char(created_on, 'DD-MM-YYYY') AS created, cg.name, u.fullname, to_char(imported_on, 'DD-MM-YYYY') AS imported";
	
	my ( $stmnt, @bind ) = $self->{sql}->select( 'import_photo ip', $select, { 'ip.id' => $photoId } );

	my %join = ( 
							 'JOIN constituent_group cg' => { 'cg.id' => 'ip.group_id' },
							 'LEFT JOIN users u' => { 'u.username' => 'ip.imported_by' } 
						 );
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );	
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	my $photoDetails = $self->{dbh}->fetchRow();
	
	return $photoDetails;
}

sub getNewPhoto {
	my ( $self, %settings ) = @_;
	
	my ( $stmnt, @bind ) = $self->{sql}->select( 'import_photo ip', 'ish.*', \%settings, 'ish.producer, ish.name, ish.cpe_id' );
	tie my %join, "Tie::IxHash"; 
	
	%join = ( 
						'JOIN import_photo_software_hardware ipsh' => { 'ipsh.photo_id' => 'ip.id' }, 
						'JOIN import_software_hardware ish' 			 => { 'ish.id' => 'ipsh.import_sh' } 
					);

	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	my @photo;
	while ( $self->nextObject() ) {
		push @photo, $self->getObject();
	}
	
	return \@photo;
}

sub sortNewPhoto {
	my ( $self, $photo, $group_id, $photoId ) = @_;
	
	my $sh = Taranis::SoftwareHardware->new();
	my $softwareHardwareTypes = $sh->getBaseTypes();
	
	foreach my $type ( keys( %$softwareHardwareTypes ) ) {
		$softwareHardwareTypes->{ lc( delete( $softwareHardwareTypes->{$type} ) ) } = lc( $type ); 
	}
	
	my @import;
	PHOTOITEM:
	foreach my $photoItem ( @$photo ) {

		my $importItem_id = $photoItem->{id};
		my $producer = $photoItem->{producer};
		my $productName = $photoItem->{name};
		my $cpe_id = $photoItem->{cpe_id};
		my $type = ( $photoItem->{type} ) ? $photoItem->{type} : '';

		my $okToImport = $self->isOkToImport( $importItem_id, $photoId );

		next PHOTOITEM if ( 
			(
				defined( $okToImport ) && $okToImport == 0
			)
			|| $self->openIssueExists( $importItem_id )
		);

		# if closed issue exists of type 2 or 3, the import should take the soft_hard_id from issue
		if ( my $issue = $self->closedIssueExists( $importItem_id, $photoId ) ) {

			if ( !$issue->{create_new_issue} || ( $issue->{create_new_issue} && $self->getIssue( followup_on_issue_nr => $issue->{id} )->{status} == 3 ) ) {

				if ( $sh->countUsage( soft_hard_id => $issue->{soft_hard_id}, group_id => $group_id ) ) {
					push @import, { 
						id => $importItem_id,
						producer => $producer, 
						name => $productName, 
						cpe_id => $cpe_id, 
						type => $type,
						soft_hard_id => $issue->{soft_hard_id},
						alreadyInPhoto => 1						
					};
				} else {
					push @import, { 
						id => $importItem_id,
						producer => $producer, 
						name => $productName, 
						cpe_id => $cpe_id, 
						type => $type,
						issueType => $issue->{type},
						soft_hard_id => $issue->{soft_hard_id},
						hasClosedIssue => 1
					};
				}
			}
		} elsif ( $cpe_id && $self->{dbh}->checkIfExists( { cpe_id => $cpe_id, deleted => 0 }, "software_hardware" ) ) {

			## Exact Match on CPE ID

			if ( $sh->countUsage( cpe_id => $cpe_id, deleted => 0, 'group_id' => $group_id ) ) {

				## Constituent has Software/Hardware in old photo  
				push @import, 
				{ 
					id => $importItem_id,
					producer => $producer, 
					name => $productName, 
					cpe_id => $cpe_id, 
					type => $type, 
					alreadyInPhoto => 1
				};							
			} else {
				my $inUse = ( 
					$sh->countUsage( cpe_id => $cpe_id, deleted => 0 ) 
					|| ( defined( $okToImport ) && $okToImport ) 
				) ? 1 : 0; 

				## Constituent does NOT have Software/Hardware in old photo

				push @import, 
				{ 
					id => $importItem_id,						
					producer => $producer, 
					name => $productName, 
					cpe_id => $cpe_id, 
					type => $type, 
					exactMatch => 1, 
					inUse => $inUse 
				};
			}

		} elsif (
			my $count =	$self->{dbh}->countRows(
				{ 
					producer => { -ilike => $producer } , 
					name => { -ilike => $productName },
					type => $softwareHardwareTypes->{ lc( $type ) }, 
					deleted => 0 
				},
				'software_hardware'
			) 
		) {

			if ( $sh->countUsage( 
					producer => { -ilike => $producer },
					name => { -ilike => $productName },
					type => $softwareHardwareTypes->{ lc( $type ) },
					deleted => 0, 
					group_id => $group_id
				)
			) {
				
				## Constituent has Software/Hardware in old photo
				
				push @import, 
				{ 
					id => $importItem_id,						
					producer => $producer, 
					name => $productName, 
					cpe_id => $cpe_id, 
					type => $type, 
					alreadyInPhoto => 1 
				};					
			
			} else {			
			
				if ( $count > 1 ) {
					push @import, 
					{ 
						id => $importItem_id,							
						producer => $producer, 
						name => $productName, 
						cpe_id => $cpe_id, 
						type => $type, 
						hasDuplicates => 1 
					};
				
				} else {

					my $inUse = ( 
						$sh->countUsage(  
							producer => $producer, 
							name 		 => $productName ,
							type		 => $softwareHardwareTypes->{ lc( $type ) },
							deleted  => 0	
						)
						|| ( defined( $okToImport ) && $okToImport )
					) ? 1 : 0;

					push @import, 
					{ 
						id => $importItem_id,							
						producer => $producer, 
						name => $productName, 
						cpe_id => $cpe_id, 
						type => $type, 
						exactMatch => 1, 
						noCpe => 1, 
						inUse => $inUse 
					};
				}
			}
		} else {
			push @import, 
			{ 
				id => $importItem_id,					
				producer => $producer, 
				name => $productName, 
				cpe_id => $cpe_id, 
				type => $type, 
				noMatch => 1 
			};
		}
	}
	
	return \@import;
}

sub getImportList {
	my ( $self, %settings ) = @_;

	my $select = "ip.id AS photo_id, to_char(ip.created_on, 'DD-MM-YYYY HH24:MI') AS created, cg.*, to_char(ip.imported_on, 'DD-MM-YYYY HH24:MI') AS imported";
	my ( $stmnt, @bind ) = $self->{sql}->select( 'import_photo ip', $select , \%settings, 'created DESC' );
	
	my %join = (	'JOIN constituent_group cg' => { 'cg.id' => 'ip.group_id' } );
	
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	my @groups;
	while ( $self->nextObject() ) {
		push @groups, $self->getObject();
	}
	
	return \@groups;	
}

sub getImportSoftwareHardware {
	my ( $self, %settings ) = @_;
	return $self->getFromImport( "import_software_hardware", \%settings );
}

sub getImportSoftwareHardwareWithOpenIssues {
	my ( $self, %settings ) = @_;

	$settings{-or} = { 'ii.type' => 5, 'ii.status' => [0,1] };
	
	my $join = {
								'JOIN import_issue ii' => { 'ii.id' => 'ish.issue_nr' },
								'JOIN import_photo_software_hardware ipsh' => { 'ipsh.import_sh' => 'ish.id' }
						 };
	
	my $select = "ish.*";
	
	return $self->getFromImport( "import_software_hardware ish", \%settings, $join, $select );
}

sub getFromImport {
	my ( $self, $table, $settings, $join, $select ) = @_;
	
	$select = ( $select ) ? $select : '*';
	
	my ( $stmnt, @bind ) = $self->{sql}->select( $table, $select, $settings );
	
	if ( $join ) {
		$stmnt = $self->{dbh}->sqlJoin( $join, $stmnt );
	}

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	my @import;
	while ( $self->nextObject() ) {
		push @import, $self->getObject();
	}
	
	return \@import;		
}

sub getDeleteList {
	my ( $self, $sortedPhoto, $oldPhoto ) = @_;
		
	OLDITEM:
	for ( my $i = 0; $i < @$oldPhoto; $i++ ) {

		my $oldItemDesrciption = lc( $oldPhoto->[$i]->{producer} ) 
														 . lc(  $oldPhoto->[$i]->{name} ) 
														 . lc(  $oldPhoto->[$i]->{description} );

		NEWITEM:
		for ( my $j = 0; $j < @$sortedPhoto; $j++ ) {
		
			my $newItemDesrciption = lc( $sortedPhoto->[$j]->{producer} ) 
															 . lc( $sortedPhoto->[$j]->{name} ) 
															 . lc( $sortedPhoto->[$j]->{type} ); 

			if ( 
						$sortedPhoto->[$j]->{alreadyInPhoto}	&&
						( 
							( 
								$oldPhoto->[$i]->{cpe_id} ne ""	
								&& $oldPhoto->[$i]->{cpe_id}
							 	&& $oldPhoto->[$i]->{cpe_id} =~ /^\Q$sortedPhoto->[$j]->{cpe_id}\E$/i
							) 
							|| 
							$newItemDesrciption =~ /^\Q$oldItemDesrciption\E$/i
						) 
			) {
				delete  $oldPhoto->[$i];
				next OLDITEM;
			}
		}
	}
	
	return $oldPhoto;
}

sub setImportPhoto {
	my ( $self, $update, $where ) = @_;
	undef $self->{errmsg};
	return $self->setObject( 'import_photo', $update, $where  );	
}

sub deleteIssue {
	my ( $self, %delete ) = @_;
	return $self->deleteFromImport( 'import_issue', \%delete ); 
} 

sub deleteImportPhoto {
	my ( $self, %delete ) = @_;
	return $self->deleteFromImport( 'import_photo', \%delete ); 
}

sub unlinkSoftwareHardware {
	my ( $self, %unlink ) = @_;
	undef $self->{errmsg};
	
	if ( scalar %unlink ) {
		return $self->deleteFromImport( 'import_photo_software_hardware', \%unlink );
	} else {
		$self->{errmsg} = "Invalid argument for sub!";
		return 0;
	} 
}

sub deleteFromImport {
	my ( $self, $table, $delete ) = @_;
	undef $self->{errmsg};
	
	my ( $stmnt, @bind ) = $self->{sql}->delete( $table, $delete );
	
	$self->{dbh}->prepare( $stmnt );
 
	if ( $self->{dbh}->executeWithBinds( @bind) > 0 ) {
		return 1;
	} elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	} else {
		$self->{errmsg} = "Delete failed, corresponding id not found in database.";
		return 0;
	}			
} 

sub isOkToImport {
	my ( $self, $sh_id, $photo_id ) = @_;
	
	my %where = ( import_sh => $sh_id, photo_id => $photo_id );
	
	my ( $stmnt, @bind ) = $self->{sql}->select( 'import_photo_software_hardware', 'ok_to_import', \%where );
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	my $okToImport = $self->{dbh}->fetchRow();
	
	if ( exists( $okToImport->{ok_to_import} ) ) {
		return $okToImport->{ok_to_import};
	} else {
		return 0
	}
}

sub setOkToImport {
	my ( $self, $photo_id, $import_sh, $is_ok ) = @_;
	
	my %where = ( photo_id => $photo_id, import_sh => $import_sh );
	my %update = ( 'ok_to_import' => $is_ok );

	return $self->setObject( 'import_photo_software_hardware', \%update, \%where );
}

sub countOpenImports {
	my ( $self, $issueNr ) = @_;

	my $isNull = "IS NULL";
	
	my $where = { 'ish.issue_nr' => $issueNr, 'ip.imported_on' => \$isNull };
	my ( $stmnt, @bind ) = $self->{sql}->select( 'import_photo ip', 'COUNT(*) as cnt', $where );
	
	tie my %join, "Tie::IxHash";
	
	%join = ( 
						'JOIN import_photo_software_hardware ipsh' => { 'ipsh.photo_id' => 'ip.id' },
						'JOIN import_software_hardware ish' 			 => { 'ish.id' => 'ipsh.import_sh' }
					);
					
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );

	my $result = $self->{dbh}->fetchRow();

	if ( defined( $result->{cnt} ) ) {
		return $result->{cnt};
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}
}

sub getGroupsByIssueNr {
	my ( $self, $issueNr ) = @_;
	
	my $where = {  
		'ish.issue_nr' => $issueNr,
		'ip.imported_on' => \"IS NOT NULL"
	};

	my ( $stmnt, @bind ) = $self->{sql}->select( 'import_photo ip', 'cg.*', $where );
	tie my %join, 'Tie::IxHash';
	
	%join = (  
		'JOIN import_photo_software_hardware ipsh' => { 'ipsh.photo_id' => 'ip.id' },
		'JOIN import_software_hardware ish' => { 'ish.id' => 'ipsh.import_sh' },
		'JOIN constituent_group cg' => { 'cg.id' => 'ip.group_id' }		
	);

	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );

	my @groups;

	while ( $self->nextObject() ) {
		push @groups, $self->getObject();
	}

	return \@groups;
}

sub getPhotosForIssue {
	my ( $self, %where ) = @_;
	
	my $select = "ip.*, cg.name, to_char(imported_on, 'DD-MM-YYYY') AS imported";
	
	my ( $stmnt, @bind ) = $self->{sql}->select( 'import_photo ip', $select, \%where, 'cg.name' );
	
	tie my %join, "Tie::IxHash";
	%join = ( 
						'JOIN constituent_group cg' => { 'cg.id' => 'ip.group_id' },
						'JOIN import_photo_software_hardware ipsh' => { 'ipsh.photo_id' => 'ip.id' },
						'JOIN import_software_hardware ish' => { 'ish.id' => 'ipsh.import_sh' }
					);
	
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );

	my @photos; 

	while ( $self->nextObject() ) {
		push @photos, $self->getObject();
	}
	
	return \@photos;
}

sub importSoftwareHardware {
	my ( $self, $group_id, $soft_hard_id ) = @_;
	undef $self->{errmsg};

	my $inserts = { 'group_id' => $group_id, soft_hard_id => $soft_hard_id };
	
	my ( $stmnt, @bind ) = $self->{sql}->insert( 'soft_hard_usage', $inserts ); 

	$self->{dbh}->prepare( $stmnt );
	
	if ( defined( $self->{dbh}->executeWithBinds( @bind ) ) > 0 ) {
		return 1;
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}	
}

sub removeSoftwareHardwareUsage {
	my ( $self, $group_id, $soft_hard_id ) = @_;
	
	return $self->deleteFromImport( 'soft_hard_usage', { group_id => $group_id, soft_hard_id => $soft_hard_id } );
}

################### ISSUE TYPES ########################
# 1. Not in use by other constituents, search source
# 2. Duplicates found in Taranis
# 3. No match found
# 4. Inform constituent
# 5. Don't import
########################################################

sub openIssueExists {
	my ( $self, $import_sh ) = @_;
	return $self->issueExists( { 'ish.id' => $import_sh, 'ii.status' => [ 0, 1 ] } );
}

sub closedIssueExists {
	my ( $self, $import_sh, $photoId ) = @_;
	return $self->issueExists( { 'ish.id' => $import_sh, 'ii.status' => [ 2, 3 ],  'ipsh.photo_id' => $photoId } );
}

sub issueExists {
	my ( $self, $where) = @_;

	my ( $stmnt, @bind ) = $self->{sql}->select( 'import_software_hardware ish', 'ii.*', $where );

	my %join = ( 'JOIN import_issue ii' => { 'ii.id' => 'ish.issue_nr' } );

	foreach my $key ( keys %$where ) {
		if ( $key =~ /^ipsh/ ) {
			$join{ 'JOIN import_photo_software_hardware ipsh'} = { 'ipsh.import_sh' => 'ish.id' };
		}
	}

	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	my $issue = $self->{dbh}->fetchRow();
	
	if ( defined( $issue->{id} ) ) {
		return $issue;
	} else {
		return 0;
	}	
}

sub getIssuesSimple {
	my ( $self, $where ) = @_;

	my @issues;	
	my $select = 'ii.*, ish.producer, ish.name, ish.type AS sh_type';
	
	my ( $stmnt, @bind ) = $self->{sql}->select( 'import_issue ii', $select, $where );
	tie my %join, "Tie::IxHash";
	
	%join = ( 
						'JOIN import_software_hardware ish' => { 'ish.issue_nr' => 'ii.id' },
						'JOIN import_photo_software_hardware ipsh' => { 'ipsh.import_sh' => 'ish.id'},
						'JOIN import_photo ip' => { 'ip.id' => 'ipsh.photo_id' }
					);
	
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	while (  $self->nextObject() ) {
		push @issues, $self->getObject();
	}
	
	return \@issues;
}

sub linkToIssue {
	my ( $self, $issueNr, $import_sh ) = @_;
	
	my $update = { issue_nr  => $issueNr };
	my $where  = { id => $import_sh };
	
	return $self->setObject( 'import_software_hardware', $update, $where );
}

sub unlinkFromIssue {
	my ( $self, $issueNr ) = @_;
	
	my $update = { issue_nr => undef };
	my $where  = { issue_nr => $issueNr };
	
	return $self->setObject( 'import_software_hardware', $update, $where );
}

sub setConstituentUsage {
	my ( $self, %ids ) = @_;
	undef $self->{errmsg};
	
	if ( !$ids{oldId} || !$ids{newId} ) {
		$self->{errmsg} = "Invalid ID.";
		return 0;
	}
	
	my $update = { soft_hard_id => $ids{newId} };
	my $where  = { soft_hard_id => $ids{oldId} };
	
	return $self->setObject( 'soft_hard_usage', $update, $where ); 
}

sub setIssue {
	my ( $self, $update, $where ) = @_;
	undef $self->{errmsg};
	
	return $self->setObject( 'import_issue', $update, $where );
}

sub createIssue {
	my ( $self, $description, $issueType, $comments, $followUpOnIssue ) = @_;
	
	$issueType = ( $issueType =~ /^[1-5]$/ ) ? $issueType : '0';
	$comments = ( $comments ) ? $comments : '';
	$followUpOnIssue = ( $followUpOnIssue ) ? $followUpOnIssue : undef;
	
	my $insert = { 
									status 							 => 0, 
									description 				 => $description, 
									type 								 => $issueType, 
									comments 						 => $comments, 
									followup_on_issue_nr => $followUpOnIssue 
							 };
	
	my ( $stmnt, @bind ) = $self->{sql}->insert( 'import_issue', $insert );
	
	$self->{dbh}->prepare( $stmnt );

	if ( defined( $self->{dbh}->executeWithBinds( @bind ) ) > 0 ) {
		return $self->{dbh}->getLastInsertedId( 'import_issue' );
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}		
}

sub getIssue {
	my ( $self, %where ) = @_;

	my ( $stmnt, @bind ) = $self->{sql}->select( 'import_issue', '*', \%where );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	return $self->{dbh}->fetchRow();
}

sub getIssues {
	my ( $self, %searchFields ) = @_;
	undef $self->{errmsg};
		
	my %where1;
	my ( @nests1, @nests2, @issues );
	
	my @search_status = @{ $searchFields{status} } if ( exists $searchFields{status}  );
	delete $searchFields{status} if ( exists $searchFields{status} );

	my $start_date = delete $searchFields{start_date};
	my $end_date 	 = delete $searchFields{end_date};

	my $limit  = sanitizeInput( "only_numbers", delete ( $searchFields{hitsperpage} ) ) if ( $searchFields{hitsperpage} );
	my $offset = sanitizeInput( "only_numbers", delete ( $searchFields{offset} ) ) if ( defined $searchFields{offset} );

	if ( $start_date && $end_date ) {
		$where1{'ii.created_on'} = {-between => [$start_date." 000000", $end_date." 235959"] };
	}

	if ( @search_status ) {
		my ( @status1, @status2 ) ;
		foreach (  @search_status ) {
			push @status1, 'ii.status' => $_;
			push @status2, 'ii2.status' => $_;
		}
		push @nests1, \@status1;
		push @nests2, \@status2;
	}		
	
	if ( $searchFields{search} ne "" ) {
		my ( @search1, @search2 );
		push @search1, "ii.description" => { -ilike => "%".$searchFields{search}."%" };		
		push @search1, "ii.comments" 		=> { -ilike => "%".$searchFields{search}."%" };
		push @search1, "ish.producer || ' ' || ish.name" => { -ilike => "%".$searchFields{search}."%" };		
		
		push @search2, "ii2.description" => { -ilike => "%".$searchFields{search}."%" };		
		push @search2, "ii2.comments"		 => { -ilike => "%".$searchFields{search}."%" };
		push @search2, "ish.producer || ' ' || ish.name" => { -ilike => "%".$searchFields{search}."%" };		
				
		push @nests1, \@search1;
		push @nests2, \@search2;
	}

	$where1{'ii.id'} = $searchFields{issueNr} if ( $searchFields{issueNr} );

	$where1{'ipsh.photo_id'} = $searchFields{ photo_id }	if ( defined( $searchFields{ photo_id } ) );
	
	tie my %where2, "Tie::IxHash";
	%where2 = %where1;

	$where1{-and} = \@nests1 if ( @nests1 );	
	$where1{ 'ii.followup_on_issue_nr' } = \"IS NULL";
	
	my $select1 = "DISTINCT( ii.id ) AS ii_id, ii.status, ii.description, ii.type AS issueType, " 
						 . "ii.comments, ii.soft_hard_id, ii.resolved_on, to_char( ii.created_on, 'DD-MM-YYYY HH24:MI' ) AS created, " 
						 . "ii.create_new_issue, ii.followup_on_issue_nr, ish.producer, ish.name, ish.type, ish.cpe_id, " 
						 . "resolved.fullname AS resolvedby, ish.id AS sh_id, to_char( ii.resolved_on, 'DD-MM-YYYY HH24:MI' ) AS resolvedon";
						 
	my ( $stmnt1, @bind1 ) = $self->{sql}->select( 'import_issue ii', $select1, \%where1 );
	tie my %join1, "Tie::IxHash";
	%join1 = ( 
							'LEFT JOIN import_software_hardware ish' => { 'ish.issue_nr' => 'ii.id' },
							'LEFT JOIN users AS resolved'	=> { 'resolved.username' => 'ii.resolved_by' }
					);
	
	if ( defined( $searchFields{ photo_id } ) ) {
		$join1{ 'JOIN import_photo_software_hardware ipsh' } = { 'ipsh.import_sh' => 'ish.id' };
	}
	
	$stmnt1 = $self->{dbh}->sqlJoin( \%join1, $stmnt1 );

	my $select2 = $select1;
	$select2 =~ s/ii\./ii2\./g;

	tie my %join2, "Tie::IxHash";

	%join2 = %join1;
	
	foreach my $key ( keys %where2 ) {
		my $value = delete( $where2{ $key } );
		$key =~ s/ii\./ii2\./;
		$where2{ $key } = $value;
	}
	
	$where2{-and} = \@nests2 if ( @nests2 );	
	
	$join2{ 'JOIN import_issue ii2'} = { 'ii2.followup_on_issue_nr' => 'ii.id' };
	
	my ( $stmnt2, @bind2 ) = $self->{sql}->select( 'import_issue ii', $select2, \%where2 );
	
	$stmnt2 = $self->{dbh}->sqlJoin( \%join2, $stmnt2 );
	
	my $orderBy = 'status, ii_id DESC, resolved_on DESC, created DESC';
	
	my $stmnt = "SELECT ii_id, status, description, issueType, " 
						 . "comments, soft_hard_id, resolved_on, created, " 
						 . "create_new_issue, followup_on_issue_nr, producer, name, type, cpe_id, " 
						 . "resolvedby, sh_id, resolvedon "
						 . "FROM ( $stmnt1 UNION $stmnt2 ) AS ISSUES ORDER BY $orderBy";
						 
#		SELECT DISTINCT( ii_id ) AS ii_id, status, created, producer, name, type, cpe_id, type AS issueType, resolvedby, sh_id, resolved_on  FROM (
#		
#		SELECT DISTINCT( ii.id ) AS ii_id, ii.status, to_char( ii.created_on, 'DD-MM-YYYY HH24:MI:SS' ) AS created, ish.producer, ish.name, ish.type, ish.cpe_id, ii.type AS issueType, resolved.fullname AS resolvedby, ish.id AS sh_id, ii.resolved_on 
#		FROM import_issue ii 
#		LEFT JOIN import_software_hardware ish ON ish.issue_nr = ii.id 
#		LEFT JOIN users AS resolved ON resolved.username = ii.resolved_by 
#		WHERE ( ( ii.status = 0 OR ii.status = 1 OR ii.status = 3 ) )
#		AND ii.followup_on_issue_nr IS NULL 
#		
#		UNION
#		
#		SELECT DISTINCT( ii2.id ) AS ii_id, ii2.status, to_char( ii2.created_on, 'DD-MM-YYYY HH24:MI:SS' ) AS created, ish.producer, ish.name, ish.type, ish.cpe_id, ii2.type AS issueType, resolved.fullname AS resolvedby, ish.id AS sh_id, ii2.resolved_on 
#		FROM import_issue ii 
#		LEFT JOIN import_software_hardware ish ON ish.issue_nr = ii.id 
#		LEFT JOIN users AS resolved ON resolved.username = ii.resolved_by 
#		JOIN import_issue ii2 ON ii2.followup_on_issue_nr = ii.id
#		WHERE ( ( ii2.status = 0 OR ii2.status = 1 OR ii2.status = 3 ) )
#		
#		) AS FOO
#		
#		ORDER BY status, resolved_on DESC, created DESC

	$self->{result_count} = $self->{dbh}->setResultCount( $stmnt, @bind1, @bind2 );

	if ( $limit && defined( $offset ) ) {
		$stmnt .= " LIMIT $limit OFFSET $offset";
	}	

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind1, @bind2 );
	
  $self->{errmsg} = $self->{dbh}->{db_error_msg};
  
  while ( $self->nextObject() ) {
		push @issues, $self->getObject();
	}
  return \@issues;	
	
}

sub getDuplicates {
	my ( $self, %settings ) = @_;
	undef $self->{errmsg};
	
	my @duplicates;
	
	my $sh = Taranis::SoftwareHardware->new();
	my $softwareHardwareTypes = $sh->getBaseTypes();
	
	foreach my $baseType ( keys( %$softwareHardwareTypes ) ) {
		$softwareHardwareTypes->{ lc( delete( $softwareHardwareTypes->{ $baseType } ) ) } = lc( $baseType ); 
	} 	
	
	my $producer = $settings{producer};
	my $product  = $settings{product};
	my $type 		 = $softwareHardwareTypes->{ lc( $settings{type} ) };
	
	my $where = {
								producer => { -ilike => $producer }, 
								name 		 => { -ilike => $product },
								type		 => $type, 
								deleted  => 0 										
							};
	
	
	my ( $stmnt, @bind ) = $self->{sql}->select( 'software_hardware', '*', $where );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	$self->{errmsg} = $self->{dbh}->{db_error_msg};
	
	while (  $self->nextObject() ) {
		push @duplicates, $self->getObject();
	}

	my $totalUsageCount = 0;
	foreach my $duplicate ( @duplicates ) {
		$duplicate->{usageCount} = $sh->countUsage( 'shu.soft_hard_id' => $duplicate->{id} );
		$totalUsageCount += $duplicate->{usageCount};
	}
	
	return \@duplicates, $totalUsageCount;	
}

## HELPERS
sub setObject {
	my ( $self, $table, $update, $where ) = @_;
	undef $self->{errmsg};

	my ( $stmnt, @bind ) = $self->{sql}->update( $table, $update, $where );
	
	$self->{dbh}->prepare( $stmnt );

	my $result = $self->{dbh}->executeWithBinds( @bind );
	
	if ( defined( $result ) && ( $result !~ m/(0E0)/i ) ) {		
		if ( $result > 0 ) {
			return 1;
		} elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			return 0;
		} 
	} else {
		$self->{errmsg} = "Update failed, corresponding id not found in database.";
		return 0;
	}
}

sub nextObject {
    my ($self) = @_;
    return $self->{dbh}->nextRecord;
}

sub getObject {
    my ($self) = @_;
    return $self->{dbh}->getRecord;
}

1;
