package Taranis::Tagging;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Database;
use SQL::Abstract;
use strict;
use Tie::IxHash;

use Taranis qw(:all);
use Data::Dumper;

our $VERSION = '0.1';

sub new {
	shift @_;
	
	my $self = {
		errmsg 	=> undef,
		dbh 		=> Taranis::Database->new(),
		sql 		=> SQL::Abstract->new()
	};
	bless $self;
	return $self;	
}

sub getTags {
	my ( $self, $tag ) = @_;
	undef $self->{errmsg};
	my @tags;
	
	my ( $stmnt, @bind ) = $self->{sql}->select( "tag", "name", { name => { -ilike => $tag . "%" } } );
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );

	$self->{errmsg} = $self->{dbh}->{db_error_msg};

	while ( $self->nextObject() ) {
		push @tags, $self->getObject()->{name};
	}
	
	return \@tags;
}

sub getTagsByItem {
	my ( $self, $item_id, $table ) = @_;
	my @tags;
	
	my ( $stmnt, @bind ) = $self->{sql}->select( "tag AS t", "t.name", { "ti.item_id" => $item_id, "ti.item_table_name" => $table }, "t.name" );
	my %join = ( "JOIN tag_item AS ti" => { "ti.tag_id" => "t.id" } );
	
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );
	
	$self->{dbh}->prepare( $stmnt );
	
	$self->{dbh}->executeWithBinds( @bind );
	
	while ( $self->nextObject() ) {
		push @tags, $self->getObject()->{name} . ",";
	}	
	
	return \@tags;	
}

sub getTagId {
	my ($self, $tag ) = @_;
	
	my ( $stmnt, @bind ) = $self->{sql}->select( "tag", "id", { name => { -ilike => $tag } } );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	my $id = $self->{dbh}->fetchRow();
	return $id->{id};
}

sub setItemTag {
	my ( $self, $tag_id, $table, $item_id ) = @_;
	undef $self->{errmsg};
	
	if ( !$tag_id || !$table || !$item_id ) {
		$self->{errmsg} = "Argument missing, tag cannot be added.";
		return 0;
	}
	
	my ( $stmnt, @bind ) = $self->{sql}->insert( "tag_item", 
																								{ item_id 				=> $item_id, 
																									item_table_name => $table, 
																									tag_id 					=> $tag_id 
																							}	);
	
	$self->{dbh}->prepare( $stmnt );
	
	if ( defined( $self->{dbh}->executeWithBinds( @bind ) ) > 0 ) {
		return 1;
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}	
}

sub removeItemTag {
	my ( $self, $item_id, $table, @tags ) = @_;
	undef $self->{errmsg};
	
	my ( $delete_stmnt, @delete_bind ) = $self->{sql}->delete( "tag_item", { item_id => $item_id, item_table_name => $table } );

	if ( exists( $tags[0] ) && scalar @{ $tags[0] } ) {
		my @where = ( name => { -ilike => \@tags } );
		my ( $stmnt, @bind ) = $self->{sql}->select( "tag", "id", \@where );

		$delete_stmnt .= " AND tag_id NOT IN ( " . $stmnt . " )"; 

		push @delete_bind, @bind;
	}
	
	$self->{dbh}->prepare( $delete_stmnt );

	$self->{dbh}->executeWithBinds( @delete_bind );
	
	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};	
		return 0;
	} else {
		return 1;
	}
}

sub loadCollection {
	my ( $self, %search_fields ) = @_;
	undef $self->{errmsg};
	
	my %where = $self->{dbh}->createWhereFromArgs( %search_fields );	

	my ( $stmnt, @bind ) = $self->{sql}->select( "tag AS t", "t.*", \%where, "t.name" );
	
	my $join = { "JOIN tag_item ti " => {"ti.tag_id" => "t.id"} };
	$stmnt = $self->{dbh}->sqlJoin( $join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	my $result = $self->{dbh}->executeWithBinds( @bind );

	$self->{errmsg} = $self->{dbh}->{db_error_msg};
	return $result;
}

sub addTag {
	my ( $self, $tag ) = @_;
	undef $self->{errmsg};
	
	if ( !$tag || length( $tag ) > 100 ) {
		$self->{errmsg} = "Invalid tag. Possibly tag is too long.";
		return 0;
	}
	
	my ( $stmnt, @bind ) = $self->{sql}->insert( "tag", { name => $tag } );
	
	$self->{dbh}->prepare( $stmnt );
	
	if ( defined( $self->{dbh}->executeWithBinds( @bind ) ) > 0 ) {
		return 1;
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}		
}

sub cleanUp {
	my $self = shift;
	
	my $stmnt =	"DELETE FROM tag WHERE id NOT IN ( SELECT tag_id FROM tag_item );";
	
	$self->{dbh}->do( $stmnt );
	
	return 1;	
}

sub nextObject {
	my ( $self ) = @_;
	return $self->{dbh}->nextRecord;
}

sub getObject {
	my ( $self ) = @_;
	return $self->{dbh}->getRecord;		
}


1;
