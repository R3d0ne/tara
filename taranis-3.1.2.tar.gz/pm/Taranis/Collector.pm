package Taranis::Collector;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;
use Taranis qw(:all);
use Taranis::Assess;
use Taranis::Analysis;
use Taranis::Config;
use Taranis::Config::Stats;
use Taranis::Config::XMLGeneric;
use Taranis::Damagedescription;
use Taranis::Database;
use Taranis::Error;
use Taranis::Parsers;
use Taranis::Publication;
use Taranis::Publication::Advisory;
use Taranis::SoftwareHardware;
use Taranis::Template;
use LWP::UserAgent;
use LWP::Authen::OAuth;
use HTTP::Cookies;
use SQL::Abstract;
use Time::Local;
use Mail::IMAPClient;
use Mail::POP3Client;
use XML::FeedPP;
use XML::SAX::ParserFactory;
use XML::Validator::Schema;
use XML::Simple;
use URI::Escape;
use URI::Split qw(uri_split uri_join);
use Digest::MD5 qw(md5 md5_hex md5_base64);
use Encode;
use HTML::Entities;
use MIME::Parser;
use Unicode::IMAPUtf7;
use filetest 'access';
use GD::Graph::bars;
use GD::Graph::hbars;
use JSON;
use Data::Dumper;

sub new {
	my ( $class, $debugSource ) = @_;

	my $stripscfg = Taranis::Config::XMLGeneric->new( "stripsconfig", "hostname", "strips" );
	my $no_proxy = [ map { trim $_ } split( /,/, Taranis::Config->getSetting( "no_proxy" ) ) ];
	my $useragentString = Taranis::Config->getSetting("useragent_string");
  	my $proxyHost = Taranis::Config->getSetting( "proxy_host" );
  	
	my $lwp = LWP::UserAgent->new();
	$lwp->protocols_allowed( [ 'http', 'https' ] );	
	$lwp->timeout( Taranis::Config->getSetting("timeout") );
	$lwp->agent( $useragentString );
	$lwp->no_proxy( @{ $no_proxy } ); 
	$lwp->cookie_jar( {file => Taranis::Config->getSetting("cookie_jar") } );
	
	if ( $LWP::UserAgent::VERSION >= 6 ) {
		$lwp->proxy( [ 'http', 'https' ], $proxyHost ) if ( $proxyHost );
	} else {
		$lwp->proxy( [ 'http' ], $proxyHost ) if ( $proxyHost );
	}

	my $dbh;
	eval{ $dbh = Taranis::Database->new() };

	if ( $@ ) {
		print "Error connecting to database\n";
		exit;
	}

	my $self = {
		errmsg => undef,
		cfg => Taranis::Config->new(),
		dbh => $dbh,
		sql => SQL::Abstract->new(),
		err => Taranis::Error->new(),
		debugSource => undef,
		strips => decodeInput( $stripscfg->loadCollection() ),
		this_source => {},
		lwp => $lwp,
		collectorTest => 0 #normal operation is set to 0
	};

	my $consumer_key = Taranis::Config->getSetting( "twitter_consumer_key" );
	my $consumer_secret = Taranis::Config->getSetting( "twitter_consumer_secret" );
	my $token = Taranis::Config->getSetting( "twitter_access_token" );
	my $token_secret = Taranis::Config->getSetting( "twitter_access_token_secret" );	

	if ( $consumer_key && $consumer_secret && $token && $token_secret ) {
		$self->{twitter} = LWP::Authen::OAuth->new(
			oauth_consumer_key => $consumer_key,
			oauth_consumer_secret => $consumer_secret,
			oauth_token => $token,
			oauth_token_secret => $token_secret,
		);
		if ( $LWP::UserAgent::VERSION >= 6 ) {
			$self->{twitter}->proxy( [ 'http', 'https' ], $proxyHost ) if ( $proxyHost );
		} else {
			$self->{twitter}->proxy( [ 'http' ], $proxyHost ) if ( $proxyHost );
		}
		$self->{twitter}->agent( 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506)' );
	}

	$self->{debugSource} = $debugSource ? $debugSource : 0;

	##################################################################
	# SSL PROXY SETTINGS
	my $ssl_proxy_host = Taranis::Config->getSetting("ssl_proxy_host");
	my $ssl_proxy_user = Taranis::Config->getSetting("ssl_proxy_user");
	my $ssl_proxy_pass = Taranis::Config->getSetting("ssl_proxy_pass");
	$ENV{HTTPS_PROXY} = $ssl_proxy_host if ( $ssl_proxy_host );
	$ENV{HTTPS_PROXY_USERNAME}	= $ssl_proxy_user if ( $ssl_proxy_user );
	$ENV{HTTPS_PROXY_PASSWORD}	= $ssl_proxy_pass if ( $ssl_proxy_pass );
	$ENV{HTTPS_DEBUG} = $self->{debugSource} ? 1 : 0 ;
	$ENV{NO_PROXY} = Taranis::Config->getSetting("no_proxy");
	#
	################################################################## 

	bless $self;
	return $self;
}

sub getSourceMtbc {
  my ( $self, $debug ) = @_;

  # put the current source data from object ($self) into $source
  my $source = $self->{this_source};
  
  return 1 if ( $self->{this_source}->{sourcename} eq $self->{debugSource} || $self->{nomtbc} );
  
  my $mtbc  = abs( $self->{this_source}->{mtbc} );
  my %where = ( source => $source->{digest} );

  my ( $stmnt, @bind ) = $self->{sql}->select( "checkstatus", "timestamp", \%where );
  
  say "$stmnt, @bind" if $debug;
  
  $self->{dbh}->prepare( $stmnt );
  $self->{dbh}->executeWithBinds( @bind );

  my $timestamp = 0;

  while ( $self->nextObject() ) {
    my $record = $self->getObject();
    $timestamp = $record->{timestamp};
  }
  
  say $timestamp if $debug;
  
  my $now = nowstring(4);

  # if it doesn't exist in checkstatus make shure we're returning true
  my $checkSource = 1;
  if ( $timestamp + $mtbc * 60 > $now ) {
    $checkSource = 0;
  } 
  
  say "getSourceMtbc return: " . $checkSource if $debug;

  return $checkSource;
}

sub getSourceData {
	my ( $self, $url ) = @_;

	$self->{http_status} = 'OK';
	$self->{this_source}->{encoding} = undef;
	$self->{errmsg} = undef;
	my $lwp = $self->{lwp};
	
	my $retrieve_url = ( $url ) ? $url : $self->{this_source}->{fullurl};

	my $response;

	$retrieve_url = decode_entities( $retrieve_url );
	$retrieve_url =~ s/\\//g; # strip backslash from url
#	print Dumper $lwp;
	my ( $scheme, $auth, $path, $query, $frag ) = uri_split( $retrieve_url );
	if ( $scheme =~ /^https/ ) {
		if ( $LWP::UserAgent::VERSION < 6 && exists( $lwp->{proxy}->{https} ) ) {
			print " ...setting https to undef... ";
			$lwp->proxy( https => undef );
		}
		
		say "SSL request $retrieve_url" if $self->{debugSource};
		my $req = HTTP::Request->new( 'GET', "$retrieve_url" );
		$response = $lwp->request( $req );
		
	} else {
		say "PLAIN HTTP request $retrieve_url" if $self->{debugSource};
		$lwp->env_proxy;
		$response = $lwp->get( $retrieve_url );    
	}

	if ( $response->is_success ) {
		print $response->status_line . "\n" if ( $self->{debugSource} );
		
		$self->{http_status_code} = $response->status_line;
		
		my $content  = $response->decoded_content;

		my $encoding = 'UTF-8';   # assume this is the default
		
		if ( $content ) {
			if ( defined $self->{this_source}->{parser} ne 'xml' && !$self->{this_source}->{is_image} ) {
				$content =~ s/\n//gi;
			} 
		
			if ( $content =~ /encoding="([^"]+)"/ ) {
				$encoding = $1;
				say $encoding if ( $self->{debugSource} );
			} elsif ( $response->headers->{'content-type'} )  {
				my $content_type = $response->headers->{'content-type'};
				my @contents;
				if ( ref $content_type eq 'ARRAY' ) {
					@contents = eval { @$content_type };  
				} else {
					$contents[0] = $content_type;
				}
				
				my @eg = eval { grep { /charset=/ } @contents };
	
				if ( !$@ ) {
					if ( $eg[0] && $eg[0] =~ /charset=(.*)/ ) {
						$encoding = $1;  
					}  
				}
			}
		}
				
		print "Encoding: $encoding\n" if $self->{debugSource};
		$self->{this_source}->{encoding} = $encoding;

		return $content;
	} else {
		print $response->status_line . "\n" if ( $self->{debugSource} );
		
		my $error = 'Could not retrieve url ' . $retrieve_url . ' ' . $response->status_line;
				
		say $error if ( $self->{debugSource} );
		
		my $errorcode = $response->code;
		my $digest    = $self->{this_source}->{digest};
		my $content 	= Dumper $response;
    
    if ( $errorcode =~ /^503$/ ) {
#    	print Dumper \%ENV;
    	$content .= "===============ENV INFO==============\n";
    	$content .= Dumper \%ENV;
    }
    
		my $is_image = ( exists( $self->{this_source}->{is_image} ) && $self->{this_source}->{is_image} ) ? 1 : 0;
		# only write errors for sources with digest
		# images don't have a digest, image errors are handled
		# in other subs

		if ( !$self->{collectorTest} && !$self->{link_check_only} && !$self->{no_db} ) {
			
			$self->{err}->writeError(
																digest 		 => $digest, 
																error 		 => $error, 
																error_code => $errorcode, 
																content 	 => $content,
																sourceName => $self->{this_source}->{sourcename}
															) if ( !$self->{link_check_only} && !$is_image ); 
		}

		$self->{http_status_line} = $response->status_line;
		$self->{http_status_code} = $errorcode;
		return 0; 
	}
}

sub processTweets {
	my ( $self, $debug ) = @_;
	
	my $sourcename = $self->{this_source}->{sourcename};
	my $categoryId = $self->{this_source}->{categoryid};
	my $sourceUrl = decodeInput( \$self->{this_source}->{fullurl} );
	my $twitter = $self->{twitter};
	my $twitterStatusPrefix = "https://twitter.com/";

	my $response;
	my ( $scheme, $auth, $path, $query, $frag ) = uri_split( $sourceUrl );
	if ( $scheme =~ /^https/ ) {
		if ( $LWP::UserAgent::VERSION < 6 && exists( $twitter->{proxy}->{https} ) ) {
			print " ...setting https to undef... ";
			$twitter->proxy( https => undef );
		}
		
		say "SSL request $sourceUrl" if $self->{debugSource};
		my $req = HTTP::Request->new( 'GET', "$sourceUrl" );
		$response = $twitter->request( $req );

	} else {
		say "PLAIN HTTP request $sourceUrl" if $self->{debugSource};
		$twitter->env_proxy;
		$response = $twitter->get( $sourceUrl );    
	}
	
	if ( $response->is_success ) {
		print $response->status_line . "\n" if ( $debug );
		
		$self->{http_status_code} = $response->status_line;
		
		my $content = from_json( $response->decoded_content );
 		my $tweets = ( ref( $content ) =~ /^HASH$/ ) ? $content->{statuses} : $content;
		my $tweetCount = 0;
		foreach my $tweet ( reverse @$tweets ) {
			my $createdAt = $self->parseTwitterDate( $tweet->{created_at} );
			my $createdAtStr = "on " . $createdAt->{day} . "-" . $createdAt->{month} . "-" . $createdAt->{year} . " at " . $createdAt->{hour} . ":" . $createdAt->{minute}; 

			my $title = encodeInput( \$tweet->{text} );
			
			my $link = "$twitterStatusPrefix$tweet->{user}->{screen_name}/status/$tweet->{id}";
			my $twitterUserName = encodeInput( \$tweet->{user}->{name} );
			my $twitterScreenName = encodeInput( \$tweet->{user}->{screen_name} );
			my $description = "Posted by $twitterUserName a.k.a \@$twitterScreenName $createdAtStr";
			
			say '>title: ' . "$title\n" if $debug;
			say '>description: ' . "$description\n\n" if $debug;
			
			if ( length( $description ) > 500 ) {
				$description = substr( $description, 0, 500 );
				$description =~ s/(.*)\s+.*?$/$1/;
			}
			
			if ( length( $title ) > 250 ) {
				$title = substr( $title, 0, 250 );
				$title =~ s/(.*)\s+.*?$/$1/;
			}

			my $itemDigest = md5_base64( $title . $description . $link );
			
			my %where = ( digest => $itemDigest );
			if ( 
				!$self->{dbh}->checkIfExists( \%where, 'item' ) 
				&& !$self->{dbh}->checkIfExists( \%where, 'item_archive' )
			) { 
				$tweetCount++;
				my %insert = (
					digest => $itemDigest,
					category => $categoryId,
					source => $sourcename,
					title => $title,
					description => $description,
					'link' => $link,
					status => 0,
					source_id => $self->{this_source}->{id}
				);
	
				# save assess item
				my ( $stmnt, @bind ) = $self->{sql}->insert( 'item', \%insert );
	
				$self->{dbh}->prepare( $stmnt );
				$self->{dbh}->executeWithBinds( @bind );
	
				if ( defined( $self->{dbh}->{db_error_msg} ) ) {
					$self->{errmsg} = $self->{dbh}->{db_error_msg} . "\n";
					say $self->{errmsg} if ( $debug );
					return 0;
				}
			}			
		}
		print "$tweetCount new tweets \n";
 		return 1;

	} else {

		print $response->status_line . "\n" if ( $self->{debugSource} );
		
		my $error = 'Could not retrieve url ' . $sourceUrl . ' ' . $response->status_line;
				
		say $error if ( $self->{debugSource} );
		
		my $errorcode = $response->code;
		my $digest = $self->{this_source}->{digest};
		my $content = Dumper $response;

		if ( !$self->{collectorTest} && !$self->{link_check_only} && !$self->{no_db} ) {
			
			$self->{err}->writeError(
				digest => $digest, 
				error => $error, 
				error_code => $errorcode, 
				content => $content,
				sourceName => $self->{this_source}->{sourcename}
			) if ( !$self->{link_check_only} ); 
		}

		$self->{http_status_line} = $response->status_line;
		$self->{http_status_code} = $errorcode;
		return 0;
	}
}

sub processImapMail {
	my ( $self, $debug ) = @_;

	my $sourcename = $self->{this_source}->{sourcename};
	my $username = $self->{this_source}->{username};
	my $password = $self->{this_source}->{password};
	my $host = $self->{this_source}->{host};
	my $categoryId = $self->{this_source}->{categoryid};
	my $getid = $self->{this_source}->{checkid};
	my $port = $self->{this_source}->{port};
	my $mailbox = $self->{this_source}->{mailbox};
	my $archiveMailbox = $self->{this_source}->{archive_mailbox};
	my $protocol = $self->{this_source}->{protocol};
	my $sourceDigest = $self->{this_source}->{digest};
	my $containsAdvisory = $self->{this_source}->{contains_advisory};
	
	my $advisoryXSD = Taranis::Config->getSetting("advisory_xsd");
	
	my $as = Taranis::Assess->new();

	my $imapUTF7 = Unicode::IMAPUtf7->new();
	$mailbox = $imapUTF7->encode( decodeInput( \$mailbox ) ) if ( $mailbox );
	$archiveMailbox = $imapUTF7->encode( decodeInput( \$archiveMailbox ) ) if ( $archiveMailbox );
	
	my $imap = Mail::IMAPClient->new();

	$imap->Server( $host );
	$imap->User( $username );
	$imap->Password( $password );
	$imap->Timeout( '60' );
	$imap->Ignoresizeerrors( 1 );
  
	$imap->Port( $port ) if ( $port );
	$imap->Ssl( 1 ) if ( $protocol =~ /^imaps$/i );
#  $imap->Debug( 1 ) if ( $debug );

	my $mimeParser = MIME::Parser->new();
	my $mimeParserOutPutDir = Taranis::Config->getSetting("mimeparser_outputdir");
	
	if ( !$mimeParserOutPutDir || !-w $mimeParserOutPutDir ) {
		$self->{errmsg} = "No valid writable Mime Parser output directory specified in config.\n" 
			. "Make sure the output directory is writable for the user running the collector.";
		return 0;
	}  else {
		$mimeParser->output_dir( $mimeParserOutPutDir );

		say "\n" . nowstring(1) . " Connecting to IMAP server $host";
		
		if ( !$imap->connect() ) {
			$self->{errmsg} = "Could not connect to IMAP server $host: $@\n";
			return 0;
		}

		if ( !$imap->select( $mailbox ) ) {
			$self->{errmsg} = "Could not select folder $mailbox: \"$@\"\n";
			return 0;
		}

		if ( !$imap->exists( $archiveMailbox ) ) {
			$self->{errmsg} = "Could not connect to archive folder $archiveMailbox: \"$@\"\n";
			print "ARCHIVE MAILBOX NAME: " . $archiveMailbox;
			return 0;
		}
	  
		say "Selected Folder " . $imap->Folder() if ( $debug );
	  
		my $msgcount = $imap->message_count();
		say nowstring(1) . " Retrieving $msgcount message(s)";
	
		my @messagesSequenceNumbers = $imap->messages();
		
		# go through each message in the $mailbox
		MESSAGE:
		foreach my $msgSequenceNumber ( @messagesSequenceNumbers ) {

			my $messageId = $imap->get_header( $msgSequenceNumber, "Message-Id" );
			my $from = $imap->get_header( $msgSequenceNumber, "From" );
			my $subject = $imap->subject( $msgSequenceNumber );
	    	my $itemStatus = 0;
			my $messageHasValidXMLAdvisory = 0;	    	
	    	my $xmlAdvisory = {};
	    	
			$subject = "" if ( !$subject );
			$messageId = "" if ( !$messageId );
	    
			my $digest = md5_base64( $messageId . $subject );

			my %where = ( digest => $digest );

			# check if the message allready has been collected and added to Taranis 
			if ( 
				( !$self->{dbh}->checkIfExists( \%where, "item" ) )  
				&& ( !$self->{dbh}->checkIfExists( \%where, "item_archive" ) ) 
			) {

				say "3.processing message nr: " . $msgSequenceNumber if ( $debug );
					
				my $title = ( $subject ) ? HTML::Entities::encode( decode( "MIME-Header", $subject ) ) : "[MESSAGE HAS NO SUBJECT]";
				$from = ( $from ) ? HTML::Entities::encode( decode( "MIME-Header", $from ) ) : "[MISSING FROM IN MESSAGE]";
		    	
		    	my $message = $imap->message_string( $msgSequenceNumber );
				my $mimeEntity;
					
				eval{ $mimeEntity = $mimeParser->parse_data( $message ) } if ( $message );
					
				if ( $@ ) {
					$self->{errmsg} = "Error from MIME parser: " . $@;
	
					$self->{err}->writeError(
						digest => $sourceDigest,
						error => $self->{errmsg},
						error_code => '011',
						content => $message,
						sourceName => $sourcename					
					);
	
					say $self->{errmsg} if ( $debug );
					next MESSAGE;
				}
				
				my $body;
				$body = HTML::Entities::encode( decodeMimeEntity( $mimeEntity, 1, 1 ) );
				$body = "FROM: " . $from . " \n" . $body;
	      
				my $description = trim( $body );
				
				# trim description of item to 500 characters or less, end with whole word
				if ( length( $description ) > 500 ) {
					$description = substr( $description, 0, 500 );
					$description =~ s/(.*)\s+.*?$/$1/;
				}

				# trim title of item to 250 characters or less, end with whole word
				if ( length( $title ) > 250 ) {
					$title = substr(  $title, 0, 250 );
					$title =~ s/(.*)\s+.*?$/$1/;
				}

				# check if the source can contain Taranis XML advisories
				if ( $containsAdvisory ) {
					
					my $attachments = $as->getAttachmentInfo( $mimeEntity, undef );

					if ( $attachments ) {
						foreach my $attachmentName ( keys %$attachments ) {
							
							# only check XML attachments
							if ( $attachments->{$attachmentName}->{filetype} =~ /^xml$/i ) {
								
								my $validator = ( $advisoryXSD ) ? XML::Validator::Schema->new( file => $advisoryXSD ) : undef;
								my $xmlParser = ( $validator ) ? XML::SAX::ParserFactory->parser( Handler => $validator ) : undef;
							
								if ( !$xmlParser ) {
									$self->{errmsg} = 'Could not create an XML parser for XML Advisory, please check advisory_xsd setting in Taranis configuration.'; 
									say $self->{errmsg} if ( $debug );
									$self->{err}->writeError(
										digest => $sourceDigest,
										error => $self->{errmsg},
										error_code => '015',
										sourceName => $sourcename
									);
								} else {
								
									my $attachment = $as->getAttachment( $mimeEntity, $attachmentName );
									my $attachmentEntity;
									eval{ $attachmentEntity = $mimeParser->parse_data( $attachment ) } if ( $attachment );
									
									my $attachmentDecoded = decodeMimeEntity( $attachmentEntity, 1, 0 );
									
									# the XML is verified by a XML schema, which can be found in the 'advisory_xsd' setting in Taranis conf
									eval{ $xmlParser->parse_string( $attachmentDecoded ) };
									if ( $@ ) {
										$self->{errmsg} = $@;
										say $self->{errmsg} if ( $debug );
										
										$self->{err}->writeError(
											digest => $sourceDigest,
											error => "XML parser error for XML Advisory: $self->{errmsg}",
											error_code => '015',
											content => $attachmentDecoded,
											sourceName => $sourcename
										);
									} else {
										$messageHasValidXMLAdvisory = 1;
	
										# set item status to waitingroom
										$itemStatus = 3;
	
										# convert XML to perl datastructure
										$xmlAdvisory = XMLin( $attachmentDecoded, SuppressEmpty => '', KeyAttr => [] );
									}
								}
							}
						}
					}
				}
				
				## because each message will be saved into two tables,
				## saving to database is put in a transaction
				$self->{dbh}->startTransaction(); 
      	
				my %insert = (
					digest => $digest,
					body => HTML::Entities::encode( $message )
				);
				
				# save raw email contents in table email_item
				my ( $stmnt, @bind ) = $self->{sql}->insert( 'email_item', \%insert );

				$self->{dbh}->prepare( $stmnt );
				$self->{dbh}->executeWithBinds( @bind );

				if ( defined( $self->{dbh}->{db_error_msg} ) ) {
					$self->{errmsg} = $self->{dbh}->{db_error_msg} . "\n";
         
					$self->{dbh}->endTransaction();
					return 0;
				}

				my $last_insert_id = $self->{dbh}->getLastInsertedId( 'email_item' );
				my $link = 'id=' . $last_insert_id;
        
				if ( length $link > 250 ) {
					$self->{err}->writeError(
						digest => $sourceDigest,
						content => undef,
						error_code => '012',
						error => 'Link exceeds max link length.'
							. 'Could be caused by the length of the "scriptroot" setting in main configuration.'
							. 'LINK: ' . $link,
						sourceName => $sourcename
					) if ( !$self->{link_check_only} );

					$link = substr(  $link, 0, 250 );                 
				}
        
				%insert = (
					digest      => $digest,
					id          => nowstring(2), #is this still used?
					date        => nowstring(0), #is this still used?
					'time'      => nowstring(1), #is this still used?
					category    => $categoryId,
					source      => $sourcename,
					title       => $title,
					description => $description,
					'link'      => $link,
					is_mail     => 1,
					status      => $itemStatus,
					source_id	=> $self->{this_source}->{id}
				);

				# save assess item
				( $stmnt, @bind ) = $self->{sql}->insert( 'item', \%insert );

				$self->{dbh}->prepare( $stmnt );
				$self->{dbh}->executeWithBinds( @bind );

				$self->{dbh}->endTransaction();
				
				if ( defined( $self->{dbh}->{db_error_msg} ) ) {
					$self->{errmsg} = $self->{dbh}->{db_error_msg} . "\n";
					return 0;
				}

				# if there's a valid Taranis XML advisory, create an analysis and link it to the assess item
				if ( $messageHasValidXMLAdvisory ) {
					say "email contains valid Taranis XML Advsiory" if ( $debug );
					$self->importAdvisory( $xmlAdvisory, $digest, $debug );
				}
	      
				if ( !$imap->move( $archiveMailbox, $msgSequenceNumber ) ) {
					$self->{errmsg} = "Message has been saved, but could not be moved to archive mailbox $archiveMailbox: " . $@;
					return 0;
				}
	      
				$mimeParser->filer->purge;
			} else {
	    	
				if ( !$imap->move( $archiveMailbox, $msgSequenceNumber ) ) {
					$self->{errmsg} = "Message has not been saved, (because a duplicate already exists in Taranis) and could not be moved to archive mailbox $archiveMailbox: " . $@;
					return 0;
				}
	      
				print "skipping existing message nr: " . $msgSequenceNumber . ". Message has been moved to archive folder.\n" if ( $debug );
			}
		}
	}
	
	$imap->expunge;
	$imap->disconnect() if ( $imap->IsConnected() );

	return 1;
}

sub processPop3Mail {
	my ( $self, $debug ) = @_;

	my $sourceDigest		= $self->{this_source}->{digest};
	my $sourcename			= $self->{this_source}->{sourcename};
	my $username				= $self->{this_source}->{username};
	my $password				= $self->{this_source}->{password};
	my $host						= $self->{this_source}->{host};
	my $categoryId			= $self->{this_source}->{categoryid};
	my $getid						= $self->{this_source}->{checkid};
	my $port						= $self->{this_source}->{port};
	my $protocol				= $self->{this_source}->{protocol};
	my $deleteMail			= $self->{this_source}->{delete_mail};
	
	my $ssl = ( $protocol =~ /^pop3s$/i ) ? 1 : 0;

	my $pop3 = Mail::POP3Client->new( 
																		HOST		=> $host,
																		USESSL	=> $ssl,
																		USER		=> $username,
																		PASS		=> $password	
																	);
  
  $pop3->Host( $host );
  $pop3->User( $username );
  $pop3->Password( $password );
  $pop3->Port( $port ) 	if ( $port );

	my $mimeParser 					= MIME::Parser->new();
	my $mimeParserOutPutDir = Taranis::Config->getSetting( "mimeparser_outputdir" );

	if ( !$mimeParserOutPutDir || !-w $mimeParserOutPutDir ) {
		$self->{errmsg} = "No valid writable Mime Parser output directory specified in config.\n" 
											. "Make sure the output directory is writable for the user running the collector.";

		return 0;
	}  else {
		$mimeParser->output_dir( $mimeParserOutPutDir );
	                         
		say "\n" . nowstring(1) . " connecting to POP3 server $host";
		
	  if ( !$pop3->Connect() ) {
			$self->{errmsg} = "Could not connect to POP3 server $host: $@\n";
	  	return 0;
	  }

	  my $msgcount = $pop3->Count();
	  say nowstring(1) . " Retrieving $msgcount message(s)";
	
		MESSAGE:
	  for ( my $msgSequenceNumber = 1; $msgSequenceNumber <= $msgcount; $msgSequenceNumber++ ) {
			my $message = $pop3->Retrieve( $msgSequenceNumber );
			
			my ( $subject, $messageId, $from );
			
	    foreach ( $pop3->Head( $msgSequenceNumber ) ) {
	      /^(Subject):\s+/i 	 and $subject 	= $_;
	      /^(message-id):\s+/i and $messageId = $_;
	      /^(from):\s+/i 			 and $from 			= $_;
	    }
			
			$subject 	 = "" if ( !$subject );
			$messageId = "" if ( !$messageId );
			
			$subject 	 =~ s/\n//g;
			$messageId =~ s/\n//g;			
	    
	    my $digest = md5_base64( $messageId . $subject );
			
			my $mimeEntity;
			
			eval{ $mimeEntity = $mimeParser->parse_data( $message ) } if ( $message );
			
			if ( $@ ) {
				$self->{errmsg} = "Error from MIME parser: " . $@;
											 
				$self->{err}->writeError(
											             digest     => $sourceDigest,
											             error      => $self->{errmsg},
											             error_code => '011',
											             content   	=> $message,
											             sourceName => $sourcename					
																 );

				say $self->{errmsg} if ( $debug );
				next MESSAGE;
			}
			
	    my %where = ( digest => $digest );
	
	    if ( 
	    			( !$self->{dbh}->checkIfExists( \%where, "item" ) )  
	    			&& ( !$self->{dbh}->checkIfExists( \%where, "item_archive" ) ) 
	    ) {
	      
	      say "processing message nr: " . $msgSequenceNumber if ( $debug );
				
				my $title = ( $subject ) ? HTML::Entities::encode( decode( "MIME-Header", $subject ) ) : "[MESSAGE HAS NO SUBJECT]";
	    	$from 		= ( $from ) 	 ? HTML::Entities::encode( decode( "MIME-Header", $from ) ) 	 : "[NO HEADER 'FROM' IN MESSAGE]";				
				
				my $body;
				$body = HTML::Entities::encode( decodeMimeEntity( $mimeEntity, 1, 1 ) );
				$body = "FROM: " . $from . " \n" . $body;
	      
	      my $description = trim( $body );
	      if ( length( $description ) > 500 ) {
					$description = substr( $description, 0, 500 );
					$description =~ s/(.*)\s+.*?$/$1/;
	      }

				if ( length( $title ) > 250 ) {
        	$title = substr(  $title, 0, 250 );
        	$title =~ s/(.*)\s+.*?$/$1/;
				}
	
      	$self->{dbh}->startTransaction();
      	
        my %insert = (
                       digest => $digest,
                       body   => HTML::Entities::encode( $message )
        						 );

        my ( $stmnt, @bind ) = $self->{sql}->insert( 'email_item', \%insert );
        
        $self->{dbh}->prepare( $stmnt );
        $self->{dbh}->executeWithBinds( @bind );
	        
        if ( defined( $self->{dbh}->{db_error_msg} ) ) {
          $self->{errmsg} = $self->{dbh}->{db_error_msg} . "\n";
          
          $self->{dbh}->endTransaction();
          return 0;
        }

        my $last_insert_id = $self->{dbh}->getLastInsertedId( 'email_item' );
        my $link           = $self->{cfg}->{scriptroot} . '/mod_assess/show_mail.pl?id=' . $last_insert_id;
        
        if ( length $link > 250 ) {
           $self->{err}->writeError(
												             digest     => $sourceDigest,
												             content    => undef,
												             error_code => '012',
												             error   		=> 'Link exceeds max link length.'
												             							 . 'Could be caused by the length of the "scriptroot" setting in main configuration.'
												             							 . 'LINK: ' . $link,
												             sourceName => $sourcename
								            				) if ( !$self->{link_check_only} );

           $link = substr(  $link, 0, 250 );                 
         }
        
        %insert = (
                    digest      => $digest,
                    id          => nowstring(2),
                    date        => nowstring(0),
                    'time'      => nowstring(1),
                    category    => $categoryId,
                    source      => $sourcename,
                    title       => $title,
                    description => $description,
                    'link'      => $link,
                    is_mail     => 1,
                    status      => 0,
                    source_id	=> $self->{this_source}->{id}
        					);

				( $stmnt, @bind ) = $self->{sql}->insert( 'item', \%insert );
          
				$self->{dbh}->prepare( $stmnt );
				$self->{dbh}->executeWithBinds( @bind );
				
				$self->{dbh}->endTransaction();
				
				if ( defined( $self->{dbh}->{db_error_msg} ) ) {
					$self->{errmsg} = $self->{dbh}->{db_error_msg} . "\n";
					return 0;
				}

				$pop3->Delete( $msgSequenceNumber ) if ( $deleteMail );
	      
	      $mimeParser->filer->purge;
	    } else {
	      print "skipping existing message nr: " . $msgSequenceNumber . "\n" if ( $debug );
	    }
	  }
	}
		  
  $pop3->Close();

  return 1;
}

sub processXmlFeed {
	my ( $self, $source_data ) = @_;
	my @feedLinks;
	undef $self->{errmsg};

	my $feed;
	my $foundItems = 0;
	
	my $debug = ( $self->{this_source}->{sourcename} eq $self->{debugSource}) ? 1 : 0;
	my $encoding = $self->{this_source}->{encoding} || 'UTF-8';

	if ( $source_data !~ /^<\?xml/i ) {
		$source_data = '<?xml version="1.0" encoding="'.$encoding.'"?>' . $source_data;
	}

	eval { $feed = XML::FeedPP->new( $source_data, ignore_error => 1 ) };
	
	if ( $@ ) {
		my $strippedError = $@;
		$strippedError =~ s/(.*?)at \/.*/$1/i;
		
		$self->{errmsg} = "XML parsing error: " . $strippedError;
		say $self->{errmsg} if ( $debug );
		$source_data = '';
		return;
	}

	my @feedItems = $feed->get_item();
	
	if ( scalar( @feedItems ) == 0 ) {
		$self->{errmsg} = "No items found in XML feed";
		return;
	}
	
	foreach my $item ( @feedItems ) {

		my $title       = $item->title();
		my $link        = $item->link();
		my $description = $item->description();
	
		if ( ref( $description ) eq 'HASH' ) {
			$description = ( ref( $description->{'a'} ) ne 'ARRAY' && exists( $description->{'a'}->{'#text'} ) && defined( $description->{'a'}->{'#text'} ) ) 
			             ? $description->{'a'}->{'#text'} 
			             : "" ;
			$description = ( $description eq "" && ref( $item->{summary} ) ne 'HASH' ) ? $item->{summary} : "";
		}

		$title		 = $self->prepareTextForSaving( $title ) if ( $title );
		$description = $self->prepareTextForSaving( $description ) if ( $description );
	
		$title = ( $title ) ? basicFilter( $title ) : "";
		$link  = basicFilter( $link );

		$description = basicFilter( $description );

		my $itemDigest = md5_base64( $title . $description . $link );
		my $table = 'item';

		if ( $link ne "" && $title ne "" ) {
			$title 			 = encodeInput( \$title );
			$description = encodeInput( \$description );

			#in some cases the combination of éé causes wrong output like &eacute;&#xFFFD;&copy; therefor:
			$title 			 =~ s/&eacute;&#xFFFD;&copy;/&eacute;&eacute;/gi;
			$description =~ s/&eacute;&#xFFFD;&copy;/&eacute;&eacute;/gi;

			#hack to remove advertisement and weird characters
			if ( $self->{this_source}->{sourcename} eq 'TheRegister') {
				$description =~ s/(.*\.)?&#xFFFD;.*hitepaper/$1/; 
			}

			print '>title: ' . "$title\n"  if $debug;
			print '>description: ' . "$description\n\n"  if $debug;
			
			if ( length( $description ) > 500 ) {
				$description = substr( $description, 0, 500 );
				$description =~ s/(.*)\s+.*?$/$1/;
			}
			
			if ( length( $title ) > 250 ) {
				$title = substr( $title, 0, 250 );
				$title =~ s/(.*)\s+.*?$/$1/;
			}
			
			if ( !$self->{collectorTest} && !$self->{no_db} ) {
 				if ( length $link > 250 ) {
           $self->{err}->writeError(
												             digest     => $self->{this_source}->{digest},
												             content    => undef,
												             error_code => '012',
												             error   		=> 'Link exceeds max link length. LINK: ' . $link,
												             sourceName => $self->{this_source}->{sourcename}
								            				) if ( !$self->{link_check_only} );
					$link = substr(  $link, 0, 250 );                 
				}
			}

			if ( $debug && ( $description =~ /(&#xFFFD;|&Atilde;|&Acirc;|&#x)/i || $title =~ /(&#xFFFD;|&Atilde;|&Acirc;|&#x)/i ) ) {
				say $1 . " --- " . $title;
				say $description;
			}

      my %insert = (
                     digest      => $itemDigest,
                     id          => nowstring(2), # is this stilled used somewhere?
                     date        => nowstring(0), # is this stilled used somewhere?
                     'time'      => nowstring(1), # is this stilled used somewhere?
                     category    => $self->{this_source}->{categoryid},
                     source      => $self->{this_source}->{sourcename},
                     title       => $title,
                     'link'      => $link,
                     description => $description,
                     status      => 0,
                     source_id	=> $self->{this_source}->{id}
      );

##### CODE FOR COLLECTOTEST SCRIPT #####
			if ( $self->{collectorTest} ) {
				my %testInsert = ( title => $title, description => $description, sourceTest => $self->{this_source}->{sourcename}, url => $self->{this_source}->{fullurl} );
				
				my ( $stmnt, @bind ) = $self->{sql}->insert( 'collectortest', \%testInsert );
				$self->{dbh}->prepare( $stmnt );
				$self->{dbh}->executeWithBinds( @bind );
			}
#########################################			
      my %where = ( digest => $itemDigest );
      if ( 
      			( !$self->{dbh}->checkIfExists( \%where, $table ) ) 
      			&& ( !$self->{dbh}->checkIfExists( \%where, $table."_archive" ) ) 
      	) {
				
				$foundItems = 1;
				
				if ( !$self->{collectorTest} && !$self->{no_db} ) {
					my ( $stmnt, @bind ) = $self->{sql}->insert( $table, \%insert );
					
					$self->{dbh}->prepare( $stmnt );
					$self->{dbh}->executeWithBinds( @bind );

					if ( defined( $self->{dbh}->{db_error_msg} ) ) {
						$self->{errmsg} = 'DB ERROR: ' . $self->{dbh}->{db_error_msg};
						return;
					}
				}
				
				push @feedLinks, { itemDigest => $itemDigest, 'link' => $link }; #, description => $description, title => $title };
				
			} else {
				$foundItems = 1;
				print "$itemDigest Exists in table item\n" if $debug;
			}
		} 
	}
	
	if ( $foundItems ) {
		return \@feedLinks;	
	} else {
		$self->{errmsg} = "XML feed only contains bad items.";
		return;		
	}
}

sub processHtmlFeed {
	my ( $self, $contents ) = @_;
	undef $self->{errmsg};
	
	my $debug = ( $self->{this_source}->{sourcename} eq $self->{debugSource} ) ? 1 : 0;

	print "processHtmlFeed debug: $debug " . $self->{debugSource} . " - " .$self->{this_source}->{sourcename} .  "\n" if ( $debug );
	
	my $parser = Taranis::Parsers->new();
	my @feedLinks;
	
	my $foundItems = 0;
	
	if ( my $element = $parser->getParser( $self->{this_source}->{parser} ) ) {
		print Dumper $element if ( $debug );

		say 'parsing ' . $self->{this_source}->{parser} if ( $debug );
		my $itemstart  = decodeInput( \$element->{item_start} );
		my $itemstop   = decodeInput( \$element->{item_stop} );
		my $titlestart = decodeInput( \$element->{title_start} );
		my $titlestop  = decodeInput( \$element->{title_stop} );
		my $descstart  = decodeInput( \$element->{desc_start} );
		my $descstop   = decodeInput( \$element->{desc_stop} );
		my $linkstart  = decodeInput( \$element->{link_start} );
		my $linkstop   = decodeInput( \$element->{link_stop} );
		my $linkprefix = decodeInput( \$element->{link_prefix} );
		my $search1    = decodeInput( \$element->{strip0_start} );
		my $replace1   = decodeInput( \$element->{strip0_stop} );
		my $search2    = decodeInput( \$element->{strip1_start} );
		my $replace2   = decodeInput( \$element->{strip1_stop} );
		my $search3    = decodeInput( \$element->{strip2_start} );
		my $replace3   = decodeInput( \$element->{strip2_stop} );

	  if ( $debug ) {
			print "\n--------\nLINKPREFIX: $linkprefix - $element->{link_prefix}\n";
			print "itemstart: $itemstart \n";
			print "itemstop: $itemstop\n";
			print "titlestart: $titlestart\n";
			print "titlestop $titlestop\n";
			print "descstart: $descstart\n";
			print "descstop: $descstop\n";
			print "linkstart: $linkstart\n";
			print "linkstop: $linkstop\n";
			print "linkprefix: $linkprefix\n"; 
		}              

		my $maxlinklength  = 250;
		my $maxdesclength  = 500;
		my $maxtitlelength = 250;

		my $oddcheck = 0;

#		my @split1   = split( "$itemstart(.*?)$itemstop", $contents ); #OLD
		my @split1   = split( /\Q$itemstart\E(.*?)\Q$itemstop\E/, $contents );		
		print scalar @split1 . " elements in split content\n" if $debug;

		if ( scalar( @split1 ) == 0 ) {
			$self->{errmsg} = "No items found in HTML feed";
			return;
		}

		my $link;

		foreach my $split1 ( @split1 ) {
			if ( isodd( $oddcheck++ ) ) {
				
				if ( length( $linkstart ) > 0 ) {
#					my @linkarr = split( "$linkstart(.*?)$linkstop", $split1 ); #OLD
					my @linkarr = split( /\Q$linkstart\E(.*?)\Q$linkstop\E/, $split1 );					
					print Dumper \@linkarr if $self->{parser_debug};
					
					my $templink = ( $linkarr[1] ) ? trim( basicFilter( $linkarr[1] ) ) : "";

					print "TEMPLINK: $templink\n" if ( $debug );
					$link = ( lc( substr( $templink, 0, 4 ) ) eq "http" ) ? $templink : $linkprefix . $templink;
					
					print "LINK: $link\n" if ( $debug ); 
				}

				my ( @titleArr, @descriptionArr );
				my ( $title, $description );

				if ( length( $titlestart ) > 0 ) {
#					@titleArr = split( "$titlestart(.*?)$titlestop", $split1 ); #OLD
					@titleArr = split( /\Q$titlestart\E(.*?)\Q$titlestop\E/, $split1 );
					$title = $titleArr[1];
				}

				if ( length( $descstart ) > 0 ) {
#					@descriptionArr = split( "$descstart(.*?)$descstop", $split1 ); #OLD
					@descriptionArr = split( /\Q$descstart\E(.*?)\Q$descstop\E/, $split1 );
					$description = $descriptionArr[1];
				}

				$description = $self->prepareTextForSaving( $description ) if ( $description );
				$title			 = $self->prepareTextForSaving( $title ) if ( $title );

				$description = basicFilter( $description );
				$title = ( $title )? basicFilter( $title ) : "";
				$link  = basicFilter( $link );

				my $itemDigest = md5_base64( $title . $description . $link );
				
				if ( $debug && ( $description =~ /(&#xFFFD;|&Atilde;|&Acirc;|&#x)/i || $title =~ /(&#xFFFD;|&Atilde;|&Acirc;|&#x)/i ) ) {
					say $1 . " --- " . $title;
					say $description;
				}

				if ( $link ne "" && $title ne "" ) {
					
					$title 			 = encodeInput( \$title );
					$description = encodeInput( \$description );

					#in some cases the combination of éé causes wrong output like &eacute;&#xFFFD;&copy; therefor:
					$title 			 =~ s/&eacute;&#xFFFD;&copy;/&eacute;&eacute;/gi;
					$description =~ s/&eacute;&#xFFFD;&copy;/&eacute;&eacute;/gi;					

					if ( length( $description ) > $maxdesclength ) {
						$description = substr( $description, 0, $maxdesclength );
						$description =~ s/(.*)\s+.*?$/$1/;
					}
					
					if ( length( $title ) > $maxtitlelength ) {
						$title = substr( $title, 0, $maxtitlelength );
						$title =~ s/(.*)\s+.*?$/$1/;
					}		

					if ( !$self->{collectorTest} && !$self->{no_db} ) {
		 				if ( length $link > $maxlinklength ) {
		           $self->{err}->writeError(
														             digest     => $self->{this_source}->{digest},
														             content    => undef,
														             error_code => '012',
														             error   		=> 'Link exceeds max link length. LINK: ' . $link,
														             sourceName => $self->{this_source}->{sourcename}
										            				) if ( !$self->{link_check_only} );
							$link = substr(  $link, 0, $maxlinklength );                 
						}
					}
					
					my %insert = (
													digest			=> $itemDigest,
													id				=> nowstring(2), #TODO: is this still being used somewhere?
													date			=> nowstring(0), # is this still being used somewhere?
													'time'			=> nowstring(1), # is this still being used somewhere?
													category		=> $self->{this_source}->{categoryid},
													source			=> $self->{this_source}->{sourcename},
													title			=> $title,
													'link'			=> $link,
													description	=> $description, 
													status			=> 0,
													source_id		=> $self->{this_source}->{id}
												);
					
##### CODE FOR COLLECTOTEST SCRIPT #####					
					if ( $self->{collectorTest} ) {
						my %testInsert = ( 
																title => $title, 
																description => $description, 
																sourceTest => $self->{this_source}->{sourcename}, 
																url => $self->{this_source}->{fullurl} 
															);
						
						my ( $stmnt, @bind ) = $self->{sql}->insert( 'collectortest', \%testInsert );
						$self->{dbh}->prepare( $stmnt );
						$self->{dbh}->executeWithBinds( @bind );
					}
#########################################

					if ( $self->{link_check_only} ) {
						push @feedLinks,  { title => $title, 'link' => $link, description => $description, digest => $itemDigest };
					}

					my %where = ( digest => $itemDigest );
					if ( 
							( !$self->{dbh}->checkIfExists( \%where, 'item' ) ) 
							&& !$self->{dbh}->checkIfExists( \%where, 'item_archive' ) 
							&& !$self->{link_check_only}
							&& !$self->{collectorTest} 
							&& !$self->{no_db} 
					)	{
						
						$foundItems = 1;	
						
						if ( !$self->{collectorTest} && !$self->{no_db} ) {

							my ( $stmnt, @bind ) = $self->{sql}->insert( 'item', \%insert );

							$self->{dbh}->prepare( $stmnt );
							$self->{dbh}->executeWithBinds( @bind );
						}
						
						if ( defined( $self->{dbh}->{db_error_msg} ) ) {
							$self->{errmsg} = "DB ERROR: " . $self->{dbh}->{db_error_msg};
							return;
						}
            
						push @feedLinks,  { itemDigest => $itemDigest, 'link' => $link }; #, description => $description, title => $title, };
					} else {
						$foundItems = 1;
						print "$itemDigest Exists in table item\n" if $debug;						
					}
				} 
			}
		}
	}
	
	if ( $foundItems ) {
		return \@feedLinks;	
	} else {
		$self->{errmsg} = "HTML feed only contains bad items.";
		return;		
	}
}

sub importAdvisory {
	my ( $self, $xmlAdvisory, $itemDigest, $debug ) = @_;
	
	my $an = Taranis::Analysis->new();
	my ( $importError, $newAnalysisId, $title, $newTitle, $basedOnAdvisoryVersion ); 
	my $analysisRating = $an->getAnalysisRatingFromAdvisory( 
		damage => lc $xmlAdvisory->{meta_info}->{damage}, 
		probability => lc $xmlAdvisory->{meta_info}->{probability} 
	);
	
	my $idString = '';
	foreach my $typeId ( %{ $xmlAdvisory->{meta_info}->{vulnerability_identifiers} } ) {
		if ( ref ( $xmlAdvisory->{meta_info}->{vulnerability_identifiers}->{$typeId}->{id} ) =~ /^ARRAY$/ ) {
			foreach my $id ( @{ $xmlAdvisory->{meta_info}->{vulnerability_identifiers}->{$typeId}->{id} } ) {
				$idString .= "$id ";
			}
		} else {
			$idString .= "$xmlAdvisory->{meta_info}->{vulnerability_identifiers}->{$typeId}->{id} ";
		}
	}
		
	$self->{dbh}->startTransaction();
	
	# save new analysis
	if ( $newAnalysisId = $an->addObject( 	
		table => "analysis",
		title => encodeInput( \encode( 'UTF-8', $xmlAdvisory->{meta_info}->{title} ) ), 
		comments => encodeInput( \encode( 'UTF-8', $xmlAdvisory->{content}->{abstract} ) ), 
		idstring => $idString, 
		rating => $analysisRating,
		status => 'pending'
	)) {
		
		# link analysis to assess item
		if ( !$an->linkToItem( $itemDigest, $newAnalysisId ) ) {
			$importError = $an->{errmsg};
			say $importError if ( $debug );
		}
	} else {
		$importError = $an->{errmsg};
		say $importError if ( $debug );
	}
	$self->{dbh}->endTransaction();
	 
	if ( $self->{this_source}->{create_advisory} && !$importError ) {
		my $pu = Taranis::Publication->new();
		my $pa = Taranis::Publication::Advisory->new();
		my $sh = Taranis::SoftwareHardware->new();
		my $dd = Taranis::Damagedescription->new();
		my $tt = Taranis::Template->new();
		my $advisoryHandler = $self->{this_source}->{advisory_handler};
		my ( $advisoryId, $publicationId );
		$basedOnAdvisoryVersion = '1.00';

		my @xmlVersionHistory = ( ref ( $xmlAdvisory->{meta_info}->{version_history}->{version_instance} ) =~ /^ARRAY$/  ) 
			? @{ $xmlAdvisory->{meta_info}->{version_history}->{version_instance} }
			: $xmlAdvisory->{meta_info}->{version_history}->{version_instance};

		foreach my $versionInstance ( @xmlVersionHistory ) {
			$basedOnAdvisoryVersion = $versionInstance->{version} if ( $versionInstance->{version} > $basedOnAdvisoryVersion );
		}

		my $typeName = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{advisory}->{email};
		my $typeId = $pu->getPublicationTypeId( $typeName )->{id};
		
		my $title = $pa->getTitleFromXMLAdvisory( $xmlAdvisory );
		my $advisoyIDDetails = $pa->getAdvisoryIDDetailsFromXMLAdvisory( $xmlAdvisory );
		my $advisoryLinks = $pa->getLinksFromXMLAdvisory( $xmlAdvisory );
		my $softwareHardwareDetails = $pa->getSoftwareHardwareFromXMLAdvisory( $xmlAdvisory );
		my $damageDescriptionDetails = $pa->getDamageDescriptionsFromXMLAdvisory( $xmlAdvisory );
		$idString =~ s/ +/, /g;
		$idString =~ s/, $//;

		# add new damage descriptions
		foreach my $xmlDamageDescription ( @{ $damageDescriptionDetails->{newDamageDescriptions} } ) {
			if ( $dd->addDamageDescription( description => $xmlDamageDescription ) ) {
				push @{ $damageDescriptionDetails->{damageDescriptionIds} }, $dd->{dbh}->getLastInsertedId('damage_description');
				
				$self->{err}->writeError(
					digest => $self->{this_source}->{digest},
					error => encode( 'UTF-8', "Damage description '$xmlDamageDescription' has been added"),
					error_code => '016',
					sourceName => $self->{this_source}->{sourcename}
				);
			} else {
				$importError = $dd->{errmsg};
			}
		}

		# start adding advisory, etc, to database 
		$pu->{dbh}->startTransaction();
		if (
			!$pu->addPublication(
				title => substr( $title, 0, 50 ),
				created_by => $advisoryHandler,
				type => $typeId,
				status => '0'
			)
			|| !( $publicationId = $pu->{dbh}->getLastInsertedId('publication') )
			|| !$pu->linkToPublication(
						table => 'analysis_publication',
						analysis_id => $newAnalysisId,
						publication_id => $publicationId
				)
			|| !$pu->linkToPublication( 
					table => 'publication_advisory',
					publication_id => $publicationId,
					version => $advisoyIDDetails->{newAdvisoryVersion},
					govcertid => $advisoyIDDetails->{newAdvisoryDetailsId},
					title => $title,
					probability => $pa->{scale}->{$xmlAdvisory->{meta_info}->{probability} },
					damage => $pa->{scale}->{ $xmlAdvisory->{meta_info}->{damage} },
					ids => $idString,
					platforms_text => encodeInput( \encode( 'UTF-8', $xmlAdvisory->{meta_info}->{system_information}->{systemdetail}->{affected_platforms_text} ) ),
					versions_text => encodeInput( \encode( 'UTF-8', $xmlAdvisory->{meta_info}->{system_information}->{systemdetail}->{affected_products_versions_text} ) ),
					products_text => encodeInput( \encode( 'UTF-8', $xmlAdvisory->{meta_info}->{system_information}->{systemdetail}->{affected_products_text} ) ),
					hyperlinks => $advisoryLinks,
					description => encodeInput( \encode( 'UTF-8', $xmlAdvisory->{content}->{description} ) ),
					consequences => encodeInput( \encode( 'UTF-8', $xmlAdvisory->{content}->{consequences} ) ),
					update => encodeInput( \encode( 'UTF-8', $xmlAdvisory->{content}->{update_information} ) ),
					solution => encodeInput( \encode( 'UTF-8', $xmlAdvisory->{content}->{solution} ) ),
					summary => encodeInput( \encode( 'UTF-8', $xmlAdvisory->{content}->{abstract} ) ),
					ques_dmg_infoleak => $xmlAdvisory->{rating}->{publisher_analysis}->{ques_dmg_infoleak},
					ques_dmg_privesc => $xmlAdvisory->{rating}->{publisher_analysis}->{ques_dmg_privesc},
					ques_dmg_remrights => $xmlAdvisory->{rating}->{publisher_analysis}->{ques_dmg_remrights},
					ques_dmg_codeexec => $xmlAdvisory->{rating}->{publisher_analysis}->{ques_dmg_codeexec},
					ques_dmg_dos => $xmlAdvisory->{rating}->{publisher_analysis}->{ques_dmg_dos},
					ques_dmg_deviation => $xmlAdvisory->{rating}->{publisher_analysis}->{ques_dmg_deviation},
					ques_pro_solution => $xmlAdvisory->{rating}->{publisher_analysis}->{ques_pro_solution},
					ques_pro_expect => $xmlAdvisory->{rating}->{publisher_analysis}->{ques_pro_expect},
					ques_pro_exploited => $xmlAdvisory->{rating}->{publisher_analysis}->{ques_pro_exploited},
					ques_pro_userint => $xmlAdvisory->{rating}->{publisher_analysis}->{ques_pro_userint},
					ques_pro_complexity => $xmlAdvisory->{rating}->{publisher_analysis}->{ques_pro_complexity},
					ques_pro_credent => $xmlAdvisory->{rating}->{publisher_analysis}->{ques_pro_credent},
					ques_pro_access => $xmlAdvisory->{rating}->{publisher_analysis}->{ques_pro_access},
					ques_pro_details => $xmlAdvisory->{rating}->{publisher_analysis}->{ques_pro_details},
					ques_pro_exploit => $xmlAdvisory->{rating}->{publisher_analysis}->{ques_pro_exploit},
					ques_pro_standard => $xmlAdvisory->{rating}->{publisher_analysis}->{ques_pro_standard},
					ques_pro_deviation => $xmlAdvisory->{rating}->{publisher_analysis}->{ques_pro_deviation},
					based_on => $xmlAdvisory->{meta_info}->{reference_number} . " $basedOnAdvisoryVersion"
				)
		) {
			$importError = $pu->{errmsg};
		} else {
			$advisoryId = $pu->{dbh}->getLastInsertedId('publication_advisory');

			# link products to advisory
			foreach my $softwareHardware ( @{ $softwareHardwareDetails->{products} } ) {
				if (
					!$pu->linkToPublication(
						table => 'product_in_publication',
						softhard_id => $softwareHardware->{id},
						publication_id => $publicationId
					)
				) {
					$importError = $pu->{errmsg};
				}
			}

			# link platforms to advisory	
			foreach my $softwareHardware ( @{ $softwareHardwareDetails->{platforms} } ) {
				if (
					!$pu->linkToPublication(
						table => 'platform_in_publication',
						softhard_id => $softwareHardware->{id},
						publication_id => $publicationId
					)
				) {
					$importError = $pu->{errmsg};
				}
			}

			# link damage descriptions to advisory	
			foreach my $damageDescriptionId ( @{ $damageDescriptionDetails->{damageDescriptionIds} } ) {
				if (
					!$pu->linkToPublication(
						table => 'advisory_damage',
						damage_id => $damageDescriptionId,
						advisory_id => $advisoryId
					)
				) {
					$importError = $pu->{errmsg};
				}
			}	
		}

		# update replacedby_id of previous version advisory with new publication id
		if ( $advisoyIDDetails->{publicationPreviousVersionId} && !$pu->setPublication( id => $advisoyIDDetails->{publicationPreviousVersionId}, replacedby_id => $publicationId ) ) {
			$importError = $pu->{errmsg};
		}

		# log software/hardware which could not be linked to advisory
		foreach my $shProblem ( @{ $softwareHardwareDetails->{importProblems} } ) {
			$self->{err}->writeError(
				digest => $self->{this_source}->{digest},
				error => $shProblem,
				error_code => '017',
				sourceName => $self->{this_source}->{sourcename},
				reference_id => $publicationId
			);
		}

		$pu->{dbh}->endTransaction();

		if ( !$importError ) {
			my $advisoryType = ( $advisoyIDDetails->{newAdvisoryVersion} > 1 ) ? 'update' : 'email';
			my $previewText = $tt->processPreviewTemplate( 'advisory', $advisoryType, $advisoryId, $publicationId, 0, 71 );
			my $xmlText = $pu->processPreviewXml( $advisoryId );

			# set contents of new publication
			if ( !$pu->setPublication( id => $publicationId, contents => $previewText, xml_contents => $xmlText ) ) {
				$importError = $pu->{errmsg};
			}

			$previewText = encodeInput( \$previewText );
			my $publisher = encodeInput( \encode( 'UTF-8', $xmlAdvisory->{meta_info}->{issuer} ) );
			my $referenceNumberNamingPart = ( $xmlAdvisory->{meta_info}->{reference_number} =~ /^(.*?)-\d{4}-\d+$/ )[0];
			my $referencesToPublisher = "";
			
			foreach my $lineWithReference ( $previewText =~ /\n(.*?$referenceNumberNamingPart.*?\n)/gmi, $previewText =~ /\n(.*?$publisher.*?\n)/gmi ) {
				$lineWithReference =~ s/^\s*(.*?)\s*$/$1/;
				
				if ( $referencesToPublisher !~ $lineWithReference ) {
					$referencesToPublisher .= $lineWithReference . "\n"; 
					$previewText =~ s/(\Q$lineWithReference\E)/<span class="mark-text">$1<\/span>/;
				}
			}

			$previewText =~ s/($referenceNumberNamingPart|$publisher)/<span class="bold">$1<\/span>/gi;

			if ( $referencesToPublisher ) {
				$self->{err}->writeError(
					digest => $self->{this_source}->{digest},
					error => "References to publisher found in advisory during advisory import",
					error_code => '018',
					content => $previewText,
					sourceName => $self->{this_source}->{sourcename},
					reference_id => $publicationId
				);
			}
		}
		
		$newTitle = "$advisoyIDDetails->{newAdvisoryDetailsId} [v$advisoyIDDetails->{newAdvisoryVersion}] $xmlAdvisory->{meta_info}->{title}";
	}

	if ( $importError ) {
		$self->{err}->writeError(
			digest => $self->{this_source}->{digest},
			error => "Advisory import error: $importError",
			error_code => '015',
			content => Dumper $xmlAdvisory,
			sourceName => $self->{this_source}->{sourcename}
		);
		return 0;						
	} else {
		
		my $notificationText = ( $self->{this_source}->{create_advisory} )
			? encode( 'UTF-8', "Imported advisory '$xmlAdvisory->{meta_info}->{reference_number} [v$basedOnAdvisoryVersion]' as pending advisory '$newTitle'")
			: encode( 'UTF-8', "Imported advisory '$xmlAdvisory->{meta_info}->{title}' as pending analysis AN-" . substr( $newAnalysisId, 0,4) . '-' .substr( $newAnalysisId, 3,4) );
		
		$self->{err}->writeError(
			digest => $self->{this_source}->{digest},
			error => $notificationText,
			error_code => '016',
			sourceName => $self->{this_source}->{sourcename}
		);
		return 1;
	}
}

sub writeSourceCheck {
	my ( $self, %arg ) = @_;

	my $source 	= $arg{source}; 
	my $comment = $arg{comment};

	my $table   = 'checkstatus';
	my %where   = ( source => $source );
	my %updates = ( timestamp => nowstring(4), comments => $comment );

	if ( $self->{dbh}->checkIfExists( \%where, $table ) ) {
		my ( $stmnt, @bind ) = $self->{sql}->update( $table, \%updates, \%where );

		$self->{dbh}->prepare( $stmnt );
		$self->{dbh}->executeWithBinds( @bind );

		if ( defined( $self->{dbh}->{db_error_msg} ) ) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			return 0;
		}

	} else {
		$updates{source} = $source;
		my ( $stmnt, @bind ) = $self->{sql}->insert( $table, \%updates );

		$self->{dbh}->prepare( $stmnt );
		$self->{dbh}->executeWithBinds( @bind );

		if ( defined( $self->{dbh}->{db_error_msg} ) ) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			return 0;
		}
	}
	return 1;
}

sub parseIdentifierPatterns {
	my ( $self, $sourceData ) = @_;

	my $identifier = Taranis::Config::XMLGeneric->new( "identifiersconfig", "idname", "ids" );
	my $identifiers = decodeInput( $identifier->loadCollection() );

	# eerst strips uitvoeren
	my $source_data = $self->stripsData( $sourceData );
	
	my @foundIdentifiers;
	foreach my $line ( @$identifiers ) {
		while ( $source_data =~ m/$line->{pattern}/gi ) {
			my $tempId = $&;
			if ( $line->{substitute} ) {

				$line->{substitute} =~ m/(.*?)\/(.*)/gi;
				my $search  = ( $1 ) ? $1 : "";
				my $replace = ( $2 ) ? $2 : "";
				$tempId =~ s/$search/$replace/gi;
			}

			push @foundIdentifiers, ( { identifier => $tempId, digest => $self->{item_digest} } );
		}
	}

	return @foundIdentifiers;
}

sub setCollectorStarted {
	my ( $self, %args ) = @_;
	undef $self->{errmsg};
	
	my $stmnt = "INSERT INTO statistics_collector DEFAULT VALUES;";

	$self->{dbh}->prepare( $stmnt );
	if ( defined( $self->{dbh}->executeWithBinds() ) > 0 ) {
		return $self->{dbh}->getLastInsertedId( 'statistics_collector' );
	} else {
		$self->{errmsg} .= $self->{dbh}->{db_error_msg};
		return 0;
	}	
}

sub setCollectorFinished {
	my ( $self, $id ) = @_;
	undef $self->{errmsg};
	
	my ( $stmnt, @bind ) = $self->{sql}->update( 'statistics_collector', { finished => \'NOW()' }, { id => $id } );

	$self->{dbh}->prepare($stmnt);
	my $result = $self->{dbh}->executeWithBinds(@bind);
	if ( defined( $result ) && ( $result !~ m/(0E0)/i ) ) {	
		if ( $result > 0 ) {
			return 1;
		} elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
			$self->{errmsg} .= $self->{dbh}->{db_error_msg};
			return 0;
		} 
	} else {
		$self->{errmsg} .= "Action failed, corresponding id not found in database.";
		return 0;
	}
}

sub writeCVE {
	my ( $self, %where ) = @_;
	my $table = 'identifier';

	undef $self->{errmsg};
	undef $self->{cve_error};

	my $cve_error;
	if ( !$where{identifier} || trim( $where{identifier} ) eq '' ) {
		$cve_error .=  'EMPTY identifier FOUND for digest: ' . $where{digest} . "\n";
	}
	 
	if ( $where{digest} eq '' ) {
		$cve_error .= 'ALERT! No digest FOUND for identifier ' . $where{identifier}. "\n";
	} 

	if ( $cve_error ) {
		$self->{cve_error} = $cve_error;
		return 0;
	}

	if ( !$self->{dbh}->checkIfExists( \%where, $table ) ) {
		my ( $stmnt, @bind ) = $self->{sql}->insert( $table, \%where );
		
		$self->{dbh}->prepare( $stmnt );
		$self->{dbh}->executeWithBinds( @bind );

		if ( defined( $self->{dbh}->{db_error_msg} ) ) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			return 0;
		}
	}
	return 1;
}

sub stripsData {
  my ( $self, $html ) = @_;
  my ( $hostname, $htmllog, $strip0, $strip1, $strip2, $strip3, $strip4 );
	
	if ( $self->{strips} ) {
	  foreach my $strip ( @{ $self->{strips} } ) {
	    $hostname = $strip->{hostname};
	    if ( $strip->{strip0} ) {
	      $strip0 = $strip->{strip0};
	      $html =~ s/$strip0//gi;
	    }
	    if ( $strip->{strip1} ) {
	      $strip1 = $strip->{strip1};
	      $html =~ s/$strip1//gi;
	    }
	    if ( $strip->{strip2} ) {
	      $strip2 = $strip->{strip2};
	      $html =~ s/$strip2//gi;
	    }
	    if ( $strip->{strip3} ) {
	      $strip3 = $strip->{strip3};
	      $html =~ s/$strip3//gi;
	    }
	    if ( $strip->{strip4} ) {
	      $strip4 = $strip->{strip4};
	      $html =~ s/$strip4//gi;
	    }
	  }
	}

  return $html;
}

sub getStats {
	my $self      = shift;
	undef $self->{errmsg};
	
	my $statsfile = $self->{cfg}->{statsconfig};
	my $st   			= Taranis::Config::Stats->new();
	my $newstats  = $st->loadCollection( $statsfile );
	
	if ( !$newstats ) {
		$self->{errmsg} = $st->{errmsg};
		return 0;
	}
	
	my @stats = @{ $newstats };
	my $table = 'statsimages';

	my $nr_images;
	
	STAT:
	foreach my $stat ( @stats ) {

		my $stat_status = 0; 
		$stat->{host}        = '';
		$stat->{url}         = $stat->{image};
		$self->{this_source} = $stat;

		my ( $scheme, $auth, $path, $query, $frag ) = uri_split( $stat->{image} );
		$self->{this_source}->{sourcename} = $auth;
		
		$self->{this_source}->{no_encoding} = 1;
		$self->{this_source}->{is_image} 		= 1;
		
		if ( !$self->getSourceMtbc() ) {
			say "skipping image: " . $self->{this_source}->{image} ;
			next STAT;
		}

		my $description = $stat->{description};
		my $image       = $stat->{image};
		my $link        = $stat->{'link'};
		my $target      = $stat->{target};
		my $source      = $stat->{source};
		my $category    = $stat->{category};
		my $digest      = md5_base64( $image );

		$self->{this_source}->{digest} = $digest;

		$description = trim( sprintf( "%100s", $description ) );
		$link        = trim( sprintf( "%100s", $link ) );
		$target      = trim( sprintf( "%100s", $target ) );
		$category    = trim( sprintf( "%50s",  $category ) );
		$source      = trim( sprintf( "%50s",  $source ) );
		
		say nowstring(1) . " Download stat " . $self->{this_source}->{image};
		if ( $self->getStatsImage() ) {
			my $stat_status = 1; 
			print "getting image\n" if $self->{debugSource};
			
			$nr_images++;
			my %where = ( digest => $digest );

			if ( $self->{dbh}->checkIfExists( \%where, $table ) ) {
				my ( $stmnt, @bind ) = $self->{sql}->delete( $table, \%where );
				$self->{dbh}->prepare($stmnt);
				$self->{dbh}->executeWithBinds(@bind);

				if ( defined( $self->{dbh}->{db_error_msg} ) ) {
					print "STAT DB ERROR: " . $self->{dbh}->{db_error_msg} . "\n";
					$self->{errmsg} = $self->{dbh}->{db_error_msg};
					return 0;
				}
			}

			my %insert = (
											digest      => $digest,
											description => $description,
											'link'      => $link,
											target      => $target,
											source      => $source,
											category    => $category
										);

			my ( $stmnt, @bind ) = $self->{sql}->insert( $table, \%insert );
			
			$self->{dbh}->prepare( $stmnt );
			$self->{dbh}->executeWithBinds( @bind );

			if ( defined( $self->{dbh}->{db_error_msg} ) ) {
				$self->{errmsg} = $self->{dbh}->{db_error_msg};
				return 0;
			}

			$self->{nr_images} += $nr_images;

			} else {
				my $stat_status = 0; 

				$self->{err}->writeError(
																	digest     => $self->{this_source}->{digest},
																	error      => $self->{errmsg},
																	error_code => $self->{http_status_code},
																) if ( !$self->{link_check_only} );
				
				delete $self->{http_status_code};																

		}
		
		my $status = ( $stat_status ) ? 'OK' : 'ERROR';
		
		$self->writeSourceCheck( 
															source  => md5_base64( $stat->{host} . $stat->{url} ),
															comment => '(' . nowstring(2) . ') ' . $status 
														);		
	}
	return 1;
}

sub getStatsImage {
	my ( $self, $arg ) = @_;
	undef $self->{errmsg};
	
	$self->{this_source}->{is_image} = 1;

	my $url       = $self->{this_source}->{image};
	my $imagefile = $self->{this_source}->{target};
	my $image 		= $self->getSourceData( $url );
	
	delete $self->{this_source}->{is_image};
	
	if ( $image ) {
		my $fh;
		open( $fh, ">", $imagefile ) or die "Can't write image, $!\n";
		binmode $fh;
		print $fh $image;
		close $fh;
		return 1;
	} else {
    $self->{errmsg} = 'Failed to download stats image ' . $url;
		return 0;
	}
}

sub creategraph {
	my ( $self, %settings ) = @_;
	my ( $sth, $cntr, $max, @x, @y, @data, $my_graph, $gd, $digest, $record );

	my $query       = $settings{query};
	my $graphType   = $settings{graphType};
	my $graphTitle  = $settings{graphTitle};
	my $graphXLabel = $settings{graphXLabel};
	my $graphYLabel = $settings{graphYLabel};
	my $filename 		= $self->{cfg}->{absroot} . "/stats/" . $settings{filename};
	my $reverse  		= $settings{'reverse'};
	my $binds				= $settings{binds};

	$self->{dbh}->prepare( $query );
	$self->{dbh}->executeWithBinds( @$binds );

	if ( defined $self->{dbh}->{db_error_msg} ) {
		say "STAT DB ERROR: " . $self->{dbh}->{db_error_msg};
	}
	
	$cntr = -1;
	$max  = 0;
	while ( $self->nextObject() ) { 
		$record = $self->getObject();
		$cntr++;
		
		$x[$cntr] = $record->{label};
		$y[$cntr] = $record->{cnt};
		
		$max = $record->{cnt} if ( $record->{cnt} > $max );
	}

	return 1 if ( !$max );
	
	if ( $reverse == 1 ) {
		@data = ( [ reverse(@x) ], [ reverse(@y) ], );
	} else {
		@data = ( [@x], [@y] );
	}

	for ( uc( $graphType ) ) {
		if (/BAR/i)  { $my_graph = new GD::Graph::bars( 650,  400 ); }
		if (/HBAR/i) { $my_graph = new GD::Graph::hbars( 650, 400 ); }
	}

	$my_graph->set(
									x_label					=> $graphXLabel,
									'y_label'				=> $graphYLabel,
									title						=> '',
									'y_max_value'		=> $max + 100,
									'y_min_value'		=> 0,
									'y_tick_number'	=> 10,
                  'y_label_skip'  => 2,
									box_axis				=> 0,
									line_width			=> 3,
									fgclr						=> 'red',
									show_values			=> 1,
									transparent			=> 1,
	);

	$my_graph->set_text_clr( 'black' );
	$gd = $my_graph->plot( \@data );
	
	eval {
		my $fh;
		open( $fh, ">", $filename );
		binmode $fh;
		print $fh $gd->gif;
		close $fh;
	};
	
	if ( $@ ) {
		$self->{errmsg} = "Stats error while saving stats image to disk: " . $@;
		return 0;
	}
	
	### Save a reference to the image to the statsimages table
	
	$digest = md5_base64( $filename );
	
	my %where = ( digest => $digest );
	
	my ( $deleteStmnt, @deleteBinds ) = $self->{sql}->delete( 'statsimages', \%where );
	$self->{dbh}->prepare( $deleteStmnt );
	$self->{dbh}->executeWithBinds( @deleteBinds );

	my %insert = ( 
									digest 			=> $digest, 
									description => $graphTitle, 
									'link' 			=> '#',
									target 			=> $filename,
									source 			=> 'Taranis',
									category 		=> 'Taranis Statistics'
								);

	my ( $insertStmnt, @insertBinds ) = $self->{sql}->insert( 'statsimages', \%insert );	

	$self->{dbh}->prepare( $insertStmnt );
	$self->{dbh}->executeWithBinds( @insertBinds );
	
 	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}
	
	return 1;
}

sub nextObject {
	my ( $self ) = @_;
	return $self->{dbh}->nextRecord();
}

sub getObject {
	my ( $self ) = @_;
	return $self->{dbh}->getRecord();
}

sub basicFilter {
  #######################################################################
  ## Function    : basicFilter
  ## Description : runs a basic filter over a string to strip off
  ##               tags and prevent quotes
  ## Input       : [0] - string to filter
  ## Output      : a filtered string
  #######################################################################

  my $filterthis = $_[0];
 	if ( $filterthis ) {
	  $filterthis =~ s/\'//gi;
	  $filterthis =~ s/\n/ /gi; # Ticket #167
	  $filterthis =~ s/&lt;/</gi;
	  $filterthis =~ s/&gt;/>/gi;
	  $filterthis =~ s/<(.*?)>//gi;
	  $filterthis =~ s/<!--(.*)-->//gi; # Ticket #167
	  $filterthis =~ s/^\s+//;
	  $filterthis =~ s/\s+$//;
	
	  my $newline = "";
	  for ( my $i = 0 ; $i < length( $filterthis ); $i++ ) {
	    my $ascii = ord( substr( $filterthis, $i, 1 ) );
	    if ( $ascii <= 255 ) { 
	      ### Only include well-known characters
	      $newline = $newline . substr( $filterthis, $i, 1 );
	    }
	  }

	  return $newline;
 	} else {
 		return ""; 	
 	}
}

sub isodd {
  return ( ( $_[0] % 2 ) != 0 );
}

sub deleteAndCopy {
	my ( $self, %arg ) = @_;

	my $from_table = $arg{from_table};
	my $to_table   = $arg{to_table};
	my $what       = $arg{what};
	my $order      = $arg{order};

	my $query = "DELETE FROM " . $to_table;
	$self->{dbh}->do( $query );

	my %where = ( $what => { "!=" => '' } );    # do not select empty records
	my ( $stmnt, @bind ) = $self->{dbh}->{sql}->select( $from_table, "DISTINCT( $what )", \%where, $order );
  
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
  
	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		say "DELETE AND COPY DB ERROR: $stmnt, @bind\n" . $self->{dbh}->{db_error_msg};
	}

	my @result;
	while ( $self->nextObject() ) {
		my $record = $self->getObject();
		push @result, $record->{ $what };
	}

	foreach my $val ( @result ) {
		my %values = ( $what => $val );
		my ( $stmnt, @bind ) = $self->{sql}->insert( $to_table, \%values );
		
		$self->{dbh}->prepare( $stmnt );
		$self->{dbh}->executeWithBinds( @bind );
    
		if ( defined( $self->{dbh}->{db_error_msg} ) ) {
			say "DELETE AND COPY DB ERROR: $stmnt, @bind\n" . $self->{dbh}->{db_error_msg};
		}
	}
	return 1;
}

sub prepareTextForSaving {
	my ( $self, $text ) = @_;
	
	$text =~ s/\xC2\xA0/ /g; #space character that does not correctly encode into HTML Entity
	
	$text =~ s/\n/ /g;
	$text =~ s/&nbsp;+/ /g;
	$text =~ s/\s+/ /g;
	
	$text = HTML::Entities::decode( $text );
	
	$text =~ s/\n/ /g;
	$text =~ s/\s+/ /g;
	
	my $test = encode( 'UTF-8', $text );
	$test = decode( 'UTF-8', $test );

	if ( $test && $test eq $text ) {
	
		my $doUtf8Encoding = 0;
		say "==LENGTH: " . length( $test ) if ( length( $test ) > 15000 && $self->{collectorTest} );

		if ( length( $test ) > 15000 ) {
			my $testPart = $test;
			
			while ( !$doUtf8Encoding && length( $testPart ) > 0 ) {
				
				my $size = ( length( $testPart ) > 15000 ) ? 15000 : length( $testPart );
				my $testPartForEvaluation = substr( $testPart, 0, $size );
				$testPart = substr( $testPart, $size );
	
				eval{ 
					if ( $testPartForEvaluation !~
				  m/\A(
				     [\x09\x0A\x0D\x20-\x7E]            # ASCII
				   | [\xC2-\xDF][\x80-\xBF]             # non-overlong 2-byte
				   |  \xE0[\xA0-\xBF][\x80-\xBF]        # excluding overlongs
				   | [\xE1-\xEC\xEE\xEF][\x80-\xBF]{2}  # straight 3-byte
				   |  \xED[\x80-\x9F][\x80-\xBF]        # excluding surrogates
				   |  \xF0[\x90-\xBF][\x80-\xBF]{2}     # planes 1-3
				   | [\xF1-\xF3][\x80-\xBF]{3}          # planes 4-15
				   |  \xF4[\x80-\x8F][\x80-\xBF]{2}     # plane 16
				  )*\z/x
					) { 
						$doUtf8Encoding = 1; 
					}
				};		
			}	
			
		} else {
			eval{ 
				if ( $test !~
			  m/\A(
			     [\x09\x0A\x0D\x20-\x7E]            # ASCII
			   | [\xC2-\xDF][\x80-\xBF]             # non-overlong 2-byte
			   |  \xE0[\xA0-\xBF][\x80-\xBF]        # excluding overlongs
			   | [\xE1-\xEC\xEE\xEF][\x80-\xBF]{2}  # straight 3-byte
			   |  \xED[\x80-\x9F][\x80-\xBF]        # excluding surrogates
			   |  \xF0[\x90-\xBF][\x80-\xBF]{2}     # planes 1-3
			   | [\xF1-\xF3][\x80-\xBF]{3}          # planes 4-15
			   |  \xF4[\x80-\x8F][\x80-\xBF]{2}     # plane 16
			  )*\z/x
				) { 
					$doUtf8Encoding = 1; 
				}
			};
		}
	  
	  if ( $doUtf8Encoding ) {
			$text = encode( 'UTF-8', $text );
#			say "::DO UTF-8 ENCODING" if ( $self->{collectorTest} );	
		} else {
#			say "::UTF-8 ENCODING NOT DONE" if ( $self->{collectorTest} );
		}
		
		say $@ if ( $@ && $self->{collectorTest} );
	}

	return $text;	
}

sub parseTwitterDate {
	# twitter date format: Thu Jun 13 15:22:00 +0000 2013
	my ( $self, $twitterDateStr ) = @_;
	my %date;

	my %months = (
		jan => 1, feb => 2, mar => 3, apr => 4,
		may => 5, jun => 6, jul => 7, sep => 8,
		aug => 9, 'oct' => 10, nov => 11, dec => 12
	);
	my $monthsString = join '|', keys %months;
	
	my %regex = ( 
		year => qr/^(\d{4})$/,
		month => qr/^($monthsString)$/i,
		day => qr/^(\d{1,2})$/,
		'time' => qr/^(\d\d):(\d\d):(\d\d)$/,
		timeZone => qr/^([+-]\d{4})$/
	);

	foreach ( split ' ', $twitterDateStr ) {
		( $date{year} ) = ( $_ =~ $regex{year} ) if ( $_ =~ $regex{year} );
		$date{month} = $months{ lc( ( $_ =~ $regex{month} )[0] ) } if $_ =~ $regex{month};
		( $date{day} ) = ( $_ =~ $regex{day} ) if ( $_ =~ $regex{day} );
		( $date{hour}, $date{minute}, $date{second} ) = ( $_ =~ $regex{'time'} ) if ( $_ =~ $regex{'time'} );
		( $date{timeZone} ) = ( $_ =~ $regex{timeZone} ) if ( $_ =~ $regex{timeZone} );
	}
	
	# local timezone correction
	my @t = localtime(time);
	my $gmt_offset_in_seconds = timegm(@t) - timelocal(@t);
	my $offsetHours = $gmt_offset_in_seconds / 3600;
	$date{hour} += $offsetHours;

	return \%date;
}

1;


=head1 NAME

Taranis::Collector - module for collecting and processing of IMAP, POP3, HTML and XML sources.

=head1 SYNOPSIS

  use Taranis::Collector;

  my $obj = Taranis::Collector->new( $debugSource );

  $obj->getSourceMtbc( $debug_mode );
  
  $obj->getSourceData( $url );

  $obj->processImapMail( $debug_mode );
  
  $obj->processPop3Mail( $debug_mode );
  
  $obj->processXmlFeed( $xml_source_data );
  
  $obj->processHtmlFeed( $source_data );

  $obj->writeSourceCheck( source => $digest, comment => $comment );

  $obj->parseIdentifierPatterns( $source_data );

  $obj->writeCVE( identifier => $identifier, digest => $digest );

  $obj->stripsData( $source_data );

  $obj->getStats();

  $obj->getStatsImage();

  $obj->creategraph( query	=> $sql_statement, graphType => $graph_type, graphTitle => $title, 
                     graphXLabel => $label_x, graphYLabel => $label_y, filename => $filename, 
                     'reverse' => $do_reverse,	binds	=> \@bind );

  $obj->basicFilter( $string );

  $obj->isodd( $int );

  $obj->deleteAndCopy( from_table => $from_table, to_table => $to_table, what => $what, order => $order );

  $obj->prepareTextForSaving( $string );

  $obj->nextObject();

  $obj->getObject();

=head1 DESCRIPTION

The collecting and processing of sources, performing collection checks and almost everything else that the collector does can be found in this module.
Every source protocol has its own method. For instance IMAP sources are collected by method processImapMail() .

If necessary it's possible to debug a source. 
It's advisable to run the collector from commandline in this case, because all debug information is printed to screen.  

=head1 METHODS

=head2 new( $debugSource )

Constructor of the C<Taranis::Collector> class. The argument is optional.

    my $obj = Taranis::Collector->new( 'mySourceName' );

Creates a new database handler which can accessed by:

    $obj->{dbh};

Creates a new C<Taranis::Config> object which can be accessed by:

    $obj->{cfg};

Creates a new C<Taranis::Error> object which can be accessed by:

    $obj->{err};

Creates a new C<SQL::Abstract> object which can be accessed by:

    $obj->{sql};

Creates a new C<LWP::UserAgent> object which can be accessed by:

    $obj->{lwp};

Clears error message for the new object. Can be accessed by:

    $obj->{errmsg};

Sets the name of the source to DEBUG. Can be accessed by:

    $obj->{debugSource};

Loads all the C<strips>. Strips are used by HTML sources to strip off unwanted content. Also Strips are read from XML conf file. 
Strips can be accessed by:

    $obj->{strips};
    
Holds the current source to process by the collector which can be accessed by:

    $obj->{this_source};

Sets option for testing and can be accessed by (do not use or change this option!):

    $obj->{collectorTest};

The constructor takes the name of a source as argument. 
This should only be used when you want to debug a specific source in a terminal. All debug info will be printed to screen. 

For C<< $obj->{lwp} >> the proxy is set if it is set up to do so in main XML configuration (taranis.conf.xml). 
Same goes for the C<no_proxy>, C<protocols_allowed> and C<timeout> setting of LWP.

The SSL settings from the main XML configuration are set in $ENV.

Returns the blessed object.

=head2 getSourceMtbc( $debug_mode )

Checks if it's time to collect and process the current source C<< $obj->{this_source} >>. 
Every source has a Mean Time Between Checks (MTBC) setting, which tells how many minutes apart the source should be checked.

This method retrieves the time when the source has last been checked (from table C<checkstatus>). 
It then compares it with the source MTBC setting and checks if at least x minutes have past since last time the source has been checked.

The check is bypassed on two occasions:

=over

=item 1

when C<< $obj->{debugSource} >> is set, and

=item 2

when collector is run with --nomtbc option on commandline. This option is set in the collector object as C<< $obj->{nomtbc} >>.

=back

This method takes C<$debug_mode> as optional argument. Setting this argument to true will print debug information to screen.

    $obj->getSourceMtbc();

OR

    $obj->getSourceMtbc( 1 );

Will return TRUE or FALSE which depends on MTBC setting, C<< $obj->{debugSource} >> setting and C<< $obj->{nomtbc} >> setting.

=head2 getSourceData( $url )

This method does the actual retrieval of source data. It uses C<LWP::UserAgent> via C<< $obj->{lwp} >>. 
In case of C<https> protocol it will first create a request using C<HTTP::Request>, to feed LWP.

It takes an URL as optional argument. If $url is defined it will retrieve the URL. If it's not defined it will use C<< $obj->{this_source}->{fullurl} >> as URL.

    $obj->getSourceData( 'http://www.govcert.nl/rss.xml' );

OR

   $obj->getSourceMtbc();

It will return the content using C<< HTTP::Response->decoded_content() >> if LWP GET request is successful. 
Also C<< $obj->{http_status_code} >> will be set to C<< HTTP::Response->status_line() >>.

If the request fails, it will return FALSE and it will write error information using C<< Taranis::Error->writeError() >> via C<< $obj->{err} >>.
Also C<< $obj->{http_status_code} >> will be set to C<< HTTP::Response->code() >> and C<< $obj->{http_status_line} >> will be set to C<< HTTP::Response->status_line() >>.

=head2 processImapMail( $debug_mode )

Method for retrieval of IMAP and IMAPS sources. It uses the source settings in C<< $obj->{this_source} >> for credentials, server info and mailbox names.
The mailbox names are encode using C<< Unicode::IMAPUtf7->encode() >>, in case a mailbox name contains diacritics.

The optional C< $debug_mode > can be set to print debug information to screen.

    $obj->processImapMail( 1 );

OR

    $obj->processImapMail();

The method will first try to make a connection then select the mailbox and looks if the archive mailbox exists. It uses C<Mail::IMAPClient> for this. 
It will return FALSE if one of these checks fails.

Next step is checking each message if it's already in Taranis. 
If it doesn't exist, it will retrieve the complete message and parse it using C<< MIME::Parser->parse_data() >>. 
If this fails an error wil be written using C<< Taranis::Error->writeError() >> via C<< $obj->{err} >> with C<error_code> 011.
When parsing of message is successful the body text will first be decoded using C<< Taranis->decodeMimeEntity() >> and secondly encoded using C<< HTML::Entities::encode >>.

A summary of the message is saved to table C<item> and the complete message is saved to C<email_item>. 
Saving of messages is put within a transaction using C<< Taranis::Database->startTransaction() >> and C<< Taranis::Database->endTransaction() >>. 

Finally the message will be moved from mailbox to the archive mailbox.

If any of the above fails the method will return FALSE and set C<< $obj->{errmsg} >> to C<< Taranis::Database->{db_error_msg} >>. 

=head2 processPop3Mail( $debug_mode )

Method for retrieving messages from POP3 and POP3S mailboxes. Works exactly the same as processImapMail() except for the following:

=over

=item *

it uses C<< Mail::POP3Client >> instead of C<Mail::IMAPClient>

=item *

it does not connect or do checks for specific mailboxes

=item *

it will delete messages from POP3 server if C<< $ob->{this_source}->{delete_mail} >> is set to true.

=back

=head2 processXmlFeed( $xml_source_data )

Method to process RSS feeds. It uses C<XML::FeedPP> to parse the feed.
It takes the complete RSS feed data as argument, which is mandatory.

    my $rss_feed_data = $obj->getSourceData();

    $obj->processXmlFeed( $rss_feed_data );

Each item found will go through a series of filters and encoders/decoders to get content that can be encoded to HTML entities correctly.

Before saving the item, it will be checked if it's already in Taranis. 
Also the length of the link will be checked, if it's to long an error will be written to database using C<< Taranis::Error->writeError() >> via C<< $obj->{err} >> with C<error_code> 012.

When saving of item to Taranis is successful, the digest and link of the item will be put in an ARRAY of HASHES, which will be returned by the method.  

If a database error occurs the mehtod fill return , and C<< $obj->{errmsg} >> will be set C<< Taranis::Database->{db_error_msg} >>.

Returns undef when C<XML::FeedPP> can't read the RSS feed. And will set C<< $obj->{errmg} >> to start with 'XML parsing error: '.
Will also return if there are no items in the RSS feed. 

=head2 processHtmlFeed( $source_data )

Method for processing sources that require screen scraping. 
It takes the source data as mandatory argument.

    my $source_data = $obj->getSourceData();

    $obj->processHtmlFeed( $source_data );

To get the right information from a webpage it needs a parser (C<Taranis::Parser>) that can be found in C<< $obj->{this_source}->{parser} >>.

The parser will search for items. Within these items it will search for title, description and link as configured in the parser.  
The title, description and link go through a series of filters and encoders/decoders to get content that can be encoded to HTML entities correctly.

Same as processXmlFeed() it will check the link size and it will return an ARRAY of HASHES with digest and link of each item.

If a database error occurs the method will return, and C<< $obj->{errmsg} >> will be set C<< Taranis::Database->{db_error_msg} >>.

=head2 writeSourceCheck( source => $digest,	comment => $comment ) 

This method will write a timestamp of a source to the database.
It takes the source digest and a comment as argument, where source digest is mandatory.
The argument should be supplied as C<< key => value >> pairs.

    $obj->writeSourceCheck( source => 'YCpWzDJgrxy+aWdXzaf2lw', comment => 'my comments' );

If no timestamp of the specified source is present it will insert a new entry.

Returns TRUE if update or insertion is successful. 
Returns FALSE if a database error occurs and will set C<< $obj->{errmsg} >> to C<< Taranis::Database->{db_error_msg} >>.

=head2 parseIdentifierPatterns( $source_data )

This method will search the source data for all identifiers which are configured in taranis.conf.identifiers.xml.

    my $source_data = $obj->getSourceData();

    $obj->parseIdentifierPatterns( $source_data );

All found identifiers are put in an ARRAY of HASHES, with keys C<identifier> ( CVE, RSHA, etc ) and C<digest> ( the item digest ).

The ARRAY of HASHES is returned.

=head2 writeCVE( identifier => $identifier, digest => $digest )

This method writes identifiers like CVE, combined with the Assess item digest to database.
Both identifier and digest are mandatory arguments and should be supplied as C<< key => value >> pairs.

    $obj->writeCVE( identifier => 'CVE-2010-0001', digest => 'YCpWzDJgrxy+aWdXzaf2lw' );

Returns TRUE if successful. Returns FALSE if a database error occurs and will set C<< $obj->{errmsg} >> to C<< Taranis::Database->{db_error_msg} >>.

=head2 stripsData( $source_data )

This method uses configured regular expressions to strip off unwanted content. 
The configured regular expressions from taranis.conf.strips.xml are accessed by C<< $obj->{strips} >>.

Takes the source data as mandatory argument.

    my $source_data = $obj->getSourceData();

    $obj->stripsData( $source_data );

Returns the stripped source data. 

=head2 getStats( )

This will collect statistics images from statistics configured in taranis.conf.stats.xml.
It uses C<Taranis::Config::Stats> to load the XML file. It takes no arguments.

    $obj->getStats();

The method takes care of:

=over

=item *

writing a source check ( writeSourceCheck() ),

=item *

writing errors ( writeError() ) in case of retrieval error,

=item * 

and downloading image to disk ( getStatsImage() ).

=back

Returns TRUE if successful. Returns FALSE if a database error occurs and will set C<< $obj->{errmsg} >> to C<< Taranis::Database->{db_error_msg} >>.

=head2 getStatsImage( )

This method will download statistics image using the URL in C<< $obj->{this_source}->{image} >> and getSourceData() for retrieval.
When downloaded it writes the image to disk using C<open>, C<binmode>, C<print> and C<close>.

Method takes no arguments.

    $obj->getStatsImage();

If the retrieved image is undefined, the method will return FALSE and C<< $obj->{errmsg} >> will contain an error description.

=head2 creategraph( query	=> $sql_statement, graphType => $graph_type, graphTitle => $title, graphXLabel => $label_x, graphYLabel => $label_y, filename => $filename, 'reverse' => $do_reverse,	binds	=> \@bind )

This method creates bar charts about Taranis statistics. It uses SQL statements to get statistics.
These SQL statements have to have C<label> (STRING) and C<cnt> (INTEGER) in their SELECT part of the query.

The following arguments are expected:

=over

=item *

query, the SQL statement containing C<label> and C<cnt> in the SELECT part of the query

=item *

graphType, two type can be entered, 'hbar' which will result in a garph with horizontal bar, or just 'bar' which will result in vertical bars on the graph

=item *

graphTitle, title of the bar chart

=item *

graphXLabel & graphYLabel, title for the x-axis and y-axis

=item *

filename, filename for saving the resulting image to disk

=item *

'reverse', to reverse the data which resulted from the SQL statement, takes a boolean value

=item *

binds, bindings for the query, this argument is optional and depends on the query

=back 

    $obj->creategraph( query => "SELECT 'myLabel' AS label, COUNT(*) AS cnt FROM table_x", graphType => 'bar', graphTitle => 'my graph title', graphXLabel => 'x-axis label', graphYLabel => 'y-axis label', filename	=> 'taranis1.gif', 'reverse' => 1, binds => \@binds );

The method uses C<< GD::Graph::bars >> and C<< GD::Graph::hbars >> to create the bar charts and C<open>, C<binmode>, C<print> and C<close> to write the image file to disk.

It also writes the graph information to database.

Method returns TRUE if all goes well and if the SQL Query results in a 0 count.
It returns FALSE if a database error occurs and will set C<< $obj->{errmsg} >> to C<< Taranis::Database->{db_error_msg} >>.
It also return FALSE the image file cannot be saved to disk.

=head2 basicFilter( $string )

Method to filter the following from specified string:

=over

=item *

deletes single quotes

=item *

changes newlines to space character

=item *

changes HTML entity &lt; to <

=item *

changes HTML entity &gt; to >

=item *

deletes HTML/XML tags

=item *

deletes HTML comments

=item *

deletes leading white space

=item *

deletes trailing white space

=back

    $obj->basicFilter( $any_string );

The method will also remove any multi-byte characters.

Returns the filtered input string.

=head2 isodd( $int )

Method checks if specified integer is even or odd.

    $obj->( 56 );

Returns TRUE if $int is odd, FALSE if it's even.

=head2 deleteAndCopy( from_table => $from_table, to_table => $to_table, what => $what, order => $order )

This method is used for emptying the 'distinct' tables and inserting them with new values.

    $obj->( from_table => 'item', to_table => 'distinct_source', what => 'source', order => 'source' ); 

Returns TRUE if successful. Returns FALSE if a database error occurs and will set C<< $obj->{errmsg} >> to C<< Taranis::Database->{db_error_msg} >>.

=head2 prepareTextForSaving( $string )

This method is used to filter a string and to make sure the returned string is UTF-8 encoded.
It also changes whitespaces that are longer than one space character into one space character. Same goes for newline characters. 
The string argument is mandatory.

    $obj->prepareTextForSaving( $my_string );

It returns an UTF-8 string.

=head2 nextObject( ) & getObject( )

Method to retrieve the list that is generated by a method like loadCollection().

This way of retrieval can be used to get data from the database one-by-one. Both methods don't take arguments.

Example:

    $obj->loadCollection( $args );

    while( $obj->nextObject ) {
        push @list, $obj->getObject;
    }

=head1 DIAGNOSTICS

The following messages can be expected from this module:

=over

=item *

I<Error connecting to database.>

Can occur when trying to create a collector object with new() and it fails to connect to database.
You should probably check your database configuration in taranis.conf.xml.

=item *

I<No valid writable Mime Parser output directory specified in config. Make sure the output directory is writable for the user running the collector.>

The directory that's configured in taranis.conf.xml within tag C<mimeparser_outputdir> should be writable for the user that runs the collector.

=item *

I<Could not connect to IMAP server host_x: ...> & I<Could not connect to POP3 server host_x: ...>

Can be caused by numerous ways. Best is to check the source details of this source and try to debug with 'Test source'.

=item *

I<Could not select folder mailbox_name: ...> & I<Could not connect to archive folder archive_mailbox_name: ...>

Caused by invalid (archive)mailbox name.

=item *

I<Error from MIME parser: ...>

Can be caused if an email message has an invalid MIME format.

=item *

I<Message has been saved, but could not be moved to archive mailbox archive_mailbox_name: ...>

When an email message has been successfully processed in Taranis, the collector will try to move the message to the archive mailbox.
This message appears when moving the email message fails.

=item *

I<XML parsing error: ...>

Is caused when C<XML::FeedPP> cannot parse the given content.

=item *

I<No items found in XML feed> & I<No items found in HTML feed>

Self explanatory, the RSS feed or HTML source contains no items.

=item *

I<XML feed only contains bad items.> & I<HTML feed only contains bad items.>

This means that the data of the source should be checked, because parsing and even collecting items is working just fine, 
but the items are not saved in Taranis.

=item *

I<Failed to download stats image http://...>

Caused by getStatsImage() trying to download the statsimage using getSourceData().

=item *

I<Stats error while saving stats image to disk: ...> 

Caused by creategraph(), while trying to save the created graph image to disk.



=item *

I<Database error, please check log for info> or I<Database error. (Error cannot be logged because logging is turned off or is not configured correctly)>

Is caused by a database syntax or input error. 

=back

=head1 DEPENDENCIES

CPAN modules required are 

=over 

=item *

B<LWP::UserAgent>

=item *

B<SQL::Abstract>

=item *

B<Time::Local>

=item *

B<Mail::IMAPClient>

=item *

B<Mail::POP3Client>

=item *

B<XML::FeedPP>

=item *

B<URI::Escape>

=item *

B<URI::Split>

=item *

B<Digest::MD5>

=item *

B<Encode>

=item *

B<HTML::Entities>

=item *

B<MIME::Parser>

=item *

B<Unicode::IMAPUtf7>

=item *

B<GD::Graph::bars>

=item *

B<GD::Graph::hbars>

=item *

B<Data::Dumper>

=back

Taranis modules required are 

=over

=item *

B<Taranis>

=item *

B<Taranis::Database>

=item *

B<Taranis::Config>

=item *

B<Taranis::Config::XMLGeneric>

=item *

B<Taranis::Config::Stats>

=item *

B<Taranis::Parsers>

=item *

B<Taranis::Error>

=back

=head1 AUTHOR

Sebastiaan van Achterbergh <info@govcert.nl>

November 2010

=cut
