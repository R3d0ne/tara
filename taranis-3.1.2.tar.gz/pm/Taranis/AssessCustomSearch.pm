package Taranis::AssessCustomSearch;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis::Database;
use SQL::Abstract;
use Data::Dumper;
use Tie::IxHash;
use strict;
use Taranis qw(:all);

sub new {
  my $class = shift;
    
  my $self = {
             errmsg			 => undef,
             dbh         => Taranis::Database->new(),
             sql				 => SQL::Abstract->new()
  };
  bless $self;
  return $self;	
}

sub getSearch {
	my ( $self, $id ) = @_;
	undef $self->{errmsg};
	tie my %join, "Tie::IxHash";
	
	my $select = "to_char(startdate, 'DD-MM-YYYY') AS startdate_plainformat, to_char(enddate, 'DD-MM-YYYY') AS enddate_plainformat, s.*";
	
	my ( $stmnt, @bind ) = $self->{sql}->select( 'search s', $select, { id => $id } );
	
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	my $search = $self->{dbh}->fetchRow();
	
	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		 $self->{errmsg} = $self->{dbh}->{db_error_msg};
		 return 0;
	}
	
	my @categories;
	my %categoryWhere = ( 'sc.search_id' => $search->{id} );
	
	my ( $categoryStmnt, @categoryBind ) = $self->{sql}->select( 'category c', 'c.*', \%categoryWhere );
	my %categoryJoin = ( 'JOIN search_category sc' => { 'sc.category_id' => 'c.id' } );
	
	$categoryStmnt = $self->{dbh}->sqlJoin( \%categoryJoin, $categoryStmnt );

	$self->{dbh}->prepare( $categoryStmnt );
	$self->{dbh}->executeWithBinds( @categoryBind );

	while ( $self->nextObject() ) {
		push @categories, $self->getObject()->{id};
	}
	
	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		 $self->{errmsg} = $self->{dbh}->{db_error_msg};
		 return 0;
	}

	$search->{categories} = \@categories;
	
	my @sources;
	my %sourceWhere = ( 'search_id' => $search->{id} );
	
	my ( $sourceStmnt, @sourceBind ) = $self->{sql}->select( 'search_source', 'sourcename', \%sourceWhere );

	$self->{dbh}->prepare( $sourceStmnt );
	$self->{dbh}->executeWithBinds( @sourceBind );

	while ( $self->nextObject() ) {
		push @sources, $self->getObject()->{sourcename};
	}
	
	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		 $self->{errmsg} = $self->{dbh}->{db_error_msg};
		 return 0;
	}

	$search->{sources} = \@sources;	

	return $search;	
}

sub loadCollection {
	my ( $self, @where ) = @_;
	undef $self->{errmsg};
	
	my @searches;

	my $select = "to_char(startdate, 'DD-MM-YYYY') AS startdate_plainformat, to_char(enddate, 'DD-MM-YYYY') AS enddate_plainformat, *";	
	
	my ( $stmnt, @bind ) = $self->{sql}->select( 'search', $select, \@where, 'description' );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	while ( $self->nextObject() ) {
		push @searches, $self->getObject(); 
	}
	
	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		 $self->{errmsg} = $self->{dbh}->{db_error_msg};
		 return 0;
	}
	
	foreach my $search ( @searches ) {
		my $searchId = $search->{id};
		my %searchWhere = ( search_id => $searchId );
		
		my @categories;
		my ( $categoryStmnt, @categoryBind ) = $self->{sql}->select( 'category c', 'c.*', \%searchWhere, 'c.name' );
		my %categoryJoin = ( 'JOIN search_category sc' => { 'sc.category_id' => 'c.id' } );
		
		$categoryStmnt = $self->{dbh}->sqlJoin( \%categoryJoin, $categoryStmnt );

		$self->{dbh}->prepare( $categoryStmnt );
		$self->{dbh}->executeWithBinds( @categoryBind );
		
		while ( $self->nextObject() ) {
			push @categories, $self->getObject();
		}
		
		my @sources;
		my ( $sourceStmnt, @sourceBind ) = $self->{sql}->select( 'search_source', 'sourcename', \%searchWhere, 'sourcename' );
		
		$self->{dbh}->prepare( $sourceStmnt );
		$self->{dbh}->executeWithBinds( @sourceBind );
		
		while ( $self->nextObject() ) {
			push @sources, $self->getObject()->{sourcename};
		}		

		$search->{categories} = \@categories;
		$search->{sources} = \@sources;		
	}
	
	return \@searches
}

sub addSearch {
  my ( $self, %inserts ) = @_;
	undef $self->{errmsg};  
	
  my @sources		 = @{ delete( $inserts{sources} ) };
  my @categories = @{ delete( $inserts{categories} ) }; 

  $self->{dbh}->startTransaction();
  
	my ( $stmnt, @bind ) = $self->{sql}->insert( 'search', \%inserts );
	$self->{dbh}->prepare( $stmnt );
	
	my $result = $self->{dbh}->executeWithBinds( @bind );
	
	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		 $self->{errmsg} = $self->{dbh}->{db_error_msg};
		 $self->{dbh}->endTransaction();
		 return 0;
	}
	
	if ( my $search_id = $self->{dbh}->getLastInsertedId( 'search' ) ) {
		foreach my $sourcename ( @sources ) {
			my %sourceInsertWhere = ( search_id => $search_id, sourcename => $sourcename );
			my ( $sourceInsertStmnt, @sourceInsertBind ) = $self->{sql}->insert( 'search_source', \%sourceInsertWhere );
	
			$self->{dbh}->prepare( $sourceInsertStmnt );
			$self->{dbh}->executeWithBinds( @sourceInsertBind );
	
			if ( defined( $self->{dbh}->{db_error_msg} ) ) {
				 $self->{errmsg} = $self->{dbh}->{db_error_msg};
				 $self->{dbh}->endTransaction();
				 return 0;
			}
		}

		foreach my $category_id ( @categories ) {
			my %categoryInsertWhere = ( search_id => $search_id, category_id => $category_id );
			my ( $categoryInsertStmnt, @categoryInsertBind ) = $self->{sql}->insert( 'search_category', \%categoryInsertWhere );
	
			$self->{dbh}->prepare( $categoryInsertStmnt );
			$self->{dbh}->executeWithBinds( @categoryInsertBind );
	
			if ( defined( $self->{dbh}->{db_error_msg} ) ) {
				 $self->{errmsg} = $self->{dbh}->{db_error_msg};
				 $self->{dbh}->endTransaction();
				 return 0;
			}
		}
	} else {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		$self->{dbh}->endTransaction();
		return 0;
	}

	$self->{dbh}->endTransaction();
	return 1
}

sub setSearch {
  my ( $self, %updates ) = @_;
	undef $self->{errmsg};
  
  my @sources		 = @{ delete( $updates{sources} ) };
  my @categories = @{ delete( $updates{categories} ) }; 
  my $search_id  = delete $updates{id};
   
  my %where = ( id => $search_id );
  
  $self->{dbh}->startTransaction();
  
	my ( $stmnt, @bind ) = $self->{sql}->update( "search", \%updates, \%where );
	$self->{dbh}->prepare( $stmnt );
	
	my $result = $self->{dbh}->executeWithBinds( @bind );
	
	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		 $self->{errmsg} = $self->{dbh}->{db_error_msg};
		 $self->{dbh}->endTransaction();
		 return 0;
	}
	
	# DELETE and INSERT sources in search_source
	my ( $sourceDeleteStmnt, @sourceDeleteBind ) = $self->{sql}->delete( 'search_source', { search_id => $search_id } );
	
	$self->{dbh}->prepare( $sourceDeleteStmnt );
	$self->{dbh}->executeWithBinds( @sourceDeleteBind );
	
	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		 $self->{errmsg} = $self->{dbh}->{db_error_msg};
		 $self->{dbh}->endTransaction();
		 return 0;
	}
	
	foreach my $sourcename ( @sources ) {
		my %sourceInsertWhere = ( search_id => $search_id, sourcename => $sourcename );
		my ( $sourceInsertStmnt, @sourceInsertBind ) = $self->{sql}->insert( 'search_source', \%sourceInsertWhere );

		$self->{dbh}->prepare( $sourceInsertStmnt );
		$self->{dbh}->executeWithBinds( @sourceInsertBind );

		if ( defined( $self->{dbh}->{db_error_msg} ) ) {
			 $self->{errmsg} = $self->{dbh}->{db_error_msg};
			 $self->{dbh}->endTransaction();
			 return 0;
		}
	}

	# DELETE and INSERT categories in search_category
	my ( $categoryDeleteStmnt, @categoryDeleteBind ) = $self->{sql}->delete( 'search_category', { search_id => $search_id } );
	
	$self->{dbh}->prepare( $categoryDeleteStmnt );
	$self->{dbh}->executeWithBinds( @categoryDeleteBind );
	
	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		 $self->{errmsg} = $self->{dbh}->{db_error_msg};
		 $self->{dbh}->endTransaction();
		 return 0;
	}
	
	foreach my $category_id ( @categories ) {
		my %categoryInsertWhere = ( search_id => $search_id, category_id => $category_id );
		my ( $categoryInsertStmnt, @categoryInsertBind ) = $self->{sql}->insert( 'search_category', \%categoryInsertWhere );

		$self->{dbh}->prepare( $categoryInsertStmnt );
		$self->{dbh}->executeWithBinds( @categoryInsertBind );

		if ( defined( $self->{dbh}->{db_error_msg} ) ) {
			 $self->{errmsg} = $self->{dbh}->{db_error_msg};
			 $self->{dbh}->endTransaction();
			 return 0;
		}
	}
	
	$self->{dbh}->endTransaction();
	
	return 1
}

sub deleteSearch {
	my ( $self, $searchId ) = @_;
	undef $self->{errmsg};
	
	my ( $deleteSearchSourceStmnt, @deleteSearchSourceBind ) = $self->{sql}->delete( "search_source", { search_id => $searchId } );
	
	$self->{dbh}->startTransaction();
	
	$self->{dbh}->prepare( $deleteSearchSourceStmnt );
	
	if ( !$self->{dbh}->executeWithBinds( @deleteSearchSourceBind ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
	} else {
		
		my ( $deleteSearchCategoryStmnt, @deleteSearchCategoryBind ) = $self->{sql}->delete( "search_category", { search_id => $searchId } );
		
		$self->{dbh}->prepare( $deleteSearchCategoryStmnt );
		
		if ( !$self->{dbh}->executeWithBinds( @deleteSearchCategoryBind ) ) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
		} else {
			
			my ( $deleteSearchStmnt, @deleteSearchBind ) = $self->{sql}->delete( "search", { id => $searchId } );
			
			$self->{dbh}->prepare( $deleteSearchStmnt );
			
			if ( !$self->{dbh}->executeWithBinds( @deleteSearchBind ) ) {
				$self->{errmsg} = $self->{dbh}->{db_error_msg};
			}
		}
	}	
	
	$self->{dbh}->endTransaction();
	
	if ( !$self->{errmsg} ) {
		return 1;
	} else {
		return 0
	}	
}

sub isOwnerOrPublic {
	my ( $self, %settings ) = @_;
	
	my $user = $settings{user};
	my $search_id = $settings{search_id};
	
	my @where = ( 
								{ created_by => $user, id => $search_id }, 
								{ is_public => 1, id => $search_id } 
							);
	
	my ( $stmnt, @bind ) = $self->{sql}->select( 'search', 'COUNT(*) AS cnt', \@where );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	my $result = $self->{dbh}->fetchRow();
	
	if ( $result->{cnt} == 0 ) {
		return 0;
	} else {
		return 1;
	}
}

sub checkRights {
	my ( $self, %settings ) = @_;
	
	my $allowedCategories = $settings{allowedCategories};
	
	my @categories;
	foreach my $category ( @$allowedCategories ) {
		push @categories, $category->{id};
	}

	my %where = ( 
								search_id => $settings{searchId}, 
								category_id => \@categories 
							);
	
	my ( $stmnt, @bind ) = $self->{sql}->select( 'search_category', 'COUNT(*) AS cnt', \%where );

	my %whereSubQuery = ( search_id => $where{search_id} );

	my ( $subStmnt, @subBind ) = $self->{sql}->select( 'search_category', 'COUNT(*)', \%whereSubQuery );
	
	$stmnt .= ' OR ( ' . $subStmnt . ' ) = 0 ';

	push @bind, @subBind;

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	my $result = $self->{dbh}->fetchRow();
	
	if ( $result->{cnt} == 0 ) {
		return 0;
	} else {
		return 1;
	}	
}

sub nextObject {
	my ( $self ) = @_;
	return $self->{dbh}->nextRecord();
}

sub getObject {
	my ( $self ) = @_;
	return $self->{dbh}->getRecord();		
}

1;

=head1 NAME

Taranis::AssessCustomSearch - functionality for custom searches in Assess

=head1 SYNOPSIS

  use Taranis::AssessCustomSearch;

  my $obj = Taranis::AssessCustomSearch->new();

  $obj->getSearch( $search_id );

  $obj->loadCollection( created_by => $userid, is_public => 1, ... );

  $obj->addSearch( description => $description, keywords => $keywords, uriw => $uriw,
                   startdate => $startdate,	enddate => $enddate, hitsperpage => $hitsPerPage,
                   sortby => $sorting, sources => \@sources, categories	=> \@categories,
                   is_public => $is_public,	created_by => $userid	);

  $obj->setSearch( id => $search_id, description => $description,	keywords => $keywords, uriw	=> $uriw,
                   startdate => $startdate,	enddate => $enddate, hitsperpage => $hitsPerPage,
                   sortby => $sorting, sources => \@sources, categories	=> \@categories,
                   is_public => $is_public, created_by => $userid );								  

  $obj->deleteSearch( $search_id );

  $obj->isOwnerOrPublic( search_id => $search_id, user => $userid );

  $obj->checkRights( searchId => $searchId, allowedCategories => \@categories );

  $obj->nextObject();

  $obj->getObject();

=head1 DESCRIPTION

Within Assess it's possible to use custom made searches which can be saved for regular use. 
The searches can be added via the main window of Assess and can be edited and removed from the user panel.
This module contains all methods for adding, editing, deletion and retrieval of custom searches as well as performing some checks on user rights and search rights. 

=head1 METHODS

=head2 new( )

Constructor of the C<Taranis::AssessCustomSearch> class.

    my $obj = Taranis::AssessCustomSearch->new();

Creates a new database handler which can accessed by:

    $obj->{dbh};

Creates a new C<SQL::Abstract> object which can be accessed by:

    $obj->{sql};

Clears error message for the new object. Can be accessed by:

    $obj->{errmsg};

Returns the blessed object.

=head2 getSearch( $search_id )

This method retrieves the search settings of one custom search.
Takes the search id as argument.

    $obj->getSearch( 87 ); 

Returns the settings as HASH reference where C<startdate> and C<enddate> are formatted to DD-MM-YYYY and renamed to C<startdate_plainformat> and C<enddate_plainformat>.
Also the search categories can be found in the HASH with the key C<categories>. Same goes for sources which can be found with key C<sources>.

Return FALSE in case of an database error, which will also result in setting C<< $obj->{errmsg} >> to C<< Taranis::Database->{db_error_msg} >>.

=head2 loadCollection( created_by => $userid, is_public => 1, ... )

This method can be used for retrieving a list of custom searches. It takes all columns as argument if specified like column_name => "value".

    $obj->loadCollection( created_by => $userid, is_public => 1 );

Formatting of columns C<startdate> and C<enddate> and the retrieval of categories and sources from the HASH reference is the same as getSearch().

Returns found searches as an ARRAY of HASHES. Returns FALSE if a database error occurs, where C<< $obj->{errmsg} >> will be set to C<< Taranis::Database->{db_error_msg} >>.

=head2 addSearch( \%inserts )

Save a newly created custom search. Takes all columns of table search as argument as well as an ARRAY reference for sources and categories.

    $obj->addSearch( description => $description, keywords => $keywords, sources => \@sources, categories	=> \@categories, created_by	=> $userid );

Within this method the search is added with the use of a transaction ( C<< Taranis::Database->startTransaction() >> ).

Returns TRUE if all goes well, returns FALSE when a database error occurs, which will also set C<< $obj->{errmsg} >> to C<< Taranis::Database->{db_error_msg} >>.

=head2 setSearch( \%updates )

Same as addSearch() except argument search id, which is mandatory.

=head2 deleteSearch( $search_id )

Method to delete a custom search. Takes the search id as argument.

    $obj->deleteSearch( 87 );

Within the method a transaction ( C<< Taranis::Database->startTransaction() >> ) is used for save deletion.

Return TRUE on success, FALSE on failure, which will also set C<< $obj->{errmsg} >> to C<< Taranis::Database->{db_error_msg} >>.

=head2 isOwnerOrPublic( search_id => $search_id, user => $userid )

Checks if the custom search, specified by the C<search_id> argument, was created by the specified C<user> or if the custom search is set to public.
If one of these conditions is true, the method will return TRUE. Else it will return FALSE.

    $obj->isOwnerOrPublic( search_id => 87, user => 'userx' );

=head2 checkRights( searchId => $searchId, allowedCategories => \@categories )

Checks if the specified search contains at least one of the specified categories.

    $obj->checkRights( searchId => 87, allowedCategories => [ 2, 5, 8 ] );

Returns TRUE or FALSE depending on the found result.

=head2 nextObject( ) & getObject( )

Method to retrieve the list that is generated by a method  like loadCollection().

This way of retrieval can be used to get data from the database one-by-one. Both methods don't take arguments.

Example:

    $obj->loadCollection( $args );

    while( $obj->nextObject ) {
        push @list, $obj->getObject;
    }

=head1 DIAGNOSTICS

The following messages can be expected from this module:

=over

=item *

I<Database error, please check log for info> or I<Database error. (Error cannot be logged because logging is turned off or is not configured correctly)>

Is caused by a database syntax or input error. 
If syslog has been setup correctly the exact SQL statement and bindings should be visible in the configured syslog.

=back

=head1 DEPENDENCIES

CPAN modules required are B<SQL::Abstract> and B<Tie::IxHash>.

Taranis modules required are B<Taranis> and B<Taranis::Database>.

=head1 AUTHOR

Sebastiaan van Achterbergh <info@govcert.nl>

November 2010

=cut
