package Taranis::Role;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use strict;
use Taranis qw(:all);
use Taranis::Config;
use Taranis::Database;
use Taranis::Entitlement qw(getEntitlement);
use Data::Dumper;
use SQL::Abstract;
use Data::Validate qw(:math);
use Tie::IxHash;

sub new {
	shift @_;
	
	my $self = {
		config       => Taranis::Config->new(),
		dbh          => Taranis::Database->new(),
		sql          => SQL::Abstract->new(),
		dbkey        => 'id',
		errmsg       => '',
		userrole     => {},
		entitlements => {},
		roles        => {},
		role_users   => {}
	};
	bless $self;
	return $self;	
}

sub loadCollection {
	my ( $self, @arg ) = @_;
	undef $self->{errmsg};
	
	return $self->getRole();
}

sub addRoleRight {
	my ( $self, %insert ) = @_;
	undef $self->{errmsg};

	if ( defined( $insert{id} ) ) {
		$self->{errmsg} = "cannot give a Role id when adding a new one";
		return 0;
	}

	my %where = ( id => $insert{entitlement_id} );

	if ( !$self->{dbh}->checkIfExists( \%where, 'entitlement' ) ) {
		$self->{errmsg} = "entitlement_id unkown";
		return 0;
	}

	my ( $stmnt, @bind ) = $self->{sql}->insert( 'role_right', \%insert );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	} else {
		return 1;
	}
}

sub setRoleRight {
	my ( $self, %roleRightSettings ) = @_;
	undef $self->{errmsg};

	if ( !defined( $roleRightSettings{entitlement_id} ) ) {
		$self->{errmsg} = "cannot change/add a RoleRight without some id";
		return 0;
	}

	my %where = ( 
								role_id 			 => $roleRightSettings{role_id}, 
								entitlement_id => $roleRightSettings{entitlement_id} 
							);

	if ( $self->{dbh}->checkIfExists( {%where}, 'role_right' ) ) {
		# this record exists, so this must be an update.
		my %update;

		$update{read_right} = $roleRightSettings{read_right} if ( defined $roleRightSettings{read_right} );

		$update{write_right} = $roleRightSettings{write_right} if ( defined $roleRightSettings{write_right} );

		$update{execute_right} = $roleRightSettings{execute_right} if ( defined $roleRightSettings{execute_right} );

		$update{particularization} = ( defined $roleRightSettings{particularization} ) ? $roleRightSettings{particularization} : undef;

		my ( $stmnt, @bind ) = $self->{sql}->update( 'role_right', \%update, \%where );

		$self->{dbh}->prepare( $stmnt );
		$self->{dbh}->executeWithBinds( @bind );

		if ( defined( $self->{dbh}->{db_error_msg} ) ) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			return 0;
		}

	} else {
		# it's an insert
		my %insert;
	
		$insert{read_right} = $roleRightSettings{read_right} if ( defined $roleRightSettings{read_right} );

		$insert{write_right} = $roleRightSettings{write_right} if ( defined $roleRightSettings{write_right} );

		$insert{execute_right} = $roleRightSettings{execute_right} if ( defined $roleRightSettings{execute_right} );

		$insert{particularization} = $roleRightSettings{particularization} if ( defined $roleRightSettings{particularization} );

		$insert{entitlement_id} = $roleRightSettings{entitlement_id};
		$insert{role_id}        = $roleRightSettings{role_id};

		my ( $stmnt, @bind ) = $self->{sql}->insert( 'role_right', \%insert );
        
		$self->{dbh}->prepare( $stmnt );
		$self->{dbh}->executeWithBinds( @bind );

		if ( defined( $self->{dbh}->{db_error_msg} ) ) {
			$self->{errmsg} = $self->{dbh}->{db_error_msg};
			return 0;
		}
	}

	return 1;
}

sub getRole {
	my ( $self, %where ) = @_;
	undef $self->{errmsg};
		
	my $order = 'name';
	my ( $stmnt, @bind ) = $self->{sql}->select( 'role', "*", \%where, $order );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}
	
	return;
}

sub getMaxRoleId {
	my ( $self, %where ) = @_;
	undef $self->{errmsg};
	
	my $select = 'max(id)';
	my ( $stmnt, @bind ) = $self->{sql}->select( 'role', "$select", \%where );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}
	return;
}

sub getRoles {
	my ( $self, @arg ) = @_;
	undef $self->{errmsg};
	my %where;
	my %arg;

	# we want this to accept 3 flavors of arguments;
	# getRole(), getRole(X) [X is a number] or getRole(name => rolename)
	my $nr_args = scalar(@arg);
	if ( $nr_args > 1 ) {
		%arg = @arg;
		if ( defined( $arg{username} ) ) {
			%where = ( username => $arg{username} );
		} else {
			%where = ( id => $arg{id} );
		}
	} elsif ( $nr_args == 1 ) {
		%where = ( id => $arg[0] );
	} else {
		undef %where;
	}

	# check to see if we're blessed into an object already
	if ( ref( \$self ) ne "REF" ) {
		$self = $self->new();
	}

	my $dbkey = $self->{dbkey};
	my $order = 'name';
	my ( $stmnt, @bind ) = $self->{sql}->select( 'role', "*", \%where, $order );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}

	my $hash_ref = $self->{dbh}->{sth}->fetchall_hashref($dbkey);
	my $roles;
	while ( my ( $uKey, $uVal ) = ( each %$hash_ref ) ) {
		while ( my ( $key, $val ) = ( each %$uVal ) ) {
			next if ( $key eq $dbkey );
			$roles->{$uKey}{$key} = $val;
		}
	}

	return $roles;
}

sub setRole {
	my ( $self, %updates ) = @_;
	undef $self->{errmsg};

	my $id;

	if ( !defined( $updates{id} ) ) {
		$self->{errmsg} = "no or unknown roles id param ";
		return 0;
	} else {
		$id = $updates{id};
	}

	# now delete id key from data, becaus we only need it for our INSERT query
	delete $updates{id};

	my %where = ( id => $id );

	if ( !$self->{dbh}->checkIfExists( \%where, 'role' ) ) {
		$self->{errmsg} = "role id does not exist";
		return 0;
	}

	my ( $stmnt, @bind ) = $self->{sql}->update( 'role', \%updates, \%where );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}

	return $self;
}

sub addRole {
	my ( $self, %roleSettings ) = @_;
	undef $self->{errmsg};

	my %insert = (
									name        => $roleSettings{'name'},
									description => $roleSettings{'description'}
							 );

	my %checkdata = ( name => $insert{name} );

	if ( $self->{dbh}->checkIfExists( \%checkdata, 'role' ) ) {
		$self->{errmsg} = "name exists";
		return 0;
	}

	my ( $stmnt, @bind ) = $self->{sql}->insert( 'role', \%insert );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	} else {
		return 1;
	}
}

sub deleteRole {
	my ( $self, %where ) = @_;
	undef $self->{errmsg};

	if ( !defined( $where{id} ) ) {
		$self->{errmsg} = "no role id supplied";
		return 0;
	}

	###################################################################
	# check if there are any user_role records connected to this role #
	###################################################################
	my $user_role_id = $where{id};
	my $urTable      = 'user_role';
	my %uWhere       = ( role_id => $user_role_id );

	my ( $stmnt, @bind ) = $self->{sql}->select( $urTable, 'count(*)', \%uWhere );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}

	while ( $self->nextObject ) {
		my $record = $self->getObject();
		
		if ( $record->{count} > 0 ) {
			$self->{errmsg} = 'There are ' . $record->{count} . ' users connected to this role';
			return 0;
		}
	}

	################################################
	# delete all role_right records from this role #
	################################################

	my %rrWhere = ( role_id => $user_role_id );
	( $stmnt, @bind ) = $self->{sql}->delete( 'role_right', \%rrWhere );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}

	# then delete the role record
	my %rWhere = ( id => $user_role_id );
	( $stmnt, @bind ) = $self->{sql}->delete( 'role', \%rWhere );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}

	return 1;
}

sub getRolesFromUser {
	my ( $self, %where ) = @_;
	undef $self->{errmsg};

	tie my %join, "Tie::IxHash";

	if ( !defined( $where{username} ) ) {
		$self->{errmsg} = "no username supplied";
		return 0;
	}

	$where{'ur.username'} = delete $where{'username'};

	my $select = 'rol.name, rol.description, ur.role_id';
	my ( $stmnt, @bind ) = $self->{sql}->select( 'user_role AS ur', $select, \%where, "rol.name" );

	%join = ( "JOIN role AS rol" => { "ur.role_id" => "rol.id" } );
	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare($stmnt);
	$self->{dbh}->executeWithBinds(@bind);

	my $dbkey    = 'role_id';
	my $hash_ref = $self->{dbh}->{sth}->fetchall_hashref($dbkey);
	my $roles;
	
	while ( my ( $uKey, $uVal ) = ( each %$hash_ref ) ) {
		while ( my ( $key, $val ) = ( each %$uVal ) ) {
			next if ( $key eq $dbkey );
			$roles->{$uKey}{$key} = $val;
		}
	}

	$self->{errmsg} = $self->{dbh}->{db_error_msg};

	return $roles;
}

sub getUsersWithRole {
	my ( $self, %search ) = @_;
	undef $self->{errmsg};

	my %where;
	
	$where{'u.disabled'} = 'f';

	if ( defined( $search{role_id} ) ) {
		$where{'ur.role_id'} = $search{role_id};
	}

	if ( defined( $search{username} ) ) {
		if ( defined( $search{fullname} ) ) {
			$where{-or} = { 'u.fullname' => $search{fullname}, 'u.username' => $search{username}  };
		} else {
			$where{'u.username'} = $search{username};
		}
	}

	tie my %join, "Tie::IxHash";
	%join = (
						'LEFT JOIN user_role as ur' => { 'ur.username' => 'u.username' },
						'LEFT JOIN role as r'       => { 'r.id'        => 'ur.role_id' }
					);

	my $select = 'u.username , u.fullname, r.name as role_name';
	my ( $stmnt, @bind ) = $self->{sql}->select( 'users u', $select, \%where, 'u.username' );

	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}

	return 1;
}

sub getRolesWithEntitlement {
	my ( $self, %arg ) = @_;
	undef $self->{errmsg};
	
	my $entitlement_id = ( defined $arg{entitlement_id} ) ? $arg{entitlement_id} : '';
	
	my $select   = "rol.name , rol.description,rol.id as id";
	my $from     = "role rol";
	my $group_by = ' GROUP BY rol.name, rol.description,rol.id';
	my %where = (
								-nest => [
														'rr.read_right'    => 'true',
														'rr.write_right'   => 'true',
														'rr.execute_right' => 'true'
								 				 ]    
							);

	$where{'rr.entitlement_id'} = $entitlement_id if ( $entitlement_id );
	$where{'rol.name'} = { -ilike => "%$arg{name}%" } if ( $arg{name} );

	my %join = ( "JOIN role_right as rr" => { "rol.id" => "rr.role_id" } );

	my ( $stmnt, @bind ) = $self->{sql}->select( $from, $select, \%where );

	$stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt );
	$stmnt .= $group_by;
    
	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
    
	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	} else {
		return 1;
	}
}

sub nextObject {
	my ( $self ) = @_;
	return $self->{dbh}->nextRecord;
}

sub getObject {
	my ( $self ) = @_;
	return $self->{dbh}->getRecord;
}

sub getRoleRightsFromRole {
	my ( $self, %where ) = @_;
	undef $self->{errmsg};

	my ( $stmnt, @bind ) = $self->{sql}->select( 'role_right', '*', \%where );

	$self->{dbh}->prepare($stmnt);
	$self->{dbh}->executeWithBinds(@bind);

	if ( defined( $self->{dbh}->{db_error_msg} ) ) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return 0;
	}
	
	return 1;
}

1;

=begin 

=head1 NAME  

Taranis::Role - A Simple API for Taranis Roles.

=head1 SYNOPSIS

use Taranis::Role;

my $obj =  Taranis::Role->new();

change search key (defaults to id)
$obj->{dbkey} = 'name';

=head1 QUICK START

use Taranis::Role;
my $obj =  Taranis::Role->new();

$obj->getRole();
Return all roles (see below)


=head1 METHODS

=head2 B<getRole()>

$obj->getRole();
returns all roles records
or 
$obj->getRole($id);
returns a single role record with id $id
or
$obj->getRole(name => 'rolename');
returns a single role record with name 'rolename'

returns a hash on success.

You can change the returned hash key by setting $obj->{dbkey} to either;
name, id or description (defaults to id).
 

=head2 B<setRole()>

$obj->setRole(id => $id, name => 'new name', description => 'new description');

=head2 B<addRole()>

$obj->addRole(name => 'new role name', description => 'new role description')

=head2 B<addRoleRight()>

    Add an entry in the role_right table
    Read, write and execute attributes are optional and default to false (0). 
    The entitlement_id and role_id must exists.

    $obj->addRoleRight(
                 entitlement_id       => $ent_id,
                 execute_right        => 0,
                 read_right           => 1,
                 write_right          => 1,
                 role_id              => $role_id,
                 particularization    => 'Goblins, Hobgoblins, Snotlings en Gnoblars');

=head2 B<setRoleRight()>

    Change an entry (id) in the role_right table
    All attributes are optional.
    The entitlement_id and role_id must exist if you want to change them.
    

    $obj->setRoleRight( 
                 id                 => 13,
                 entitlement_id     => $ent_id,
                 execute_right      => 1,
                 read_right         => 0,
                 write_right        => 1,
                 role_id            => $role_id,
                 particularization  => 'Goblins exclusive');
             
             
=head1 AUTHOR

jeroen
Sep 15, 2008

=cut

