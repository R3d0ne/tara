package Taranis::Entitlement;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

our $VERSION = '0.01';

use strict;
use Taranis qw(:all);
use Taranis::Database;
use SQL::Abstract;
use Data::Dumper;

sub new {

    my ( $self, $arg ) = @_;

    $self = bless {}, $self;

     my $obj = {
              dbtable     => 'entitlement',
              entitlement => {},
              dbkey       => 'id',
              dbh         => Taranis::Database->new(),
              sql         => SQL::Abstract->new()
    };

    bless $obj;
    return $obj;
}

sub getEntitlement {

    my ( $self, %where ) = @_;

    if (    defined( $where{id} )
         && defined( $self->{entitlement}->{ $where{id} } ) )
    {
        return $self->{entitlement}->{ $where{id} };
    }

    my $key = $where{key} ? $where{key} : $self->{dbkey};

    my $table = $self->{dbtable};
    my $order = 'name';
    my ( $stmnt, @bind ) = $self->{sql}->select( $table, "*", \%where, $order );

    $self->{dbh}->prepare($stmnt);
    $self->{dbh}->executeWithBinds(@bind);

}

sub setEntitlement {

    my ( $self, %args ) = @_;

    my $id;

    if( !defined( $args{id} ) )    {
        $self->{errmsg} =  "no or unknown entitlement id" ;
        return 0;
    } else {
        $id = delete $args{id};
    }
    my $table = $self->{dbtable};

    my %where = ( id => $id );
    
    if ( !$self->{dbh}->checkIfExists( \%where, $table ) ) {
        $self->{errmsg} = "entitlement id does not exist";
        return 0;
    }

    my ( $stmnt, @bind ) = $self->{sql}->update( $table, \%args, \%where );

    my $sth = $self->{dbh}->prepare($stmnt);
    $sth->execute(@bind);

    return 1;

}

sub addEntitlement {

   # call: $obj->addEntitlement(name => 'NewName', 'description' => 'New Description');

    my ( $self, @arg ) = @_;

    my %argumenten = @arg;

    while ( my ( $key, $val ) = ( each %argumenten ) ) {
        $argumenten{$key} = sanitizeParameter($val);
    }

    if ( defined( $argumenten{id} ) ) {
         $self->{errmsg} =  "cannot give an entitlement id when adding a new one";
         return 0;
    }

    my %data = (
                 name        => $argumenten{'name'},
                 description => $argumenten{'description'}
    );

    my %checkdata = ( name => $data{name} );

    my $table = $self->{dbtable};

    if ( $self->{dbh}->checkIfExists( \%checkdata, $table ) ) {
        $self->{errmsg} = "name exists";
        return 0;
    }

    my ( $stmnt, @bind ) = $self->{sql}->insert( $table, \%data );

    my $sth = $self->{dbh}->prepare($stmnt);

    $self->{dbh}->{PrintError} = 1;
    $self->{dbh}->{RaiseError} = 1;

    my $res = $self->{dbh}->executeWithBinds(@bind);

    if ( defined( $self->{dbh}->{sth}->errstr ) ) {
         $self->{errmsg} =  $self->{dbh}->{sth}->errstr;
        return 0;
    }

    my $newid = $self->{dbh}->{dbh}->last_insert_id( undef, undef, $table, undef, undef );

    return $newid;

}

sub delEntitlement {

    return  'NOT IMPLEMENTED YET';

}

sub nextObject {
    my ($self) = @_;
    return $self->{dbh}->nextRecord;
}

sub getObject {
    my ($self) = @_;
    return $self->{dbh}->getRecord;
}


=head1 NAME

Taranis::Entitlement -  mainly for retrieving entitlements.

=head1 SYNOPSIS

  use Taranis::Entitlement

  my $obj = Taranis::Entitlement->new();

  $obj->getEntitlement()

  $obj->nextObject();

  $obj->getObject();

=head1 DESCRIPTION

This module is used for retrieving entitlements using the getEntitlement() method and helper methods getObject() and nextObject(). 
Other methods should not be used, because they have not been fully tested!

=head1 METHODS

=head2 new( )

Constructor of the C<Taranis::Entitlement> class.

    my $obj = Taranis::Entitlement->new();

Creates a new database handler which can accessed by:

    $obj->{dbh};

Creates a new C<SQL::Abstract> object which can be accessed by:

    $obj->{sql};

Clears error message for the new object. Can be accessed by:

    $obj->{errmsg};

Returns the blessed object.

=head2 getEntitlement( ), nextObject( ) & getObject( )

Method for retrieving all entitlements. Should be used with helper methods getObject() and nextObject() . 

Example:

    $obj->getEntitlement();

    while( $obj->nextObject ) {
        push @list, $obj->getObject;
    }

=head1 DEPENDENCIES

CPAN modules required are B<SQL::Abstract>.

Taranis modules required are B<Taranis> and B<Taranis::Database>.

=head1 AUTHOR

Sebastiaan van Achterbergh <info@govcert.nl>

November 2010

=cut

1;
