package Taranis::Template;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use Taranis qw(:all);
use Taranis::Database;
use Taranis::Config;
use strict;
use Template;
use SQL::Abstract;
use Data::Validate qw(:math);
use XML::Simple;
use POSIX;
use JSON -support_by_pp; 
use Encode;
use Date::Calc qw(N_Delta_YMDHMS);
use Date::Language;
use Date::Parse;

use CGI::Simple;
use CGI::Ajax;
use Data::Dumper;

our $VERSION = '0.01';

sub new {
  my ($class, %arg) = @_;

  my $cfg = Taranis::Config->new();
 
  # you only need this if your template is in an other path.
  my $relative = (defined $arg{RELATIVE} == 1) ? 1 : 0;
  my $absolute = (defined $arg{ABSOLUTE} == 1) ? 1 : 0;
  
  my $self = {
    errmsg    => undef,
    tpl_error => undef,
    tt        => Template->new(
                         {
                           INCLUDE_PATH => [ $cfg->{ttroot} ],
                           PRE_CHOMP    => 1,
                           POST_CHOMP   => 1,
                           RELATIVE     => $relative,
                           ABSOLUTE     => $absolute
                         }
    ),
    dbh => Taranis::Database->new(),
    sql => SQL::Abstract->new()

  };

	# extra template vmethod decodeEntity
	$self->{tt}->context->define_vmethod( 'scalar', 'decodeEntity',
		sub {
			my $encodedText = shift;
			return decodeInput( \$encodedText );
		} 
	);  

	# extra template vmethod keysReverseSortByValue
	$self->{tt}->context->define_vmethod( 'hash', 'keysReverseSortByValue',
		sub {
			my $hash = shift;
			my %hashCopy = %$hash;
			return reverse sort( { $hashCopy{$a} cmp $hashCopy{$b} } keys %hashCopy ); 
		} 
	);
	
	# extra template vmethod durationText
	$self->{tt}->context->define_vmethod( 'scalar', 'durationText',
		sub {
			my $startDateTime = shift;
			my $endDateTime = shift;

			my ( $sec1, $min1, $hour1, $day1, $month1, $year1 ) = ( localtime($startDateTime) )[0,1,2,3,4,5]; 
			my ( $sec2, $min2, $hour2, $day2, $month2, $year2 ) = ( localtime($endDateTime) )[0,1,2,3,4,5];

			# correct month and year
			$month1 += 1;
			$month2 += 1;
			$year1 += 1900;
			$year2 += 1900;

			my ( $years, $months , $days, $hours, $minutes, $seconds ) = N_Delta_YMDHMS(
					$year1,$month1,$day1, $hour1,$min1,$sec1,
					$year2,$month2,$day2, $hour2,$min2,$sec2
				);
			
			my $durationText = '';
			$durationText .= $days . ' day' if ( $days );
			$durationText =~ s/(.*)/$1s, / if ( $days > 1 );
			
			$durationText .= $hours . ' hour' if ( $hours );
			$durationText =~ s/(.*)/$1s/ if ( $hours > 1 );
			
			$durationText .= ' and ' if ( $hours );
			$durationText .= $minutes . ' minute' if ( $minutes );
			$durationText =~ s/(.*)/$1s/ if ( $minutes > 1 );

			return $durationText;
		} 
	);
  
  bless $self;
  return $self;
}

sub addTemplate {
  my $self = shift;

  if ( @_ % 2 ) {
    $self->{errmsg} = "Default options must be 'name => value' pairs (odd number supplied)";
    return 0;
  }

  my %data = @_;

  my ( $stmnt, @bind ) = $self->{sql}->insert( "publication_template", \%data );

  $self->{dbh}->prepare($stmnt);
  if ( defined( $self->{dbh}->executeWithBinds(@bind) ) > 0 ) {
    return 1;
  } else {
    $self->{errmsg} = $self->{dbh}->{db_error_msg};
    return 0;
  }
}

sub setTemplate {
  my $self = shift;
  my %data = @_;

  if ( !defined( $data{id} ) || !is_integer( $data{id} ) ) {
    $self->{errmsg} = "No valid id given for routine.";
    return 0;
  }

  my %where = ( id => delete $data{id} );
  my ( $stmnt, @bind ) = $self->{sql}->update( "publication_template", \%data, \%where );

  $self->{dbh}->prepare($stmnt);
  my $result = $self->{dbh}->executeWithBinds(@bind);

  if ( defined($result) && ( $result !~ m/(0E0)/i ) ) {
    if ( $result > 0 ) {
      return 1;
    } elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
      $self->{errmsg} = $self->{dbh}->{db_error_msg};
      return 0;
    }
  } else {
    $self->{errmsg} = $self->{dbh}->{db_error_msg};
    return 0;
  }
}

sub deleteTemplate {
  my ( $self, $id ) = @_;

  if ( !defined($id) || !is_integer($id) ) {
    $self->{errmsg} = "No valid id given for routine.";
    return 0;
  }

  my ( $stmnt, @bind ) = $self->{sql}->delete( "publication_template", { id => $id } );
  $self->{dbh}->prepare($stmnt);

  my $result = $self->{dbh}->executeWithBinds(@bind);
  if ( defined($result) && ( $result !~ m/(0E0)/i ) ) {
    if ( $result > 0 ) {
      return 1;
    } elsif ( defined( $self->{dbh}->{db_error_msg} ) ) {
      $self->{errmsg} = $self->{dbh}->{db_error_msg};
      return 0;
    }
  } else {
    $self->{errmsg} = "Delete failed, corresponding id not found in database.";
    return 0;
  }
}

sub getTemplate {
  my ( $self, %searchFields ) = @_;
  undef $self->{errmsg};
  my @pt_data;

	my %where = $self->{dbh}->createWhereFromArgs( %searchFields );

  my ( $stmnt, @bind ) =  $self->{sql}->select( "publication_template", "title, id, description, type, template AS tpl",  \%where, "title" );

  $self->{dbh}->prepare($stmnt);
  my $result = $self->{dbh}->executeWithBinds(@bind);

  $self->{errmsg} = $self->{dbh}->{db_error_msg};
  return $result;
}

sub getTypeIds {
	my ( $self, @type_names ) = @_;
	undef $self->{errmsg};
	my @ids;
	
	my ( $stmnt, @bind ) = $self->{sql}->select( "publication_type", "id", { title => { ilike => \@type_names} } );

	$self->{dbh}->prepare( $stmnt );
	$self->{dbh}->executeWithBinds( @bind );
	
	if ( defined( $self->{dbh}->{db_error_msg} )) {
		$self->{errmsg} = $self->{dbh}->{db_error_msg};
		return;
	} else {	
		while ( $self->nextObject() ) {
			push @ids, $self->getObject()->{id};
		}
		return \@ids;
	}	
}

sub nextObject {
  my ($self) = @_;
  return $self->{dbh}->nextRecord;
}

sub getObject {
  my ($self) = @_;
  return $self->{dbh}->getRecord;
}

sub processTemplate {
  my ( $self, $template, $vars ) = @_;
  my ( $package, $file, $line ) = caller();

	$vars->{footer_year} = nowstring(6);# + 1900;
	
  if ( !defined $vars->{webroot} ) { $vars->{webroot} = Taranis::Config->getSetting("webroot") }
  if ( !defined $vars->{scriptroot} ) {
    $vars->{scriptroot} = Taranis::Config->getSetting("scriptroot");
  }
  
  my $header;

  if ( $file !~ /login\.pl$/ ) {
    $header = "Cache-Control: no-cache, no-store, max-age=0, must-revalidate\n";
    $header .= "Content-type: text/html\n\n";
  } else {
    $header = "Content-type: text/html\n\n";
  }

  print $header;

  return $self->{tt}->process( $template, $vars ) || ( $self->{errmsg} = $self->{tt}->error );
}

sub processAjaxTemplate {
  my ( $self, $template, $vars, $ajax ) = @_;

  my $cgi = CGI::Simple->new();

	$vars->{footer_year} = nowstring(6);# + 1900;
  
  if ( !defined $vars->{webroot} ) { $vars->{webroot} = Taranis::Config->getSetting("webroot") }
  if ( !defined $vars->{scriptroot} ) {
    $vars->{scriptroot} = Taranis::Config->getSetting("scriptroot");
  }

  my $html = '';
  $self->{tt}->process( $template, $vars, \$html );

  my $pjx = CGI::Ajax->new(%$ajax);
  $pjx->DEBUG(0);
  $pjx->JSDEBUG(0);
  $pjx->CACHE(0);
  
  $pjx->skip_header(1);
  
  my $header = "Cache-Control: no-cache, no-store, max-age=0, must-revalidate\n";
  $header .= "Content-type: text/html\n\n";
  print $header;
  print $pjx->build_html( $cgi, $html );

}

sub processTemplateNoHeader {
  my ( $self, $template, $vars, $noprint ) = @_;

  if ( !exists $vars->{webroot} ) { $vars->{webroot} = Taranis::Config->getSetting("webroot"); }
  if ( !exists $vars->{scriptroot} ) { $vars->{scriptroot} = Taranis::Config->getSetting("scriptroot"); }
	
	if ($noprint) {
	   my $output = '';
    $self->{tt}->process( $template, $vars, \$output ) || ( $self->{errmsg} = $self->{tt}->error );

    return $output;	  
	} else {
	  return $self->{tt}->process( $template, $vars ) || ( $self->{errmsg} = $self->{tt}->error );
	}
  
}

sub processPublicationTemplate {
  my ( $self, $template, $tab ) = @_;
  undef $self->{tpl_error};
  
	$template =~ s/&lt;/</g;
	$template =~ s/&gt;/>/g;
	$template =~ s/&quot;/"/g;
	$template =~ s/&#39;/'/g;  

  $template =~ /<template>(.*?)<\/template>/s;

  my $tpl_content = $1;
	
	if ( $template !~ /<template><!\[CDATA\[.*?\]\]><\/template>/is ) {
  	$template =~ s/<template>.*?<\/template>/<template><!\[CDATA\[$tpl_content]]><\/template>/s;
	}
	
  my $ref = eval { XMLin( $template ) };
  if ($@) {
    $self->{tpl_error} = "XML parse error. Please check the publication template syntax.(1)<br />" . $@;
    return;
  }

  my $fields_html;
  my $field_names;
  my $fields = $ref->{fields};
  for my $key ( keys %$fields ) {
    for ( $fields->{$key}->{content} ) {

      if (m/^(textarea)/i) {
      	if ( exists( $fields->{$key}->{desc} ) ) {
	        $fields->{$key}->{content} =~ m/:(.*):(.*)/i;
	        my $attr_cols = $1;
	        my $attr_rows = $2;
	        if (    !defined($attr_cols)
	             || !defined($attr_rows)
	             || !is_integer($attr_cols)
	             || !is_integer($attr_rows) )
	        {
	          $self->{tpl_error} .= "Attributes width and height for <textarea> are not defined properly. Example: 'textarea:100:20'.";
	        } else {
	          $fields_html .= "<div class='tpl-heading'>$fields->{$key}->{desc}:</div><textarea name='$key' id='$key' style='width: " . $attr_cols . "px; height: " . $attr_rows . "px' class='input-default'></textarea>";
	          $field_names .= $tab . "$key:";
	        }
        } else {
          $self->{tpl_error} .= "Attribute 'desc' missing for $fields->{$key}.";
        }
      } elsif (m/^(text)/i) {
        if ( exists( $fields->{$key}->{desc} ) ) {
          $fields->{$key}->{content} =~ m/:(.*)/i;
          my $attr_length = $1;
          if ( !defined($attr_length) ) {
            $self->{tpl_error} .= "Attribute length for <input type='text'> is not defined properly. Example: 'text:30'.";
          } else {
            $fields_html .= "<div class='tpl-heading'>$fields->{$key}->{desc}:</div><input name='$key' id='$key' type='text' style='width: " . $attr_length . "px' class='input-default'>";
            $field_names .= $tab . "$key:";
          }
        } else {
          $self->{tpl_error} .= "Attribute 'desc' missing for $fields->{$key}.";
        }
      } elsif (m/^(dropdown)/i) {
        $fields->{$key}->{content} =~ s/^(dropdown:)//i;
        my @list = split( /:/, $fields->{$key}->{content} );
        if ( @list > 0 ) {
          $fields_html .= "<div class='tpl-heading'>$fields->{$key}->{desc}:</div><select name='$key' class='input-default' id='$key'>";
          for ( my $i = 0 ; $i < @list ; $i++ ) {
            $fields_html .= "<option value='$list[$i]'>$list[$i]</option>";
          }
          $fields_html .= "</select>";
          $field_names .= $tab . "$key:";
        } else {
          $self->{tpl_error} .= "The option list for the drop-down listbox has not been defined properly. Example: 'dropdown:green:red:orange'.";
        }
      } elsif (m/^(radio)/i) {
        $fields->{$key}->{content} =~ s/^(radio:)//i;
        my @list = split( /:/, $fields->{$key}->{content} );
        if ( @list > 0 ) {
          $fields_html .= "<div class='tpl-heading'>$fields->{$key}->{desc}:</div>";
          for ( my $i = 0 ; $i < @list ; $i++ ) {
            $fields_html .= "<input type='radio' name='$key' value='$list[$i]' id='$list[$i]'><label for='$list[$i]'>$list[$i]</label><br>";
            $field_names .= $tab . "$list[$i]:";
          }
        } else {
          $self->{tpl_error} .= "The list for the radio buttons has not been defined properly. Example: 'radio:green:red:orange'.";
        }
      } elsif (m/^(multiple)/i) {
        $fields->{$key}->{content} =~ s/^(multiple:)//i;
        my @list = split( /:/, $fields->{$key}->{content} );
        if ( @list > 0 ) {
          $fields_html .= "<div class='tpl-heading'>$fields->{$key}->{desc}:</div>";
          for ( my $i = 0 ; $i < @list ; $i++ ) {
            $fields_html .= "<input type='checkbox' name='$key' value='$list[$i]' id='$list[$i]'><label for='$list[$i]'>$list[$i]</label><br>";
            $field_names .= $tab . "$list[$i]:";
          }
        } else {
          $self->{tpl_error} .= "The list for the checkboxes has not been defined properly. Example: 'multiple:green:red:orange'.";
        }
      } elsif (m/^(taranis)/i) {
      } else {
        $self->{tpl_error} .= "Incorrect definition found: '$fields->{$key}->{content}'";
      }
    }
  }

  $field_names =~ s/:$//i;
	if ( !$field_names ) {
		$fields_html .= "<div class='tpl-heading'>This template contains no input fields. Press '< Apply template' to add template text.</div>";
	}
  return $fields_html;
}

sub processPublicationTemplateText {
  my ( $self, $json_str, $tab ) = @_;
  undef $self->{tpl_error};

  my $tpl_data = decode_json($json_str);

  $self->getTemplate( id => $tpl_data->{template_id} );
  
  my $template = $self->{dbh}->fetchRow()->{tpl};

	$template =~ s/&lt;/</g;
	$template =~ s/&gt;/>/g;
	$template =~ s/&quot;/"/g;
	$template =~ s/&#39;/'/g;
	
  $template =~ /<template>(.*?)<\/template>/s;

  my $tpl_content = $1;

	if ( $template !~ /<template><!\[CDATA\[.*?\]\]><\/template>/is ) {
  	$template =~ s/<template>.*?<\/template>/<template><!\[CDATA\[$tpl_content]]><\/template>/s;
	}
	
  my $ref = eval { XMLin( $template ) };
  if ($@) {
    $self->{tpl_error} = "XML parse error. Please check the publication template syntax.(2)";
    return;
  }

  my $tpl_txt = $ref->{template};

  foreach my $key ( keys %$tpl_data ) {
    my $tpl_fieldname = $key;
    $key =~ s/$tab//i;
    if ( ref( $tpl_data->{$tpl_fieldname} ) eq "ARRAY" ) {
      my $tmp;
      foreach ( @{ $tpl_data->{$tpl_fieldname} } ) {
        $tmp .= "$_, ";
      }
      $tmp     =~ s/,\s$//;
      $tpl_txt =~ s/_($key)_/$tmp/ig;
    } else {
      $tpl_txt =~ s/_($key)_/$tpl_data->{$tpl_fieldname}/ig;
    }
  }

	foreach my $field ( keys %{ $ref->{fields} } ) {
		$tpl_txt =~ s/_$field\_//gi;
	}

  # do sorting of headers 
  if ( $tpl_data->{original_txt} && $tpl_data->{original_txt} =~ /-=.*?=-/ ) {
	  $tpl_txt = $tpl_data->{original_txt} . "\n" . $tpl_txt;
	  
		my @lines = split( /(\s*-=.*?=-)/ , $tpl_txt );
		
		my $text;
		my %text_per_heading;
		
		for ( my $i = 0; $i < @lines; $i++ ) {
			if ( $lines[$i] =~ /-=.*?=-/ ) {
				$text_per_heading{ trim( $lines[$i] ) } .= trim( $lines[$i] ) . ( delete $lines[$i+1] );
				$i++;
			} else {
				$text = $lines[$i];
			} 
		}
		
		@lines = sort sortAnyCase( keys %text_per_heading );
		
		foreach ( @lines ) {
			$text .= "\n\n".$text_per_heading{$_};
		}
	  
	  $tpl_txt = $text;
  } else {
  	$tpl_txt = $tpl_data->{original_txt} . $tpl_txt; 
  }
  
  $tpl_txt = trim($tpl_txt);
  return $tpl_txt . "\n";
}

sub processPreviewTemplate {
  my ( $self, $publication, $publication_type, $pub_details_id, $publication_id, $is_wdalert, $line_width ) = @_;

  my $xml_str;
  my $tpl_name = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{$publication}->{$publication_type};

  $self->getTemplate( title => $tpl_name );
  while ( $self->nextObject() ) {
    $xml_str = decodeInput( \$self->getObject()->{tpl} );
  }

	my %id = (
	           publication_id 	=> $publication_id,
	           "publication.id" => $publication_id	           				
					 );

  if ( $publication eq "advisory" ) {
	  $id{"advisory_id"} 						 = $pub_details_id;
		$id{"publication_advisory.id"} = $pub_details_id;
  
  } elsif ( $publication eq "eow" ) {
	  $id{"eow_id"} 									= $pub_details_id;
		$id{"publication_endofweek.id"} = $pub_details_id;
  } elsif ( $publication eq "eos" ) {
    $id{"eos_id"}                   = $pub_details_id;
    $id{"publication_endofshift.id"} = $pub_details_id;
  } else {
  	$self->{errmsg} = "Unknown publication: $publication";
  	return;
  }

  my $ref = eval { XMLin($xml_str ) };
  if ($@) {
    $self->{errmsg} = "XML parse error:" . $@;
    return;
  }

  my ( %statements, %replacements, %settings );
  
  my $fields       = $ref->{fields};
  my $template_txt = $ref->{template};

  #################### CONVERT XML INTO SQL STATEMENTS (<fields></fields>) ####################
  foreach my $key ( keys %$fields ) {

    if ( ref( $fields->{$key} ) ne 'ARRAY' ) {
      $fields->{$key}[0] = delete $fields->{$key};
    }

    for ( my $j = 0 ; $j < @{ $fields->{$key} } ; $j++ ) {
      my $field_type = $fields->{$key}->[$j]->{type};

      for ($field_type) {
        if (/database/) {
          my ( %join, %where );
          my ( $tbl1, $tbl1_column, $tbl2, $tbl2_column, $select, $from );

          for ( my $i = 0 ; $i < @{ $fields->{$key}->[$j]->{tbl} } ; $i++ ) {
            if (    ( exists $fields->{$key}->[$j]->{tbl}->[$i]->{content} )
                 && ( exists $fields->{$key}->[$j]->{tbl}->[$i]->{type} )
                 && ( exists $fields->{$key}->[$j]->{tbl}->[$i]->{column} ) )
            {
              my $type   = $fields->{$key}->[$j]->{tbl}->[$i]->{type};
              my $column = $fields->{$key}->[$j]->{tbl}->[$i]->{column};
              my $table  = $fields->{$key}->[$j]->{tbl}->[$i]->{content};

              for ($type) {
                if (/^key$/) {
                  my $where_column = ( $column eq "id" ) ? $table . "." . $column : $column;
                  %where = ( $table . "." . $column => $id{$where_column} );
                }
                if (/^select$/) {
                  $select = "DISTINCT(" . $table . "." . $column . ")";
                  $from = $table;
                }
                if (/^select_date$/) {
                  $select = "to_char(" . $table . "." . $column . ", 'YYYYMMDD')";
                  $from   = $table;
                }
                if (/^(select_date_.+)$/) {
                  $select = "DISTINCT(" . $table . "." . $column . ")";
                  $from = $table;
                  $settings{$key}->{$1} = undef;
                }
                if (/^join1$/) {
                  $tbl1        = $table;
                  $tbl1_column = $column;
                }
                if (/^join2$/) {
                  $tbl2        = $table;
                  $tbl2_column = $column;
                }
              }
            } else {
              $self->{errmsg} = "Template error: syntax for type 'database' incorrectPlease correct template $tpl_name\n";
            }
          }
          my ( $stmnt, @bind ) = $self->{sql}->select( $from, $select, \%where );
          if ( $tbl1 && $tbl2 ) {
            %join =
              ( "JOIN " . $tbl1 => { $tbl1 . "." . $tbl1_column => $tbl2 . "." . $tbl2_column } );
            $stmnt = $self->{dbh}->sqlJoin( \%join, $stmnt ) if ( scalar %join );
          }
          $statements{$key} = { $stmnt => @bind };
        } elsif (/replace/) {

          if ( exists( $fields->{$key}->[$j]->{rp} ) ) {

          	#If there is only one element in 'replace', must be placed in an array for walking through 'replace'
          	if ( ref( $fields->{$key}->[$j]->{rp} ) ne 'ARRAY' ) { 
          		$fields->{$key}->[$j]->{rp}->[0] = delete $fields->{$key}->[$j]->{rp};
          	}
          	
	          for ( my $k = 0 ; $k < @{ $fields->{$key}->[$j]->{rp} }; $k++ ) {
	            $replacements{$key}->{ $fields->{$key}->[$j]->{rp}->[$k]->{original_value} } = $fields->{$key}->[$j]->{rp}->[$k]->{content};
	          }
	          
          } else {
	          $self->{errmsg} = "Template error: child element(s) 'rp' missing for type 'replace'. Please correct template $tpl_name\n";
          }
        } elsif (/settings/) {
        	if ( exists( $fields->{$key}->[$j]->{setting} ) ) {
          	
          	#If there is only one element in 'settings', must be placed in an array for walking through 'settings'
          	if ( ref( $fields->{$key}->[$j]->{setting} ) ne 'ARRAY' ) { 
          		$fields->{$key}->[$j]->{setting}->[0] = delete $fields->{$key}->[$j]->{setting};
          	}
          	
	        	for ( my $l = 0; $l < @{ $fields->{$key}->[$j]->{setting} }; $l++ ) {
	        		$settings{$key}->{$fields->{$key}->[$j]->{setting}->[$l]->{type} } = $fields->{$key}->[$j]->{setting}->[$l]->{content};
	        	}
	        	
        	} else {
        		$self->{errmsg} = "Template error: child element(s) 'setting' missing for type 'settings'. Please correct template $tpl_name\n";
        	}
        }
      }
    }
  }

  #################### QUERY THE STATEMENTS ####################
  my %results;
  foreach my $field ( keys %statements ) {
    $self->{dbh}->prepare( keys %{ $statements{$field} } );
    $self->{dbh}->executeWithBinds( values %{ $statements{$field} } );

    while ( $self->{dbh}->nextRecord() ) {
      push @{ $results{$field} }, $self->{dbh}->getRecord();
    }
  }

	#################### PROCESS THE TEMPLATE TEXT WITH THE RESULTS FROM THE DATABASE ####################
	foreach my $field_name ( keys %statements ) {
		my $result_txt = "";
		if ( exists( $replacements{$field_name} ) ) {
			for ( my $k = 0; $k < @{ $results{$field_name} }; $k++ ) {
				foreach my $result_key ( keys %{ $results{$field_name}->[$k] } ) {
					my $result_value = [ values %{ $results{$field_name}->[$k] } ]->[0];
					$results{$field_name}->[$k]->{$result_key} = $replacements{$field_name}->{ $result_value };
				}
			}
		}

		if ( exists( $results{$field_name} ) ) {
			#If the result for a field is more than one record
			if ( scalar @{ $results{$field_name} } > 1 ) {
					
				for ( my $j = 0; $j < @{ $results{$field_name} }; $j++ ) {
					$result_txt .= [ values %{ $results{$field_name}->[$j] } ]->[0] . "\n"
						if ( [ values %{ $results{$field_name}->[$j] } ]->[0] );
				}
			} else {
				$result_txt = [ values %{ $results{$field_name}->[0] } ]->[0];
				$result_txt = ( $result_txt ) ? $result_txt : "";
			}
		
			my $field_name_idx = index( $template_txt, "_$field_name" );
			
			my $margin;
			$template_txt =~ /\n( *_$field_name\_\b)/;
			if ( $1 ) {
				$margin = $field_name_idx - ( index( $template_txt, $1 ) );
			} else {
				$template_txt =~ /\n(.*\s*_$field_name)/;
				$margin = $field_name_idx - ( index( $template_txt, $1 ) );
			}

			my $alignment_space;
			for ( my $i = 0; $i < $margin; $i++ ) {
				$alignment_space .= " ";
			} 
			
			if ( $line_width != 0 ) {
        $result_txt = $self->setNewlines( $result_txt, $margin, $line_width );
			}

			my $new_txt;
			foreach ( split("\n", $result_txt) ) {
				$new_txt .= $_."\n".$alignment_space; 
			}
			$new_txt =~ s/\n$alignment_space$//;
			$result_txt = $new_txt;
				
			if ( exists( $settings{$field_name} ) && $result_txt ) {
				for ( keys %{ $settings{$field_name} } ) {
					if (/heading/) {
						$result_txt =~ s/(\s*)(.*)/\n$settings{$field_name}->{heading}\n$alignment_space$2/;
						$template_txt =~s/\n\s*_($field_name)_/\n_$field_name\_/i;
					}
          if (/^footer$/) {
            $result_txt =~ s/(.*?)[\s\n\r]*$/$1\n$settings{$field_name}->{footer}/s;
          }
          if (/^select_date_(.+)$/ ) {
            eval{
              my $lang = Date::Language->new( $1 );
              $result_txt = $lang->time2str("%A %d-%m-%Y %H:%M", str2time($result_txt) );
            };

            if ( $@ ) {
              $result_txt .= " DATE LANGUAGE NOT SUPPORTED OR INVALID DATE FORMAT SUPPLIED";
            }
          }
				}				
			}
			
			if ( $result_txt ) {
				$template_txt =~s/_($field_name)_/$result_txt/i;	
			} else {
				$template_txt =~s/\n\s*_($field_name)_|_($field_name)_//i;
			}
		} else {
			$template_txt =~s/_($field_name)_//;
		}	
	}
	return $template_txt;
}

sub processPreviewTemplateRT {
  my ( $self, %publicationSettings ) = @_;

	my $publication = $publicationSettings{publication};
	my $publication_type = $publicationSettings{publication_type};
	
	my $line_width = delete( $publicationSettings{line_width} );
	
	my $formData = $publicationSettings{formData};

  my $xml_str;
  my $tpl_name = Taranis::Config->new( Taranis::Config->getSetting("publication_templates") )->{$publication}->{$publication_type};

  $self->getTemplate( title => $tpl_name );
  while ( $self->nextObject() ) {
    $xml_str = decodeInput( \$self->getObject()->{tpl} );
  }

  my $ref = eval { XMLin($xml_str ) };
  if ($@) {
    $self->{errmsg} = "XML parse error! Please check your publication template for invalid XML.";
    return;
  }

  my ( %replacements, %settings );
  
	my %results;
  my $fields       = $ref->{fields};
  my $template_txt = $ref->{template};

	#################### CREATE DATASTRUCTURE FROM FROMDATA ####################
	foreach my $field ( keys %$fields ) {
		
    if ( ref( $fields->{$field} ) !~ /^ARRAY$/i ) {
      $fields->{$field}[0] = delete $fields->{$field};
    }		

		foreach my $fieldItem ( @{ $fields->{$field} } ) {

			for ( $fieldItem->{type} ) {
				if (/^database$/i) {
					
					if ( exists( $fieldItem->{tbl} ) ) {
					
						TBLITEM:
						foreach my $tblItem ( @{ $fieldItem->{tbl} } ) {
							next TBLITEM if ( $tblItem->{type} !~ /^(select|select_date|select_date_.+)$/i );

              my ( $fieldValue, $keyName );
              
              if ( exists( $formData->{ $tblItem->{alias} } ) ) {
                $fieldValue = $formData->{ $tblItem->{alias} };
                $keyName = 'alias';
              } elsif ( exists( $formData->{ $tblItem->{column} } ) ) {
								$fieldValue = $formData->{ $tblItem->{column} };
                $keyName = 'column';
							} elsif ( exists( $formData->{ $tblItem->{content} . '.' . $tblItem->{column} } ) ) {
								$fieldValue = $formData->{ $tblItem->{content} . '.' . $tblItem->{column} };
								$keyName = 'column';
							}
							
							if ( $tblItem->{type} =~ /^select_date_(.+)$/ ) {
								# when using a date format like xx-xx-yyyy str2time will use the first xx as month
								eval{
								  my $lang = Date::Language->new( $1 );
								  $fieldValue = $lang->time2str("%A %d-%m-%Y %H:%M", str2time( $fieldValue ) );
								};

								if ( $@ ) {
									$fieldValue .= " DATE LANGUAGE NOT SUPPORTED OR INVALID DATE FORMAT SUPPLIED";
								}
							}
							
              if ( ref( $fieldValue ) =~ /ARRAY/i ) {
                $results{$field} = $fieldValue;
              } else {
                $results{$field} = [ { $tblItem->{$keyName} => $fieldValue } ]; 
              } 							
							 
						}
					} else {
						$self->{errmsg} = "Template error: child element(s) tbl missing for type database. Please correct template $tpl_name\n";
						return 0;						
					}
				} elsif (/^replace$/i) {
					
					if ( exists( $fieldItem->{rp} ) ) {

						if ( ref( $fieldItem->{rp} ) !~ /^ARRAY$/i ) {
							$fieldItem->{rp}->[0] = delete $fieldItem->{rp};
						}						
						
	          foreach my $replace ( @{ $fieldItem->{rp} } ) {
	          	$replacements{$field}->{ $replace->{original_value} } = $replace->{content};
	          }
					} else {
						$self->{errmsg} = "Template error: child element(s) rp missing for type replace. Please correct template $tpl_name\n";
						return 0;
					}
				} elsif (/^settings$/i) {
					
        	if ( exists( $fieldItem->{setting} ) ) {

						if ( ref( $fieldItem->{setting} ) !~ /^ARRAY$/i ) {
							$fieldItem->{setting}->[0] = delete $fieldItem->{setting};
						}

	          foreach my $setting ( @{ $fieldItem->{setting} } ) {
	          	$settings{$field}->{ $setting->{type} } = $setting->{content};
	          }
        	} else {
        		$self->{errmsg} = "Template error: child element(s) setting missing for type settings. Please correct template $tpl_name\n";
        		return 0;
        	}					
				}
			}
		}
	}

	#################### PROCESS THE TEMPLATE TEXT WITH THE FORM DATA ####################
	foreach my $field_name ( keys %results ) {
		my $result_txt = "";
		if ( exists( $replacements{$field_name} ) ) {
			for ( my $k = 0; $k < @{ $results{$field_name} }; $k++ ) {
				foreach my $result_key ( keys %{ $results{$field_name}->[$k] } ) {
					my $result_value = [ values %{ $results{$field_name}->[$k] } ]->[0];
					$results{$field_name}->[$k]->{$result_key} = $replacements{$field_name}->{ $result_value };
				}
			}
		}

		if ( exists( $results{$field_name} ) ) {
			#If the result for a field is more than one record
			if ( scalar @{ $results{$field_name} } > 1 ) {
					
				for ( my $j = 0; $j < @{ $results{$field_name} }; $j++ ) {
					$result_txt .= [ values %{ $results{$field_name}->[$j] } ]->[0] . "\n"
						if ( [ values %{ $results{$field_name}->[$j] } ]->[0] );
				}
			} else {
				$result_txt = [ values %{ $results{$field_name}->[0] } ]->[0];
				$result_txt = ( $result_txt ) ? $result_txt : "";
			}
		
			my $field_name_idx = index( $template_txt, "_$field_name" );
			
			my $margin;
			$template_txt =~ /\n( *_$field_name\_\b)/;
			if ( $1 ) {
				$margin = $field_name_idx - ( index( $template_txt, $1 ) );
			} else {
				$template_txt =~ /\n(.*\s*_$field_name)/;
				$margin = $field_name_idx - ( index( $template_txt, $1 ) );
			}

			my $alignment_space;
			for ( my $i = 0; $i < $margin; $i++ ) {
				$alignment_space .= " ";
			} 

			$result_txt =~ s/\n/\r\n/g;

      if ( $line_width != 0 ) {
        $result_txt = $self->setNewlines( $result_txt, $margin, $line_width );
      }			

			my $new_txt;
			foreach ( split("\n", $result_txt) ) {
				$new_txt .= $_."\n".$alignment_space; 
			}
			$new_txt =~ s/\n$alignment_space$//;
			$result_txt = $new_txt;

			if ( exists( $settings{$field_name} ) && $result_txt ) {
				for ( keys %{ $settings{$field_name} } ) {
					if (/^heading$/) {
						$result_txt =~ s/(\s*)(.*)/\n$settings{$field_name}->{heading}\n$alignment_space$2/;
						$template_txt =~s/\n\s*_($field_name)_/\n_$field_name\_/i;
					}
          if (/^footer$/) {
          	$result_txt =~ s/(.*?)[\s\n\r]*$/$1\n$settings{$field_name}->{footer}/s;
          }
				}				
			}
			
			if ( $result_txt ) {
				$template_txt =~s/_($field_name)_/$result_txt/i;	
			} else {
				$template_txt =~s/\n\s*_($field_name)_|_($field_name)_//i;
			}
		} else {
			$template_txt =~s/_($field_name)_//;
		}	
	}

	return $template_txt;
}

sub setNewlines {
	my ( $self, $text, $margin, $width ) = @_;
	my $done 				= 0;
	my $offset 			= 0;
	my $line_length = $width - $margin;
	my $link_length = $line_length - 3;
	my $newstr			= "";
	my $newline_is_set = 0;

	$text = decodeInput( \$text );
	
	my $is_hyperlink = 0;
	while ( $done == 0 ) {
		if ( length( substr( $text, $offset ) ) > $line_length ) {
			my $line = substr( $text, $offset, $line_length );

			if ( $line =~ /(\n).*/ ) {
				
				if ( $newline_is_set && $line =~ /^\n.*/ ) {
					$line =~ s/^\n(.*)/$1/;
					$newline_is_set = 0;
				}
				
				$newstr .= $`.$1 if ( $` );

				$offset += index( $line, $1 ) if ( $1 );

				$offset += 1;
			
				$is_hyperlink = 0;
			} elsif ( $line !~ /.*\s.*/ ) {

				# hyperlink that's too long
				$line = substr( $line, 0, $link_length );
				
				if ( $line =~ /(.*)\/.*/ ) {
					$line =~ /(.*)\/.*$/;
					my $pre_slash_length =  length( $1 );
					if ( $pre_slash_length eq 0 ) {
						$offset += length( $line );
						$newstr .= $line . "\n   ";
					} else {
						$offset += $pre_slash_length;
						$newstr .= $1 . "\n   ";
					}
				} else {
					$line = substr( $line, 0, $link_length );
					$offset += length( $line );
					$newstr .= $line . "\n   ";
				}

				$is_hyperlink = 1;
				
			} else {
				
				if ( $line =~ /^\s+.*/ ) {
					$line .= "\n";
					if ( length( $line ) == $line_length + 1 ) {
						$offset += length( $line );
					} else {
						$offset += length( $line ) + 1;
					}
										
				} else {
					$line =~ s/(.*)\s.*$/$1\n/;
					$offset += length( $1 ) + 1;					
				}

				$newline_is_set = 1;
				$newstr .= $line;
				$is_hyperlink = 0;
			}
		} else {
			my $rest_txt = substr( $text, $offset );
			
			if ( $is_hyperlink ) {
				my $rest_link_txt = $rest_txt;
				if ( length( $rest_link_txt ) > $link_length ) {
					$rest_link_txt = substr( $rest_link_txt, 0, $link_length );

					my $link_offset = length( $rest_link_txt );

					$rest_link_txt =~ s/(.+)\/(.*)$/$1\n   \/$2/;

					$rest_txt = $rest_link_txt . "\n   " . substr( $rest_txt, $link_offset ); 
				}
				
			}	elsif ( $newline_is_set && $rest_txt =~ /^\n.*/ ) {
				$rest_txt =~ s/^\n(.*)/$1/;
				$newline_is_set = 0;
			}
			$newstr .= $rest_txt;
			$done = 1;
		}
	}

	return encodeInput( \$newstr );
}

sub createPageBar {
  my ( $self, $my_page, $number_results, $max_results ) = @_;

  my $this_page  = ( $my_page ne '' ) ? $my_page : 1;
  my $start_page = 1;
  my $max_row    = 9;
  my $next_page  = $this_page + 1;
  my $last_page  = ceil( $number_results / $max_results );

  my @row      = "$start_page" .. "$last_page";
  my $row_size = scalar(@row);
  my @button_row;

  if ( ( $row_size >= $max_row ) && ( ( $last_page - $this_page ) >= $max_row ) ) {
    my $new_lastpage = $this_page + $max_row;
    @button_row = "$this_page" .. "$new_lastpage";
  } elsif ( $row_size > $max_row ) {
    my $remainder = $row_size - $max_row;
    @button_row = "$remainder" .. "$row_size";
  } else {
    @button_row = @row;
  }

  return {
           next_page      => $next_page,
           last_page      => $last_page,
           button_row     => \@button_row,
           number_results => $number_results,
           my_page        => $my_page
  };
}

sub sortAnyCase {
	return lc($a) cmp lc($b);
}

1;

=head1 NAME 

Taranis::Template - Add, edit remove and process templates. Uses Template Toolkit.

=head1 SYNOPSIS

  use Taranis::Template;
  
  my $obj = Taranis::Template->new();
  
  $obj->addTemplate( title => $my_title, type => $publication_type_id, template => $my_template_text, [ description => $my_description ] );
  
  $obj->setTemplate( id => $id_nr, [ title => $my_title, type => $publication_type_id, etc.. ] );

  $obj->deleteTemplate( $id_nr );
	
  $obj->getTemplate( [ id => $id_nr ] );
  
  $obj->getTypeIds( @publication_type_names );
  
  $obj->nextObject();

  $obj->getObject();  
  
  $obj->processTemplate( $template_filename [, { template_variable => $my_var, etc... }, $header ] );
  
  $obj->processAjaxTemplate( $template, { template_variable => $my_var, etc... }, \%ajax_functions );
  
  $obj->processTemplateNoHeader( $template, $vars, $noprint );
  
  $obj->processPublicationTemplate( $publication_template_string );
  
  $obj->processPublicationTemplateText( $json_str, $tab );
  
  $obj->processPreviewTemplate( $publication, $publication_type, $publication_details_id, $publication_id );
  
  $obj->setNewlines( $text, $margin, $width );
  
  $obj->createPageBar( $page_number, $number_of_results, $maximum_results );
  
  $obj->sortAnyCase( @list );
  
=head1 METHODS

=head2 B<new>

Constructor for the Taranis::Template class:

    my $obj = Taranis::Template->new():

Creates a new database handler which can accessed by:

    $obj->{dbh};

Creates a new SQL::Abstract object which can be accessed by:

    $obj->{sql};
	
Clears error message for the new object. Can be accessed by:
   
    $obj->{errmsg};
    	  
Returns the blessed object.

=head2 B<addTemplate>

Method for adding publication templates.

Expects arguments to be supplied in 'key => value' pairs:
  
    $obj->addTemplate( 
    		      title    => "my publication template title", 
    		      type     => 3, 
    		      template => "<publication><template>my publication template text</template></publication>" 
    		     );

Returns TRUE if insertion is successful, or FALSE if unsuccessful and sets $errmsg of this object to Taranis::Database->{db_error_msg}.
  
=head2 B<setTemplate>

Method for editing publication templates.

Argument are Hash types and contain all fields that needs to be changed: {column_name => "input value", column_name => etc.}.
'id' in this case is mandatory.

Example:
 
    $obj->setTemplate( id => 4, title => "my new title" );
	
Returns TRUE if database update is successful. Returns FALSE if update is unsuccessful and sets $errmsg of this object to Taranis::Database->{db_error_msg}.	

=head2 B<deleteTemplate>

Method for deleting publication templates from database.

Argument is a scalar of type Integer which represents the id of a publication template.

Example:
  
    $obj->deleteTemplate( 3 );

Returns TRUE if database deletion is successful. Returns FALSE if delete is unsuccessful and sets $errmsg of this object to Taranis::Database->{db_error_msg}.	

=head2 B<getTemplate>

Method for retrieving publication templates from the database.

The argument can be the id, title or publication type id. With no argument specified all publication templates will be retreived.
  
For retrieving one specific template:

    $obj->getTemplate( id => 3 );

For retrieving all templates:

    $obj->getTemplate();
	
Returns a Hash with all found types. Column 'template' is returned as 'tpl'. Returns undef if there is a database error and sets $errmsg of this object to Taranis::Database->{db_error_msg}.	

=head2 B<getTypeIds> 

Method for retrieving the ID's of publication types.
  
Takes a list of publication type names as argument:

Example:

    $obj->getTypeIds( [ 'Advisory (email)', 'End-of-Week (email)' ] );

Sets $errmsg of this object to Taranis::Database->{db_error_msg} if database execution fails. Returns a list of ID's.

=head2 B<nextObject> & B<getObject>

Method to retreive the list that is generated by method loadCollection.

This way of retrieval can be used to get data from the database one-by-one. Both methods do not take arguments.

Example:

    $obj->loadCollection( $args );

    while( $obj->nextObject ) {
      myFunction( $obj->getObject );
    }

=head2 B<processTemplate>

Method for processing the template files with Template Toolkit.
  
Takes 3 arguments:

=over

=item 1

filename of the template

=item 2

the variables that are used in the template file

=item 3

the HTML file header which is optional. Standard header will be added is it not supplied

=back

Example:

    $obj->processTemplate( "my_template_file.tt", { my_var_name => "my value", etc... }, $header_string );

Note: this method also turns off browser caching by adjusting the header and sets the webroot and scriptroot into $var if it is not present. 
  
Returns the template in HTML format. If Template Toolkit produces an error message the error is put into $errmsg of this object.

=head2 B<processAjaxTemplate>

Method for processing templates that use AJAX.

Takes three arguments:

=item 1

filename of the template

=item 2

the variables that are used in the template file

=item 3

the AJAX functions match between the HTML page and perl subroutine:

=back
    
Example:

    %funcs = ( 'javascript_function' => \&perSubroutine );
  
    $obj->processAjaxTemplate( "constituent_individuals_details.tt", $vars, \%funcs );
  
Note: sets the webroot and scriptroot into $var if it is not present. 

Returns the template in HTML format.

=head2 B<processTemplateNoHeader>

Method for processing a template without creation of content headers.
  
Takes three arguments:

=item 1

the template

=item 2

the template variables

=item 3

'no print' (optional)

=back    
    
Example:

    $obj->processTemplateNoHeader( "template.tt", $vars, 'noprint');
  
Note: Use optional third argument is to make sure that only template content is returned. 

With argument 'no print' set, returns the HTML output. Without argument 'no print' returns Template->process(...);
  
=head2 B<processPublicationTemplate>

Method for processing the publication template before it is processed by processTemplate.

Argument is a scalar of type string which contains the template text:
  
    $obj->processPublicationTemplate( "<publication><template>my publication template text</template></publication>" );

Note: the template text should always start and close with the publication tag.

When processing the publication template all errors are concatenated into $errmsg of this object.

=head2 B<processPublicationTemplateText>

Method for processing the template result.
 
Where sub processPublicationTemplate creates the HTML which is declared within the <fields> tags, sub processPublicationTemplateText creates the resulting text (declared within the <template> tags) with the input from the HTML input fields.
  
Takes two arguments:

=item 1

JSON string which holds at least the following data:

=item I<template_id, to select a template from the database>

=item I<result_location, the destination of the resulting text>

=item I<original_txt, the text already present in the destination field (result_location)>

=item 2

tab name, name of the tab where the template is used on
 
=back

Example:

    $obj->processPublicationTemplateText( {"tab_summaryfld_title":"test","template_id":"24","result_location":"tab_summary_txt","original_txt":"original text from textfield"}, "tab_summary" );

Note: does sorting of headings that begin with '-=' and end with '=-'. 

Returns the complete text for the result location and also the name of the result location.

=head2 B<processPreviewTemplate>

Method for creating the publication text as it will be send out. The publication is based on a template stored in the database. 
  
Takes four arguments:

=item 1

publication type, for instance 'advisory' or 'eow'

=item 2

publication subtype, for instance 'email' or 'update'

=item 3

publication details id

=item 4

publication id

=back

Example:
  
    $obj->processPreviewTemplate( "advisory", "email", 34, 76 );
    
The preview template deviates from the publication template on the contents of the <fields> tags.

Within the <fields> tag the content of the placeholders, set in the <template> tag as '_placeholder_', is specified. 
The tag name for the placeholder is the same as the placeholder but without the surrounding _ (underscore).
The type attribute is mandatory and can be set to 'database', 'settings' or 'replace' (see below).
  
B<type="database">

For replacing the placeholder with the data from one column from a specific table. The child element is <tbl/>. With I<type="database"> at least two <tbl/> children are needed. One with I<type="key"> and one with I<type="select"> or I<type="select_date">. 

=item I<type="key"> is for specifying the column and table to use in th WHERE clause of the SQL statement. The column is specified with an attribute of the <tbl> element: I<column="my_column_name">. The table is specified as the content of the <tbl> element. Note: So far only the values of the publication id, advisory id and end-of-week id are available in this routine. 

=item I<type="select"> is for specifying the column and table you want to use as data to replace the placeholder with. Column and table specification are the same as I<type="key">.

=back

Other options 

=item I<type="select_date"> is the same as I<type="select">, only in this case a date is being retrieved from the database and is formatted as 'YYYYMMDD' (eg. 20090615).

=item I<type="join1"> & I<type="join2"> is for spcifying the tables to 'join'. Startingpoint is always the table publication, from there on every join is possible if there are matching columns. The column on which to join tables is specified by I<column="my_column_name">. The table is specified as the content of the <tbl> element.

=back

Example:

  <fld_author type="database">
    <tbl type="select" column="fullname">users </tbl>
    <tbl type="key" column="id">publication </tbl>
    <tbl type="join1" column="created_by">publication </tbl>
    <tbl type="join2" column="username">users </tbl>
  </fld_author> 


B<type="settings">

Can be used for specifying certain settings. At this moment only one setting is implemented, I<type="heading">. The child element is <setting/> 

=item I<type="heading"> is for specifying a heading title that will be placed above the placeholder. The actual title is specified as the content of the <setting> element. 

=back

Example:

  <fld_update type="database">
    <tbl type="key" column="id">publication_advisory </tbl>
    <tbl type="select" column="update">publication_advisory </tbl>
  </fld_update>
  
  <fld_update type="settings">
    <setting type="heading">Update </setting>
  </fld_update>

B<type="replace">

For specifying replacement values for the data that is retrieved from the database. The child element is <rp/>. The original value is set using the attribute I<original_value>. The replacement value is specified as the content of the <rp> element.

=item I<original_value="my_value"> 

Example:

  <fld_damage type="replace">
    <rp original_value="1">high </rp>
    <rp original_value="2">medium </rp>
    <rp original_value="3">low </rp>
  </fld_damage>  

Note: all placeholders with no values to replace will be removed from the template.

Returns the complete template text.

=head2 B<setNewlines>

Method for formatting a text with newline characters.
  
Takes three arguments:

=item 1

the text to format

=item 2

the margin on the left side of the text. This will only shorten the width of the text. 

=item 3

the width of the text (or line length).

=back

Example:

  $obj->setNewlines( $txt, 3, 71 );

Returns HTML encoded text.

=head2 B<createPageBar>

Method for generating all date to generate a page bar with template 'page_bar.tt'.

Takes three arguments:

=item 1

the page number of the current page.

=item 2

the total number of results.

=item 3

the maximum number of results per page.

=back

Example:

    $obj->createPageBar( 1, 1000, 100 );
  
The calling for processing of the page_bar.tt should be done within a template:
  
    [% PROCESS page_bar.tt %] 
  
By default the template that uses this page should also include the following for the javascript function goToPage(url, page, element_id) ):
  
    <script type="text/javascript" src="[% webroot %]/include/jslib.js"></script>
      
In the programm the variable $my_page should be retrieved from the posted data (key is 'mypage').
  
Returns a collection of values which should be set in $vars->{page_bar} (where $vars is the second argument of method processTemplate):
  
    $vars->{page_bar} = $obj->createPageBar( 1, 1000, 100 );

=head2 B<sortAnyCase>

For case insensitive sorting.

Takes an array as argument.

  $obj->sortAnyCase( ['banana', 'peach', 'Apple'] ); 

Returns an sorted array.

=head1 AUTHOR

Sebastiaan van Achterbergh 

June 15, 2009

=cut

