package Taranis;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

use 5.008008;
use strict;
use warnings;
use POSIX;
use Taranis::Config;
use HTML::Entities;    # qw(:DEFAULT encode_entities_numeric);
use Encode; 
use Encode::Detect;
use Exporter;
use MIME::QuotedPrint;
use MIME::Base64;

use Encode::DoubleEncodedUTF8;

our @ISA = qw(Exporter);

# This allows declaration use Taranis ':all' or
# use Taranis ':util' ;

our %EXPORT_TAGS = (
  'all' => [
    qw(
      nowstring sanitizeParameter readFile trim filter keyword_ok logdit decodeInput logErrorToSyslog
      encodeInput sanitizeInput ip_is_ipv4 formatDateTimeString say decodeMimeEntity validateDateString fileToString)
  ],
  'util' => [
    qw(
      nowstring sanitizeParameter trim logdit decodeInput formatDateTimeString encodeInput say logErrorToSyslog)

  ]
);
our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} }, @{ $EXPORT_TAGS{'util'} } );

our @EXPORT = qw(@EXPORT_OK);

our $VERSION = '0.01';
my $cfg = Taranis::Config->new();

sub formatDateTimeString {
  my $str = $_[0];

  if ( $str =~ /-/ ) {
    my ( $day, $month, $year ) = split( "-", $str );
    $str = $year . $month . $day;
  }

  return $str;
}

sub nowstring {

  my $type = $_[0];
  my $time = time();

  #		type 3 en 13 is yesterday!
  if ( $type == 3  || $type == 13 ) { $time -= 86400 }

  my $timeformat = {
                     0  => '%Y%m%d',
                     1  => '%T',
                     2  => '%Y%m%d%H%M%S',
                     3  => '%Y%m%d',
                     4  => '%s',
                     5  => '%d-%m-%Y',
                     6  => '%Y',
                     7  => '%d-%m-%Y %T',
                     8  => '%H%M%S',
                     9  => '%Y%m%d',
                     10 => '%Y%m%d %H%M%S',
                     11 => '%Y-%m-%d',
                     12 => '%H',
                     13 => '%d-%m-%Y'
  };

  return strftime( "$timeformat->{$type}", localtime($time) );

}

sub validateDateString {
	# allow dates: dd-mm-yyyy and d-m-yyyy
	return ( $_[0] =~ /^(0?[1-9]|[12][0-9]|3[01])-(0?[1-9]|1[012])-(19|20)[0-9]{2}$/ ) ? 1 : 0;
}

sub trim {
  my $string = $_[0];
  return if ( !$string );
  $string =~ s/^\s+//;
  $string =~ s/\s+$//;
  return $string;
}

# this subroutine will become obsolete, use sanitizeInput with option 'blacklist_old_style'
sub sanitizeParameter {
  my $parameter = $_[0];

  $parameter =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
  $parameter =~ s/'//gi;
  $parameter =~ s/"//gi;
  $parameter =~ s/--//gi;

  return $parameter;
}

sub sanitizeInput {
  my ( $type, @input ) = @_;

  for ( my $i = 0 ; $i < @input ; $i++ ) {
  	next if ( !$input[$i] );
    for ($type) {
      if (/xml_primary_key/) {
        $input[$i] =~ s/[^\.\s\w\-:]//gi;
        $input[$i] =~ s/(\s)\s+/$1/gi;
      } elsif (/filename/) {
        $input[$i] =~ s/[^\.\w-]//g;
      } elsif (/no_gt_lt/) {
        $input[$i] =~ s/<|>//g;
      } elsif (/only_numbers/) {
        $input[$i] =~ s/[^\d]//g;
      } elsif (/newline_to_br/) {
        $input[$i] =~ s/\n/\<br\/\>/gi;
      } elsif (/parse_post_data/) {
        $input[$i] =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
#        $input[$i] =~ s/_PLUS_/\+/gi;
        $input[$i] =~ s/_EQ_/=/gi;
        $input[$i] =~ s/_DASH_/#/gi;
        $input[$i] =~ s/'//gi;
        $input[$i] =~ s/"//gi;
        $input[$i] =~ s/--//gi;
        $input[$i] =~ s/;//gi;
      } elsif (/blacklist_old_style/) {
        $input[$i] =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
        $input[$i] =~ s/'//gi;
        $input[$i] =~ s/"//gi;
        $input[$i] =~ s/--//gi;
        $input[$i] =~ s/;//gi;
      } elsif (/c_style/) {
        $input[$i] =~ tr/+/ /;
        $input[$i] =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
      } elsif (/db_naming/) {
        $input[$i] =~ s/[^\w\d]//gi;
      } else {
        $input[$i] =~ s/[^\w]//gi;
      }
    }
  }
  return wantarray ? @input : "@input";
}

# usage of encodeInput
# 	%my_hash 										= encodeInput( \%my_hash 									);
#		%$my_hash_in_scalar_context = encodeInput( $my_hash_in_scalar_context );
#		@my_array										= encodeInput( \@my_array 								);
#		$my_scalar									= encodeInput( \$my_scalar 								);
#		$my_array_of_hashes					= encodeInput( $my_array_of_hashes 				);

sub encodeInput {
  my $input = shift;

  my $type = ref( $input );

  for ( $type ) {
    if ( /HASH/ ) {
      foreach my $key ( keys %$input ) {
        my $utf8 = eval { decode( "Detect", $input->{$key} ) };

        if ( $@ ) {
          $input->{$key} = HTML::Entities::encode( $input->{$key} ); 
        } else {
          if ( $utf8 ne $input->{$key} ) {
            $input->{$key} = HTML::Entities::encode( decode( "utf-8-de", $input->{$key} ) );
          } else {
            $input->{$key} = HTML::Entities::encode( $input->{$key} );
          }
        }
      }
      return %$input;
      
    } elsif (/ARRAY/) {
      if ( ref( $input->[0] ) eq "HASH" ) {
        for ( my $i = 0 ; $i < @$input ; $i++ ) {
          %{ $input->[$i] } = encodeInput( \$input->[$i] );
        }
        return $input;
      } else {
        my @return_array;
        foreach my $i ( @$input ) {
          my $utf8 = eval { decode( "Detect", $i ) };

          if ( $@ ) {
            push @return_array, HTML::Entities::encode( $i ); 
          } else {
            if ( $utf8 ne $i ) {
            	push @return_array, HTML::Entities::encode( decode( "utf-8-de", $i ) ); 
            } else {
              push @return_array, HTML::Entities::encode( $i );
            }
          }
        }
        return @return_array;
      }
      
    } elsif ( /SCALAR/ ) {
      my $input = $$input;
      my $utf8 = eval { decode( "Detect", $input ) };

      if ( $@ ) {
				if ( $@ =~ /gb18030/i ) { # Encode::Detect sometimes gives error "Unknown encoding: gb18030" while it's not this chinese encoding that's used but UTF-8
					return  HTML::Entities::encode( decode( "utf-8-de", $input ) );
				} else {
      		return HTML::Entities::encode( $input );
				}
      } else {
        if ( $utf8 ne $input ) {
        	return  HTML::Entities::encode( decode( "utf-8-de", $input ) ); # OK via web
        } else {
          return HTML::Entities::encode( $input );
        }
      }
    } else {
      return 0;
    }
  }
}

# usage of decodeInput
# 	%my_hash 										= decodeInput( \%my_hash 									);
#		%$my_hash_in_scalar_context = decodeInput( $my_hash_in_scalar_context );
#		@my_array										= decodeInput( \@my_array 								);
#		$my_scalar									= decodeInput( \$my_scalar 								);
#		$my_array_of_hashes					= decodeInput( $my_array_of_hashes 				);
sub decodeInput {
  my $input = shift;

  my $type = ref($input);

  for ($type) {
    if (/HASH/) {
      foreach my $key ( keys %$input ) {
        $input->{$key} =  encode_utf8(decode_entities( $input->{$key} ));
      }
      return %$input;
    } elsif (/ARRAY/) {
      if ( ref( $input->[0] ) eq "HASH" ) {
        for ( my $i = 0 ; $i < @$input ; $i++ ) {
          %{ $input->[$i] } = decodeInput( $input->[$i] );
        }
        return $input;
      } else {
        my @return_array;
        foreach my $i (@$input) {
          push @return_array,  encode_utf8(decode_entities($i));
        }
        return @return_array;
      }
    } elsif (/SCALAR/) {
      return encode_utf8(decode_entities($$input)) if $$input;
    } else {
      return 0;
    }
  }
}

sub decodeMimeEntity {
	my ( $entity, $noHtmlPart, $noAttachment ) = @_;
	
	my $bodyContent = "";

	if ( $entity->parts() ) {
		foreach my $part ( $entity->parts() ) {
			$bodyContent .= decodeMimeEntity( $part, $noHtmlPart, $noAttachment );
		}
	} else {
		
		my $suggestedEncoding = $entity->suggest_encoding(); 
		my $head = $entity->head();
		
		my $contentType = $head->mime_type();
		my $charset = $head->mime_attr("content-type.charset"); 
		my $contentTransferEncoding = $head->mime_encoding();
		
		$charset = "" if ( !$charset );
		$contentTransferEncoding = "" if ( !$contentTransferEncoding );
		
		return " " if ( $noHtmlPart && $contentType =~ /text\/html/i );
		return " " if ( $noAttachment && $contentType !~ /^text.*/i );
		
		$bodyContent = $entity->stringify_body();
		
		# decode message with base64
		if ( $contentTransferEncoding =~ /base64/i ) {
			$bodyContent = decode_base64( $bodyContent );
		}
		
		# decode Quoted-printable encoding
		if ( $suggestedEncoding =~ /quoted-printable/i || $contentTransferEncoding =~ /quoted-printable/i ) { 
			$bodyContent = decode_qp( $bodyContent );
		}

		$bodyContent = decode_utf8( encode( 'UTF-8', $bodyContent ) );
		
		# decode UTF-8 if message/part has character set UTF-8 
		if ( $charset =~ /utf.?8/i ) {
			$bodyContent = decode_utf8( $bodyContent );
			
		} elsif ( $charset && $charset !~ /ascii/i && !$bodyContent ) {
			eval{ $bodyContent = decode( $charset, $bodyContent ) };
			if ( $@ ) {
				print "decodeMimeEntity error: " . $@ . "\n";
			}
		}
	}
	
	return $bodyContent;
}

sub readFile {
  my $filename = $_[0];
  my $line     = "";
  my $output   = "";
  my $include  = "";
  my $idx1     = 0;
  my $idx2     = 1;
  my $incfile  = "";
  my $ttroot   = $cfg->{'ttroot'};

  if ( -e $filename ) {
  	my $fh;
    open( $fh, "<", $filename );
    while ( $line = <$fh> ) {
      if ( substr( trim($line), 0, 1 ) ne "#" ) {
        $output .= $line;
      }
    }
  }

  my @includes = split( /_include(.*?)_/, $output );
  foreach $include (@includes) {
    $include = trim($include);
    $idx1    = index( $include, "(" );
    $idx2    = index( $include, ")" );

    if ( ( $idx1 == 0 ) && ( $idx2 > -1 ) && ( $idx2 > $idx1 ) ) {
      $incfile = substr( $include, 1, $idx2 - $idx1 - 1 );
      if ( index( $incfile, ".tpl" ) > -1 ) {
        $incfile = $ttroot . $incfile;
      }
      $include = readFile($incfile);
      $output =~ s/_include\($incfile\)_/$include/gi;
    }
  }

  return $output;
}

sub fileToString {
	my $filename = $_[0];
	my $line     = "";
	my $output   = "";

	if ( -e $filename ) {
		my $fh;
		open( $fh, "<", $filename );
		while ( $line = <$fh> ) {
			$output .= $line;
		}
	}

	return $output;
}

sub filter {
  my $i         = 0;
  my $to_filter = $_[0];
  my $return    = "";
  my $char      = "";
  
  if ( $to_filter ) {
	  #Encode::from_to($to_filter, "iso-8859-1", "utf-8");
	  $to_filter =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	
	  for ( $i = 0 ; $i < length($to_filter) ; $i++ ) {
	    $char = substr( $to_filter, $i, 1 );
	    if ( ord($char) == 155 ) {
	      $return = $return . "'";
	    } else {
	      $return = $return . $char;
	    }
	  }
  }
  
  return $return;
}

sub keyword_ok {
  my $keyword = $_[0];
  my $blacklist;

  if ( index( $keyword, ")" ) > -1 )  { $keyword =~ s/\)/ /gi; }
  if ( index( $keyword, "(" ) > -1 )  { $keyword =~ s/\(/ /gi; }
  if ( index( $keyword, ":" ) > -1 )  { $keyword =~ s/\:/ /gi; }
  if ( index( $keyword, "\"" ) > -1 ) { $keyword =~ s/\"/ /gi; }
  if ( index( $keyword, "'" ) > -1 )  { $keyword =~ s/\'/ /gi; }
  if ( index( $keyword, "/" ) > -1 )  { $keyword =~ s/\// /gi; }

  $keyword = trim( uc($keyword) );

  $blacklist = "
    *THE**A**AND**DENIAL**SERVICE**OF**CORRUPTION**MEMORY**LEADS**TO*
    *CODE**EXECUTION**ANTIVIRUS**MULTIPLE**REMOTE**PRIVILEGE**ESCALATION*
    *VULNERABILITY**VULNERABILITIES**INFORMATION**DISCLOSURE**XSS*
    *CROSS**SITE**SCRIPTING**PRINT**SERVER**BUFFER**OVERFLOW**HEAP*
    *STACK**BASED**PARSE**EXCEPTION**HTML**XML**COMMAND**EXECUTION*
    *CORRUPTION**ACTIVEX**CREDENTIAL**DISCLOSURE**UNAUTHORIZED**ACCESS*
    *MALFORMED**ANTI-VIRUS**FORMAT**STRING**LINUX**ELEVATED**SQL**CLIENT*
    *RELEASED**ON**WITH**MICROSOFT**WINDOWS**FEDORA**REDHAT**RED**HAT*
    *UBUNTU**FREEBSD**OPENBSD**NETBSD**1**2**3**4**5**6**7**8**9**0*
    *SECURITY**FOR**INFORMATION**EXPLOIT**OPEN**HOLE**IN**-**INTEGER*
    *CROSS-SITE**ISSUE**BACKUP**LETS**FILE**FILES**:**,**;**.**/**DOS*
    *MAC**HANDLING**ENGINE**ANTI**ANTIVIRUS**VIRUS**SUN**CISCO**UBUNTU*
    *DEBIAN**UPDATE**EXPLORER**INTERNET**CORRUPT**CORRUPTION**MAY**LET*
    *USER**USERS**LOG**PROCESSING**APPLE**REQUEST**REQUESTS**SYSTEM*
    *LOCAL**TWO**ONE**THREE**FOUR**FIVE**SIX**SEVEN**EIGHT**NINE**TEN*
    *WEB**VULN**NEW**FROM**SUPPORT**PASSWORD**ORACLE**NOW**AVAILABLE*
    *COMMON**SERVICE**SERVICES**PAGE**PAGES**DIGITAL**PUT**OFF**WIRE*
    *ISSUES**IN**LIGHT**LIGHTS**WIRE**HOME**ADD**ADDS**MUSIC**DOWNLOAD*
    *REVERSE**BYPASS**SOCIAL**NETWORKING**PHYSICAL**NOTICE**RECEIVE*
    *RECEIVES**READIES**CRITICAL**PLAYER**MORE**MEDIA**MODULE*
    *BUFFER-OVERFLOW**EXTENDED**PICTURE**YEAR**GOOD**EVIL**BOTH**VS*
    *VS.**PACK**SHIP**SHIPPING**XP**2000**VISTA**HAND**HANDS**US*
    *U.S.**CONDEMN*CONDEMNS**CELEBRITY**CULTURE**FIRM**BUY**BUYS*
    *DOC**MGT**ALL-IN-ONE**PLAN**REPORT**REPORTS**MOVIE**ONLINE*
    *FREE**UNSPECIFIED**INJECTION**BLIND**PACKAGE**PACKAGES**NEW*
    *FIX**TOP**CYBER**CRIME**CYBERCRIME**UPDATED**CVE**UPLOAD**EXEC*
    *BACKUP**EXECUTE**ARBITRARY**BUG**FRSIRT**IDEFENSE**ADVISORY**NOTE*
    *CERT-IN*
    *ZIJN**IS**DE**EEN**HET**VIRUSSCANNER**GEBRUIKERS**UIT**BREKEN*
    *AAN**RODE**ROOD**KAART**VAN**DEEL**KLAAR**EERSTE**RUSSISCH*
    *NEDERLANDS**BIJ**WELKOM**KEER**GROEIEN**GROEIT**STELLEN**DIVISIE*
    *KNAAGT**BEWONERS**ONRUST**MINISTER**VRAGEN**VRAAGT**OPLOSSING*
    *VERKOOP**VERWACHT**NEMEN**STERKER**KRIJGT**KRIJGEN**GESTOLEN*
    *NAAR**ACHTER**DODE**DODEN**DOOR**BOVEN**BUITEN**CIRCA**CONFORM*
    *DANKZIJ**DOOR**MET**MIDDEN**NABIJ**NAMENS**ONDANKS**OVER**ONDER*
    *PER**PLUS**ROND**SINDS**TEGEN**TEGENOVER**TIJDENS**TOT**TUSSEN*
    *UIT**VAN**VANAF**VANUIT**VANWEGE**VIA**VOOR**VOORBIJ**WEGENS*
    *ZONDER**WORDEN**WORDT**KUNNEN**DICHTERBIJ**HUN**NIET**MEER*
  ";

  if (    ( index( $blacklist, "*" . $keyword . "*" ) > -1 )
       || ( length($keyword) < 3 ) )
  {
    return '';
  } else {
    return $keyword;
  }
}

sub ip_is_ipv4 {
  my $value = shift;  
  return unless defined($value);       
  my(@octets) = $value =~ /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
	return unless (@octets == 4);
	foreach (@octets) {
		return unless ($_ >= 0 && $_ <= 255 && $_ !~ /^0\d{1,2}$/);
	}
  return 1;
}

sub say {
  print "@_" . "\n";
  return;
}

# logdit will log to syslog DEBUG level
sub logdit {
  my $regel = shift;
  my ( $package, $file, $line ) = caller();
  my $fh;
  open( $fh, ">>", "/tmp/Taranis_debug.log" );
  print $fh "\n[" . nowstring(7) . "] $file, $line :\n" . $regel . "\n";
  close $fh;

	Taranis::Database::logError( { log_error_enabled => 1 } ,"$file, $line : " . $regel, 'debug' );
}

sub logErrorToSyslog {
	my $error = shift;
	my ( $package, $file, $line ) = caller();
	if ( !$error ) {
		$error = '';
	}
	Taranis::Database::logError( { log_error_enabled => 1 } ,"$file, $line : " . $error, 'error' );
}

1;

=head1 NAME

  Taranis - Simple Taranis tools class

=head1 SYNOPSIS

  use Taranis qw(:all);
  
=head1 DESCRIPTION

  All kind of tools and leftovers not belonging anywhere.

=head2 EXPORT

  :all  :util

=head1 METHODS

=head2 B<trim()>

  chops of all whitespace from beginning and end of a string.
  trim($string);

=head2 sanitizeParameter()

  sanatize a single string

=head2 sanatizeArray()

  sanatizes a whole array or a hash.
  convenient when you want to sanatize @_ or all POSTed data.
 
  my @arr = qw(red apple yellow banana green kiwi);
  my %hash = sanatizeArray(@arr);


       $hash = {
           'green' => 'kiwi',
           'red' => 'apple',
           'yellow' => 'banana'
           };
         


=head2 B<encodeInput()>  
  B<ONLY USE FROM WITHIN MOD_PERL/Apache environment>

  encode UTF-8 strings to HTML Entities
  my %hash = encodeInput(\%hash);
  my @array = encodeInput(\@array);
  my $scalar = encodeInput(\$scalar);

  Param must be a reference to your hash,array, scalar
  Doesn't work with Arrays of Hashes,
  
=head2 B<encodeInputTrue()>  
  B<ONLY USE OUTSIDE MOD_PERL/Apache environment>

  encode UTF-8 strings to HTML Entities
  my %hash = encodeInputTrue(\%hash);
  my @array = encodeInputTrue(\@array);
  my $scalar = encodeInputv(\$scalar);

  Param must be a reference to your hash,array, scalar
  Doesn't work with Arrays of Hashes,

=head2 B<nowstring()>
  
  returns a formatted time string:
  
        command                 result (POSIX strftime)
  --------------------------------------------------------
  nowstring(0)  :             20090610 (%Y%m%d)
  nowstring(1)  :             12:20:53 (%T)
  nowstring(2)  :       20090610122053 (%Y%m%d%H%M%S)
  nowstring(3)  :             20090609 (%Y%m%d)
  nowstring(4)  :           1244629253 (%s)
  nowstring(5)  :           10-06-2009 (%d-%m-%Y)
  nowstring(6)  :                 2009 (%Y)
  nowstring(7)  :  10-06-2009 12:20:53 (%d-%m-%Y %T)
  nowstring(8)  :               122053 (%H%M%S)
  nowstring(9)  :             20090610 (%Y%m%d)
  nowstring(10) :      20090610 122053 (%Y%m%d %H%M%S)
  nowstring(11) :           2009-06-10 (%Y-%m-%d)
  nowstring(12) :                   12 (%H)

=head2 B<ip_is_ipv4()>

  returns true if a given address conforms to IPv4 addressing schema.

=head2 B<say()>

  Just like print() but with a newline.
  This should be removed when perl (>= v5.10) is used.

=head2 B<logdit>

  Only used for debugging/devloping
  print to the Debug logfile /tmp/Taranis/debug.log.


=head1 SEE ALSO

  POSIX(3)

=cut

__END__
