package My::Fixup;
###
# Copyright 2013 NCSC-NL
# 
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
# 
# http://ec.europa.eu/idabc/eupl
# 
# Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and limitations under the Licence.
# 
# $Rev $
# $Date $
###

# This module is needed to enable the mod_dir directive DirectoryIndex. 
# Please see http://www.perlmonks.org/bare/?node_id=631334

use strict;
use warnings FATAL => qw(all);

use Apache2::Const -compile => qw(DIR_MAGIC_TYPE OK DECLINED);
use Apache2::RequestRec;
use Apache2::RequestUtil;

sub handler {
  my $r = shift;

  if ($r->handler eq 'perl-script' && -d $r->filename 
      && $r->is_initial_req)
  {
    $r->handler(Apache2::Const::DIR_MAGIC_TYPE);
    return Apache2::Const::OK;
  }
  return Apache2::Const::DECLINED;
}
1;
